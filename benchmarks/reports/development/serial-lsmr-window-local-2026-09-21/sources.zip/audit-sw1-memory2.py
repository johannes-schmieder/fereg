import csv
import json
from pathlib import Path
import sys

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import audit_milestone
import audit_outputs
import graph_oracle
from score import sha

import importlib.util
spec = importlib.util.spec_from_file_location('memory_outputs', artifacts / 'sw1-memory-output-auditor1.py')
audit_outputs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit_outputs)
root = repo / 'target/g21sm1'
records = []
oracle = None
for path in sorted((root / 'runs').glob('*/result.json')):
    result = json.loads(path.read_text())
    request = json.loads((path.parent / 'request.json').read_text())
    assert result['status'] == 'pass'
    if oracle is None:
        oracle = graph_oracle.solve(Path(request['data']), result['cell']['weight_kind'], result['cell']['vce'])
    check = graph_oracle.compare(path, oracle)
    assert check['status'] == 'pass'
    with (path.parent / 'fereg_runtime.csv').open() as stream:
        runtime = {(int(row['row']), int(row['column'])): float(row['value']) for row in csv.DictReader(stream)}
    assert runtime[13, 2] <= runtime[8, 2]
    records.append(dict(run=path.parent.name, result_sha256=sha(path), request_sha256=sha(path.parent/'request.json'),
        inference=check, available_bytes=runtime[6, 2], usable_bytes=runtime[8, 2],
        observed_allocation_peak_bytes=runtime[13, 2], input_sha256=result['input_sha256'], sample_sha256=result['sample_sha256']))
assert len(records) == 2
assert len({r['input_sha256'] for r in records}) == len({r['sample_sha256'] for r in records}) == 1
audit_outputs.audit(root, 'cap', 'sw1')
output = artifacts / 'sw1-memory-audit1.json'
assert not output.exists()
output.write_text(json.dumps(dict(schema='ols-serial-lsmr-window-memory-audit-v1', records=records,
    controller_sha256=sha(Path(__file__)), output_auditor_sha256=sha(Path(audit_outputs.__file__)), limitation='Captured generic experiment only; no production/shared routing acceptance.'), indent=2) + '\n')
print('SW1_INDEPENDENT_AUDIT_PASS', flush=True)

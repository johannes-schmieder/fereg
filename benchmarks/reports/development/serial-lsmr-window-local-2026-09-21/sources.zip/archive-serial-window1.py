import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import zipfile

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science
output = repo / 'benchmarks/reports/development/serial-lsmr-window-local-2026-09-21'
roots = [repo / 'target/g21sw1', repo / 'target/g21sm1']
assert (roots[0] / 'screen-complete.json').is_file()
assert (roots[1] / 'diagnostic-complete.json').is_file()
archive_science.archive(roots, output, compact=True, omit_output_arrays=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def portable(data):
    return data.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>') \
        .replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')
tables = {'sources': {}, 'checks': {}}
with zipfile.ZipFile(output / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw)
        bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['wr2', 'sw1']:
        path = artifacts / f'identity-{variant}.json'
        identity = json.loads(path.read_text())
        add(path.name, path.read_bytes())
        data = subprocess.check_output(['/opt/homebrew/bin/git', 'archive', identity['base_commit'],
            'Cargo.toml', 'Cargo.lock', 'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            base = {entry.name: sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
        changed = []
        for relative, digest in identity['source'].items():
            raw = (artifacts / variant / relative).read_bytes()
            assert sha(raw) == digest
            if base.get(relative) != digest:
                changed.append(relative)
                add(variant + '/' + relative, raw)
        add(variant + '/captured-differences.json', (json.dumps(changed, indent=2) + '\n').encode())
    for root in roots:
        add(root.name + '/execution-source.py', (root / 'execution-source.py').read_bytes())
    for name in ['audit_milestone.py', 'audit_outputs.py', 'graph_oracle.py', 'run.py', 'route_development.py']:
        add(name, (repo / 'benchmarks/two_fe_dense' / name).read_bytes())
    add('score-before-broad-isolation.py', subprocess.check_output(['/opt/homebrew/bin/git', 'show', '18447afe:benchmarks/two_fe_dense/score.py'], cwd=repo))
    add('score-with-broad-isolation.py', (repo / 'benchmarks/two_fe_dense/score.py').read_bytes())
    for name in ['score-kernel-screen2.py', 'audit-sw1.py', 'audit-sw1-memory2.py', 'sw1-memory-output-auditor1.py', 'archive-serial-window1.py']:
        add(name, (artifacts / name).read_bytes())
    for name in ['build.py', 'serial_lsmr_window.py']:
        add(name, (repo / 'benchmarks/one_fe_optimization' / name).read_bytes())
with zipfile.ZipFile(output / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add_check(name, raw, **extra):
        clean = portable(raw)
        bundle.writestr(name, clean)
        tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean), **extra)
    for name in ['sw1-batch-tests1.txt', 'sw1-memory-tests1.txt', 'sw1-screen-inference1.json', 'sw1-screen-score1.json',
                 'sw1-screen-score1.txt', 'sw1-memory-audit1.json', 'sw1-audit1.txt', 'sw1-memory-audit2.txt']:
        add_check(name, (artifacts / name).read_bytes())
    for path in sorted((roots[1] / 'runs').glob('*/stderr.txt')):
        raw = path.read_bytes()
        trace = ('\n'.join(line for line in raw.decode().splitlines() if line.startswith(('FEREG_PHASE|', 'FEREG_SOLVER_TRACE|'))) + '\n').encode()
        add_check(path.parent.name + '/native-trace.txt', trace, original_stream_sha256=sha(raw),
                  extraction='Only native phase/solver trace lines, in original order.')
for name, table in tables.items():
    (output / (name + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')
print('SERIAL_WINDOW_SUPPLEMENTS_COMPLETE', flush=True)

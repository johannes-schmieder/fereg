import subprocess
from pathlib import Path
r=Path(__file__).parent;py='target/one-fe-profile-20260919/python/bin/python'
cmd=[py,'benchmarks/next_subsystem/run.py',str(r/'native-profile'),'--ppml-surface','--artifacts','target/ppml-next-20260922/artifacts','--variants','slope_cert_profile2','ppmlgeom_profile','--fixest-archive','target/one-fe-profile-20260919/fixest.tar.gz','--cells',str(r/'pairs-cells.json'),'--seed','202609304','--repeats','1']
with (r/'profile-driver.log').open('x') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)

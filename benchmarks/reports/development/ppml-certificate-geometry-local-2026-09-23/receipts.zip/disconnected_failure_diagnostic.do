version 18.0
clear all
set more off
use "$REPO/target/ppml-certificate-geometry-20260923/fresh/data/c3-full.dta", clear
capture noisily feppml y x1 x2 x3 x4 x5 x6, absorb(g1##c.(z1) g2##c.(z2) g3) threads(4) solver(auto) poolsize(10) vce(robust) memory(fast) mu(saved_mu)
local actual_rc = _rc
display as result "DISCONNECTED_FAILURE_RC|rc=`actual_rc'"
assert `actual_rc' == 459
capture confirm variable saved_mu
assert _rc != 0
assert "`e(cmd)'" == ""
display as result "END_FIXTURE|disconnected_failure_diagnostic|rc=0"

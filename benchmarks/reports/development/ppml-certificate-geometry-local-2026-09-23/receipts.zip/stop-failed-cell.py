import json,os,signal,time
from pathlib import Path
import psutil
r=Path(__file__).parent;target=str(r/'fresh')
controllers=[];drivers=[]
for p in psutil.process_iter(['pid','cmdline']):
 args=p.info['cmdline'] or []
 if 'benchmarks/next_subsystem/run.py' in args and target in args:controllers.append(p)
 if any(x.endswith('/ppml-certificate-geometry-20260923/run-screen.py') for x in args) and 'fresh' in args:drivers.append(p)
assert len(controllers)==1 and len(drivers)==1,(controllers,drivers)
progress=json.loads((r/'fresh/progress.json').read_text())
first=[x for x in progress if x['case']==3 and x['repetition']==0]
assert len(first)==3 and sum(x['status']!='pass' for x in first)>=2
controller=controllers[0];children=controller.children(recursive=True)
record=dict(reason='Stop further repetitions after both native variants fail the first disconnected comparison; preserve completed science/timing and do not rank failed calls.',completed_attempts=len(progress),interrupted_directories=[p.name for p in (r/'fresh/runs').iterdir() if p.is_dir() and not (p/'result.json').exists()],processes=[dict(pid=p.pid,command=p.cmdline()) for p in [*drivers,controller,*children]])
(r/'adaptive-stop.json').write_text(json.dumps(record,indent=2)+'\n')
# Stop only the identified controller tree; no new arm may start during cleanup.
for p in [*drivers,controller]:p.suspend()
for p in children:
 try:p.terminate()
 except psutil.NoSuchProcess:pass
_,alive=psutil.wait_procs(children,timeout=5)
for p in alive:
 try:p.kill()
 except psutil.NoSuchProcess:pass
for p in [controller,*drivers]:
 try:p.kill()
 except psutil.NoSuchProcess:pass
print('Stopped failed-case repetitions; retained',len(progress),'completed attempts;',record['interrupted_directories'])

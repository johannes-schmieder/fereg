import sys,json,hashlib,re
from pathlib import Path
sys.path.insert(0,'scripts');from run_stata_tests import run_fixture,expected_sentinel
r=Path(__file__).parent;repo=Path('.').resolve();plugin=repo/'target/ppml-next-20260922/artifacts/ppmlgeom1/dist/fereg_macos.plugin';data=r/'fresh/data/c3-full.dta';fixture=r/'disconnected_failure_diagnostic.do'
fixture.write_text(f'''version 18.0
clear all
set more off
use "{data.resolve()}", clear
capture noisily feppml y x1 x2 x3 x4 x5 x6, absorb(g1##c.(z1) g2##c.(z2) g3) threads(4) solver(auto) poolsize(10) vce(robust) memory(fast) mu(saved_mu)
local actual_rc = _rc
display as result "DISCONNECTED_FAILURE_RC|rc=`actual_rc'"
assert `actual_rc' == 459
capture confirm variable saved_mu
assert _rc != 0
assert "`e(cmd)'" == ""
display as result "END_FIXTURE|disconnected_failure_diagnostic|rc=0"
''')
h=hashlib.sha256(plugin.read_bytes()).hexdigest()
result=run_fixture('/Applications/Stata/StataMP.app/Contents/MacOS/stata-mp',fixture.resolve(),repo,plugin=plugin,plugin_sha256=h,log_dir=r/'diagnostic-licensed-logs',require_status=True)
record=dict(purpose='Locate the already-observed error and check absence of partial public state; not a passing estimation or a timing repeat.',plugin=h,input_sha256=hashlib.sha256(data.read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),process_returncode=result.process_returncode,stata_rc=result.stata_rc,error=result.error,failure_kind=result.failure_kind,terminal_sentinel=expected_sentinel(fixture) in result.log_text)
(r/'failure-diagnostic.json').write_text(json.dumps(record,indent=2)+'\n')
lines=[line for line in result.log_text.splitlines() if re.search(r'(reusable MAP|nonconver|exhaust|certif|fereg:|feppml:|DISCONNECTED_FAILURE_RC|^END_FIXTURE)',line)]
(r/'failure-diagnostic.protocol').write_text('\n'.join(lines)+'\n')
print(record);print('\n'.join(lines))
if result.error:raise RuntimeError(result.error)

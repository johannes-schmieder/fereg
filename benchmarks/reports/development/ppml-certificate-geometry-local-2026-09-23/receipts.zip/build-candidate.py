import subprocess,os
from pathlib import Path
r=Path(__file__).parent
paths=['crates/fereg-core/src/'+s for s in ['fe/borrowed_map.rs','fe/map.rs','ols/linear_session.rs','ppml/memory.rs','ppml/prepared_irls.rs']]
with (r/'candidate-build-driver.log').open('x') as f:
 subprocess.run(['/opt/homebrew/bin/python3','benchmarks/one_fe_optimization/build.py','target/ppml-next-20260922/artifacts','ppmlgeom1','--revision','5cb0434a','--overlay',*paths],stdout=f,stderr=subprocess.STDOUT,check=True)

import json,csv,statistics,hashlib,sys,re
from pathlib import Path
r=Path(__file__).parent;sys.path.insert(0,'benchmarks/next_subsystem')
from audit import compare,exact_exports
base,candidate='ppmlproj1','ppmlgeom1';timings=[];solver=[];means=[];repeats=[];applications=[]
for block in ['pilot','pairs','fresh','controls','ols-controls']:
 root=r/block;plan=json.loads((root/'plan.json').read_text());progress=json.loads((root/'progress.json').read_text());summary=json.loads((r/f'{block}-summary.json').read_text())
 if block!='ols-controls':
  audit=json.loads((r/f'{block}-audit.json').read_text())
  for i,c in enumerate(audit['records']):
   for key,state in c['public_states'].items():
    if state.get('status')=='worker_failure':continue
    assert state['passed'],(block,i,key,state)
   for pair in c['pairs']:
    if not (block=='fresh' and i==3):assert pair['checks']['passed'],(block,i,pair)
 for a in progress:
  assert not a['overlaps'] and not a['monitor_errors'],a
  applications.append(dict(block=block,**a))
 for i,c in enumerate(summary['cells']):
  for j,pair in enumerate(c['pairs']):
   if not pair['clean']:continue
   assert pair['checks']['passed'] and pair['exact']['passed'],(block,i,pair)
   paths=[root/f'runs/c{i}-r{j}-{v}' for v in [base,candidate]]
   name='feppml_solver.csv' if c['cell']['model']=='ppml' else 'fereg_solver.csv';clocks={14,15,16} if c['cell']['model']=='ppml' else {9,10}
   fields=[]
   for path in paths:
    with (path/name).open() as f:fields.append([(x['row'],x['column'],x['value'].strip()) for x in csv.DictReader(f) if int(x['column']) not in clocks])
   assert fields[0]==fields[1],(block,i,j,'solver')
   solver.append(dict(block=block,case=i,repetition=j,exact=True,fields=len(fields[0])))
   if c['cell']['model']=='ppml':
    equal=(paths[0]/'means.bin').read_bytes()==(paths[1]/'means.bin').read_bytes();assert equal
    means.append(dict(block=block,case=i,repetition=j,exact=True))
  for v in plan['variants']:
   first=root/f'runs/c{i}-r0-{v}'
   first_result=json.loads((first/'result.json').read_text())
   for j in range(1,plan['repeats']):
    other=root/f'runs/c{i}-r{j}-{v}'
    if not (other/'result.json').exists():continue
    result=json.loads((other/'result.json').read_text())
    if first_result['status']!='pass' or result['status']!='pass':continue
    check=compare(first,other,c['cell']['model']);exact=exact_exports(first,other);mean_equal=(first/'means.bin').read_bytes()==(other/'means.bin').read_bytes() if (first/'means.bin').exists() else None
    assert check['passed'] and exact['passed'] and mean_equal is not False
    repeats.append(dict(block=block,case=i,variant=v,repetition=j,checks=check,exact=exact,exact_means=mean_equal))
  raw={v:[dict(ms=a['seconds']*1000,status=a['status']) for a in progress if a['case']==i and a['variant']==v] for v in plan['variants']}
  heap=[p['tracked_peak_bytes'][candidate]-p['tracked_peak_bytes'][base] for p in c['pairs'] if p['clean']]
  row=dict(block=block,case=i,cell=c['cell'],milliseconds=raw,paired_ratio=c['ratios'],heap_delta=heap)
  timings.append(row);print(block,i,raw,c['ratios'],'heap',heap,flush=True)
(r/'timing-summary.json').write_text(json.dumps(timings,indent=2)+'\n')
for name,obj in [('solver-field-audit',solver),('exact-mean-pairs',means),('repeat-audit',repeats),('application-audit',applications)]:
 (r/f'{name}.json').write_text(json.dumps(obj,indent=2)+'\n')
passed=set()
for p in [r/'reusable-tests.log',r/'focused-tests.log']:
 passed.update(re.findall(r'^test (\S+) \.\.\. ok$',p.read_text(),re.M))
(r/'rust-test-inventory.json').write_text(json.dumps(dict(distinct=len(passed),passed=sorted(passed)),indent=2)+'\n')
print('COUNTS',len(solver),len(means),len(repeats),len(applications),len(passed))

import subprocess,os
from pathlib import Path
r=Path(__file__).parent
commands=[['cargo','test','-p','fereg-core','--lib','ppml::prepared_irls::tests'],['cargo','test','-p','fereg-core','--lib','public_solver_workspace'],['cargo','test','-p','fereg-testkit','--test','fe_certificate_oracle','--test','intercept_slope_oracle']]
with (r/'focused-tests.log').open('x') as f:
 for cmd in commands:
  print('COMMAND',cmd,file=f,flush=True);subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)

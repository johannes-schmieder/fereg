import json
from pathlib import Path
r=Path(__file__).parent;a=json.loads((r/'pilot-audit.json').read_text());out=[]
for i,c in enumerate(a['records']):
 row=dict(case=i,oracle=c['oracle_info'],variants={})
 for v in ['ppmlproj1','ppmlgeom1','fixest']:
  m=json.loads((r/'pilot'/f'runs/c{i}-r0-{v}/result.json').read_text())['metadata']
  total=m['df_k'] if v=='fixest' else m['rank']+m['df_a']
  assert total==c['oracle_info']['fe_rank']+c['cell']['k']
  dof=m.get('df_structural');assert v=='fixest' or dof==c['oracle_info']['df_r']==m['df_resid']
  row['variants'][v]=dict(total_rank=total,df_structural=dof)
 out.append(row)
(r/'independent-rank-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('Independent rank and structural DoF pass')

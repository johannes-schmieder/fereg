from pathlib import Path
p=Path('crates/fereg-core/src/fe/map.rs');s=p.read_text()
s=s.replace('    certificate_basis: Vec<f64>,\n','    certificate_basis: Vec<f64>,\n    certificate_geometry: Option<ReusableCertificateGeometry>,\n',1)
mark='#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]\npub(crate) struct ReusableMapCapacities'
s=s.replace(mark,'''// Capacity belongs to the session; validity belongs only to an absorb stack frame.
struct ReusableCertificateGeometry {
    basis: Vec<f64>,
    ranks: Vec<usize>,
}

fn reusable_certificate_dimensions(design: &FeDesign) -> Result<(usize, usize)> {
    design.effects().iter().try_fold((0_usize, 0_usize), |(basis, ranks), effect| {
        let basis = design.nobs().checked_mul(effect.channels())
            .and_then(|n| basis.checked_add(n));
        let ranks = ranks.checked_add(effect.n_levels());
        basis.zip(ranks).ok_or_else(|| FeregError::new(
            ErrorCode::Allocation, "reusable certificate geometry dimensions overflow"))
    })
}

''' + mark)
s=s.replace('    pub(crate) certificate_basis: usize,','    pub(crate) certificate_basis: usize,\n    pub(crate) certificate_geometry: usize,\n    pub(crate) certificate_ranks: usize,',1)
s=s.replace('            certificate_basis: reserved_zeroes(\n', '            certificate_geometry: None,\n            certificate_basis: reserved_zeroes(\n',1)
mark='    pub(crate) const fn max_rhs(&self) -> usize {'
s=s.replace(mark,'''    pub(crate) fn certificate_geometry_bytes(design: &FeDesign) -> Result<u128> {
        let (basis, ranks) = reusable_certificate_dimensions(design)?;
        Ok(basis as u128 * 8 + ranks as u128 * std::mem::size_of::<usize>() as u128)
    }

    /// The caller admits this optional bank for the entire session lifetime.
    /// An allocation refusal retains the existing uncached certificate path.
    pub(crate) fn enable_certificate_geometry(&mut self) -> Result<()> {
        let (basis_len, rank_len) = reusable_certificate_dimensions(&self.design)?;
        let basis = reserved_zeroes(basis_len, "reusable certificate geometry")?;
        let mut ranks = Vec::new();
        ranks.try_reserve_exact(rank_len).map_err(|_| FeregError::new(
            ErrorCode::Allocation, "unable to reserve reusable certificate ranks"))?;
        ranks.resize(rank_len, 0);
        if basis.capacity() > basis_len || ranks.capacity() > rank_len {
            return Err(FeregError::new(ErrorCode::Allocation,
                "reusable certificate capacity exceeds admission"));
        }
        self.certificate_geometry = Some(ReusableCertificateGeometry { basis, ranks });
        Ok(())
    }

''' + mark,1)
s=s.replace('            certificate_basis: self.certificate_basis.capacity(),','''            certificate_basis: self.certificate_basis.capacity(),
            certificate_geometry: self.certificate_geometry.as_ref().map_or(0, |g| g.basis.capacity()),
            certificate_ranks: self.certificate_geometry.as_ref().map_or(0, |g| g.ranks.capacity()),''',1)
s=s.replace('        let initial = self.certify(&values, weights, rhs, config.tolerance)?;', '''        // Even an identical weight slice starts a new geometry lifetime. Neither
        // an early return nor an error can authorize reuse in the next call.
        let mut geometry_valid = false;
        let initial = self.certify(&values, weights, rhs, config.tolerance, &mut geometry_valid)?;''',1)
s=s.replace('self.certify(&values, weights, rhs, config.tolerance)?;', 'self.certify(&values, weights, rhs, config.tolerance, &mut geometry_valid)?;',1)
a=s.index('    fn certify(',s.index('impl ReusableMapAbsorber'));b=s.index('\nfn reusable_map_report(',a);body=s[a:b]
body=body.replace('        tolerance: f64,\n','        tolerance: f64,\n        geometry_valid: &mut bool,\n',1)
body=body.replace('        for effect in self.design.effects() {','        let mut geometry_offset = 0_usize;\n        let mut group_index = 0_usize;\n        for effect in self.design.effects() {',1)
a1=body.index('                let mut active = 0_usize;');b1=body.index('                for column in 0..rhs {\n                    let denominator',a1)
qr=body[a1:b1]
wrapped='''                let basis_count = if *geometry_valid {
                    self.certificate_geometry.as_ref().expect("valid geometry has storage").ranks[group_index]
                } else {
'''+''.join('    '+l+'\n' for l in qr.splitlines())+'''                    if let Some(geometry) = self.certificate_geometry.as_mut() {
                        geometry.ranks[group_index] = basis_count;
                        for basis in 0..basis_count {
                            let start = basis * self.max_level_members;
                            let target = geometry_offset + basis * member_count;
                            geometry.basis[target..target + member_count].copy_from_slice(
                                &self.certificate_basis[start..start + member_count]);
                        }
                    }
                    basis_count
                };
                let (basis_values, basis_offset, basis_stride) = match self.certificate_geometry.as_ref() {
                    Some(geometry) => (geometry.basis.as_slice(), geometry_offset, member_count),
                    None => (self.certificate_basis.as_slice(), 0, self.max_level_members),
                };
'''
body=body[:a1]+wrapped+body[b1:]
body=body.replace('let start = basis * self.max_level_members;\n                            let mut coefficient', 'let start = basis_offset + basis * basis_stride;\n                            let mut coefficient',1)
body=body.replace('coefficient = self.certificate_basis[start + local]', 'coefficient = basis_values[start + local]',1)
body=body.replace('            }\n        }\n        let relative_two','                geometry_offset += channels * member_count;\n                group_index += 1;\n            }\n        }\n        *geometry_valid = self.certificate_geometry.is_some();\n        let relative_two',1)
s=s[:a]+body+s[b:];p.write_text(s)
p=Path('crates/fereg-core/src/ols/linear_session.rs');s=p.read_text()
s=s.replace('    pub(crate) fe_certificate_basis_elements: usize,','    pub(crate) fe_certificate_basis_elements: usize,\n    pub(crate) fe_certificate_geometry_elements: usize,\n    pub(crate) fe_certificate_rank_elements: usize,',1)
s=s.replace('            fe_certificate_basis_elements: fe.certificate_basis,','            fe_certificate_basis_elements: fe.certificate_basis,\n            fe_certificate_geometry_elements: fe.certificate_geometry,\n            fe_certificate_rank_elements: fe.certificate_ranks,',1)
s=s.replace('    pub(crate) fn enable_checkpoint_lsmr(&mut self) {','''    pub(crate) fn enable_ppml_certificate_geometry(&mut self) -> Result<()> {
        match self.fe_projector.as_mut() {
            Some(ReusableLinearMapProjector::Generic(projector)) => {
                match projector.enable_certificate_geometry() {
                    Ok(()) => Ok(()),
                    Err(error) if error.code == ErrorCode::Allocation => Ok(()),
                    Err(error) => Err(error),
                }
            }
            _ => Err(invalid_argument(
                "PPML certificate geometry requires the generic reusable MAP owner",
            )),
        }
    }

    pub(crate) fn enable_checkpoint_lsmr(&mut self) {''',1);p.write_text(s)
p=Path('crates/fereg-core/src/ppml/memory.rs');s=p.read_text()
s=s.replace('    pub reusable_projection_bytes: u128,','    pub reusable_projection_bytes: u128,\n    /// Optional current-call certificate geometry; capacity shares the linear session lifetime.\n    pub reusable_certificate_bytes: u128,',1)
s=s.replace('.saturating_add(self.reusable_projection_bytes)', '.saturating_add(self.reusable_projection_bytes)\n            .saturating_add(self.reusable_certificate_bytes)')
s=s.replace('.and_then(|n| n.checked_add(bytes))\n        else', '.and_then(|n| n.checked_add(self.reusable_certificate_bytes))\n            .and_then(|n| n.checked_add(bytes))\n        else',1)
mark='    pub(crate) fn with_solver_workspace(mut self, bytes: u128) -> Result<Self> {'
s=s.replace(mark,'''    pub(crate) fn admit_reusable_certificate(&mut self, bytes: u128) -> bool {
        let Some(peak) = self.selected_inventory().peak_bytes
            .checked_add(self.solver_workspace_bytes)
            .and_then(|n| n.checked_add(self.reusable_projection_bytes))
            .and_then(|n| n.checked_add(bytes))
        else { return false; };
        if self.usable_bytes.is_some_and(|usable| peak > usable) {
            return false;
        }
        self.reusable_certificate_bytes = bytes;
        true
    }

''' + mark,1)
s=s.replace('.and_then(|n| n.checked_add(self.reusable_projection_bytes))\n            .ok_or_else', '.and_then(|n| n.checked_add(self.reusable_projection_bytes))\n            .and_then(|n| n.checked_add(self.reusable_certificate_bytes))\n            .ok_or_else',1)
s=s.replace('        reusable_projection_bytes: 0,','        reusable_projection_bytes: 0,\n        reusable_certificate_bytes: 0,',1)
s=s.replace('if !reconstructed.admit_reusable_projection(self.plan.reusable_projection_bytes)\n', 'if !reconstructed.admit_reusable_projection(self.plan.reusable_projection_bytes)\n            || !reconstructed.admit_reusable_certificate(self.plan.reusable_certificate_bytes)\n',1);p.write_text(s)
p=Path('crates/fereg-core/src/ppml/prepared_irls.rs');s=p.read_text()
s=s.replace('        capacity.fe_certificate_basis_elements,','        capacity.fe_certificate_basis_elements,\n        capacity.fe_certificate_geometry_elements,\n        capacity.fe_certificate_rank_elements,',1)
mark='    // The retained bank cannot consume slack promised to another solver call.'
s=s.replace(mark,'''    let certificate_geometry = if matches!(purpose, PreparedPpmlIrlsPurpose::Publication)
        && config.solver_plan.selected == super::PpmlSolverFamily::Map
        && fe_design.effects().len() > 1
        && fe_design.effects().iter().any(|effect| !effect.slopes().is_empty())
    {
        match crate::fe::ReusableMapAbsorber::certificate_geometry_bytes(&fe_design) {
            Ok(bytes) => memory_plan.admit_reusable_certificate(bytes),
            Err(error) if error.code == ErrorCode::Allocation => false,
            Err(error) => return Err(error),
        }
    } else { false };
''' + mark,1)
s=s.replace('.checked_add(memory_plan.reusable_projection_bytes)\n            .ok_or_else', '.checked_add(memory_plan.reusable_projection_bytes)\n            .and_then(|n| n.checked_add(memory_plan.reusable_certificate_bytes))\n            .ok_or_else',1)
s=s.replace('    session.set_phase_allocator_probe(config.linear_phase_allocation_probe);','    if certificate_geometry {\n        session.enable_ppml_certificate_geometry()?;\n    }\n    session.set_phase_allocator_probe(config.linear_phase_allocation_probe);',1);p.write_text(s)

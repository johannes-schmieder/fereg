local slope_absorb "g1##c.(z1) g2##c.(z2)"
local memory "fast"

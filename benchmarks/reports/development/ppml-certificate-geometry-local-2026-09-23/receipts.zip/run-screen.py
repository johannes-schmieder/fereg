import subprocess,sys
from pathlib import Path
r=Path(__file__).parent;py='target/one-fe-profile-20260919/python/bin/python'
settings={'pilot':(202609299,1),'pairs':(202609300,3),'fresh':(202609301,3),'controls':(202609302,3),'ols-controls':(202609303,3)}
for label in sys.argv[1:]:
 seed,repeats=settings[label];variants=['ppmlproj1','ppmlgeom1']+([] if label=='ols-controls' else ['fixest'])
 cmd=[py,'benchmarks/next_subsystem/run.py',str(r/label),'--surface' if label=='ols-controls' else '--ppml-surface','--artifacts','target/ppml-next-20260922/artifacts','--variants',*variants,'--fixest-archive','target/one-fe-profile-20260919/fixest.tar.gz','--cells',str(r/f'{label}-cells.json'),'--seed',str(seed),'--repeats',str(repeats)]
 with (r/f'{label}-driver.log').open('x') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)

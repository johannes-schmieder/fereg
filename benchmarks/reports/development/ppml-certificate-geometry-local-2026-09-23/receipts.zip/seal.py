import json,hashlib,zipfile,sys
from pathlib import Path
r=Path(__file__).parent;sys.path.insert(0,'benchmarks/next_subsystem');from archive import archive
out=Path('benchmarks/reports/development/ppml-certificate-geometry-local-2026-09-23/receipts.zip')
extras=sorted(p.name for p in r.iterdir() if p.is_file() and not p.name.startswith('.'))
archive(r,out,['pilot','pairs','fresh','controls','ols-controls','native-profile','native-profile-traced'],extras)
with zipfile.ZipFile(out) as z:
 m=json.loads(z.read('archive-hashes.json'));assert len(z.namelist())==len(m)+1
 for name,h in m.items():assert hashlib.sha256(z.read(name)).hexdigest()==h['archived_sha256'],name
print('VERIFIED',len(m),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())

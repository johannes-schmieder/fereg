import subprocess
from pathlib import Path
r=Path(__file__).parent;py='target/one-fe-profile-20260919/python/bin/python'
for label in ['fresh','controls']:
 with (r/f'{label}-audit.log').open('x') as f:subprocess.run([py,'benchmarks/next_subsystem/ppml_audit.py',str(r/label),str(r/f'{label}-audit.json')],stdout=f,stderr=subprocess.STDOUT,check=True)
for label in ['pilot','fresh','controls','ols-controls']:
 with (r/f'{label}-summary.log').open('x') as f:subprocess.run([py,'benchmarks/next_subsystem/summarize.py',str(r/label),str(r/f'{label}-summary.json'),'ppmlproj1','ppmlgeom1'],stdout=f,stderr=subprocess.STDOUT,check=True)
subprocess.run([py,str(r/'rank-audit.py')],check=True)
print('AUDITS COMPLETE')

import json,hashlib,shutil,re,subprocess,io,tarfile
from pathlib import Path
r=Path(__file__).parent;a=Path('target/ppml-next-20260922/artifacts')
variants=['ppmlproj1','ppmlgeom1','slope_cert_profile2','ppmlgeom_profile']
modified={}
for v in variants:
 identity=json.loads((a/f'identity-{v}.json').read_text())
 shutil.copy2(a/f'identity-{v}.json',r/f'identity-{v}.json');shutil.copy2(a/f'build-{v}.log',r/f'artifact-build-{v}.log')
 blob=subprocess.check_output(['git','archive',identity['base_commit'],*identity['source']])
 with tarfile.open(fileobj=io.BytesIO(blob)) as tf:
  changed=[]
  for name,h in identity['source'].items():
   content=(a/v/name).read_bytes();assert hashlib.sha256(content).hexdigest()==h
   if hashlib.sha256(tf.extractfile(name).read()).hexdigest()!=h:
    saved=v+'--'+name.replace('/','--');(r/saved).write_bytes(content);changed.append(dict(source=name,archived=saved,sha256=h))
 modified[v]=dict(base=identity['base_commit'],changed=changed)
(r/'artifact-source-overlays.json').write_text(json.dumps(modified,indent=2)+'\n')
identity=json.loads((a/'identity-ppmlgeom1.json').read_text());mismatches=[n for n,h in identity['source'].items() if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h]
assert not mismatches
(r/'source-binding.json').write_text(json.dumps(dict(base=identity['base_commit'],candidate='ppmlgeom1',plugin=identity['plugin'],matched=len(identity['source']),mismatches=mismatches),indent=2)+'\n')
for name in ['run','surface','ppml_surface','ppml_audit','profile','designs','oracles','summarize','audit','archive','test_surface','test_ppml_surface']:
 shutil.copy2(Path('benchmarks/next_subsystem')/f'{name}.py',r/f'{name}.py')
for name in ['oracle','common']:shutil.copy2(Path('benchmarks/systematic')/f'{name}.py',r/f'systematic-{name}.py')
shutil.copy2('benchmarks/one_fe_optimization/build.py',r/'builder.py')
for name in ['stock-reference','python-dependencies']:shutil.copy2(Path('target/ppml-breadth-20260923')/f'{name}.json',r/f'{name}.json')
fixtures=json.loads((r/'fixtures.json').read_text())
for f in fixtures:
 p=Path('tests/stata')/f['fixture'];shutil.copy2(p,r/p.name)
 assert f['process_returncode']==0 and f['stata_rc']==0 and not f['error'] and f['terminal_sentinel']
 (r/(p.stem+'.protocol')).write_text(f"fixture={f['fixture']}\nprocess_returncode=0\nstata_rc=0\nEND_FIXTURE|{p.stem}|rc=0\n")
# Preserve only the pertinent error, wrapped continuation and transaction sentinel.
lines=[]
for p in (r/'diagnostic-licensed-logs').glob('*.log'):
 raw=p.read_text().splitlines()
 for i,line in enumerate(raw):
  if line.startswith(('fereg:','DISCONNECTED_FAILURE_RC|','END_FIXTURE|')):
   lines.append(line)
   if line.startswith('fereg:'):
    for more in raw[i+1:]:
     if not more.startswith('> '):break
     lines.append(more)
(r/'failure-diagnostic.protocol').write_text('\n'.join(lines)+'\n')
# Replace an overbroad first selector in the driver's captured stdout; the raw
# licensed log itself is retained only under ignored target/.
(r/'failure-driver.log').write_text(json.dumps(json.loads((r/'failure-diagnostic.json').read_text()),indent=2)+'\n'+'\n'.join(lines)+'\n')
profile_checks=[];profile_calls=[]
from sys import path
path.insert(0,'benchmarks/next_subsystem');from audit import compare,exact_exports
for block,label in [('native-profile','profile'),('native-profile-traced','profile-traced')]:
 d=json.loads((r/f'{label}-audit.json').read_text())
 for c in d['records']:
  assert all(x['checks']['passed'] for x in c['pairs']) and all(x['passed'] for x in c['public_states'].values())
 for i in range(2):
  paths=[r/block/f'runs/c{i}-r0-{v}' for v in ['slope_cert_profile2','ppmlgeom_profile']]
  checks=compare(*paths,'ppml');exact=exact_exports(*paths);means=(paths[0]/'means.bin').read_bytes()==(paths[1]/'means.bin').read_bytes()
  assert checks['passed'] and exact['passed'] and means
  profile_checks.append(dict(block=block,case=i,checks=checks,exact=exact,exact_means=means))
 rows=json.loads((r/block/'progress.json').read_text());assert all(x['status']=='pass' and not x['overlaps'] and not x['monitor_errors'] for x in rows)
 profile_calls.extend(dict(block=block,**x) for x in rows)
(r/'profile-exact-audit.json').write_text(json.dumps(profile_checks,indent=2)+'\n')
(r/'profile-application-audit.json').write_text(json.dumps(profile_calls,indent=2)+'\n')
summary=dict(completed_screen_calls=76,successful_screen_calls=73,application_failures=3,interrupted_stock_attempts=1,unattempted_declared_arms=4,native_exact_pairs=26,native_exact_mean_pairs=20,repeat_checks=44,comparable_headline_stock_pairs=18,independent_pilots=2,successful_profile_calls=8,untimed_failed_case_diagnostic=1,rust_tests=64,licensed_fixtures_passed=3,source_inputs=529)
(r/'acceptance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(summary)

from pathlib import Path
import json
r=Path(__file__).parent;out=[]
for i in range(2):
 for v in ['slope_cert_profile2','ppmlgeom_profile']:
  sums={};counts={};parts={};it=[]
  for line in (r/'native-profile'/f'runs/c{i}-r0-{v}/stderr.txt').read_text().splitlines():
   if not line.startswith('FEREG_PHASE|'):continue
   p=line.split('|');d=dict(x.split('=',1) for x in p[2:])
   if d.get('rows')!='30720':continue
   if p[1]=='ppml_map' or (p[1]=='owned_fe' and d.get('phase')=='projection'):
    k=p[1]+':'+d['phase'];sums[k]=sums.get(k,0)+float(d['seconds']);counts[k]=counts.get(k,0)+1
   if p[1]=='reusable_certificate':
    for k in ['norms','normalize','qr','project','raw_moments']:parts[k]=parts.get(k,0)+float(d[k])
   if p[1]=='ppml_slope_it':it.append(d)
  row=dict(case=i,variant=v,seconds=sums,counts=counts,certificate_parts=parts,extrapolation_steps=it);out.append(row)
  print(i,v,sums,counts,parts,'IT',len(it),flush=True)
(r/'native-phase-summary.json').write_text(json.dumps(out,indent=2)+'\n')

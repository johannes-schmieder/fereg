from pathlib import Path
p=Path('crates/fereg-core/src/fe/borrowed_map.rs');s=p.read_text().replace('            certificate_basis: 0,','            certificate_basis: 0,\n            certificate_geometry: 0,\n            certificate_ranks: 0,',1);p.write_text(s)
p=Path('crates/fereg-core/src/fe/map.rs');s=p.read_text();mark='    #[test]\n    fn reusable_parallel_projection_refreshes_weights_rhs_and_capacity() {'
s=s.replace(mark,'''    #[test]
    fn reusable_certificate_geometry_is_exact_and_rebuilt_after_every_call() {
        let rows = 120;
        let z: Vec<_> = (0..rows).map(|i| (i % 7) as f64 - 3.0).collect();
        let design = FeDesign::new(rows, vec![
            EffectTerm::new((0..rows).map(|i| (i % 5) as u32).collect(), 6, true,
                vec![z.clone(), z.iter().map(|v| 2.0 * v).collect(), vec![0.0; rows]]).unwrap(),
            EffectTerm::new((0..rows).map(|i| ((i / 5) % 4) as u32).collect(), 4, false,
                vec![(0..rows).map(|i| (i % 11) as f64 - 5.0).collect()]).unwrap(),
        ]).unwrap();
        let mut plain = ReusableMapAbsorber::new(design.clone(), 7).unwrap();
        let mut cached = ReusableMapAbsorber::new(design.clone(), 7).unwrap();
        cached.enable_certificate_geometry().unwrap();
        let capacities = cached.capacities();
        assert_eq!(capacities.certificate_geometry, rows * 5);
        assert_eq!(capacities.certificate_ranks, 10);
        assert_eq!(ReusableMapAbsorber::certificate_geometry_bytes(&design).unwrap(),
            (rows * 5 * 8 + 10 * std::mem::size_of::<usize>()) as u128);
        for (generation, rhs) in [7, 1, 3, 7].into_iter().enumerate() {
            let weights: Vec<_> = (0..rows).map(|i| 0.1 + ((i * (generation + 1)) % 13) as f64).collect();
            let mut values = DenseMatrix::zeros(rows, rhs).unwrap();
            for row in 0..rows { for col in 0..rhs {
                values[(row, col)] = ((row * 19 + col * 11 + generation) % 97) as f64;
            }}
            for limit in [1, 16000] {
                let config = MapConfig { max_iterations: limit, ..MapConfig::default() };
                let expected = plain.absorb(&weights, values.clone(), config, false);
                let actual = cached.absorb(&weights, values.clone(), config, false);
                match (actual, expected) {
                    (Ok(actual), Ok(expected)) => {
                        assert_eq!(actual.residualized(), expected.residualized());
                        assert_eq!(actual.report().certificate, expected.report().certificate);
                        assert_eq!(actual.report().iterations, expected.report().iterations);
                        let norms = weighted_column_norms(&values, &weights).unwrap();
                        assert!(certify_residuals_with_reference_norms(&design, &weights,
                            actual.residualized(), &norms, 1e-8).unwrap().passed);
                    }
                    (Err(actual), Err(expected)) => assert_eq!(actual.code, expected.code),
                    _ => panic!("cached and uncached outcomes differ"),
                }
                assert_eq!(cached.capacities(), capacities);
            }
        }
        // Initial zero-residual success must rebuild even when the old basis is
        // finite but has the wrong numerical rank under the new weights.
        let design = FeDesign::new(3, vec![EffectTerm::new(vec![0; 3], 2, true,
            vec![vec![1e150, 2e150, 3e150], vec![0.0; 3]]).unwrap()]).unwrap();
        let mut cached = ReusableMapAbsorber::new(design, 1).unwrap();
        cached.enable_certificate_geometry().unwrap();
        for (weights, rank) in [(vec![1.0; 3], 2), (vec![1.0, 1e-60, 1e-60], 1), (vec![1.0; 3], 2)] {
            cached.absorb(&weights, DenseMatrix::zeros(3, 1).unwrap(), MapConfig::default(), false).unwrap();
            assert_eq!(cached.certificate_geometry.as_ref().unwrap().ranks, vec![rank, 0]);
            assert!(cached.absorb(&[f64::NAN; 3], DenseMatrix::zeros(3, 1).unwrap(),
                MapConfig::default(), false).is_err());
        }
    }

''' +mark,1)
# Extend the existing threaded/serial oracle to cover the additional optional bank too.
s=s.replace('        parallel.enable_parallel_projection(plan).unwrap();','        parallel.enable_parallel_projection(plan).unwrap();\n        parallel.enable_certificate_geometry().unwrap();',1);p.write_text(s)
p=Path('crates/fereg-core/src/ppml/memory.rs');s=p.read_text();mark='    #[test]\n    fn optional_reusable_projection_respects_exact_budget_and_phase_lifetime() {'
s=s.replace(mark,'''    #[test]
    fn optional_reusable_certificate_accounts_for_projection_and_phase_lifetime() {
        let mut base = plan_ppml_memory(dimensions(), PpmlMemoryConfig::default())
            .unwrap().with_solver_workspace(1024).unwrap();
        assert!(base.admit_reusable_projection(2048));
        let mut plan = base;
        plan.usable_bytes = Some(base.selected_bytes() + 4095);
        let before = plan;
        assert!(!plan.admit_reusable_certificate(4096));
        assert_eq!(plan, before);
        plan.usable_bytes = Some(base.selected_bytes() + 4096);
        assert!(plan.admit_reusable_certificate(4096));
        assert_eq!(plan.selected_bytes(), base.selected_bytes() + 4096);
        assert!(plan.with_solver_workspace(1025).is_err());
        assert!(!plan.admit_reusable_projection(2049));
        assert!(!plan.admit_reusable_certificate(u128::MAX));
        for phase in [PpmlPhase::Preparation, PpmlPhase::WeightResponseRefresh,
            PpmlPhase::FeProjection, PpmlPhase::FiniteSolve,
            PpmlPhase::ObjectiveLineSearch, PpmlPhase::StrictFinalSolve] {
            assert_eq!(plan.modeled_phase_peak_bytes(phase), base.modeled_phase_peak_bytes(phase) + 4096);
        }
        for phase in [PpmlPhase::SeparationFe, PpmlPhase::SeparationMu,
            PpmlPhase::Inference, PpmlPhase::FeRecovery, PpmlPhase::Publication] {
            assert_eq!(plan.modeled_phase_peak_bytes(phase), base.modeled_phase_peak_bytes(phase));
        }
        assert!(base.admit_reusable_certificate(4096));
        let mut telemetry = PpmlMemoryTelemetry::new(base, dimensions().threads, dimensions().threads).unwrap();
        telemetry.observe_linear_route(FeSolverKind::Map);
        telemetry.observe_scratch(0);
        telemetry.validate().unwrap();
        telemetry.plan.reusable_certificate_bytes += 1;
        // Re-admission verifies a real budget, rather than trusting prior telemetry.
        telemetry.plan.usable_bytes = Some(1);
        assert!(telemetry.validate().is_err());
    }

''' + mark,1);p.write_text(s)

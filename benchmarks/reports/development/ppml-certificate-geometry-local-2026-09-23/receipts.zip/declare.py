import json,subprocess
from pathlib import Path
r=Path(__file__).parent;old=Path('target/ppml-parallel-projection-20260923')
pairs=json.loads((old/'pairs-cells.json').read_text());freshold=json.loads((old/'fresh-cells.json').read_text())
sets={'pilot':[dict(c,n=2400,k=4) for c in pairs], 'pairs':pairs,
      'fresh':[freshold[0],freshold[1],freshold[2],dict(pairs[1],topology='disconnected')],
      'controls':[freshold[3]],
      'ols-controls':json.loads((old/'controls-cells.json').read_text())}
for label,cells in sets.items():(r/f'{label}-cells.json').write_text(json.dumps(cells,indent=2)+'\n')
(r/'predeclared.json').write_text(json.dumps(dict(base='5cb0434a',baseline='ppmlproj1',candidate='ppmlgeom1',hypothesis='Cache identical weighted certificate QR bases only within each reusable MAP absorb call. Local validity starts false on every invocation. Full session capacity is optionally admitted after projection; no numerical product is reused across calls.',eligibility='Publication MAP, multiple effects, at least one slope; no size/thread/seed gate. Mu/non-MAP/single/categorical remain unchanged. Refusal keeps uncached path.',seeds=dict(pilot=202609299,pairs=202609300,fresh=202609301,controls=202609302,ols_controls=202609303,profile=202609304),overlays=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines(),repeats=3,limits='One structural candidate. Require exact native residual science/certificates/iterations, independent Poisson/current-Hessian small pilots, fresh public states and stock with already-adjudicated strict tolerances. Full-rank weights and changing local numerical rank checked independently of performance. Fresh expansion only if representative gain. Keep all failures and losses; no full qualification.'),indent=2)+'\n')

import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2]; artifacts=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import archive_science
root=repo/'target/g21tail'; output=repo/'benchmarks/reports/development/two-fe-coverage-tail-local-2026-09-21'
assert json.loads((root/'tail-complete.json').read_text())['attempted']==24
archive_science.archive([root],output,compact=True,omit_output_arrays=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={kind:{} for kind in ['sources','checks']}
with zipfile.ZipFile(output/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    def add(name,raw):
        clean=portable(raw);bundle.writestr(name,clean)
        tables['sources'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
    for variant in ['baseline','sf1']:
        path=artifacts/f'identity-{variant}.json';identity=json.loads(path.read_text());add(path.name,path.read_bytes())
        raw=subprocess.check_output(['/opt/homebrew/bin/git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'],cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            base={entry.name:sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
        for relative,digest in identity['source'].items():
            data=(artifacts/variant/relative).read_bytes();assert sha(data)==digest
            if base.get(relative)!=digest: add(variant+'/'+relative,data)
    for name in ['milestone.py','score_milestone.py','audit_milestone.py','audit_outputs.py','graph_oracle.py','run.py','route_development.py','score.py','archive_science.py']:
        add(name,(repo/'benchmarks/two_fe_dense'/name).read_bytes())
    add('archive-coverage-tail1.py',Path(__file__).read_bytes())
with zipfile.ZipFile(output/'checks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for name in ['coverage-tail-score1.json','coverage-tail-score1.txt','coverage-tail-inference1.json','coverage-tail-inference1.txt','coverage-tail-outputs1.txt','coverage-tail1.txt']:
        raw=(artifacts/name).read_bytes();clean=portable(raw);bundle.writestr(name,clean)
        tables['checks'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
for kind,table in tables.items(): (output/(kind+'-hashes.json')).write_text(json.dumps(table,indent=2)+'\n')
verifier=(repo/'benchmarks/reports/development/cmg-batch-wide-retention-local-2026-09-21/verify.py').read_text()
verifier=verifier.replace("['m4', 'm5', 'cb1', 'wr1', 'wr2']","['baseline', 'sf1']").replace("cmg-wide-archive-integrity-v1","coverage-tail-archive-integrity-v1").replace('CMG_WIDE_ARCHIVE_INTEGRITY_PASS','COVERAGE_TAIL_ARCHIVE_INTEGRITY_PASS')
(output/'verify.py').write_text(verifier)
score=json.loads((artifacts/'coverage-tail-score1.json').read_text())
rows=[]
for cell in score['cells']:
    c=cell['cell'];s=cell['median_seconds'];reference='—' if c['weight_kind']=='fw' else f"{1000*s['fixest']:.0f}"
    rows.append(f"| {c['design']} | {c['weight_kind']} | {c['case']} | {1000*s['baseline']:.0f} | {1000*s['sf1']:.0f} | {reference} | {cell['median_comparator_ratio']:.4f} |")
(output/'README.md').write_text('''# Additional two-FE graph, weight and output coverage

All twenty-four remaining cells in the expanded three-pair screen complete:
198 successful calls, with no detected competing process in any cell. The
candidate beats default fixest in all eighteen comparable cells by more than
10%. Six frequency-weight cells use the pinned native baseline; ordinary
fixest weights do not reproduce Stata frequency-weight inference.

The independent grounded sparse-direct audits pass all 48 native fits, and
144 repeated native result checks match exactly. All 36 candidate saved-output
audits pass. Nine reference inference audits pass and nine disagree; the
original reference disagreements remain failures and are preserved in full.
These are exploratory timings, not final independent-block acceptance.

The unchanged inputs have N=245,760, K=6 and sixteen native/R workers. Each
cell requests a crossing cluster with saved effects or two nested clusters
without outputs. The baseline is source `0efa78bd`; sf1 includes the current
captured graph/fit drafts plus the separately accepted slope optimization.
No inference, sample or convergence tolerance changes for these comparisons.

| Graph | Weight | Request | Baseline ms | sf1 ms | fixest ms | Paired comparator ratio |
|---|---|---|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

`verify.py` checks portable evidence, full baseline/sf1 source reconstruction
and the independent-auditor binding. Large output arrays remain local with
explicit hashes; the committed independent audits record their checks. Raw
licensed logs are excluded. The earlier partial and ring/cycle screens used
different artifacts, so their union is not one final-candidate campaign.
Broader protection, final blocks, routing decisions and Linux confirmation
remain open. No installation, push or qualification is performed.
''')
print('COVERAGE_TAIL_ARCHIVE_PREPARED')

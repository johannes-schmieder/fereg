import hashlib,json,re,shutil,subprocess
from pathlib import Path
from statistics import median
from collections import Counter
root=Path(__file__).resolve().parent
repo=Path.cwd()
art=repo/'target/ppml-next-20260922/artifacts'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x): p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
rows=[]; pairs=[]; all_attempts=[]
for block in ['screen','confirm','controls']:
    s=json.loads((root/f'{block}-summary.json').read_text())
    attempts=json.loads((root/block/'progress.json').read_text())
    all_attempts+=attempts
    for i,(cell,a) in enumerate(zip(s['cells'],s['audit']['records'])):
        pp=cell['pairs']; pairs+=pp
        assert all(x['clean'] and x['checks']['passed'] for x in pp)
        assert all(x['checks']['passed'] for x in cell['repeats'])
        assert all(x['checks']['passed'] for x in a['comparisons'])
        memory={}
        for v in ['residual2','batch1','fixest']:
            rr=[json.loads((root/block/x['result']/'result.json').read_text()) for x in attempts if x['case']==i and x['variant']==v]
            if rr:
                rss=[x['peak_rss_gib'] for x in rr]
                memory[v]={'rss_gib':{'min':min(rss),'median':median(rss),'max':max(rss)},'rss_samples':[x['rss_samples'] for x in rr]}
        row=dict(block=block,case=i,cell=cell['cell'],timings=a['timings'],ratios=cell['ratios'],memory=memory,
            tracked_peaks=[x['tracked_peak_bytes'] for x in pp],phases={v:{k:x for k,x in r.items() if k.startswith('time_')} for v,r in a['runtime'].items()})
        rows.append(row)
        print(block,i,cell['cell'],'timings', {v:round(t['median']*1000,1) for v,t in a['timings'].items()},'ratios',cell['ratios'])
        print('memory',memory,'native_peak',row['tracked_peaks'][0])
        print('phase',row['phases'])
assert all(x['status']=='pass' and not x['overlaps'] and not x['monitor_errors'] for x in all_attempts)
deltas=[x['tracked_peak_bytes']['batch1']-x['tracked_peak_bytes']['residual2'] for x in pairs]
errors={key:max(p['checks'].get(key,{}).get('maximum_absolute_error',0) for p in pairs) for key in ['coefficients','covariance','ll','deviance']}
summary=dict(rows=rows,attempts=len(all_attempts),native_pairs=len(pairs),exact_native_pairs=sum(x['exact']['passed'] for x in pairs),maximum_errors=errors,native_peak_delta_range=[min(deltas),max(deltas)])
write(root/'milestone-summary.json',summary)
print('SUMMARY', {k:v for k,v in summary.items() if k!='rows'})
ident=json.loads((art/'identity-batch1.json').read_text())
mismatch=[p for p,h in ident['source'].items() if not (repo/p).is_file() or sha(repo/p)!=h]
assert not mismatch,mismatch
binding=dict(base='af38bce7595c247cb4857f6d1a77350183f688b8',candidate='batch1',captured_inputs=len(ident['source']),mismatches=mismatch,plugin=ident['plugin'])
write(root/'source-binding.json',binding)
for name in ['identity-residual2.json','identity-batch1.json','fixtures-batch1.json','build-batch1.log']:
    shutil.copyfile(art/name,root/name)
(root/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','af38bce7','--','crates/fereg-core/src/fe/borrowed_map.rs']))
shutil.copyfile(repo/'tests/stata/development/feppml_narrow_checkpoint_schur.do',root/'feppml_narrow_checkpoint_schur.do')
fixtures=[]
for r in json.loads((art/'fixtures-batch1.json').read_text()):
    assert sha(repo/'tests/stata'/r['fixture'])==r['sha256']
    d=art/'fixtures/batch1'/Path(r['fixture']).stem
    hashes={p.name:sha(p) for p in d.iterdir() if p.is_file()}
    lines=[]
    for name in ['stdout.txt','run.log']:
        for line in (d/name).read_text().splitlines():
            if re.match(r'^(FEREG_PHASE\||FEREG_SOLVER_TRACE\||END_FIXTURE\||ACCESSOR_FIXTURE_COMPLETE)',line): lines.append(line)
    (root/(Path(r['fixture']).stem+'.protocol')).write_text('\n'.join(lines)+'\n')
    fixtures.append(dict(receipt=r,log_hashes=hashes))
write(root/'fixture-binding.json',fixtures)
tests=[]
for name in ['tests-checkpoint.txt','tests-ppml.txt','tests-schur.txt']:
    txt=(root/name).read_text()
    assert 'test result: ok.' in txt
    tests.extend(re.findall(r'^test (.+) \.\.\. ok$',txt,re.M))
write(root/'test-summary.json',dict(executions=len(tests),distinct=len(set(tests)),tests=sorted(set(tests))))
print('BINDING',binding,'TESTS',len(tests),len(set(tests)))

import csv, hashlib, json
from pathlib import Path
repo=Path(__file__).resolve().parents[2]
root=repo/'target/g21in1'; output=repo/'target/ols-next-20260921/initial-norm-equivalence1.json'
assert not output.exists()
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((root/'screen-plan.json').read_text())
progress=json.loads((root/'screen-progress.json').read_text())
def solver(path):
    return {(int(r['row']),int(r['column'])):float(r['value'])
        for r in csv.DictReader(path.open()) if int(r['column']) not in [9,10]}
records=[]
names=['coefficients.csv','covariance.csv','b.csv','V.csv','fereg_fit.csv','fereg_dof.csv',
       'fereg_certificate.csv','fereg_status.csv','fereg_fe.csv','outputs.bin']
for attempt in progress:
    paths={v:sorted((root/'runs').glob(attempt['label']+'-*-'+v+'/result.json')) for v in plan['variants']}
    assert all(len(v)==plan['repeats'] for v in paths.values())
    for i in range(plan['repeats']):
        left,right=[paths[v][i] for v in plan['variants']]
        a,b=[json.loads(p.read_text()) for p in [left,right]]
        checks={name:sha(left.with_name(name))==sha(right.with_name(name)) for name in names}
        checks.update(application=a['status']==b['status']=='pass',sample=a['sample_sha256']==b['sample_sha256'],
                      solver_and_certificates=solver(left.with_name('fereg_solver.csv'))==solver(right.with_name('fereg_solver.csv')))
        records.append(dict(index=attempt['index'],rep=i+1,checks=checks,status='pass' if all(checks.values()) else 'mismatch',
                            result_sha256={v:sha(paths[v][i]) for v in plan['variants']}))
result=dict(schema='initial-norm-exact-equivalence-v1',controller_sha256=sha(Path(__file__)),
            solver_layout_source_sha256=sha(repo/'crates/fereg-plugin/src/result.rs'),
            plan_sha256=sha(root/'screen-plan.json'),progress_sha256=sha(root/'screen-progress.json'),
            planned=len(plan['cells'])*plan['repeats'],passing=sum(r['status']=='pass' for r in records),records=records,
            excluded_solver_columns={'9':'setup_seconds','10':'solve_seconds'})
output.write_text(json.dumps(result,indent=2)+'\n')
print('INITIAL_NORM_EQUIVALENCE',result['passing'],'/',result['planned'])
assert result['passing']==result['planned']

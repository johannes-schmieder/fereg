import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2]; artifacts=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import archive_science
roots=[repo/'target/g21in1']
output=repo/'benchmarks/reports/development/initial-ols-norm-local-2026-09-21'
for root in roots:
    assert json.loads((root/'screen-complete.json').read_text())['attempted']==16
archive_science.archive(roots,output,compact=True,omit_output_arrays=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={kind:{} for kind in ['sources','checks']}
with zipfile.ZipFile(output/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    def add(name,raw):
        clean=portable(raw);bundle.writestr(name,clean)
        tables['sources'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
    for variant in ['sf1','in1']:
        path=artifacts/f'identity-{variant}.json';identity=json.loads(path.read_text());add(path.name,path.read_bytes())
        raw=subprocess.check_output(['/opt/homebrew/bin/git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'],cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            base={entry.name:sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
        for relative,digest in identity['source'].items():
            data=(artifacts/variant/relative).read_bytes();assert sha(data)==digest
            if base.get(relative)!=digest: add(variant+'/'+relative,data)
    for name in ['audit_milestone.py','audit_outputs.py','graph_oracle.py','run.py','route_development.py','score.py','broad.py','archive_science.py']:
        add(name,(repo/'benchmarks/two_fe_dense'/name).read_bytes())
    for relative in ['crates/fereg-plugin/src/result.rs']:
        add(relative,(repo/relative).read_bytes())
    for name in ['initial-norm-screen1.py','initial-norm-screen2.py','score-kernel-screen2.py','archive-direct-route1.py']:
        add(name,(artifacts/name).read_bytes())
with zipfile.ZipFile(output/'checks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for index in [1]:
        for kind in ['score','inference','outputs','screen','equivalence','tests']:
            for suffix in ['json','txt']:
                name=f'initial-norm-{kind}{index}.{suffix}';path=artifacts/name
                if not path.exists(): continue
                raw=path.read_bytes();clean=portable(raw);bundle.writestr(name,clean)
                tables['checks'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
for kind,table in tables.items(): (output/(kind+'-hashes.json')).write_text(json.dumps(table,indent=2)+'\n')
verifier=(repo/'benchmarks/reports/development/two-fe-coverage-tail-local-2026-09-21/verify.py').read_text()
verifier=verifier.replace("['baseline', 'sf1']","['sf1', 'in1']").replace('coverage-tail-archive-integrity-v1','initial-ols-norm-archive-integrity-v1').replace('COVERAGE_TAIL_ARCHIVE_INTEGRITY_PASS','INITIAL_OLS_NORM_ARCHIVE_INTEGRITY_PASS')
verifier=verifier.replace("if name.endswith('-inference1.json') and name != 'wr2-memory-inference1.json':", "if name in ['initial-norm-inference1.json']:")
verifier=verifier.replace("assert audit['controller_sha256'] in known_sources, name", "assert audit['controller_sha256'] in known_sources, name\n            assert audit['oracle_source_sha256'] in known_sources, name")
(output/'verify.py').write_text(verifier)
rows=[]
for index in [1]:
    for record in json.loads((artifacts/f'initial-norm-score{index}.json').read_text())['cells']:
        c=record['cell'];s=record['median_seconds']
        rows.append(f"| {c['design']} | {c['weight_kind']} | {c['k']} | {c['threads']} | {c['case']} | {1000*s['sf1']:.0f} | {1000*s['in1']:.0f} | {record['median_native_ratio']:.4f} |")
(output/'README.md').write_text("""# Initial automatic OLS norm pass

Candidate in1 replaces the duplicate initial norm calculation inside borrowed
automatic absorption with the existing initial-certificate helper. The input
is unchanged since its reference norms were computed. All FE moments are still
freshly checked, and later residuals retain their independent norm scans.
The change adds no allocation and changes no solver selection or tolerance.

The focused fixture covers serial/parallel execution, 257/16,385 rows,
1/7/52 RHS columns, zero and extreme values, and unit/supplied weights across
extreme common scales. Both certificate calculations and their resulting
workspace values match. The captured plugin passes the actual ABI fixture.

Sixteen three-pair whole-command cells complete 96 successful calls with clean
isolation. All 32 independent native inference audits, 96 within-arm repeats
and 48 candidate output audits pass. All 48 native pairs have exact finite
exports, samples, status, FE metadata, fresh certificates and saved vectors.
Every solver-report field except setup/solve time is also exact.

The paired runtime ratios range from 0.9653 to 1.0189; these are small changes,
not a broad speed breakthrough. All measured cells remain within 5% of sf1.
The original times, pair ratios and tracked allocation peaks remain in the
scores. This is development evidence, not final-block or Linux acceptance.

| Graph | Weight | K | Threads | Request | sf1 ms | in1 ms | Paired in1/sf1 |
|---|---|---:|---:|---|---:|---:|---:|
"""+ '\n'.join(rows)+"""

`verify.py` verifies the portable archive, source reconstruction and independent
auditor bindings. Output arrays remain local with hashes. Raw licensed logs
and compiled binaries are excluded. No installation, release or push occurs.
""")
print('INITIAL_OLS_NORM_ARCHIVE_PREPARED')

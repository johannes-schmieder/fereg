from pathlib import Path
p=Path('crates/fereg-core/src/fe/single_slope.rs');s=p.read_text()
s=s.replace('        let serial_norms = if self.serial_ordered', '        let mut fused_certification_seconds = 0.0;\n        let mut fused_checks_valid = false;\n        let serial_norms = if self.serial_ordered',1)
s=s.replace('            Some(if rhs <= 16 {','            let (norms, checks_valid, seconds) = if rhs <= 16 {',1)
s=s.replace('self.project_serial_ordered::<16, 64>(&original, &mut result, &mut coefficients)?', 'self.project_serial_ordered::<16, 64>(&original, &mut result, &mut coefficients, &references, &mut checks)?',1)
s=s.replace('                    &mut coefficients,\n                )?\n            })','                    &mut coefficients,\n                    &references,\n                    &mut checks,\n                )?\n            };\n            fused_certification_seconds = seconds;\n            fused_checks_valid = checks_valid;\n            Some(norms)',1)
s=s.replace('        let mut scales = references;\n        for (scale, norm) in scales.iter_mut().zip(&residual_norms) {\n            *scale = scale.max(*norm);\n        }','''        let mut scales = references;
        for (scale, norm) in scales.iter_mut().zip(&residual_norms) {
            let updated = scale.max(*norm);
            fused_checks_valid &= updated == *scale;
            *scale = updated;
        }''',1)
s=s.replace('        let certificate = self.check_matrix(&result, &scales, tolerance, &mut checks, right_scales)?;\n        let certification_seconds = certificate_started.elapsed().as_secs_f64();','''        let certificate = if fused_checks_valid {
            self.reduce_checks(&checks, rhs, tolerance)
        } else {
            self.check_matrix(&result, &scales, tolerance, &mut checks, right_scales)?
        };
        let certification_seconds = certificate_started.elapsed().as_secs_f64() + fused_certification_seconds;''',1)
s=s.replace('        right_scales: &mut [f64],\n    ) -> Result<Vec<f64>> {','''        right_scales: &mut [f64],
        references: &[f64],
        checks: &mut [Check],
    ) -> Result<(Vec<f64>, bool, f64)> {''',1)
a=s.index('    fn project_serial_ordered<');b=s.index('\n    fn check_matrix(',a)
section=s[a:b]
section=section.replace('        for level in 0..self.groups.len() {','''        let mut checks_valid = true;
        let mut certification_seconds = 0.0;
        // Independent checks consume freshly written residuals while each
        // batch is still local. Final norm enlargement invalidates all of
        // these checks and uses the ordinary full-matrix certificate instead.
        for first in (0..self.groups.len()).step_by(256) {
            let end = (first + 256).min(self.groups.len());
            for level in first..end {''',1)
needle='''        let mut norms = filled(rhs, 0.0)?;'''
section=section.replace(needle,'''            let check_started = Instant::now();
            for (level, check) in checks.iter_mut().enumerate().take(end).skip(first) {
                if checks_valid {
                    match self.check_group::<WIDTH, CELLS>(level, result, references, Some(right_scales)) {
                        Ok(fresh) => *check = fresh,
                        // A provisional scale can overflow even when the final
                        // norm rescales safely. Preserve ordinary error order
                        // by completing projection and rerunning the final check.
                        Err(_) => checks_valid = false,
                    }
                }
            }
            certification_seconds += check_started.elapsed().as_secs_f64();
        }
''' + needle,1)
section=section.replace('        Ok(norms)\n','        Ok((norms, checks_valid, certification_seconds))\n',1)
s=s[:a]+section+s[b:]
needle='''        let mut certificate = FeCertificate {'''
a=s.index('    fn check_matrix(');b=s.index(needle,a)
s=s[:b]+'''        Ok(self.reduce_checks(checks, rhs, tolerance))
    }

    fn reduce_checks(&self, checks: &[Check], rhs: usize, tolerance: f64) -> FeCertificate {
'''+s[b:]
a=s.index('    fn reduce_checks(');b=s.index('    fn check_group<',a)
section=s[a:b].replace('        Ok(certificate)','        certificate',1)
s=s[:a]+section+s[b:];p.write_text(s)

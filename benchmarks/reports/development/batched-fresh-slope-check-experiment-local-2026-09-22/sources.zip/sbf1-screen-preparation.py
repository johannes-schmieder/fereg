from pathlib import Path
art=Path('target/ols-next-20260921')
for name in ['sgk1-screen1.py','audit-sgk1-screen1.py','sgk1-solver-screen-check1.py']:
 s=(art/name).read_text().replace('sgk1','sbf1').replace('small-gram-kernel','batched-fresh-slope-certificate').replace('SMALL_GRAM_KERNEL','BATCHED_FRESH_SLOPE_CERTIFICATE')
 if name=='sgk1-screen1.py':
  start=s.index("scope='Fixed dimensions");end=s.index("')\nbroad.write",start)
  s=s[:start]+"scope='Serial ordered cached-slope projection checks fresh residuals in batches of 256 groups while preserving every recurrence and group reduction. Existing check buffers, rank basis and memory admission are unchanged. Any enlarged final reference norm or invalid provisional check reruns the ordinary full certificate. Threaded/shuffled/shared and PPML routes retain their eligibility. Ordinary fixest is excluded for FW inference."+s[end:]
 (art/name.replace('sgk1','sbf1')).write_text(s)

    #[test]
    fn batched_fresh_checks_repeat_after_norm_enlargement_or_provisional_overflow() {
        let pool = rayon::ThreadPoolBuilder::new().num_threads(1).build().unwrap();
        pool.install(|| {
            let levels = 513;
            let n = levels * 5;
            let effect = EffectTerm::new(
                (0..n).map(|row| (row / 5) as u32).collect(),
                levels,
                true,
                vec![(0..n).map(|row| (row as f64 * 0.37).sin()).collect()],
            ).unwrap();
            let partition = BorrowedInterceptEffect::new(effect.codes(), levels, effect.level_index()).unwrap();
            for rhs in [1, 12, 52] {
                for input_scale in [1.0, 1e200] {
                    for reference_scale in [0.0, 1e-300] {
                        let build = || {
                            let view = CategoricalAbsorbedEffectView::new(true, vec![effect.slopes()[0].as_slice()]).unwrap();
                            SingleSlopeAbsorber::build(partition, view, BorrowedMapWeights::Unit, rhs, None,
                                &mut SolverWorkspacePeak::ZERO).unwrap().unwrap()
                        };
                        let input = DenseMatrix::from_columns(&(0..rhs).map(|col| (0..n)
                            .map(|row| input_scale * ((row * (col + 7)) as f64 * 0.19).cos())
                            .collect()).collect::<Vec<_>>()).unwrap();
                        let references = vec![reference_scale; rhs];
                        let mut fused = build();
                        let mut ordinary = build();
                        ordinary.serial_ordered = false;
                        let SingleSlopeAttempt::Certified(a) = fused.absorb(input.clone(), 1e-8, None, Some(&references), false).unwrap()
                            else { panic!("fused projection must certify with the enlarged final norms"); };
                        let SingleSlopeAttempt::Certified(b) = ordinary.absorb(input, 1e-8, None, Some(&references), false).unwrap()
                            else { panic!("ordinary projection must certify"); };
                        assert_eq!(a.residualized(), b.residualized());
                        assert_eq!(a.report().certificate, b.report().certificate);
                        assert!(a.report().certificate.relative_infinity_norm > 0.0,
                            "the final check must not reuse the zero-scale provisional moments");
                        assert_eq!(a.report().solver_workspace_peak, b.report().solver_workspace_peak);
                    }
                }
            }
        });
    }


import subprocess,sys
from pathlib import Path
repo=Path.cwd(); art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/one_fe_optimization')); import build
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert set(files)=={'crates/fereg-core/src/fe/borrowed_map.rs','crates/fereg-core/src/fe/cmg.rs','crates/fereg-core/src/fe/lsmr_batch.rs','crates/fereg-core/src/memory.rs','crates/fereg-core/src/ols/prepared_fit.rs','crates/fereg-core/src/ols/prepared_rhs.rs','crates/fereg-core/src/fe/single_slope.rs'}
build.build(art,'sbf1','HEAD',files)

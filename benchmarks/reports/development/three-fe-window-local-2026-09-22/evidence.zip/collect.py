from pathlib import Path
import hashlib,json,re,shutil,statistics
root=Path(__file__).resolve().parent
repo=Path.cwd(); art=repo/'target/ppml-next-20260922/artifacts'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
s=json.loads((root/'screen-summary.json').read_text()); result=[]; differences=[]
for i,c in enumerate(s['cells']):
 assert all(x['clean'] and x['checks']['passed'] and x['exact']['passed'] for x in c['pairs'])
 assert all(x['checks']['passed'] for x in c['repeats'])
 rr={}
 for v in ['batch1','threadwindow1','fixest']:
  runs=[json.loads((root/'screen/runs'/f'c{i}-r{r}-{v}/result.json').read_text()) for r in range(3)]
  rr[v]=dict(rss_gib=[x['peak_rss_gib'] for x in runs],rss_samples=[x['rss_samples'] for x in runs])
 for x in c['pairs']:differences.append(x['tracked_peak_bytes']['threadwindow1']-x['tracked_peak_bytes']['batch1'])
 result.append(dict(cell=c['cell'],rss=rr))
for block in ['baseline','screen']:
 progress=json.loads((root/block/'progress.json').read_text())
 assert all(x['status']=='pass' and not x['overlaps'] and not x['monitor_errors'] for x in progress)
write(root/'decision.json',dict(disposition='Reject generic medium threaded RHS window; no production policy change',reason='Dense benefit is modest and T4 dense regresses; stop under the predeclared small/inconsistent gain rule without tuning window sizes',headline_attempts=45,native_pairs=9,exact_native_pairs=9,tracked_peak_delta_range=[min(differences),max(differences)],memory=result,unrun_confirmation='All four predeclared fresh cases; not justified after mixed screen',limitations=['Sparse stock beta/V discrepancies remain unranked','No constrained-memory qualification or memory admission acceptance']))
for name in ['identity-batch1.json','identity-threadwindow1.json','build-threadwindow1.log','fixtures-threadwindow1.json','fixtures-batch1-threefe.json']:
 shutil.copyfile(art/name,root/name)
for rel in ['benchmarks/one_fe_optimization/build.py','benchmarks/next_subsystem/threaded_lsmr_window.py','tests/stata/development/ols_three_fe_batch_oracle.do']:
 shutil.copyfile(repo/rel,root/Path(rel).name)
fixtures=[]
for variant in ['threadwindow1','batch1-threefe']:
 d=art/'fixtures'/variant/'ols_three_fe_batch_oracle'
 files={p.name:sha(p) for p in d.iterdir() if p.is_file()}
 lines=[]
 for name in ['run.log','stdout.txt']:
  lines.extend(x for x in (d/name).read_text().splitlines() if re.match(r'^(FEREG_PHASE\||FEREG_SOLVER_TRACE\||END_FIXTURE\||ACCESSOR_FIXTURE_COMPLETE)',x))
 (root/f'{variant}-fixture.protocol').write_text('\n'.join(lines)+'\n')
 fixtures.append(dict(variant=variant,files=files))
write(root/'fixture-log-hashes.json',fixtures)
for v in ['batch1','threadwindow1']:
 identity=json.loads((art/f'identity-{v}.json').read_text())
 assert all(sha(art/v/p)==h for p,h in identity['source'].items())
 assert sha(art/v/'dist/fereg_macos.plugin')==identity['plugin']
write(root/'production-binding.json',dict(source='37af7d82',matched_inputs=527,changed_captured_inputs=[p for p,h in json.loads((art/'identity-batch1.json').read_text())['source'].items() if sha(repo/p)!=h],new_fixture_sha256=sha(repo/'tests/stata/development/ols_three_fe_batch_oracle.do')))
print('CAPTURE_PASS',len(s['cells'])*3,'exact native pairs; native peak delta',min(differences),max(differences))
for x in result:print(x['cell'],{v:statistics.median(a['rss_gib']) for v,a in x['rss'].items()})

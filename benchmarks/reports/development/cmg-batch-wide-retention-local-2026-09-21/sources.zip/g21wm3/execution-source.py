import hashlib
import json
import os
from pathlib import Path
import sys

repo = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import run
import broad

artifacts = repo / 'target/ols-next-20260921'
root = repo / 'target/g21wm3'
root.mkdir(exist_ok=False)
folder = run.stage(root)
worker = folder / 'measure.py'
original = worker.read_bytes()
marker = '    environment.update(thread_environment(threads))'
text = original.decode()
assert text.count(marker) == 1
worker.write_text(text.replace(marker, marker + '\n    environment["FEREG_MEMORY_LIMIT_BYTES"] = str(cell["diagnostic_available_bytes"])\n    environment["FEREG_SOLVER_TRACE"] = "1"'))
run.write(folder / 'source-manifest.json', run.controller_manifest(folder))
sys.path.insert(0, str(folder))
measure = run.load('memory_preconditioner_measure', worker).measure
(root / 'work/refs').mkdir(parents=True)
request = json.loads(next((repo / 'target/g21wr2/runs').glob('wide-c000-*-r1-wr2/request.json')).read_text())
manifest = json.loads((repo / 'benchmarks/systematic/manifest.json').read_text())
manifest['measurement'].update(command_timeout_seconds=90, rss_interval_seconds=.05)
specs = [('admitted-cb1', 'cb1', 'auto', 'auto', 5_000_000_000),
         ('admitted-wr2', 'wr2', 'auto', 'auto', 5_000_000_000),
         ('diagonal', 'wr2', 'lsmr', 'diagonal', 2_536_870_912),
         ('off', 'wr2', 'lsmr', 'off', 2_036_870_912)]
plan = dict(schema='ols-preconditioner-memory-diagnostic-v1', specs=specs,
    scope='Diagnostic application, scientific and admission checks. Not paired timing or a new routing policy.',
    controller_sha256=broad.sha(Path(__file__)), runner_sha256=broad.sha(Path(run.__file__)),
    original_worker_sha256=hashlib.sha256(original).hexdigest(), worker_sha256=broad.sha(worker))
broad.write(root / 'diagnostic-plan.json', plan)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
records = []
os.environ['ONE_FE_BREADTH_OUTPUTS'] = 'all'
for label, variant, solver, preconditioner, available in specs:
    identity = json.loads((artifacts / f'identity-{variant}.json').read_text())
    assert broad.sha(artifacts / variant / 'dist/fereg_macos.plugin') == identity['plugin']
    cell = dict(request['cell'], diagnostic_available_bytes=available,
        fit_options=f'residuals(out_resid) preconditioner({preconditioner}) memory(fast)')
    fingerprint = dict(native=identity, controller={p.name: broad.sha(p) for p in folder.iterdir() if p.is_file()},
        harness_sha256=broad.sha(Path(__file__)))
    output = root / 'runs' / (label + '-' + variant)
    result = measure(root, cell, 'fereg', 'warm', Path(request['data']), Path(request['warm']),
        output, manifest, identity=fingerprint, source=artifacts / variant, trace=True, solver=solver)
    records.append(dict(label=label, variant=variant, solver=solver, preconditioner=preconditioner,
        available_bytes=available, status=result['status'], result_sha256=broad.sha(output / 'result.json')))
    broad.write(root / 'diagnostic-progress.json', records)
    print(label, result['status'], result['seconds'], result.get('metadata', {}).get('rc'), flush=True)
broad.write(root / 'diagnostic-complete.json', dict(status='attempts_complete', planned=len(specs), attempted=len(records),
    plan_sha256=broad.sha(root / 'diagnostic-plan.json'), progress_sha256=broad.sha(root / 'diagnostic-progress.json')))

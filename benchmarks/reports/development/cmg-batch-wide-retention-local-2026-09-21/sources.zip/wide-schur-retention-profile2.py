import json
import os
from pathlib import Path
import re
import subprocess

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
failed = next((repo / 'target/g21r1/runs').glob('route-c005-r1-auto-*/request.json'))
request = json.loads(failed.read_text())
root = artifacts / 'wide-schur-retention-profile2'
root.mkdir(exist_ok=False)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
records = []
for variant in ['wr1']:
    out = root / variant
    out.mkdir()
    source = artifacts / variant
    program = f'''version 19.0
clear all
set more off
set varabbrev off
set processors 8
sysdir set PLUS "{out}"
sysdir set PERSONAL "{out}"
capture adopath - SITE
capture adopath - "."
adopath ++ "{source}/stata"
adopath ++ "{source}/dist"
quietly use "{request['data']}", clear
capture noisily fereg y x1-x50, absorb(out_fe1=g1 out_fe2=g2) threads(1) solver(auto) poolsize(10) vce(cluster c1 c2) residuals(out_resid) memory(fast)
local result = _rc
display "MEMORY_DIAGNOSTIC_RC|`result'"
display "MEMORY_DIAGNOSTIC_COMPLETE"
exit, clear
'''
    (out / 'run.do').write_text(program)
    env = dict(os.environ, FEREG_PHASE_TIMING='1')
    env.pop('FEREG_MEMORY_LIMIT_BYTES', None)
    with (out / 'stdout.txt').open('x') as stream:
        result = subprocess.run(['<stata-installation>/StataMP.app/Contents/MacOS/stata-mp',
                                 '-b', 'do', 'run.do'], cwd=out, env=env,
                                stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    log = (out / 'run.log').read_text(errors='replace')
    codes = re.findall(r'^MEMORY_DIAGNOSTIC_RC\|(\d+)\s*$', log, re.MULTILINE)
    assert len(codes) == 1
    records.append(dict(variant=variant, process_returncode=result.returncode, plugin=json.loads((artifacts / ('identity-' + variant + '.json')).read_text())['plugin'], scope='Diagnostic phase trace, not a headline timing',
        application_returncode=int(codes[0]), sentinel=any(line.strip() == 'MEMORY_DIAGNOSTIC_COMPLETE' for line in log.splitlines())))
    (root / 'attempts.json').write_text(json.dumps(records, indent=2) + '\n')
    print(records[-1], flush=True)

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science

output = repo / 'benchmarks/reports/development/cmg-batch-wide-retention-local-2026-09-21'
roots = [repo / 'target' / name for name in ['g21cb1', 'g21cb2', 'g21cb3', 'g21wr1', 'g21wr2', 'g21wm1', 'g21wm2', 'g21wm3', 'g21wm4']]
for root in roots:
    terminal = 'memory-dispatch.json' if root.name in ['g21wm1', 'g21wm2'] else \
        'diagnostic-complete.json' if root.name.startswith('g21wm') else 'screen-complete.json'
    assert (root / terminal).is_file()
archive_science.archive(roots, output, compact=True, omit_output_arrays=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def portable(data):
    return data.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>') \
        .replace(b'<stata-installation>', b'<stata-installation>') \
        .replace(b'<reference-library>', b'<reference-library>')

tables = {'sources': {}, 'checks': {}}
with zipfile.ZipFile(output / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw)
        bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['m4', 'm5', 'cb1', 'wr1', 'wr2']:
        path = artifacts / f'identity-{variant}.json'
        identity = json.loads(path.read_text())
        add(path.name, path.read_bytes())
        for relative in identity['overlays']:
            data = (artifacts / variant / relative).read_bytes()
            assert sha(data) == identity['source'][relative]
            add(variant + '/' + relative, data)
    for root in roots:
        add(root.name + '/execution-source.py', (root / 'execution-source.py').read_bytes())
        if root.name.startswith('g21wm'):
            continue
        plan = json.loads((root / 'screen-plan.json').read_text())
        revision = 'c668aa92' if root.name in ['g21cb1', 'g21cb2'] else '18b4cd83'
        data = subprocess.check_output(['/opt/homebrew/bin/git', 'show', revision + ':benchmarks/two_fe_dense/route_development.py'], cwd=repo)
        assert sha(data) == plan['isolation_source_sha256']
        add(root.name + '/route_development.py', data)
    for name in ['audit_milestone.py', 'audit_outputs.py', 'graph_oracle.py', 'run.py']:
        add(name, (repo / 'benchmarks/two_fe_dense' / name).read_bytes())
    for name in ['score-kernel-screen1.py', 'score-kernel-screen2.py', 'audit-milestone-pre-native-only1.py', 'wide-schur-retention-profile1.py',
                 'wide-schur-retention-profile2.py', 'audit-wr2-memory1.py', 'archive-cmg-wide1.py']:
        add(name, (artifacts / name).read_bytes())
    add('test_route_timing_isolation.py', (repo / 'tests/python/test_route_timing_isolation.py').read_bytes())
    add('wide-memory-estimate1.rs', (artifacts / 'wide-memory-estimate1.rs').read_bytes())

names = ['cb1-batch-subtraction-tests1.txt', 'wr1-wide-retention-tests1.txt',
         'wr1-narrow-retention-tests1.txt', 'timing-isolation-tests1.txt',
         'cb1-screen-inference1.json', 'cb1-screen-inference1.txt', 'cb1-screen-outputs1.txt', 'cb1-screen-score1.json',
         'cb1-repeat-inference1.json', 'cb1-repeat-inference1.txt', 'cb1-repeat-outputs1.txt', 'cb1-repeat-score1.json',
         'cb1-ancestry-inference1.json', 'cb1-ancestry-inference1.txt', 'cb1-ancestry-outputs1.txt', 'cb1-ancestry-score1.json',
         'wr1-screen-inference1.json', 'wr1-screen-inference1.txt', 'wr1-screen-outputs1.txt', 'wr1-screen-score1.json',
         'wr2-screen-inference1.json', 'wr2-screen-inference1.txt', 'wr2-screen-outputs1.txt', 'wr2-screen-score1.json',
         'wr2-memory-inference1.json', 'wr2-memory-check1.json',
         'wr2-memory-admitted-cb1-outputs1.txt', 'wr2-memory-admitted-wr2-outputs1.txt', 'wr2-memory-auto-wr2-outputs1.txt',
         'wide-memory-estimate1.txt', 'wide-memory-estimate1-binding.json',
         'wide-schur-retention-profile1/attempts.json', 'wide-schur-retention-profile2/attempts.json']
with zipfile.ZipFile(output / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add_check(name, raw, **extra):
        clean = portable(raw)
        bundle.writestr(name, clean)
        tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean), **extra)
    for name in names:
        add_check(name, (artifacts / name).read_bytes())
    for number, variant in [(1, 'm5'), (2, 'wr1')]:
        path = artifacts / f'wide-schur-retention-profile{number}' / variant / 'stdout.txt'
        raw = path.read_bytes()
        phases = ('\n'.join(line for line in raw.decode().splitlines() if line.startswith('FEREG_PHASE|')) + '\n').encode()
        add_check(f'wide-profile-{variant}-phases.txt', phases, original_stream_sha256=sha(raw),
                  extraction='Only lines beginning FEREG_PHASE|, in their original order.')
    for root in roots:
        if root.name not in ['g21wm3', 'g21wm4']:
            continue
        for path in sorted((root / 'runs').glob('*/stderr.txt')):
            raw = path.read_bytes()
            trace = ('\n'.join(line for line in raw.decode().splitlines() if line.startswith(('FEREG_PHASE|', 'FEREG_SOLVER_TRACE|'))) + '\n').encode()
            add_check(root.name + '/' + path.parent.name + '/native-trace.txt', trace,
                      original_stream_sha256=sha(raw), extraction='Only native phase/solver trace lines, in original order.')
for name, hashes in tables.items():
    (output / (name + '-hashes.json')).write_text(json.dumps(hashes, indent=2) + '\n')
print('CMG_WIDE_SUPPLEMENTS_COMPLETE', flush=True)

import hashlib
import json
from pathlib import Path
import subprocess
import sys

repo = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import run
import route_development

for index, usable in enumerate([300_000_000, 1_500_000_000], start=1):
    root = repo / f'target/g21wm{index}'
    root.mkdir(exist_ok=False)
    folder = run.stage(root)
    worker = folder / 'measure.py'
    original = worker.read_bytes()
    marker = '    environment.update(thread_environment(threads))'
    text = original.decode()
    assert text.count(marker) == 1
    available = usable + 536_870_912
    worker.write_text(text.replace(marker, marker + '\n    environment["FEREG_MEMORY_LIMIT_BYTES"] = ' + repr(str(available))))
    run.write(folder / 'source-manifest.json', run.controller_manifest(folder))
    cell = route_development.cells(1)[69]
    command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root),
        '--artifacts', str(repo / 'target/ols-next-20260921'), '--label', 'memory',
        '--variants', 'cb1', 'wr2', '--repeats', '1', '--timeout', '60', '--keep-going',
        *broad.arguments(cell)]
    plan = dict(schema='ols-wide-retention-memory-development-v1', cell=cell, command=command,
        usable_bytes=usable, available_bytes=available, reserve_bytes=536_870_912,
        variants=['cb1', 'wr2'], expected='preparation_rejection' if index == 1 else 'scientific_pass',
        scope='Admission, outputs and observed memory only; no timing claim.',
        original_worker_sha256=hashlib.sha256(original).hexdigest(),
        worker_sha256=broad.sha(worker), controller_sha256=broad.sha(Path(__file__)))
    broad.write(root / 'memory-plan.json', plan)
    (root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
    with (root / 'memory.stdout.txt').open('x') as stream:
        code = subprocess.call(command, stdout=stream, stderr=subprocess.STDOUT)
    broad.write(root / 'memory-dispatch.json', dict(process_returncode=code,
        plan_sha256=broad.sha(root / 'memory-plan.json'), stdout_sha256=broad.sha(root / 'memory.stdout.txt')))
    print(root.name, usable, code, flush=True)

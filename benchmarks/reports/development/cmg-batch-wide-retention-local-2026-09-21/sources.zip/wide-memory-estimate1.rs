fn main() {
    for threads in [1, 8, 16] {
        let estimate = fereg_core::memory::estimate_fe_solver_memory(
            245_760, 52, &[81_920, 2_048], threads, Some(4),
        ).unwrap();
        println!("threads={threads}\n{estimate:#?}");
    }
}

import argparse
import json
from pathlib import Path
import statistics
import sys

repo = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import graph_oracle
from score import sha

p = argparse.ArgumentParser()
p.add_argument('root', type=Path)
p.add_argument('output', type=Path)
a = p.parse_args()
assert not a.output.exists()
plan = json.loads((a.root / 'screen-plan.json').read_text())
progress = json.loads((a.root / 'screen-progress.json').read_text())
exports = ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv']
records = []
for attempt in progress:
    extra = plan.get('extra_control')
    extra_variant = extra['variant'] if extra and extra['index'] == attempt['index'] else None
    variants = ([extra_variant] if extra_variant else []) + plan['variants']
    rows = {v: sorted((a.root / 'runs').glob(attempt['label'] + '-*-' + v + '/result.json')) for v in variants}
    assert all(len(paths) == plan['repeats'] for paths in rows.values())
    pairs = []
    for index in range(plan['repeats']):
        paths = {v: rows[v][index] for v in variants}
        data = {v: json.loads(path.read_text()) for v, path in paths.items()}
        assert all(d['status'] == 'pass' for d in data.values())
        times = {v: d['seconds'] for v, d in data.items()}
        baseline, candidate = plan['baseline'], plan['candidate']
        names = exports + (['outputs.bin'] if data[candidate]['cell']['outputs'] != 'none' else [])
        pairs.append(dict(rep=index + 1, seconds=times,
            native_ratio=times[candidate] / times[baseline],
            reference_ratio=times[candidate] / times['fixest'],
            native_exports_equal={name: sha(paths[candidate].parent / name) == sha(paths[baseline].parent / name) for name in names},
            sample_equal=data[candidate]['sample_sha256'] == data[baseline]['sample_sha256'],
            native_peaks={v: data[v]['metadata']['fereg_native_allocation_bytes'] for v in [baseline, candidate]},
            result_sha256={v: sha(path) for v, path in paths.items()}))
    record = dict(index=attempt['index'], cell=attempt['cell'], isolation=attempt['timing_isolation']['status'],
        pairs=pairs, median_seconds={v: statistics.median(pair['seconds'][v] for pair in pairs) for v in variants},
        median_native_ratio=statistics.median(pair['native_ratio'] for pair in pairs),
        median_reference_ratio=statistics.median(pair['reference_ratio'] for pair in pairs))
    if extra_variant:
        first = rows[extra_variant][0]
        dataset = Path(json.loads((first.parent / 'request.json').read_text())['data'])
        result = json.loads(first.read_text())
        record['extra_oracle'] = graph_oracle.compare(first, graph_oracle.solve(dataset, attempt['cell']['weight_kind'], result['cell']['vce']))
        record['extra_repeat_exports_equal'] = [all(sha(path.parent / name) == sha(first.parent / name) for name in names) for path in rows[extra_variant]]
        record['median_baseline_extra_ratio'] = statistics.median(pair['seconds'][baseline] / pair['seconds'][extra_variant] for pair in pairs)
    records.append(record)
receipt = dict(schema='ols-kernel-screen-score-v1', plan_sha256=sha(a.root / 'screen-plan.json'),
    progress_sha256=sha(a.root / 'screen-progress.json'), controller_sha256=sha(Path(__file__)), cells=records)
a.output.write_text(json.dumps(receipt, indent=2) + '\n')
for record in records:
    print(record['index'], record['isolation'], record['median_seconds'], record['median_native_ratio'], record.get('median_baseline_extra_ratio'), flush=True)

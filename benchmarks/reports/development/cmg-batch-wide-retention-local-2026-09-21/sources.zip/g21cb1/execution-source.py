import json
from pathlib import Path
import sys

repo = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route

artifacts = repo / 'target/ols-next-20260921'
root = repo / 'target/g21cb1'
root.mkdir(exist_ok=False)
selection = [(32, 16), (35, 16), (67, 16), (71, 16), (75, 16), (79, 16),
             (71, 8), (79, 8), (27, 16), (64, 16)]
cells = [route.cells(threads)[index] for index, threads in selection]
plan = dict(schema='ols-cmg-batch-subtraction-screen-v1', cells=cells, selection=selection,
    baseline='m5', candidate='cb1', variants=['m5', 'cb1', 'fixest'], repeats=3,
    extra_control=dict(index=9, variant='m4', purpose='Repeat the earlier unit-ring robust regression.'),
    controller_sha256=broad.sha(Path(__file__)),
    isolation_source_sha256=broad.sha(Path(route.__file__)),
    acceptance='Exploratory screen; independent numerical audits precede any acceptance.')
broad.write(root / 'screen-plan.json', plan)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
records = []
for index, cell in enumerate(cells):
    label = f'batch-c{index:03d}'
    variants = (['m4'] if index == 9 else []) + plan['variants']
    command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root),
        '--artifacts', str(artifacts), '--label', label, '--variants', *variants,
        '--repeats', '3', '--timeout', '60', '--keep-going',
        '--record-reference-science-disagreement', '--record-reference-output-disagreement',
        *broad.arguments(cell)]
    code, isolation = route.invoke(command, root / (label + '.stdout.txt'))
    complete = root / (label + '-complete.json')
    records.append(dict(index=index, cell=cell, label=label, command=command,
        process_returncode=code, timing_isolation=isolation,
        completion=json.loads(complete.read_text()) if complete.exists() else None))
    broad.write(root / 'screen-progress.json', records)
    print(index + 1, '/', len(cells), label, code, isolation['status'], flush=True)
broad.write(root / 'screen-complete.json', dict(status='attempts_complete',
    attempted=len(records), planned=len(cells), plan_sha256=broad.sha(root / 'screen-plan.json'),
    progress_sha256=broad.sha(root / 'screen-progress.json')))

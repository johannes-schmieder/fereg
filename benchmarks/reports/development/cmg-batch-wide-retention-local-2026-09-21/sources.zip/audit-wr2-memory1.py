from contextlib import redirect_stdout
import csv
import hashlib
import json
from pathlib import Path
import re
import sys

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import audit_outputs
import graph_oracle
from score import sha

records, checks, oracles = [], [], {}
for name in ['g21wm1', 'g21wm2', 'g21wm3', 'g21wm4']:
    root = repo / 'target' / name
    for path in sorted((root / 'runs').glob('*/result.json')):
        result = json.loads(path.read_text())
        request = json.loads((path.parent / 'request.json').read_text())
        record = dict(root=name, run=path.parent.name, status=result['status'],
            process_returncode=result['process_returncode'], sentinel=result['sentinel'],
            application_returncode=result.get('metadata', {}).get('rc'),
            result_sha256=sha(path), request_sha256=sha(path.parent / 'request.json'))
        if result['status'] == 'pass':
            cell = result['cell']
            key = (Path(request['data']), cell['weight_kind'], cell['vce'])
            if key not in oracles:
                oracles[key] = graph_oracle.solve(*key)
            checked = graph_oracle.compare(path, oracles[key])
            checks.append(checked)
            record['independent_inference'] = checked['status']
            with (path.parent / 'fereg_runtime.csv').open() as stream:
                runtime = {(int(row['row']), int(row['column'])): float(row['value']) for row in csv.DictReader(stream)}
            record['available_bytes'] = runtime[6, 2]
            record['usable_bytes'] = runtime[8, 2]
            record['observed_allocation_peak_bytes'] = runtime[13, 2]
            record['observed_peak_below_cap'] = runtime[13, 2] <= runtime[8, 2]
            record['input_sha256'] = result['input_sha256']
            record['sample_sha256'] = result['sample_sha256']
            assert record['observed_peak_below_cap']
        else:
            matches = []
            for log in path.parent.glob('*.log'):
                codes = re.findall(r'^SYSTEMATIC_WARMUP_FAILED rc=(\d+)\s*$', log.read_text(errors='replace'), re.MULTILINE)
                matches.extend(dict(application_returncode=int(code), log_sha256=sha(log)) for code in codes)
            if matches:
                record['warmup_failures'] = matches
        records.append(record)
for prefix, variant, name in [('admitted', 'cb1', 'g21wm3'), ('admitted', 'wr2', 'g21wm3'), ('auto', 'wr2', 'g21wm4')]:
    with (artifacts / f'wr2-memory-{prefix}-{variant}-outputs1.txt').open('x') as stream:
        with redirect_stdout(stream):
            audit_outputs.audit(repo / 'target' / name, prefix, variant)
assert len(records) == 10
assert len(checks) == 4 and all(check['status'] == 'pass' for check in checks)
assert len({record['input_sha256'] for record in records if record['status'] == 'pass'}) == 1
assert len({record['sample_sha256'] for record in records if record['status'] == 'pass'}) == 1
assert all(record['application_returncode'] == 909 for record in records if record['root'] == 'g21wm1')
assert all(record['status'] == 'command_timeout' for record in records if record['root'] == 'g21wm2')
assert sum(bool(record.get('warmup_failures')) for record in records) == 2
for name, data in [('wr2-memory-inference1.json', checks), ('wr2-memory-check1.json', dict(
    schema='ols-wide-retention-memory-audit-v1', controller_sha256=sha(Path(__file__)),
    records=records, successful_independent_checks=4,
    limitation='Two allocation rejections, two timeouts and two explicit-LSMR warm-up failures remain recorded. No timing or policy acceptance.'))]:
    output = artifacts / name
    assert not output.exists()
    output.write_text(json.dumps(data, indent=2) + '\n')
print('WIDE_MEMORY_AUDIT_PASS', len(records), len(checks), flush=True)

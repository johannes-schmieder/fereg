import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'scripts');from run_stata_tests import run_fixture,expected_sentinel
r=Path(__file__).parent;root=Path('.').resolve();rows=[]
for v,f in [('parproj1','parity_ppmlhdfe/estimate_ppml_hidden_transaction.do'),('ppmlproj1','installation/estimate_ols_eclass_transaction.do'),('ppmlproj1','parity_reghdfe/estimate_ols_intercept_slope_parity.do')]:
 plugin=(Path('target/ppml-next-20260922/artifacts')/v/'dist/fereg_macos.plugin').resolve();h=hashlib.sha256(plugin.read_bytes()).hexdigest();p=root/'tests/stata'/f
 result=run_fixture('/Applications/Stata/StataMP.app/Contents/MacOS/stata-mp',p,root,plugin=plugin,plugin_sha256=h,log_dir=r/('licensed-logs-'+v),require_status=True)
 rows.append(dict(variant=v,fixture=f,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),plugin=h,process_returncode=result.process_returncode,stata_rc=result.stata_rc,error=result.error,failure_kind=result.failure_kind,terminal_sentinel=expected_sentinel(p) in result.log_text))
 (r/'fixtures-followup.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(v,f,result.error or 'PASS',flush=True)

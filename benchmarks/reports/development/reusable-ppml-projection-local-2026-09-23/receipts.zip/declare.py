from pathlib import Path
import json,subprocess
r=Path(__file__).parent
base=json.loads(Path('target/ppml-breadth-20260923/strict-screen-cells.json').read_text())
pairs=[base[2],base[3]]
fresh=[dict(base[3],n=61440,k=10,threads=8),dict(base[2],threads=1),base[4],base[0]]
pilot=[dict(c,n=2400,k=4) for c in pairs]
controls=[dict(model='ols',design='strong_d6',n=30720,k=6,threads=4,slope_partitions={'g1':['z1'],'g2':['z2']}),dict(model='ols',design='three_fe_dense',n=30720,k=6,threads=4)]
for name,cells in [('pairs',pairs),('fresh',fresh),('pilot',pilot),('controls',controls),('profile',pairs)]:
 (r/(name+'-cells.json')).write_text(json.dumps(cells,indent=2)+'\n')
(r/'predeclared.json').write_text(json.dumps(dict(base_commit='fa20dfd5',baseline='parproj1',candidate='ppmlproj1',overlays=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines(),hypothesis='Admit optional group-coefficient and row-projection storage for the complete PPML publication MAP session; recompute current-weight coefficients on every call. No weighted geometry cache.',seeds=dict(pairs=202609292,fresh=202609293,pilot=202609294,controls=202609295,profile=202609296),repeats=3,limits='One structural candidate, no case/seed guard tuning. Strict public stock tolerances as previously adjudicated; native sample, means, beta, V, objectives and fresh-state checks remain mandatory. Mu exploration and non-MAP engines stay excluded because of distinct parent/solver lifetimes. Constrained-memory availability refusal retains serial.'),indent=2)+'\n')

import json,hashlib,sys
from pathlib import Path
sys.path.insert(0,'benchmarks/next_subsystem');from audit import exact_exports
r=Path(__file__).parent;rows=[]
for i in range(2):
 a,b=[r/'native-profile'/f'runs/c{i}-r0-{v}' for v in ['ppmlbreadth_profile','ppmlproj_profile']]
 x=exact_exports(a,b);same=(a/'means.bin').read_bytes()==(b/'means.bin').read_bytes();assert x['passed'] and same
 rows.append(dict(case=i,exact=x,exact_means=same,mean_sha256=hashlib.sha256((b/'means.bin').read_bytes()).hexdigest()))
(r/'profile-exact-audit.json').write_text(json.dumps(rows,indent=2)+'\n')

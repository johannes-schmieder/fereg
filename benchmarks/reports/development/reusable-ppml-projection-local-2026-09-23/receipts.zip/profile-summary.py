import json
from pathlib import Path
r=Path(__file__).parent;results=[]
for case in range(2):
 for v in ['ppmlbreadth_profile','ppmlproj_profile']:
  sums={};counts={};teams=[]
  for line in (r/'native-profile'/f'runs/c{case}-r0-{v}/stderr.txt').read_text().splitlines():
   if not line.startswith('FEREG_PHASE|'):continue
   parts=line.split('|');d=dict(x.split('=',1) for x in parts[2:])
   if d.get('rows')!='30720':continue
   if parts[1]=='ppml_map' or (parts[1]=='owned_fe' and d.get('phase')=='projection'):
    key=parts[1]+':'+d['phase']+':rhs'+d['rhs'];sums[key]=sums.get(key,0)+float(d['seconds']);counts[key]=counts.get(key,0)+1
   if parts[1]=='owned_projection_parallel':teams.append(int(d['threads']))
  assert all(t==4 for t in teams)
  x=dict(case=case,variant=v,seconds=sums,counts=counts,parallel_calls=len(teams),threads=sorted(set(teams)));results.append(x)
  print(case,v,'parallel calls',len(teams),[(prefix,sum(s for k,s in sums.items() if k.startswith(prefix)),sum(s for k,s in counts.items() if k.startswith(prefix))) for prefix in ['owned_fe:projection','ppml_map:certificate','ppml_map:absorb']])
(r/'native-phase-summary.json').write_text(json.dumps(results,indent=2)+'\n')

import subprocess,sys
from pathlib import Path
r=Path(__file__).parent;py='target/one-fe-profile-20260919/python/bin/python'
settings={'pilot':(202609294,1,['parproj1','ppmlproj1','fixest'],'--ppml-surface'), 'pairs':(202609292,3,['parproj1','ppmlproj1','fixest'],'--ppml-surface'),'fresh':(202609293,3,['parproj1','ppmlproj1','fixest'],'--ppml-surface'),'controls':(202609295,3,['parproj1','ppmlproj1'],'--surface')}
for label in sys.argv[1:]:
 seed,repeats,variants,surface=settings[label]
 args=[py,'benchmarks/next_subsystem/run.py',str(r/label),surface,'--artifacts','target/ppml-next-20260922/artifacts','--variants',*variants,'--fixest-archive','target/one-fe-profile-20260919/fixest.tar.gz','--cells',str(r/(label+'-cells.json')),'--seed',str(seed),'--repeats',str(repeats)]
 with (r/(label+'-driver.log')).open('x') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)

import json,csv,sys,statistics,hashlib,subprocess
from pathlib import Path
r=Path(__file__).parent;py='target/one-fe-profile-20260919/python/bin/python';sys.path.insert(0,'benchmarks/next_subsystem')
from audit import compare,exact_exports
for b in ['fresh','controls','pilot']:
 subprocess.run([py,'benchmarks/next_subsystem/summarize.py',str(r/b),str(r/f'{b}-summary.json'),'parproj1','ppmlproj1'],check=True)
clock_columns={'fereg_solver.csv':{9,10},'feppml_solver.csv':{14,15,16}}
solvers=[];repeats=[];means={};pairs=[];times=[]
for b in ['pilot','pairs','fresh','controls']:
 root=r/b;plan=json.loads((root/'plan.json').read_text());progress=json.loads((root/'progress.json').read_text());summary=json.loads((r/f'{b}-summary.json').read_text())
 for i,c in enumerate(summary['cells']):
  assert all(p['clean'] and p['checks']['passed'] and p['exact']['passed'] for p in c['pairs']),(b,i)
  for j in range(plan['repeats']):
   paths=[root/f'runs/c{i}-r{j}-{v}' for v in ['parproj1','ppmlproj1']]
   name='feppml_solver.csv' if c['cell']['model']=='ppml' else 'fereg_solver.csv'
   parts=[]
   for p in paths:
    with (p/name).open() as f:parts.append([(x['row'],x['column'],x['value'].strip()) for x in csv.DictReader(f) if int(x['column']) not in clock_columns[name]])
   solvers.append(dict(block=b,case=i,repetition=j,exact=parts[0]==parts[1],fields=len(parts[0])))
   assert parts[0]==parts[1],(b,i,j,'solver')
   if c['cell']['model']=='ppml':
    same=(paths[0]/'means.bin').read_bytes()==(paths[1]/'means.bin').read_bytes();assert same
    pairs.append(dict(block=b,case=i,repetition=j,exact_means=same))
  for v in plan['variants']:
   first=root/f'runs/c{i}-r0-{v}'
   for j in range(1,plan['repeats']):
    other=root/f'runs/c{i}-r{j}-{v}';check=compare(first,other,c['cell']['model']);exact=exact_exports(first,other)
    equal_means=(first/'means.bin').read_bytes()==(other/'means.bin').read_bytes() if (first/'means.bin').exists() else None
    repeats.append(dict(block=b,case=i,variant=v,repetition=j,checks=check,exact=exact,exact_means=equal_means))
    assert check['passed'] and exact['passed'] and equal_means is not False
  distributions={v:{k:round(f([p['seconds']*1000 for p in progress if p['case']==i and p['variant']==v]),3) for k,f in [('minimum',min),('median',statistics.median),('maximum',max)]} for v in plan['variants']}
  row=dict(block=b,case=i,cell=c['cell'],milliseconds=distributions,paired_ratio=c['ratios'],heap_delta=[p['tracked_peak_bytes']['ppmlproj1']-p['tracked_peak_bytes']['parproj1'] for p in c['pairs']]);times.append(row)
  print(b,i,distributions,c['ratios'],'heap',row['heap_delta'],flush=True)
 for p in (root/'runs').glob('*/means.bin'):means[str(p.relative_to(r))]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for name,obj in [('timing-summary',times),('solver-field-audit',dict(clock_columns={k:sorted(v) for k,v in clock_columns.items()},records=solvers)),('repeat-audit',repeats),('mean-hashes',means),('exact-mean-pairs',pairs)]:
 (r/f'{name}.json').write_text(json.dumps(obj,indent=2)+'\n')

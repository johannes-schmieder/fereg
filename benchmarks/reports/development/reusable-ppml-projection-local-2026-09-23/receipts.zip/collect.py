import json,hashlib,shutil,re
from pathlib import Path
r=Path(__file__).parent;a=Path('target/ppml-next-20260922/artifacts');apps=[]
for b in ['pilot','pairs','fresh','controls','native-profile']:
 rows=json.loads((r/b/'progress.json').read_text());assert all(x['status']=='pass' and not x['overlaps'] and not x['monitor_errors'] for x in rows)
 apps.append(dict(block=b,attempts=len(rows),passes=len(rows),timeouts=0,overlaps=0,monitor_errors=0))
for b in ['pilot','pairs','fresh','profile']:
 audit=json.loads((r/f'{b}-audit.json').read_text())
 for x in audit['records']:
  assert all(p['checks']['passed'] for p in x['pairs']) and all(p['passed'] for p in x['public_states'].values())
  assert all(p['passed'] for p in x['oracles'].values())
(r/'application-audit.json').write_text(json.dumps(apps,indent=2)+'\n')
for v in ['parproj1','ppmlproj1','ppmlbreadth_profile','ppmlproj_profile']:
 for name in ['identity','build']:shutil.copy2(a/f'{name}-{v}.json' if name=='identity' else a/f'{name}-{v}.log',r/f'{name}-{v}.json' if name=='identity' else r/f'artifact-{name}-{v}.log')
 for f in ['fe/projection.rs','fe/map.rs','fe/mod.rs','fe/borrowed_map.rs','ols/linear_session.rs','ppml/memory.rs','ppml/prepared_irls.rs']:
  shutil.copy2(a/v/'crates/fereg-core/src'/f,r/(v+'-'+f.replace('/','-')))
for name in ['run','surface','ppml_surface','ppml_audit','profile','designs','oracles','summarize','audit','archive','test_surface','test_ppml_surface']:
 shutil.copy2(Path('benchmarks/next_subsystem')/f'{name}.py',r/f'{name}.py')
for name in ['oracle','common']:shutil.copy2(Path('benchmarks/systematic')/f'{name}.py',r/f'systematic-{name}.py')
shutil.copy2('benchmarks/one_fe_optimization/build.py',r/'build.py');shutil.copy2('target/ppml-breadth-20260923/stock-reference.json',r/'stock-reference.json')
shutil.copy2('target/ppml-breadth-20260923/python-dependencies.json',r/'python-dependencies.json')
fixtures=[]
for name in ['fixtures','fixtures-followup']:
 for x in json.loads((r/f'{name}.json').read_text()):
  v=x.get('variant','ppmlproj1');x['variant']=v;fixtures.append(x);p=Path('tests/stata')/x['fixture'];shutil.copy2(p,r/p.name)
  text=f"variant={v}\nfixture={x['fixture']}\nprocess_returncode={x['process_returncode']}\nstata_rc={x['stata_rc']}\n"
  if x['terminal_sentinel']:text+=f'END_FIXTURE|{p.stem}|rc=0\n'
  else:
   folder=r/('licensed-logs' if name=='fixtures' else 'licensed-logs-'+v)
   log=(folder/('tests__stata__'+x['fixture'].replace('/','__')+'.log')).read_text()
   expected='. assert e(feppml_receipt)[1,3] == 2\nassertion is false\nr(9);';assert expected in log
   text+=expected+'\nThe unchanged source PPML_RESULT_WIRE_VERSION is 1.3. No terminal success claimed.\n'
  (r/f'{v}-{p.stem}.protocol').write_text(text)
(r/'fixture-adjudication.json').write_text(json.dumps(dict(passes=sum(x['terminal_sentinel'] for x in fixtures),failures=[x for x in fixtures if not x['terminal_sentinel']],conclusion='Unchanged hidden PPML transaction fixture expects minor 2; source emits minor 3. Both baseline and candidate fail at the same assertion after prior failure-atomicity stages. Fixture is preserved and not counted as passing.'),indent=2)+'\n')
summary=dict(headline_calls=66,native_exact_pairs_including_pilots=26,native_exact_solver_pairs=26,native_exact_mean_pairs=20,repeat_checks=44,stock_headline_comparisons=18,independent_pilots=2,rust_tests=65,licensed_fixtures_passed=4,licensed_failures=2,source_inputs=529)
(r/'acceptance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(apps,summary)

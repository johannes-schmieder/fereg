from pathlib import Path
import json
from collections import defaultdict

r = Path(__file__).parent
result = []
for case, tag in [(i,t) for i in range(2) for t in ["incrementbaseledger1"]]:
    spans = []
    path = r / f'profile/runs/c{case}-r0-{tag}/stderr.txt'
    for line in path.read_text().splitlines():
        if not line.startswith('FEREG_PHASE|span|'):
            continue
        d = dict(t.split('=', 1) for t in line.split('|')[2:])
        spans.append(dict(name=d['name'], rows=int(d['rows']),
                          start=int(d['start_ns']), end=int(d['end_ns'])))
    roots = [s for s in spans if s['name'] == 'plugin:estimate']
    assert len(roots) == 2
    root = max(roots, key=lambda s: s['start'])
    selected = [s for s in spans if s['start'] >= root['start'] and s['end'] <= root['end']]
    metrics = defaultdict(lambda: dict(calls=0, inclusive_ms=0., exclusive_ms=0.))
    for s in selected:
        contained = sorted([(c['start'], c['end']) for c in selected
                            if c is not s and c['start'] >= s['start'] and c['end'] <= s['end']])
        covered = 0
        end = s['start']
        for a, b in contained:
            covered += max(0, b - max(a, end))
            end = max(end, b)
        m = metrics[s['name']]
        m['calls'] += 1
        m['inclusive_ms'] += (s['end'] - s['start']) / 1e6
        m['exclusive_ms'] += (s['end'] - s['start'] - covered) / 1e6
    total = (root['end'] - root['start']) / 1e6
    assert abs(sum(m['exclusive_ms'] for m in metrics.values()) - total) < 1e-6
    result.append(dict(case=case, artifact=tag, plugin_ms=total, phases=dict(metrics), raw_spans=selected))
    print('CASE', case, tag, 'plugin', round(total, 3))
    for name, m in sorted(metrics.items(), key=lambda item: -item[1]['exclusive_ms']):
        print(name, m)
(r / 'profile-summary.json').write_text(json.dumps(result, indent=2) + '\n')

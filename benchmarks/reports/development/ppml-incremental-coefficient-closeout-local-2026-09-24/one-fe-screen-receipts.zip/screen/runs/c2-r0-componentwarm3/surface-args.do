local slope_absorb ""
local memory "low"

from pathlib import Path
import json
r=Path(__file__).parent
base=dict(model='ppml',outputs='mu',fixest_strict=True,design='one_fe')
cells=[dict(base,n=16320,k=12,threads=4,memory='fast'),dict(base,n=61440,k=10,threads=4,memory='fast'),dict(base,n=49152,k=12,threads=4,memory='low'),dict(base,n=30720,k=3,threads=1,memory='fast',topology='unbalanced')]
(r/'cells.json').write_text(json.dumps(cells,indent=2)+'\n');(r/'profile-cells.json').write_text(json.dumps(cells[:2],indent=2)+'\n')
(r/'declaration.json').write_text(json.dumps(dict(base='e9c7f598',artifact='componentwarm3',profile_artifact='incrementbaseledger1',seed=202609347,repetitions=3,scope='Current-source opportunity screen for one FE after closing the bounded categorical incremental-engine experiment. Matched robust inference and saved means, strict pinned unmodified fixest; diagnostic profile separately. No fresh validation seed consumed.'),indent=2)+'\n')

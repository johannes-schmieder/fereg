from pathlib import Path
import hashlib, json, re, sys, zipfile
sys.path.insert(0, 'benchmarks/next_subsystem')
from archive import archive

root = Path(__file__).parent
report = Path('benchmarks/reports/development/ppml-incremental-coefficient-closeout-local-2026-09-24')
extras = [str(p.relative_to(root)) for p in sorted(root.iterdir())
          if p.is_file() and p.suffix in ('.py', '.json', '.txt', '.log')]
archive(root, root / 'screen-raw-receipts.zip', ['screen', 'profile'], extras)
output = report / 'one-fe-screen-receipts.zip'
with zipfile.ZipFile(root / 'screen-raw-receipts.zip') as source, zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED) as dest:
    manifest = json.loads(source.read('archive-hashes.json'))
    for name, record in manifest.items():
        data = source.read(name)
        assert hashlib.sha256(data).hexdigest() == record['archived_sha256']
        data = data.replace(b'$R_DEPENDENCIES', b'$R_DEPENDENCIES')
        data = re.sub(rb'$TEMP_PATH"\'<>]+', b'$TEMP_PATH', data)
        assert b'$HOME' not in data
        assert not re.search(rb'(?m)^\s*(?:Serial number:|Licensed to:)', data)
        assert not name.endswith(('.dta', '.bin', '.plugin'))
        record['archived_sha256'] = hashlib.sha256(data).hexdigest()
        dest.writestr(name, data)
    dest.writestr('archive-hashes.json', json.dumps(manifest, sort_keys=True, indent=2) + '\n')
output.with_suffix('.sha256').write_text(hashlib.sha256(output.read_bytes()).hexdigest() + '  ' + output.name + '\n')
with zipfile.ZipFile(output) as bundle:
    for name, record in manifest.items():
        assert hashlib.sha256(bundle.read(name)).hexdigest() == record['archived_sha256']
print('VERIFIED', len(manifest), 'one-FE receipts', output.stat().st_size, 'bytes')

local slope_absorb ""
local memory "fast"

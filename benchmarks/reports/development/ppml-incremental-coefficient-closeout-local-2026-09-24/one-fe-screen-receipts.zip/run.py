from pathlib import Path
import os,subprocess,json
r=Path(__file__).parent;py='target/one-fe-profile-20260919/python/bin/python';env=dict(os.environ,R_LIBS_USER=str(Path('target/one-fe-profile-20260919/R-stock').resolve())+':$R_DEPENDENCIES',STATA_MP_PATH='/Applications/Stata/StataMP.app/Contents/MacOS/stata-mp',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONPATH='benchmarks/next_subsystem:benchmarks/systematic')
for name,variants,cells,repeats,trace in [('screen',['componentwarm3','fixest'],'cells.json',3,False),('profile',['incrementbaseledger1'],'profile-cells.json',1,True)]:
 c=[py,'benchmarks/next_subsystem/run.py',str(r/name),'--artifacts','target/ppml-next-20260922/artifacts','--variants',*variants,'--fixest-archive','target/one-fe-profile-20260919/fixest.tar.gz','--cells',str(r/cells),'--seed','202609347','--repeats',str(repeats),'--ppml-surface']+(['--trace'] if trace else [])
 with (r/(name+'-controller.log')).open('x') as f:z=subprocess.run(c,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert z.returncode==0
 c=[py,'benchmarks/next_subsystem/ppml_audit.py',str(r/name),str(r/(name+'-audit.json'))]
 with (r/(name+'-audit.log')).open('x') as f:z=subprocess.run(c,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert z.returncode==0
 print(name,'complete',flush=True)

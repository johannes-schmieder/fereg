import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2]; artifacts=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import archive_science
root=repo/'target/g21cy2'
output=repo/'benchmarks/reports/development/cycle-routing-memory-local-2026-09-21'
assert json.loads((root/'screen-complete.json').read_text())['attempted']==46
archive_science.archive([root,*[repo/('target/'+name) for name in ['g21cymem1','g21cymem2','g21cymem3','g21cyfast1']]],output,compact=True,omit_output_arrays=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def portable(raw):
 return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={kind:{} for kind in ['sources','checks']}
with zipfile.ZipFile(output/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 def add(name,raw):
  clean=portable(raw);bundle.writestr(name,clean)
  tables['sources'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
 for variant in ['owf1','cy1','cy2']:
  path=artifacts/f'identity-{variant}.json';identity=json.loads(path.read_text());add(path.name,path.read_bytes())
  raw=subprocess.check_output(['git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'],cwd=repo)
  with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
   base={entry.name:sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
  for relative,digest in identity['source'].items():
   data=(artifacts/variant/relative).read_bytes();assert sha(data)==digest
   if base.get(relative)!=digest: add(variant+'/'+relative,data)
 for name in ['audit_milestone.py','audit_outputs.py','graph_oracle.py','run.py','route_development.py','score.py','broad.py','archive_science.py','audit_routes.py']:
  add(name,(repo/'benchmarks/two_fe_dense'/name).read_bytes())
 for relative in ['crates/fereg-plugin/src/result.rs','benchmarks/one_fe_optimization/build.py','benchmarks/one_fe_optimization/cycle_ols_lsmr.py','benchmarks/one_fe_optimization/cycle_ols_lsmr.rs','benchmarks/one_fe_optimization/cycle_probe_memory.py','benchmarks/one_fe_optimization/cycle_probe_memory.rs','benchmarks/one_fe_optimization/cycle_probe_memory_tests.rs']:
  add(relative,(repo/relative).read_bytes())
 for name in ['cycle-memory-screen1.py','audit-cycle-memory1.py','audit-cycle-memory-routing1.py','score-kernel-screen2.py','cycle-constrained1.py','cycle-constrained2.py','cycle-constrained3.py','audit-cycle-constrained1.py','sw1-memory-output-auditor1.py','cycle-fastest-training1.py','archive-cycle-memory1.py']:
  add(name,(artifacts/name).read_bytes())
with zipfile.ZipFile(output/'checks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 names=[path.name for path in artifacts.iterdir() if path.suffix in ['.json','.txt'] and any(path.name.startswith(prefix) for prefix in ['cycle-memory-','cycle-constrained','cycle-fastest-'])]
 names += ['cy2-cycle-tests1.txt','cycle-guard-inference1.json']
 for name in sorted(names):
  path=artifacts/name;raw=path.read_bytes();clean=portable(raw);bundle.writestr(name,clean)
  tables['checks'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
for kind,table in tables.items(): (output/(kind+'-hashes.json')).write_text(json.dumps(table,indent=2)+'\n')
verifier=(repo/'benchmarks/reports/development/cycle-ols-lsmr-local-2026-09-21/verify.py').read_text()
verifier=verifier.replace("['in1', 'cy1']", "['owf1', 'cy1', 'cy2']").replace("'/opt/homebrew/bin/git'", "'git'")
verifier=verifier.replace('cycle-guard-inference1.json','cycle-memory-inference1.json').replace('cycle-guard-routing1.json','cycle-memory-routing1.json')
verifier=verifier.replace('cycle-ols-lsmr-archive-integrity-v1','cycle-routing-memory-archive-integrity-v1').replace('CYCLE_OLS_LSMR_ARCHIVE_INTEGRITY_PASS','CYCLE_ROUTING_MEMORY_ARCHIVE_INTEGRITY_PASS')
extra="""
with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    hashes=json.loads((folder/'checks-hashes.json').read_text())
    all_checks={r['original_sha256'] for r in hashes.values()}
    for name in ['cycle-memory-inference1.json','cycle-constrained-audit1.json']:
        audit=json.loads(bundle.read(name))
        assert audit['oracle_cache_sha256'] in all_checks
    routes=json.loads(bundle.read('cycle-fastest-audit1.json'))
    assert routes['complete'] and routes['planned']==routes['attempted']==168
    assert all(r['status']=='science_pass' and r['isolation']=='no_detected_overlap' for r in routes['records'])
    assert max(r['median_paired_auto_to_fastest_valid'] for r in routes['cells'])<=1.05
    assert routes['controller_sha256'] in known_sources
    memory=json.loads(bundle.read('cycle-constrained-audit1.json'))
    assert len(memory['records'])==18 and sum(r['status']=='pass' for r in memory['records'])==8
    assert all(r['inference']['status']=='pass' for r in memory['records'] if r['status']=='pass')
    assert all(r['status']=='pass' for r in memory['rejected_route_pairs'])
    assert memory['source_sha256'] in known_sources and memory['output_auditor_sha256'] in known_sources
    tests=json.loads(bundle.read('cycle-memory-tests1.json'))
    assert tests['status']=='pass' and len(tests['tests'])==6
    assert tests['plugin']==next(s['plugin'] for s in sources if s['variant']=='cy2')
"""
verifier=verifier.replace('receipt = dict(schema=',extra+'\nreceipt = dict(schema=')
(output/'verify.py').write_text(verifier)
(output/'README.md').write_text("""# Cycle routing: memory admission and training confirmation

This captured-source cy2 experiment budgets every temporary descriptor table,
charges actual capacities and rejected-probe peaks, and checks the existing
LSMR envelope before selecting the route. A selected fit reuses its validated
borrowed descriptor and charges its retained bytes with every projection.
Interaction sources and mismatched requested/installed teams are excluded.
The exact graph predicate, recurrence tolerances, fresh certificates and
fallback algorithms remain unchanged. Production core routing is unchanged.

The plugin passes its ABI fixture and six focused release tests, including
exact-budget admission, one-byte-below rejection, original-route exclusions,
graph relabeling and the existing cycle controls. The 46-cell three-pair
training screen completes 414 successful calls with clean isolation. All
138 independent inference checks, 414 exact within-arm repeats, 288 saved-
output audits and 138 route comparisons pass. The 28 selected cycle cells
have paired cy2/owf1 ratios of 0.5017–0.7325. All 18 excluded controls are
within 1.05, with worst 1.0254; their scientific exports and solver reports
other than timing are exact. Ratios versus the prior cy1 prototype are
0.9643–1.0248 on selected cells. This is not a memory-neutral optimization.

The 28-cell automatic/explicit LSMR comparison completes another 168 calls
with clean isolation and independent inference/output acceptance. Automatic
routing is fastest in 23 cells. In the other five it stays within 4.05% of
the faster explicit route by median paired ratio. This meets the 5% training
criterion without changing tolerances. LSMR was the fastest valid competing
route identified by the preceding solver-family investigation; this block
does not repeat every rejected family.

Eighteen fixed-budget diagnostics preserve two allocation rejections and
eight 60-second timeouts. The eight completed fits pass independent inference;
four full-output fits also pass reconstruction and normal-equation audits.
Tight-budget no-output unit/T1 and AW/T16 pairs preserve exact numerical
exports and solver reports. The selected cy2 route is admitted for saved
unit/T1 at 3 GB and AW/T16 at 12 GB. The conservative threaded Schwarz memory
model excludes it even at 3 GB in this weighted design; it is not weakened.
The old fallback with saved effects times out in both artifacts at the lower
budgets. These are diagnostic outcomes, not successful bounded-memory fits
or timing comparisons, and they do not establish transaction atomicity.

All 600 application attempts are preserved: 590 successes, two allocation
rejections and eight timeouts. Source trees for owf1, cy1 and cy2 reconstruct
from their original commits and captured overlays. The original independent
oracle cache is included and hash-bound. Large arrays remain local with
hashes; raw licensed logs and binaries are excluded. Filtered numerical phase
traces retain hashes of their original local stderr files.

The next step is to freeze cy2 before using the two untouched routing seeds.
Linux confirmation remains blocked on SSH renewal. This is Mac development
evidence and does not admit production routing, install a package, authorize
a release or push, or close the broader optimization milestone.
""")
print('CYCLE_ROUTING_MEMORY_ARCHIVE_PREPARED')

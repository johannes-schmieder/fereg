import json, os, subprocess, sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2]
art=repo/'target/ols-next-20260921'; root=repo/'target/g21cy2'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import audit_outputs
from score import sha
assert json.loads((root/'screen-complete.json').read_text())['attempted']==46
commands=[
 [sys.executable,str(art/'score-kernel-screen2.py'),str(root),str(art/'cycle-memory-score1.json')],
 [sys.executable,str(repo/'benchmarks/two_fe_dense/audit_milestone.py'),str(root),'screen',str(art/'cycle-memory-inference1.json'),'--oracle-cache',str(art/'cycle-guard-inference1.json')],
 [sys.executable,str(art/'audit-cycle-memory-routing1.py')],
]
records=[]
for kind,command in zip(['score','inference','routing'],commands):
 with (art/f'cycle-memory-{kind}1.txt').open('x') as stream:
  subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=True)
 print(kind,'complete',flush=True)
plan=json.loads((root/'screen-plan.json').read_text())
progress=json.loads((root/'screen-progress.json').read_text())
for attempt in progress:
 if attempt['cell']['case'].endswith('_none'): continue
 for variant in plan['variants']:
  receipt=root/f"{attempt['label']}-{variant}-independent-outputs.json"
  assert not receipt.exists()
  audit_outputs.audit(root,attempt['label'],variant)
  rows=json.loads(receipt.read_text())
  assert len(rows)==plan['repeats'] and all(r['status']=='pass' for r in rows)
  records.append(dict(index=attempt['index'],variant=variant,receipt_sha256=sha(receipt),records=rows))
out=art/'cycle-memory-outputs1.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='cycle-memory-output-audit-v1',source_sha256=sha(Path(__file__)),output_auditor_sha256=sha(Path(audit_outputs.__file__)),records=records),indent=2)+'\n')
print('CYCLE_MEMORY_AUDITS_COMPLETE',len(records),flush=True)

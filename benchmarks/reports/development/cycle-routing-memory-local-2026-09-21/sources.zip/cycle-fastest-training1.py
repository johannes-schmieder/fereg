import json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad,route_development as route
root=repo/'target/g21cyfast1';root.mkdir(exist_ok=False)
prior=repo/'target/g21cy2/screen-plan.json'
cells=json.loads(prior.read_text())['cells'][:28]
plan=dict(schema='ols-whole-command-route-exploration-v1',candidate='cy2',families=['auto','lsmr'],
 selected_indices=list(range(28)),cells=cells,repeats=3,timeout_seconds=60,
 controller_sha256=broad.sha(Path(__file__)),runner_sha256=broad.sha(repo/'benchmarks/two_fe_dense/run.py'),
 selection_plan_sha256=broad.sha(prior),
 acceptance='Training comparison with the fastest previously valid competing route; unchanged tolerances and fresh scientific audits. Both validation seeds remain unused.')
broad.write(root/'route-plan.json',plan)
(root/'execution-source.py').write_bytes(Path(__file__).read_bytes())
progress=[]
for index,cell in enumerate(cells):
 for rep in range(3):
  families=plan['families'];offset=(index+rep)%len(families)
  for family in families[offset:]+families[:offset]:
   label=f'route-c{index:03d}-r{rep+1}-{family}'
   request=dict(cell,solver=family)
   command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),
    '--artifacts',str(art),'--label',label,'--variants','cy2','--repeats','1','--timeout','60',
    '--keep-going',*broad.arguments(request)]
   stdout=root/(label+'.stdout.txt')
   code,isolation=route.invoke(command,stdout)
   complete=root/(label+'-complete.json')
   progress.append(dict(index=index,original_index=index,rep=rep+1,family=family,label=label,
    cell=request,command=command,process_returncode=code,stdout_sha256=broad.sha(stdout),
    timing_isolation=isolation,completion=json.loads(complete.read_text()) if complete.exists() else None))
   broad.write(root/'route-progress.json',progress)
   print(len(progress),'/',len(cells)*6,label,code,isolation['status'],flush=True)
broad.write(root/'route-complete.json',dict(status='attempts_complete',planned=len(cells)*6,
 attempted=len(progress),process_failures=sum(r['process_returncode']!=0 for r in progress),
 plan_sha256=broad.sha(root/'route-plan.json'),progress_sha256=broad.sha(root/'route-progress.json')))

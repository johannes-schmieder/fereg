import json
from pathlib import Path
import sys
repo=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad
import route_development as route
artifacts=repo/'target/ols-next-20260921'; root=repo/'target/g21cy2'
root.mkdir(exist_ok=False)
selection=[(i,t) for t in [1,8,16] for i in range(72,80)]
cells=[route.cells(threads)[index] for index,threads in selection]
for weight in ['pw','fw']:
    for index in [74,75]:
        cells.append(dict(route.cells(16)[index],weight_kind=weight))
for index in [1,3,9,11,17,19,25,27,33,35,41,49,57,59,65,67]:
    cells.append(route.cells(16)[index])
for threads in [1,16]:
    cells.append(dict(route.cells(threads)[73],solver='lsmr'))
plan=dict(schema='ols-cycle-memory-screen-v1',cells=cells,selection=selection,
    baseline='owf1',candidate='cy2',variants=['owf1','cy1','cy2'],repeats=3,
    expected_selected=[True]*28+[False]*18,
    controller_sha256=broad.sha(Path(__file__)),isolation_source_sha256=broad.sha(Path(route.__file__)),
    acceptance='Training screen of budgeted cycle descriptor construction, direct-route admission and descriptor reuse; previous cycle artifact is an additional control. All scientific checks remain unchanged. No production or Linux acceptance; fresh seeds remain unused.')
broad.write(root/'screen-plan.json',plan)
(root/'execution-source.py').write_bytes(Path(__file__).read_bytes())
records=[]
for index,cell in enumerate(cells):
    label=f'cycle-c{index:03d}'
    command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),
        '--artifacts',str(artifacts),'--label',label,'--variants',*plan['variants'],
        '--repeats','3','--timeout','120','--keep-going',*broad.arguments(cell)]
    code,isolation=route.invoke(command,root/(label+'.stdout.txt'))
    complete=root/(label+'-complete.json')
    records.append(dict(index=index,cell=cell,label=label,command=command,process_returncode=code,
        timing_isolation=isolation,completion=json.loads(complete.read_text()) if complete.exists() else None))
    broad.write(root/'screen-progress.json',records)
    print(index+1,'/',len(cells),label,code,isolation['status'],flush=True)
broad.write(root/'screen-complete.json',dict(status='attempts_complete',attempted=len(records),planned=len(cells),
    plan_sha256=broad.sha(root/'screen-plan.json'),progress_sha256=broad.sha(root/'screen-progress.json')))

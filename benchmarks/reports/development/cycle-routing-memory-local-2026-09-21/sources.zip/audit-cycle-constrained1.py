import csv,importlib.util,json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import audit_milestone,graph_oracle
from score import sha
p=art/'sw1-memory-output-auditor1.py'
spec=importlib.util.spec_from_file_location('memory_outputs',p)
outputs=importlib.util.module_from_spec(spec);spec.loader.exec_module(outputs)
cache_path=art/'cycle-memory-inference1.json'
cache=audit_milestone.load_oracle_cache(cache_path)
out=art/'cycle-constrained-audit1.json';assert not out.exists()
records=[];pairs=[];inputs={}
def solver(p):
 return {(int(r['row']),int(r['column'])):float(r['value']) for r in csv.DictReader(p.open())}
for number,planned in [(1,8),(2,8),(3,2)]:
 root=repo/f'target/g21cymem{number}'
 done=json.loads((root/'diagnostic-complete.json').read_text())
 assert done['attempted']==done['planned']==planned
 paths=sorted((root/'runs').glob('*/result.json'));assert len(paths)==planned
 for index,p in enumerate(paths):
  result=json.loads(p.read_text());request=json.loads(p.with_name('request.json').read_text())
  expected='pass' if number==3 or number==2 and index<6 else 'worker_failure' if number==1 and index<2 else 'command_timeout'
  r=dict(root=root.name,run=p.parent.name,status=result['status'],expected=expected,
   result_sha256=sha(p),request_sha256=sha(p.with_name('request.json')),
   process_returncode=result['process_returncode'],sentinel=result['sentinel'],
   usable_bytes=request['cell']['diagnostic_available_bytes']-536870912)
  assert result['status']==expected
  if expected=='command_timeout':
   assert result['process_returncode']==-15 and not result['sentinel'] and result['command_time_lower_bound']==60
   r['command_time_lower_bound_seconds']=60
  else:
   assert result['process_returncode']==0 and result['sentinel']
   r['application_rc']=result['metadata']['rc']
   if expected=='worker_failure':assert r['application_rc']==909
   else:
    assert r['application_rc']==0
    data=Path(request['data'])
    if data not in inputs:inputs[data]=sha(data)
    assert inputs[data]==result['input_sha256']
    oracle=cache[(inputs[data],result['cell']['weight_kind'],result['cell']['vce'])]
    r['inference']=graph_oracle.compare(p,oracle)
    r['allocation_bytes']=int(result['metadata']['fereg_native_allocation_bytes'])
    assert r['allocation_bytes']<=r['usable_bytes']
    report=solver(p.with_name('fereg_solver.csv'));r['initial_used_solver']=report[(1,2)]
    variant=p.parent.name.rsplit('-',1)[1];label=p.parent.name.rsplit('-',1)[0]
    if number==2 and index<4:assert r['initial_used_solver']==4
    elif variant=='cy2':assert r['initial_used_solver']==3
    if result['cell']['outputs']=='all':
     receipt=root/f'{label}-{variant}-independent-outputs.json';assert not receipt.exists()
     outputs.audit(root,label,variant);r['output_audit_sha256']=sha(receipt)
  records.append(r)
  print(root.name,p.parent.name,r['status'],r.get('inference',{}).get('status'),flush=True)
 if number==2:
  for i in [0,2]:
   left,right=paths[i:i+2]
   names=['coefficients.csv','covariance.csv','b.csv','V.csv','fereg_fit.csv','fereg_dof.csv','fereg_certificate.csv','fereg_status.csv','fereg_fe.csv']
   checks={n:sha(left.with_name(n))==sha(right.with_name(n)) for n in names}
   a,b=[solver(p.with_name('fereg_solver.csv')) for p in [left,right]]
   checks['solver']={k:v for k,v in a.items() if k[1] not in [9,10]}=={k:v for k,v in b.items() if k[1] not in [9,10]}
   checks['sample']=json.loads(left.read_text())['sample_sha256']==json.loads(right.read_text())['sample_sha256']
   pairs.append(dict(runs=[p.parent.name for p in [left,right]],checks=checks,status='pass' if all(checks.values()) else 'mismatch'))
receipt=dict(schema='cycle-constrained-admission-audit-v1',source_sha256=sha(Path(__file__)),
 oracle_source_sha256=sha(Path(graph_oracle.__file__)),output_auditor_sha256=sha(Path(outputs.__file__)),
 oracle_cache_sha256=sha(cache_path),records=records,rejected_route_pairs=pairs,
 limitations='Diagnostic fixed-budget checks only. Two allocation rejections and eight timeouts remain failures. No timing ranking, full allocation proof or failure-transaction claim.')
out.write_text(json.dumps(receipt,indent=2)+'\n')
assert all(r['inference']['status']=='pass' for r in records if r['status']=='pass')
assert all(r['status']=='pass' for r in pairs)
print('CYCLE_CONSTRAINED_ADMISSION_AUDIT_PASS',len(records),sum(r['status']=='pass' for r in records),flush=True)

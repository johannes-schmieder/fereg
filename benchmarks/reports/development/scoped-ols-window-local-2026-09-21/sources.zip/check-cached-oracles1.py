import json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921';root=repo/'target/g21nrt2'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import graph_oracle
from score import sha
receipt=json.loads((art/'narrow-residual-inference1.json').read_text());checks=[]
for index in [6,9]:
 record=receipt['records'][index];prior=next(r for r in record['attempts'] if r['variant']=='nrt2')
 assert prior['oracle_origin']=='verified_cache'
 path=root/'runs'/prior['run']/'result.json';request=json.loads((path.parent/'request.json').read_text());result=json.loads(path.read_text())
 oracle=graph_oracle.solve(Path(request['data']),record['cell']['weight_kind'],result['cell']['vce'])
 fresh=graph_oracle.compare(path,oracle)
 assert fresh['status']=='pass' and fresh['oracle']==prior['oracle']
 checks.append(dict(index=index,status='pass',input_sha256=prior['input_sha256'],result_sha256=sha(path),oracle_exact_equality=True))
 assert fresh['checks']==prior['checks']
output=art/'cached-oracle-equivalence1.json';assert not output.exists()
output.write_text(json.dumps(dict(schema='independent-oracle-cache-equivalence-v1',source_sha256=sha(Path(__file__)),oracle_source_sha256=sha(Path(graph_oracle.__file__)),prior_audit_sha256=sha(art/'current-primary-inference1.json'),cached_audit_sha256=sha(art/'narrow-residual-inference1.json'),checks=checks),indent=2)+'\n')
print('CACHED_ORACLE_FRESH_RESOLVE_EXACT_PASS',len(checks))

import json
from pathlib import Path
import sys
repo=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad
import route_development as route
artifacts=repo/'target/ols-next-20260921';root=repo/'target/g21ow3'
root.mkdir(exist_ok=False)
selection=[(i,1) for i in [13,15,69,71,77,79,65,67,68]]+[(71,16)]
cells=[route.cells(t)[i] for i,t in selection]
for weight in ['pw','fw']:
 cells.append(dict(route.cells(1)[71],weight_kind=weight))
cells.append(dict(route.cells(1)[69],solver='lsmr'))
plan=dict(schema='ols-retained-serial-window-screen-v1',cells=cells,selection=selection,
 baseline='in1',candidate='nrt2',variants=['in1','nrt2'],repeats=3,
 narrow_numeric_guard_expected=False,
 controller_sha256=broad.sha(Path(__file__)),isolation_source_sha256=broad.sha(Path(route.__file__)),
 acceptance='Paired runtime/science and tracked memory for the scoped retained serial OLS window. Preserve every failure and excluded timing. No shared, Linux or final-block acceptance.')
broad.write(root/'screen-plan.json',plan);(root/'execution-source.py').write_bytes(Path(__file__).read_bytes())
records=[]
for index,cell in enumerate(cells):
 label=f'window-c{index:03d}'
 command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),
 '--artifacts',str(artifacts),'--label',label,'--variants',*plan['variants'],
 '--repeats','3','--timeout','120','--keep-going',*broad.arguments(cell)]
 code,isolation=route.invoke(command,root/(label+'.stdout.txt'))
 complete=root/(label+'-complete.json')
 records.append(dict(index=index,cell=cell,label=label,command=command,process_returncode=code,
 timing_isolation=isolation,completion=json.loads(complete.read_text()) if complete.exists() else None))
 broad.write(root/'screen-progress.json',records)
 print(index+1,'/',len(cells),label,code,isolation['status'],flush=True)
broad.write(root/'screen-complete.json',dict(status='attempts_complete',attempted=len(records),planned=len(cells),
 plan_sha256=broad.sha(root/'screen-plan.json'),progress_sha256=broad.sha(root/'screen-progress.json')))

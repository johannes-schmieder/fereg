import json
from pathlib import Path
import sys
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921';root=repo/'target/g21owmem3'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
from score import sha
records=[]
for p in sorted((root/'runs').glob('*/result.json')):
 r=json.loads(p.read_text());q=json.loads((p.parent/'request.json').read_text());log=p.parent/'import.log'
 record=dict(run=p.parent.name,status=r['status'],result_sha256=sha(p),request_sha256=sha(p.parent/'request.json'),original_log_sha256=sha(log),process_returncode=r['process_returncode'],sentinel=r['sentinel'],usable_bytes=q['cell']['diagnostic_available_bytes']-536870912)
 if record['usable_bytes']==1000000000:
  assert r['status']=='worker_failure' and r['process_returncode']==0 and r['sentinel'] and r['metadata']['rc']==909
  error='automatic FE solver memory preflight found neither LSMR nor CG able to fit the joint execution plan'
  assert error in log.read_text(errors='replace');record.update(application_rc=909,allocation_error=error)
 else:
  assert record['usable_bytes']==1500000000
  assert r['status']=='command_timeout' and r['process_returncode']==-15 and not r['sentinel'] and r['command_time_lower_bound']==90
  record['command_time_lower_bound_seconds']=90
 records.append(record)
assert len(records)==4
out=art/'ols-window-memory-followup-audit1.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='scoped-window-memory-followup-v1',source_sha256=sha(Path(__file__)),records=records,earlier_controller_failure=dict(root='g21owmem2',attempted_applications=0,controller_sha256=sha(art/'ols-window-memory2.py'),log_sha256=sha(art/'ols-window-memory2.txt')),scope='Preserves two joint-admission rejections and two 90-second timeouts. No timing, scientific pass or transaction-atomicity claim.'),indent=2)+'\n')
print('SCOPED_WINDOW_MEMORY_FOLLOWUP_AUDIT_PASS',len(records))

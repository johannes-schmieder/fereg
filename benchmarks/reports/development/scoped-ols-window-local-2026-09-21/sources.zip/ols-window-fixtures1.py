from pathlib import Path
root=Path(__file__).resolve().parents[2]
p=root/'crates/fereg-core/src/fe/lsmr_batch.rs';s=p.read_text()
old='''pub(super) fn solve_prepared_batch(
    solver: &Solver<'_>,
    rhs: &[&[f64]],
    options: &LsmrOptions,
) -> Result<BatchSolveResult, BatchError> {
        solve_prepared_batch_with_policy(solver, rhs, options, LsmrBatchPolicy::Default)
}

'''
assert s.count(old)==1;s=s.replace(old,'').replace('solve_prepared_batch_with_policy(', 'solve_prepared_batch(')
s=s.replace('        solve_batch_with_policy(effects, rhs, weights, options, preconditioner, LsmrBatchPolicy::Default)','    solve_batch_with_policy(effects, rhs, weights, options, preconditioner, LsmrBatchPolicy::Default)')
s=s.replace('solve_prepared_batch(&solver, &rhs, &options)', 'solve_prepared_batch(&solver, &rhs, &options, LsmrBatchPolicy::Default)')
s=s.replace('solve_prepared_batch(&solver, &batch, &LsmrOptions::default())', 'solve_prepared_batch(&solver, &batch, &LsmrOptions::default(), LsmrBatchPolicy::Default)')
anchor='    #[test]\n    fn a_later_window_failure_returns_no_partial_batch()'
fixture='''    #[test]
    fn retained_serial_ols_windows_match_full_batches_and_fail_atomically() {
        let rows = 512;
        let left: Vec<u32> = (0..rows).map(|r| (r % 32) as u32).collect();
        let right: Vec<u32> = (0..rows).map(|r| ((r / 7) % 19) as u32).collect();
        let weights: Vec<f64> = (0..rows).map(|r| 0.5 + (r % 13) as f64 / 13.0).collect();
        let columns: Vec<Vec<f64>> = (0..64).map(|c| (0..rows)
            .map(|r| ((r * 17 + c * 31) as f64 * 0.0031).sin()).collect()).collect();
        let views: Vec<&[f64]> = columns.iter().map(Vec::as_slice).collect();
        let options = LsmrOptions { tol: 1e-10, maxiter: 500, local_size: Some(4) };
        for threads in [1, 4] {
            rayon::ThreadPoolBuilder::new().num_threads(threads).build().unwrap().install(|| {
                for weighted in [false, true] {
                    for preconditioner in [PreconditionerConfig::Off, PreconditionerConfig::Diagonal,
                        PreconditionerConfig::default()]
                    {
                        let effects = || vec![Effect::new(&left, true, []).unwrap(),
                            Effect::new(&right, true, []).unwrap()];
                        let w = weighted.then_some(weights.as_slice());
                        let solver = Solver::new(effects(), w.map(<[f64]>::to_vec), preconditioner.clone()).unwrap();
                        for width in [16, 52, 64] {
                            let rhs = &views[..width];
                            let expected = solver.solve_batch(rhs, &options).unwrap();
                            assert!(expected.converged.iter().all(|&v| v));
                            for actual in [
                                solve_prepared_batch(&solver, rhs, &options, LsmrBatchPolicy::RetainedSerialOls).unwrap(),
                                solve_batch_with_policy(effects(), rhs, w, &options, preconditioner.clone(),
                                    LsmrBatchPolicy::RetainedSerialOls).unwrap(),
                            ] {
                                assert_eq!(actual.x, expected.x);
                                assert_eq!(actual.demeaned, expected.demeaned);
                                assert_eq!(actual.unidentified, expected.unidentified);
                                assert_eq!(actual.converged, expected.converged);
                                assert_eq!(actual.iterations, expected.iterations);
                                assert_eq!(actual.residual, expected.residual);
                                assert_eq!((actual.n_dofs, actual.n_obs), (expected.n_dofs, expected.n_obs));
                            }
                        }
                        if threads == 1 {
                            let mut malformed = views[..16].to_vec();
                            malformed[15] = &columns[15][..rows - 1];
                            for attempt in [
                                solve_prepared_batch(&solver, &malformed, &options, LsmrBatchPolicy::RetainedSerialOls),
                                solve_batch_with_policy(effects(), &malformed, w, &options, preconditioner.clone(),
                                    LsmrBatchPolicy::RetainedSerialOls),
                            ] {
                                assert!(matches!(attempt, Err(BatchError::Upstream(_))));
                            }
                        }
                    }
                }
            });
        }
    }

'''
assert s.count(anchor)==1;s=s.replace(anchor,fixture+anchor);p.write_text(s)
p=root/'crates/fereg-core/src/fe/borrowed_map.rs';s=p.read_text().replace('solve_prepared_batch_with_policy(', 'solve_prepared_batch(')
s=s.replace('            skip_map_pilot: false,\n        batch_policy:', '            skip_map_pilot: false,\n            batch_policy:')
# Explicitly bind the existing forced-cap MAP oracle to each installed team;
# otherwise its machine-default LSMR setting cannot exercise the serial guard.
anchor='''                        for (cap, fallback) in [(OLS_SCHUR_MAX_ITERATIONS, false), (1, true)] {'''
assert s.count(anchor)==1
s=s.replace(anchor,'''                        let mut config = config;
                        config.lsmr.threads = crate::options::ThreadConfig::from_requested(threads, false).unwrap();
'''+anchor)
p.write_text(s)
p=root/'crates/fereg-core/src/memory.rs';s=p.read_text()
anchor='    #[test]\n    fn lsmr_batch_model_bounds_window_frames_and_retained_outputs()'
fixture='''    #[test]
    fn retained_serial_ols_window_model_preserves_other_admission_envelopes() {
        for threads in [1, 4, 16] {
            for rhs in [1, 7, 15, 16, 17, 52, 64, 65] {
                let ordinary = estimate_fe_solver_memory(16_384, rhs, &[4096, 1024], threads, Some(4)).unwrap();
                let default = estimate_fe_solver_memory_with_batch_policy(16_384, rhs, &[4096, 1024],
                    threads, Some(4), LsmrBatchPolicy::Default).unwrap();
                assert_eq!(ordinary, default);
                let windowed = estimate_fe_solver_memory_with_batch_policy(16_384, rhs, &[4096, 1024],
                    threads, Some(4), LsmrBatchPolicy::RetainedSerialOls).unwrap();
                if threads == 1 && (16..=64).contains(&rhs) {
                    assert_eq!(LsmrBatchPolicy::RetainedSerialOls.rhs_window(rhs, threads), 1);
                    let one = estimate_fe_solver_memory(16_384, 1, &[4096, 1024], 1, Some(4)).unwrap();
                    assert_eq!(windowed.krylov_bytes, one.krylov_bytes);
                    assert_eq!(ordinary.krylov_bytes, rhs as u128 * one.krylov_bytes);
                    assert_eq!(windowed.cg_bytes, ordinary.cg_bytes);
                    assert_eq!(windowed.coefficient_batch_bytes, ordinary.coefficient_batch_bytes);
                    assert_eq!(windowed.rhs_copy_bytes, ordinary.rhs_copy_bytes);
                    assert_eq!(windowed.topology_bytes, ordinary.topology_bytes);
                    assert_eq!(windowed.lsmr_schwarz_retained_bytes, ordinary.lsmr_schwarz_retained_bytes);
                    assert!(windowed.lsmr_off_bytes < ordinary.lsmr_off_bytes);
                    assert!(windowed.lsmr_diagonal_bytes < ordinary.lsmr_diagonal_bytes);
                    assert!(windowed.lsmr_schwarz_bytes < ordinary.lsmr_schwarz_bytes);
                } else {
                    assert_eq!(ordinary, windowed);
                }
            }
        }
    }

'''
assert s.count(anchor)==1;s=s.replace(anchor,fixture+anchor);p.write_text(s)
print('OLS_WINDOW_FIXTURES_WRITTEN_NOT_YET_RUN')

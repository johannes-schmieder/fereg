#!/bin/bash
set -euo pipefail
cd <repository>
export PATH=/opt/homebrew/opt/rustup/bin:/opt/homebrew/bin:/usr/bin:/bin
export DEVELOPER_DIR=/Library/Developer/CommandLineTools
export CARGO_NET_OFFLINE=true
py=target/one-fe-profile-20260919/python/bin/python
"$py" benchmarks/one_fe_optimization/build.py target/ols-next-20260921 owf1 --revision d764894f --overlay crates/fereg-core/src/fe/borrowed_map.rs crates/fereg-core/src/fe/cmg.rs crates/fereg-core/src/fe/lsmr_batch.rs crates/fereg-core/src/memory.rs crates/fereg-core/src/ols/prepared_fit.rs crates/fereg-core/src/ols/prepared_rhs.rs
export CARGO_TARGET_DIR=<repository>/target/ols-next-20260921/cargo-owf1-test
cargo test --manifest-path target/ols-next-20260921/owf1/Cargo.toml --locked --offline --release -p fereg-core fe::lsmr_batch::tests:: -- --nocapture > target/ols-next-20260921/owf1-batch-tests1.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/owf1/Cargo.toml --locked --offline --release -p fereg-core retained_serial_ols_window_model_preserves_other_admission_envelopes -- --nocapture > target/ols-next-20260921/owf1-memory-tests1.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/owf1/Cargo.toml --locked --offline --release -p fereg-core ols_schur_probe_solve_budget_and_order_match_independent_map -- --nocapture > target/ols-next-20260921/owf1-map-tests1.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/owf1/Cargo.toml --locked --offline --release -p fereg-core numeric_tiles_preserve_rhs_and_raw_residual_bits_across_threads -- --nocapture > target/ols-next-20260921/owf1-numeric-tests1.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/owf1/Cargo.toml --locked --offline --release -p fereg-core narrow_weighted_final_overlap_preserves_fits_and_error_order -- --nocapture > target/ols-next-20260921/owf1-overlap-tests1.txt 2>&1
printf 'SCOPED_WINDOW_WITH_NARROW_REVERT_BUILD_AND_TESTS_PASS\n'

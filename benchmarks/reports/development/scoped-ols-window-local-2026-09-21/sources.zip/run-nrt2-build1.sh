#!/bin/bash
set -euo pipefail
cd <repository>
export PATH=/opt/homebrew/opt/rustup/bin:/opt/homebrew/bin:/usr/bin:/bin
export DEVELOPER_DIR=/Library/Developer/CommandLineTools
export CARGO_NET_OFFLINE=true
py=target/one-fe-profile-20260919/python/bin/python
"$py" - <<'PY'
import json
from pathlib import Path
s=json.loads(Path('target/g21pri1/primary1-complete.json').read_text())
assert s['attempted']==s['planned']==77 and s['process_failures']==0
PY
"$py" benchmarks/one_fe_optimization/build.py target/ols-next-20260921 nrt2 --revision 9e4daec9 --overlay crates/fereg-core/src/fe/borrowed_map.rs crates/fereg-core/src/fe/cmg.rs crates/fereg-core/src/fe/lsmr_batch.rs crates/fereg-core/src/memory.rs crates/fereg-core/src/ols/prepared_fit.rs crates/fereg-core/src/ols/prepared_rhs.rs
export CARGO_TARGET_DIR=<repository>/target/ols-next-20260921/cargo-nrt2-test
cargo test --manifest-path target/ols-next-20260921/nrt2/Cargo.toml --locked --offline --release -p fereg-core numeric_tiles_preserve_rhs_and_raw_residual_bits_across_threads -- --nocapture > target/ols-next-20260921/narrow-residual-tiles-tests2.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/nrt2/Cargo.toml --locked --offline --release -p fereg-core narrow_weighted_final_overlap_preserves_fits_and_error_order -- --nocapture > target/ols-next-20260921/narrow-residual-overlap-tests2.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/nrt2/Cargo.toml --locked --offline --release -p fereg-core final_residual_overlap_preserves_bits_and_rejection_order -- --nocapture > target/ols-next-20260921/narrow-residual-control-tests2.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/nrt2/Cargo.toml --locked --offline --release -p fereg-core fe::lsmr_batch::tests:: -- --nocapture > target/ols-next-20260921/ols-window-batch-tests3.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/nrt2/Cargo.toml --locked --offline --release -p fereg-core retained_serial_ols_window_model_preserves_other_admission_envelopes -- --nocapture > target/ols-next-20260921/ols-window-memory-tests3.txt 2>&1
cargo test --manifest-path target/ols-next-20260921/nrt2/Cargo.toml --locked --offline --release -p fereg-core ols_schur_probe_solve_budget_and_order_match_independent_map -- --nocapture > target/ols-next-20260921/ols-window-map-tests3.txt 2>&1
printf 'NARROW_RESIDUAL_AND_OLS_WINDOW_FOCUSED_TESTS_PASS\n'

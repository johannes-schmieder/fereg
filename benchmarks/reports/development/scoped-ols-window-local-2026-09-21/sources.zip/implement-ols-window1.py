from pathlib import Path
root=Path(__file__).resolve().parents[2]
def replace(text,old,new,n=1):
 assert text.count(old)==n,(old[:100],text.count(old),n)
 return text.replace(old,new)
p=root/'crates/fereg-core/src/memory.rs';s=p.read_text()
anchor='/// Estimate the complete incremental solver workspace after topology is known.'
s=replace(s,anchor,'''/// The estimator that owns a serial retained fallback opts into one live RHS.
/// Legacy/shared callers keep their existing transport and admission envelope.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum LsmrBatchPolicy {
    Default,
    RetainedSerialOls,
}

impl LsmrBatchPolicy {
    pub(crate) fn rhs_window(self, rhs: usize, threads: usize) -> usize {
        if self == Self::RetainedSerialOls && threads == 1 && (16..=64).contains(&rhs) {
            1
        } else {
            lsmr_rhs_window(rhs, threads)
        }
    }
}

'''+anchor)
old='''    estimate_fe_solver_memory_for_channels(
        observations,
        rhs_columns,
        effect_level_counts,
        threads,
        local_reorthogonalization_size,
        false,
    )
}

fn estimate_fe_solver_memory_for_channels('''
new='''    estimate_fe_solver_memory_with_batch_policy(
        observations, rhs_columns, effect_level_counts, threads,
        local_reorthogonalization_size, LsmrBatchPolicy::Default,
    )
}

pub(crate) fn estimate_fe_solver_memory_with_batch_policy(
    observations: usize,
    rhs_columns: usize,
    effect_level_counts: &[usize],
    threads: usize,
    local_reorthogonalization_size: Option<usize>,
    batch_policy: LsmrBatchPolicy,
) -> Result<FeSolverMemoryEstimate> {
    estimate_fe_solver_memory_for_channels(
        observations, rhs_columns, effect_level_counts, threads,
        local_reorthogonalization_size, false, batch_policy,
    )
}

#[allow(clippy::too_many_arguments)]
fn estimate_fe_solver_memory_for_channels('''
s=replace(s,old,new)
s=replace(s,'    signed_cover: bool,\n) -> Result<FeSolverMemoryEstimate>', '    signed_cover: bool,\n    batch_policy: LsmrBatchPolicy,\n) -> Result<FeSolverMemoryEstimate>')
s=replace(s,'let active_rhs = lsmr_rhs_window(rhs_columns, threads) as u128;', 'let active_rhs = batch_policy.rhs_window(rhs_columns, threads) as u128;')
p.write_text(s)
p=root/'crates/fereg-core/src/fe/lsmr_batch.rs';s=p.read_text()
s=replace(s,'use crate::error::{ErrorCode, FeregError};','use crate::error::{ErrorCode, FeregError};\nuse crate::memory::LsmrBatchPolicy;')
start=s.index("pub(super) fn solve_batch<'a>(");end=s.index('// Keep the upstream',start)
header=s[start:end]
wrapper=header+'''    solve_batch_with_policy(effects, rhs, weights, options, preconditioner, LsmrBatchPolicy::Default)
}

'''
inner=header.replace('fn solve_batch<','fn solve_batch_with_policy<').replace('    preconditioner: PreconditionerConfig,','    preconditioner: PreconditionerConfig,\n    batch_policy: LsmrBatchPolicy,')
s=s[:start]+wrapper+inner+s[end:]
s=replace(s,'rhs.len() <= crate::memory::lsmr_rhs_window(rhs.len(), rayon::current_num_threads())','rhs.len() <= batch_policy.rhs_window(rhs.len(), rayon::current_num_threads())')
s=replace(s,'let mut result = solve_prepared_batch(&solver, rhs, options)?;', 'let mut result = solve_prepared_batch_with_policy(&solver, rhs, options, batch_policy)?;')
start=s.index('pub(super) fn solve_prepared_batch(');end=s.index('// An explicit outer window',start)
header=s[start:end]
wrapper=header+'''    solve_prepared_batch_with_policy(solver, rhs, options, LsmrBatchPolicy::Default)
}

'''
inner=header.replace('fn solve_prepared_batch(', 'fn solve_prepared_batch_with_policy(').replace('    options: &LsmrOptions,','    options: &LsmrOptions,\n    batch_policy: LsmrBatchPolicy,')
s=s[:start]+wrapper+inner+s[end:]
s=replace(s,'let window = crate::memory::lsmr_rhs_window(rhs.len(), rayon::current_num_threads());', 'let window = batch_policy.rhs_window(rhs.len(), rayon::current_num_threads());')
p.write_text(s)
p=root/'crates/fereg-core/src/fe/borrowed_map.rs';s=p.read_text()
s=replace(s,'use crate::memory::{estimate_fe_solver_memory, FeSolverMemoryBudget, SolverWorkspacePeak};', '''use crate::memory::{
    estimate_fe_solver_memory, estimate_fe_solver_memory_with_batch_policy,
    FeSolverMemoryBudget, LsmrBatchPolicy, SolverWorkspacePeak,
};''')
s=replace(s,'    skip_map_pilot: bool,\n}', '    skip_map_pilot: bool,\n    batch_policy: LsmrBatchPolicy,\n}')
s=replace(s,'        skip_map_pilot: false,','        skip_map_pilot: false,\n        batch_policy: LsmrBatchPolicy::Default,',2)
s=replace(s,'            skip_map_pilot: true,','            skip_map_pilot: true,\n            batch_policy: LsmrBatchPolicy::Default,')
s=replace(s,'        skip_map_pilot,\n    } = lsmr_plan;', '        skip_map_pilot,\n        batch_policy,\n    } = lsmr_plan;')
s=replace(s,'    let solver_memory = estimate_fe_solver_memory(\n', '    let solver_memory = estimate_fe_solver_memory_with_batch_policy(\n')
s=replace(s,'        lsmr_config.and_then(|lsmr| lsmr.local_size),\n    )?;', '        lsmr_config.and_then(|lsmr| lsmr.local_size),\n        batch_policy,\n    )?;')
s=replace(s,'let mut memory = BorrowedLsmrCallMemory::new(\n                        solver_memory,','let mut memory = BorrowedLsmrCallMemory::with_batch_policy(\n                        solver_memory,')
s=replace(s,'                        retained_coefficient_bytes + original_norm_bytes,\n                    )?;', '                        retained_coefficient_bytes + original_norm_bytes,\n                        batch_policy,\n                    )?;')
s=replace(s,'struct BorrowedLsmrCallMemory {\n', 'struct BorrowedLsmrCallMemory {\n    batch_policy: LsmrBatchPolicy,\n')
needle='''        let mut memory = Self {
            peak: SolverWorkspacePeak::ZERO,'''
s=replace(s,needle,'''        Self::with_batch_policy(estimate, preconditioner, budget, parent_bytes, LsmrBatchPolicy::Default)
    }

    fn with_batch_policy(
        estimate: crate::memory::FeSolverMemoryEstimate,
        preconditioner: LsmrPreconditioner,
        budget: Option<FeSolverMemoryBudget>,
        parent_bytes: u128,
        batch_policy: LsmrBatchPolicy,
    ) -> Result<Self> {
        let mut memory = Self {
            batch_policy,
            peak: SolverWorkspacePeak::ZERO,''')
# Bind prepared and cold transport to the same policy used for admission.
start=s.index("impl<'a> BorrowedLsmrPrepared<'a> {");end=s.index('fn borrowed_lsmr_effects',start)
section=s[start:end]
section=replace(section,'    fn solve(\n','    #[allow(clippy::too_many_arguments)]\n    fn solve(\n')
section=replace(section,'        preconditioner: PreconditionerConfig,\n', '        preconditioner: PreconditionerConfig,\n        batch_policy: LsmrBatchPolicy,\n')
section=replace(section,'let memory = estimate_fe_solver_memory(', 'let memory = estimate_fe_solver_memory_with_batch_policy(')
section=replace(section,'            options.local_size,\n', '            options.local_size,\n            batch_policy,\n')
section=replace(section,'super::lsmr_batch::solve_prepared_batch(', 'super::lsmr_batch::solve_prepared_batch_with_policy(',2)
section=replace(section,'            options,\n        );', '            options,\n            batch_policy,\n        );')
section=replace(section,'                    options,\n                )', '                    options,\n                    batch_policy,\n                )')
s=s[:start]+section+s[end:]
start=s.index("fn run_borrowed_lsmr_with_prepared<'a>(");end=s.index('    // The candidate is wholly overwritten',start)
section=s[start:end]
section=replace(section,'            preconditioner,\n        )?', '            preconditioner,\n            memory.batch_policy,\n        )?')
section=replace(section,'super::lsmr_batch::solve_batch(', 'super::lsmr_batch::solve_batch_with_policy(',2)
section=replace(section,'            preconditioner,\n        );', '            preconditioner,\n            memory.batch_policy,\n        );')
section=replace(section,'                    PreconditionerConfig::Off,\n', '                    PreconditionerConfig::Off,\n                    memory.batch_policy,\n')
s=s[:start]+section+s[end:]
needle='''                absorb_borrowed_intercept_auto_direct_lsmr_certified(
                    &design, weights, values, remaining, config.lsmr,
                    config.solver_memory_budget, false, retain_fallback_coefficients,
                )?'''
s=replace(s,needle,'''                let mut plan = AutoLsmrPlan::direct_lsmr(config.lsmr, config.solver_memory_budget);
                // Only public serial OLS asks this wide Schur fallback to
                // retain products. Shared calls clear that request at their
                // fit boundary; narrow, threaded and explicit routes keep
                // their original transport and memory admission.
                if retain_fallback_coefficients && design.effects().len() == 2
                    && (16..=64).contains(&values.ncols())
                    && config.lsmr.threads.resolved() == 1 && rayon::current_num_threads() == 1
                {
                    plan.batch_policy = LsmrBatchPolicy::RetainedSerialOls;
                }
                let mut reservation = SystemWorkspaceReservation;
                absorb_auto_with_reservation(
                    &design, weights, values, remaining, plan,
                    AutoRunOptions { empty_design_is_structural_constant: false,
                        retain_coefficients: retain_fallback_coefficients },
                    &mut reservation,
                )?''')
p.write_text(s)
print('OLS_RETAINED_SERIAL_WINDOW_DRAFT_WRITTEN')

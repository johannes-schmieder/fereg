from pathlib import Path
import difflib
repo=Path(__file__).resolve().parents[2]
p=repo/'crates/fereg-core/src/ols/prepared_fit.rs';old=p.read_text();new=old
def sub(a,b,n=1):
 global new
 assert new.count(a)==n,(a[:100],new.count(a))
 new=new.replace(a,b)
sub('''    let defer_raw_residuals = residual_overlap && !perturbations.raw_residual_overlap_disabled;''', '''    let defer_raw_residuals = residual_overlap && !perturbations.raw_residual_overlap_disabled;
    let narrow_numeric_residual = residual_overlap && config.allow_final_fe_recovery
        && config.absorb.solver == FeSolverKind::Auto && generated_columns < 8;''')
sub('''            &qr,
            reservation,
        )?)''', '''            &qr,
            reservation,
            narrow_numeric_residual,
        )?)''')
sub('''                prepared, frame.response(), &qr, reservation,
            )?);''', '''                prepared, frame.response(), &qr, reservation, narrow_numeric_residual,
            )?);''')
sub('''    qr: &QrFit,
    reservation: &mut R,
) -> Result<Vec<f64>> {''', '''    qr: &QrFit,
    reservation: &mut R,
    narrow_numeric: bool,
) -> Result<Vec<f64>> {''')
sub('''    if let Some(columns) =
        super::prepared_rhs::NumericOlsColumns::bind(prepared.fit_model(), prepared.fit_sample())?
    {
        columns.subtract_fitted(&qr.generated_coefficients, &mut residuals)?;''', '''    // The public narrow overlap path can reuse the existing numeric binding
    // and tiled FMA order instead of streaming the full residual per column.
    let columns = if narrow_numeric {
        super::prepared_rhs::NumericOlsColumns::bind_residual_mean(prepared.fit_model(), prepared.fit_sample())?
    } else {
        super::prepared_rhs::NumericOlsColumns::bind(prepared.fit_model(), prepared.fit_sample())?
    };
    if let Some(columns) = columns {
        columns.subtract_fitted(&qr.generated_coefficients, &mut residuals)?;''')
sub('''                            assert!(bound.residual_at(&coefficients[..1], 0, response[0]).is_err());''', '''                            let mut narrow_residuals = response.clone();
                            bound.subtract_fitted(&coefficients, &mut narrow_residuals).unwrap();
                            assert!(narrow_residuals.iter().zip(&expected_residuals)
                                .all(|(a, b)| a.to_bits() == b.to_bits()));
                            assert!(bound.residual_at(&coefficients[..1], 0, response[0]).is_err());''')
output=repo/'target/ols-next-20260921/narrow-residual-update1.patch';assert not output.exists()
relative=str(p.relative_to(repo))
output.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),'a/'+relative,'b/'+relative)))
print('NARROW_RESIDUAL_PATCH_PREPARED_NOT_APPLIED')

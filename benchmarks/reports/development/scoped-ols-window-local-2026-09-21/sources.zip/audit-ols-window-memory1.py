from contextlib import redirect_stdout
import hashlib,json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921';root=repo/'target/g21owmem1'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import graph_oracle
from score import sha
import importlib.util
p=art/'sw1-memory-output-auditor1.py';spec=importlib.util.spec_from_file_location('memory_outputs',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
records=[];complete=json.loads((root/'diagnostic-complete.json').read_text());assert complete['planned']==complete['attempted']==6
for p in sorted((root/'runs').glob('*/result.json')):
 r=json.loads(p.read_text());q=json.loads((p.parent/'request.json').read_text())
 record=dict(run=p.parent.name,status=r['status'],application_rc=r['metadata']['rc'],process_rc=r['process_returncode'],sentinel=r['sentinel'],result_sha256=sha(p),request_sha256=sha(p.parent/'request.json'))
 assert record['process_rc']==0 and record['sentinel']
 if r['status']=='pass':
  oracle=graph_oracle.solve(Path(q['data']),r['cell']['weight_kind'],r['cell']['vce']);check=graph_oracle.compare(p,oracle);assert check['status']=='pass'
  record['independent_inference']=check
  m=r['metadata'];record['observed_peak_bytes']=int(m['fereg_native_allocation_bytes']);record['usable_bytes']=int(q['cell']['diagnostic_available_bytes'])-536870912
  assert record['observed_peak_bytes']<=record['usable_bytes']
  variant=p.parent.name.rsplit('-',1)[1];label=p.parent.name.rsplit('-',1)[0]
  with (art/'ols-window-memory-outputs1.txt').open('x') as stream:
   with redirect_stdout(stream):module.audit(root,label,variant)
  record['output_audit_sha256']=sha(root/f'{label}-{variant}-independent-outputs.json')
 else:assert record['application_rc']==909
 records.append(record)
assert len(records)==6 and sum(r['status']=='pass' for r in records)==1
out=art/'ols-window-memory-audit1.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='ols-scoped-window-memory-audit-v1',source_sha256=sha(Path(__file__)),oracle_sha256=sha(Path(graph_oracle.__file__)),output_auditor_sha256=sha(art/'sw1-memory-output-auditor1.py'),records=records,limitations='Five allocation rejections preserved. No timing inference, generic memory proof, Linux acceptance, or failure-transaction proof.'),indent=2)+'\n')
print('SCOPED_WINDOW_MEMORY_AUDIT_PASS',len(records),1)

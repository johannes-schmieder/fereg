import hashlib,json,os,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];artifacts=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import run,broad
root=repo/'target/g21owmem3';root.mkdir(exist_ok=False)
folder=run.stage(root);worker=folder/'measure.py';original=worker.read_bytes()
marker='    environment.update(thread_environment(threads))';text=original.decode();assert text.count(marker)==1
worker.write_text(text.replace(marker,marker+'\n    environment["FEREG_MEMORY_LIMIT_BYTES"] = str(cell["diagnostic_available_bytes"])\n    environment["FEREG_SOLVER_TRACE"] = "1"'))
stata_worker=folder/'stata_worker.do'
source=stata_worker.read_text();old="capture quietly `command'";assert source.count(old)==2
stata_worker.write_text(source.replace(old,"capture noisily `command'"))
run.write(folder/'source-manifest.json',run.controller_manifest(folder))
sys.path.insert(0,str(folder));measure=run.load('retained_window_memory_measure',worker).measure
(root/'work/refs').mkdir(parents=True)
prior=repo/'target/g21in1';progress=json.loads((prior/'screen-progress.json').read_text());requests={}
for index in [5,6]:
 attempt=progress[index];w=attempt['cell']['weight_kind']
 path=next((prior/'runs').glob(attempt['label']+'-*-r1-in1/request.json'))
 requests[w]=json.loads(path.read_text())
 assert requests[w]['cell']['k']==50 and requests[w]['cell']['threads']==1
 assert requests[w]['cell']['outputs']=='all' and requests[w]['cell']['design']=='bottleneck_ring'
manifest=json.loads((repo/'benchmarks/systematic/manifest.json').read_text())
manifest['measurement'].update(command_timeout_seconds=90,rss_interval_seconds=.05)
specs=[('nrt2','aw',1_000_000_000),('in1','none',1_000_000_000),('nrt2','aw',1_500_000_000),('in1','aw',1_500_000_000)]
plan=dict(schema='ols-retained-serial-window-memory-v1',specs=specs,
 scope='Whole-fit constrained admission and numerical behavior only. Runs beside independent auditing; elapsed times are diagnostic and cannot rank performance. Preserve all failures.',
 controller_sha256=broad.sha(Path(__file__)),runner_sha256=broad.sha(Path(run.__file__)),
 original_worker_sha256=hashlib.sha256(original).hexdigest(),worker_sha256=broad.sha(worker))
broad.write(root/'diagnostic-plan.json',plan);(root/'execution-source.py').write_bytes(Path(__file__).read_bytes());records=[]
os.environ['ONE_FE_BREADTH_OUTPUTS']='all'
for index,(variant,weight,usable) in enumerate(specs):
 request=requests[weight];identity=json.loads((artifacts/f'identity-{variant}.json').read_text())
 assert broad.sha(artifacts/variant/'dist/fereg_macos.plugin')==identity['plugin']
 cell=dict(request['cell'],diagnostic_available_bytes=usable+536_870_912,
  fit_options='residuals(out_resid) preconditioner(auto) memory(fast)')
 fingerprint=dict(native=identity,controller={p.name:broad.sha(p) for p in folder.iterdir() if p.is_file()},
  harness_sha256=broad.sha(Path(__file__)))
 label=f'memory-c{index:03d}-{variant}';out=root/'runs'/label
 result=measure(root,cell,'fereg','warm',Path(request['data']),Path(request['warm']),out,manifest,
  identity=fingerprint,source=artifacts/variant,trace=True,solver='auto')
 records.append(dict(index=index,label=label,variant=variant,weight=weight,usable_bytes=usable,
  status=result['status'],result_sha256=broad.sha(out/'result.json')))
 broad.write(root/'diagnostic-progress.json',records)
 print(label,weight,usable,result['status'],result.get('metadata',{}).get('rc'),flush=True)
broad.write(root/'diagnostic-complete.json',dict(status='attempts_complete',planned=len(specs),attempted=len(records),
 plan_sha256=broad.sha(root/'diagnostic-plan.json'),progress_sha256=broad.sha(root/'diagnostic-progress.json')))

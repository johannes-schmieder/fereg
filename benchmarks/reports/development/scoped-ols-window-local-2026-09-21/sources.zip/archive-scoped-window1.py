import hashlib,io,json,subprocess,sys,tarfile,zipfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import archive_science
output=repo/'benchmarks/reports/development/scoped-ols-window-local-2026-09-21'
roots=[repo/'target'/name for name in ['g21ow3','g21nrt2','g21owmem1','g21owmem3']]
for name,count in [('ols-window',13),('narrow-residual',14)]:
 d=json.loads((art/f'{name}-inference1.json').read_text());assert d['complete'] and d['planned']==d['native_complete']==count
assert 'SCOPED_WINDOW_WITH_NARROW_REVERT_BUILD_AND_TESTS_PASS' in (art/'build-owf1-controller1.txt').read_text()
archive_science.archive(roots,output,compact=True,omit_output_arrays=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def portable(raw):
 return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={k:{} for k in ['sources','checks']}
variants=['in1','ow2','nrt1','nrt2','owf1']
with zipfile.ZipFile(output/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 def add(name,raw):
  clean=portable(raw);z.writestr(name,clean);tables['sources'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
 for variant in variants+['ow1']:
  p=art/(f'identity-{variant}.json' if variant!='ow1' else 'failed-ow1-source1.json')
  identity=json.loads(p.read_text());add(p.name,p.read_bytes())
  raw=subprocess.check_output(['/opt/homebrew/bin/git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'],cwd=repo)
  with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
   base={e.name:sha(archive.extractfile(e).read()) for e in archive.getmembers() if e.isfile()}
  for relative,digest in identity['source'].items():
   raw=(art/variant/relative).read_bytes();assert sha(raw)==digest
   if base.get(relative)!=digest:add(variant+'/'+relative,raw)
 for name in ['audit_milestone.py','audit_outputs.py','graph_oracle.py','run.py','route_development.py','score.py','broad.py','archive_science.py']:
  add(name,(repo/'benchmarks/two_fe_dense'/name).read_bytes())
 for relative in ['tests/python/test_graph_inventory_audit.py','benchmarks/one_fe_optimization/build.py','docs/adr/0095-retained-serial-ols-lsmr-window.md']:
  add(relative,(repo/relative).read_bytes())
 names=['archive-scoped-window1.py','ols-window-screen1.py','ols-window-screen2.py','narrow-residual-screen1.py','score-kernel-screen2.py',
 'ols-window-memory1.py','ols-window-memory2.py','ols-window-memory3.py','audit-ols-window-memory1.py','audit-ols-window-memory-followup1.py','sw1-memory-output-auditor1.py',
 'check-cached-oracles1.py','narrow-residual-update1.patch','implement-ols-window1.py','ols-window-fixtures1.py','prepare-narrow-residual-patch1.py',
 'run-ow1-build1.sh','run-ow2-build1.sh','run-nr1-build1.sh','run-nrt1-build1.sh','run-nrt2-build1.sh','run-owf1-build1.sh']
 for name in names:add(name,(art/name).read_bytes())
 with zipfile.ZipFile(repo/'benchmarks/reports/development/current-ols-primary-screen-local-2026-09-21/sources.zip') as old:
  add('cached-primary-audit_milestone.py',old.read('audit_milestone.py'))
with zipfile.ZipFile(output/'checks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 paths=set()
 for pattern in ['ols-window-*.json','ols-window-*.txt','narrow-residual-*.json','narrow-residual-*.txt','owf1-*-tests1.txt','graph-oracle-cache-tests1.txt','cached-oracle-equivalence1.*','current-primary-inference1.json',
  'build-ow1-controller1.txt','build-ow2-controller1.txt','build-nr1-controller1.txt','build-nrt1-controller1.txt','build-nrt2-controller1.txt','build-owf1-controller1.txt','build-ow1.log']:
  paths.update(p for p in art.glob(pattern) if p.is_file())
 for p in sorted(paths):
  raw=p.read_bytes();clean=portable(raw);z.writestr(p.name,clean);tables['checks'][p.name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
for kind,table in tables.items():(output/(kind+'-hashes.json')).write_text(json.dumps(table,indent=2)+'\n')
v=(repo/'benchmarks/reports/development/current-ols-primary-screen-local-2026-09-21/verify.py').read_text()
v=v.replace("['in1']",repr(variants)).replace('current-ols-primary-archive-integrity-v1','scoped-ols-window-archive-integrity-v1').replace('CURRENT_OLS_PRIMARY_ARCHIVE_INTEGRITY_PASS','SCOPED_OLS_WINDOW_ARCHIVE_INTEGRITY_PASS')
v=v.replace("if name in ['current-primary-inference1.json']:","if name in ['current-primary-inference1.json', 'ols-window-inference1.json', 'narrow-residual-inference1.json']:")
marker='receipt = dict(';assert v.count(marker)==1
extra='''with zipfile.ZipFile(folder / 'sources.zip') as bundle:
    identity = json.loads(bundle.read('failed-ow1-source1.json'))
    data = subprocess.check_output(['git', 'archive', identity['base_commit'],
        'Cargo.toml', 'Cargo.lock', 'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        reconstructed = {e.name: sha(archive.extractfile(e).read()) for e in archive.getmembers() if e.isfile()}
    for relative in identity['source']:
        name = 'ow1/' + relative
        if name in bundle.namelist(): reconstructed[relative] = sha(bundle.read(name))
    assert reconstructed == identity['source']
with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    table = json.loads((folder / 'checks-hashes.json').read_text())
    for name in ['ols-window-inference1.json', 'narrow-residual-inference1.json']:
        audit = json.loads(bundle.read(name))
        assert audit['oracle_cache_sha256'] == table['current-primary-inference1.json']['original_sha256']
    equivalent = json.loads(bundle.read('cached-oracle-equivalence1.json'))
    assert len(equivalent['checks']) == 2 and all(r['oracle_exact_equality'] for r in equivalent['checks'])
    assert equivalent['source_sha256'] in known_sources

'''
v=v.replace(marker,extra+marker).replace('sources=sources,','sources=sources, failed_ow1_source_reconstruction="all_captured_hashes_match",')
(output/'verify.py').write_text(v)
rows=[]
for name,base,candidate in [('ols-window','in1','nrt2'),('narrow-residual','ow2','nrt2')]:
 d=json.loads((art/f'{name}-score1.json').read_text())
 for c in d['cells']:
  cell=c['cell'];s=c['median_seconds'];peaks=[p['native_peaks'][candidate]-p['native_peaks'][base] for p in c['pairs']]
  rows.append(f"| {name} | {c['index']} | {cell['design']} | {cell['weight_kind']} | {cell['k']} | {cell['threads']} | {cell['case']} | {1000*s[base]:.0f} | {1000*s[candidate]:.0f} | {c['median_native_ratio']:.4f} | {min(peaks):.0f} to {max(peaks):.0f} |")
(output/'README.md').write_text('''# Scoped serial OLS memory and narrow residual experiments

The scoped serial LSMR window reduces the unit ring K50/T1/full-output tracked
allocation peak from 645,481,767 to 523,613,047 bytes, a reduction of
121,868,720 bytes. Its paired whole-command ratio is 0.9948. All other measured
peaks are unchanged. Across thirteen cells, native paired runtime ratios are
0.9908–1.0171, with exact finite exports, samples and saved vectors in all
39 native pairs. All 78 calls complete without detected timing overlap.
This is a narrow memory benefit, not a broad runtime speedup or Linux acceptance.

The separate fourteen-cell residual traversal experiment completes 126 calls
with clean isolation and exact exports, samples and allocation peaks in all
42 native pairs. It shows no consistent useful gain; ratios range from
0.9783 to 1.0345, including excluded controls. The change was rejected and
reverted. The new owf1 candidate contains the scoped memory policy and the
preceding residual traversal. Its build, actual ABI check and eight focused
transport, memory, MAP, numeric and weighted full-fit fixtures pass.

Independent inference passes all 26 native window and 28 native residual
comparisons. All 162 within-arm repeats and 78 native saved-output checks
pass. The residual reference audit has thirteen passes and one discrepancy;
that default-fixest discrepancy remains recorded. The native output auditor
was also mistakenly invoked on fixest; its wrong-arm assertion is preserved
as a controller error, not a scientific reference failure.

The new optional oracle cache binds the independent solver source, complete
prior audit, weight/VCE and byte-identical original input. Every fresh export
is still compared, and every native fit retains its fresh runtime certificates.
Missing cache entries use a fresh independent solve. All fourteen residual
cells reuse the audited primary equations; the window cells use fresh solves.
Four controller fixtures cover completeness, cache hits/misses, changed actual
input, wrong source, incomplete records and conflicting entries. Two fresh
independent re-solves exactly reproduce the cached unit and weighted oracles.

Ten constrained-memory attempts preserve one successful unit ring fit,
seven r(909) rejections and two ninety-second weighted timeouts. At 1 GB
usable, nrt2 passes the unit fit with independent inference and outputs where
in1 rejects. Both weighted 1 GB calls reject in the joint automatic preflight;
both weighted 1.5 GB calls time out. Both 300 MB nrt2 requests reject.
The scoped policy does not resolve the weighted constrained case. These
concurrent-audit diagnostics do not rank runtime or prove transaction atomicity.

The archive also preserves the failed ow1 compilation, ow2's overly strict
memory-fixture assertion, a pre-existing artifact-name collision and a
controller-only visible-error patch assertion. None changed scientific
thresholds or overwrote existing artifacts. The corrected memory fixture
recognizes an unchanged preconditioner-construction peak exactly.

| Experiment | Index | Graph | Weight | K | T | Request | Before ms | nrt2 ms | Paired ratio | Peak change, bytes |
|---|---:|---|---|---:|---:|---|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

`verify.py` reconstructs all five successful source snapshots and the failed
ow1 source, checks archived hashes and binds both cache users to the original
independent oracle receipt. Large output arrays remain local with hashes;
raw licensed logs and compiled binaries are omitted. The new candidate still
requires final protected inventories and Linux confirmation. No installation,
push, release or production acceptance of the cycle routing experiment occurs.
''')
print('SCOPED_OLS_WINDOW_ARCHIVE_PREPARED')

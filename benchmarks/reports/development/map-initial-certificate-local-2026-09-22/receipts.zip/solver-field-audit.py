"""Compare all non-clock public solver fields using the declared result schemas."""
import csv,json
from pathlib import Path
r=Path('target/owned-certificate-20260922');records=[]
# One-based wire columns: result.rs::write_solver_row; ppml_result.rs::solver_matrix.
clock_columns={'fereg_solver.csv':{9,10},'feppml_solver.csv':{14,15,16}}
for block in ['pairs','fresh','weak-native','controls']:
 root=r/block;plan=json.loads((root/'plan.json').read_text())
 for case,cell in enumerate(plan['cells']):
  name='fereg_solver.csv' if cell['model']=='ols' else 'feppml_solver.csv'
  for rep in range(plan['repeats']):
   parts=[]
   for v in ['projrow1','mapinit1']:
    with (root/f'runs/c{case}-r{rep}-{v}'/name).open() as f:
     parts.append([(int(x['row']),int(x['column']),x['value'].strip()) for x in csv.DictReader(f) if int(x['column']) not in clock_columns[name]])
   assert parts[0] and parts[0]==parts[1],(block,case,rep)
   records.append(dict(block=block,case=case,repetition=rep,fields=len(parts[0]),exact=True))
(r/'solver-field-audit.json').write_text(json.dumps(dict(scope='All non-clock solver matrix values, including routes, preconditioners, iterations, contraction, fallback and certificates',clock_columns={k:sorted(v) for k,v in clock_columns.items()},records=records),indent=2)+'\n')
print('EXACT_SOLVER_PAIRS',len(records))

"""Join fresh confirmations without replacing original failures."""
import hashlib, json, statistics
from collections import Counter
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
bound = {}
def read(name):
    path = art / (name + '.json')
    bound[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return json.loads(path.read_text())
reference = read('current-graphs1-reference-score1')
frequency = read('current-graphs1-frequency-score1')
ra = read('current-graphs1-reference-inference1')
fa = read('current-graphs1-frequency-inference1')
nested = read('current-graph-nested-confirm-score1')['cells'][0]
d2 = read('current-graph-fw-confirm-score1')['cells'][0]
cycle = read('cycle-fw-confirm-score1')
ca = read('cycle-fw-confirm-inference1')
decimal = read('cycle-fw-confirm-decimal1')
original_decimal = read('cycle-effect-adjudication1')
paired = read('cycle-fw-confirm-paired-outputs1')
for name in ['current-graph-nested-confirm-inference1', 'current-graph-fw-confirm-inference1']:
    audit = read(name)
    assert audit['native_complete'] == audit['planned']
assert reference['planned'] == reference['timing_eligible'] == 126
assert frequency['planned'] == 42 and frequency['timing_eligible'] == 38
assert ra['native_complete'] == 126 and fa['native_complete'] == 38
assert ca['native_complete'] == ca['planned'] == 2 and ca['repetitions'] == 5
assert all(p['status'] == 'mismatch' and p['science']['sample_exact'] for p in paired['records'])
assert len(paired['records']) == 10
for evidence, expected in [(decimal, 20), (original_decimal, 4)]:
    assert len(evidence['records']) == expected
    for record in evidence['records']:
        assert record['precision_50_80_float_equality']
        assert record['status'] == ('pass' if record['run'].endswith('-owf1') else 'mismatch')
records = []
for kind, score, audit in [('reference', reference, ra), ('frequency', frequency, fa)]:
    for item, science in zip(score['cells'], audit['records']):
        assert item['cell'] == science['cell']
        native = [a for a in science['attempts'] if a.get('variant') == 'owf1']
        assert len(native) == 1 and native[0]['status'] == 'pass'
        index = item['index']
        record = dict(kind=kind, index=index, cell=item['cell'], original_ratio=item.get('median_paired_ratio'),
            original_timing_eligible=item['timing_eligible'], original_issues=item['issues'],
            candidate_science='pass', candidate_original_counts=science['application_counts']['owf1'],
            outcome='original_complete', accepted_ratio=item.get('median_paired_ratio'))
        if kind == 'reference' and index == 117:
            assert nested['cell'] == item['cell'] and nested['isolation'] == 'no_detected_overlap'
            record.update(outcome='fresh_five_pair_confirmation', accepted_ratio=nested['median_reference_ratio'])
        if kind == 'frequency' and index == 1:
            assert d2['cell'] == item['cell'] and d2['isolation'] == 'no_detected_overlap'
            record.update(outcome='fresh_five_pair_confirmation', accepted_ratio=statistics.median(
                p['seconds']['owf1'] / p['seconds']['baseline'] for p in d2['pairs']))
        if kind == 'frequency' and index in [29, 31]:
            assert science['application_counts']['owf1']['passing'] == 3
            assert science['application_counts']['baseline']['passing'] == 0
            record.update(outcome='candidate_complete_baseline_timeout', accepted_ratio=None)
        if kind == 'frequency' and index in [33, 35]:
            fresh = cycle['cells'][[33, 35].index(index)]
            assert fresh['cell'] == item['cell'] and fresh['isolation'] == 'no_detected_overlap'
            record.update(outcome='fresh_five_pairs_baseline_effect_mismatch_adjudicated',
                accepted_ratio=fresh['median_native_ratio'], candidate_fresh_repeats=5)
        if record['accepted_ratio'] is not None:
            assert record['accepted_ratio'] < (1 if kind == 'reference' else 1.05)
        records.append(record)
roots = ['g21currentgraphs1', 'g21nestedconfirm1', 'g21d2fwconfirm1', 'g21cyclefwconfirm1']
counts = {}
for name in roots:
    results = [json.loads(p.read_text()) for p in (repo / 'target' / name / 'runs').glob('*/result.json')]
    counts[name] = dict(attempts=len(results), statuses=dict(Counter(r['status'] for r in results)))
assert counts['g21currentgraphs1']['attempts'] == 996
assert sum(v['attempts'] for v in counts.values()) == 1046
receipt = dict(schema='current-graph-coverage-adjudication-v1', controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    evidence_sha256=bound, application_counts=counts, records=records,
    candidate_complete_cells=168, reference_winning_cells_with_confirmation=126,
    frequency_complete_pairs_with_confirmation=40, frequency_baseline_timeouts=2,
    scope='All candidate cells complete with original or fresh repeats. Two baseline timeouts remain unranked; two baseline effect mismatches remain failures adjudicated against independent Decimal equations. Original records are unchanged. Development evidence only.')
with (art / 'current-graph-adjudication1.json').open('x') as stream:
    json.dump(receipt, stream, indent=2); stream.write('\n')
print('CURRENT_GRAPH_ADJUDICATION_PASS', len(records), counts)

"""Confirm every approved large graph cell on owf1, with valid comparators.

Keep all 168 inputs and three pairs. Ordinary-weight cells compare owf1 with
default fixest; FW cells compare with the pinned native baseline. The earlier
three-arm measurements and their failures remain immutable. The 111 protected
baseline controls are a separate current-artifact campaign.
"""
import copy, json, sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import milestone
import route_development as route

def plans():
    manifest = repo / 'benchmarks/manifests/ols_optimization_20260921_v1.json'
    spec = json.loads(manifest.read_text())
    for name in ['primary', 'holdout']:
        assert broad.sha(repo / spec['protection'][name + '_manifest']) == spec['protection'][name + '_manifest_sha256']
    freeze_path = art / 'final-candidate-freeze1.json'
    freeze = json.loads(freeze_path.read_text())
    assert broad.sha(art / 'identity-owf1.json') == freeze['identity_sha256']
    assert broad.sha(art / 'owf1/dist/fereg_macos.plugin') == freeze['plugin']
    baseline = json.loads((art / 'identity-baseline.json').read_text())
    assert baseline['base_commit'] == spec['baseline_commit'] and baseline['abi'] == 'pass'
    assert broad.sha(art / 'baseline/dist/fereg_macos.plugin') == baseline['plugin']
    cells = milestone.expand(spec, 'screen')
    assert len(cells) == 168
    assert not any(cell['seed'] in spec['measurement']['fresh_validation_seeds'] for cell in cells)
    # score.py uses the older broad-inventory threshold names. This explicit
    # execution projection adds those aliases without altering the manifest.
    projected = copy.deepcopy(spec)
    projected['acceptance'] = dict(
        primary_max_median_paired_ratio=spec['measurement']['maximum_primary_median_paired_ratio'],
        native_control_max_confirmed_regression=spec['measurement']['maximum_confirmed_native_control_ratio'])
    result = []
    for kind, count, variants in [('reference', 126, ['owf1', 'fixest']), ('frequency', 42, ['baseline', 'owf1'])]:
        indices = [index for index, cell in enumerate(cells) if (cell['weight_kind'] == 'fw') == (kind == 'frequency')]
        assert len(indices) == count
        result.append(dict(schema='two-fe-broad-execution-v1', label='current-graphs1-' + kind,
            phase='screen', inventory_kind='controls' if kind == 'frequency' else 'primary',
            repetitions=3, variants=variants, cells=[cells[index] for index in indices],
            original_cell_indices=indices, source_inventory_cells=168,
            manifest=projected, manifest_sha256=broad.sha(manifest),
            manifest_projection='Original approved milestone plus mechanically renamed score.py acceptance thresholds.',
            purpose=__doc__, controller_sha256=broad.sha(Path(__file__)),
            cell_expander_sha256=broad.sha(Path(milestone.__file__)),
            cell_runner_sha256=freeze['cell_runner_sha256'], isolation_source_sha256=freeze['isolation_source_sha256'],
            baseline_identity_sha256=broad.sha(art / 'identity-baseline.json'),
            candidate_freeze_sha256=broad.sha(freeze_path)))
    assert sorted(index for plan in result for index in plan['original_cell_indices']) == list(range(168))
    for plan in result:
        assert all(cell == cells[index] for index, cell in zip(plan['original_cell_indices'], plan['cells']))
    return result, freeze

def main():
    inventories, freeze = plans()
    if sys.argv[1:] == ['--dry-run']:
        print(json.dumps(dict(status='inventory_and_identities_pass', planned=168,
            groups=[dict(label=p['label'], cells=len(p['cells']), variants=p['variants'],
                original_cell_indices=p['original_cell_indices']) for p in inventories]), indent=2))
        return
    assert not sys.argv[1:]
    root = repo / 'target/g21currentgraphs1'
    root.mkdir(exist_ok=False)
    (root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
    completions = []
    for plan in inventories:
        label = plan['label']
        broad.write(root / (label + '-plan.json'), plan)
        progress = []
        for index, cell in enumerate(plan['cells']):
            assert broad.sha(repo / 'benchmarks/two_fe_dense/run.py') == freeze['cell_runner_sha256']
            assert broad.sha(Path(route.__file__)) == freeze['isolation_source_sha256']
            assert broad.sha(art / 'owf1/dist/fereg_macos.plugin') == freeze['plugin']
            cell_label = f'{label}-c{index:03d}'
            output = root / (cell_label + '.stdout.txt')
            command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root),
                '--artifacts', str(art), '--label', cell_label, '--variants', *plan['variants'],
                '--repeats', '3', '--timeout', '240', '--keep-going',
                '--record-reference-science-disagreement', '--record-reference-output-disagreement',
                *broad.arguments(cell)]
            code, isolation = route.invoke(command, output)
            completion = root / (cell_label + '-complete.json')
            status = json.loads(completion.read_text())['status'] if completion.exists() else 'incomplete'
            progress.append(dict(index=index, original_index=plan['original_cell_indices'][index],
                label=cell_label, cell=cell, command=command, process_returncode=code,
                comparison_status=status, stdout_sha256=broad.sha(output), timing_isolation=isolation))
            broad.write(root / (label + '-progress.json'), progress)
            print(label, index + 1, '/', len(plan['cells']), code, status, isolation['status'], flush=True)
        complete = dict(status='attempts_complete', attempted=len(progress), planned=len(plan['cells']),
            process_failures=sum(row['process_returncode'] != 0 for row in progress),
            plan_sha256=broad.sha(root / (label + '-plan.json')),
            progress_sha256=broad.sha(root / (label + '-progress.json')))
        broad.write(root / (label + '-complete.json'), complete)
        completions.append(complete)
    broad.write(root / 'current-graphs1-complete.json', dict(status='attempts_complete', planned=168,
        attempted=sum(row['attempted'] for row in completions),
        process_failures=sum(row['process_failures'] for row in completions)))
    print('CURRENT_GRAPH_COVERAGE_ATTEMPTS_COMPLETE', flush=True)

if __name__ == '__main__':
    main()

import json, os, subprocess, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
root = repo / 'target/g21cyclefwconfirm1'
base = repo / 'benchmarks/two_fe_dense'
sys.path.insert(0, str(base))
import run
from score import sha
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
commands = [
 ('score', [sys.executable, str(art / 'score-kernel-screen2.py'), str(root), str(art / 'cycle-fw-confirm-score1.json')]),
 ('inference', [sys.executable, str(base / 'audit_milestone.py'), str(root), 'screen', str(art / 'cycle-fw-confirm-inference1.json')]),
 ('owf1-outputs', [sys.executable, str(base / 'audit_outputs.py'), str(root), 'cycle', 'owf1']),
 ('baseline-outputs', [sys.executable, str(base / 'audit_outputs.py'), str(root), 'cycle', 'baseline']),
]
for kind, command in commands:
    with (art / ('cycle-fw-confirm-' + kind + '1.txt')).open('x') as stream:
        process = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    print(kind, process.returncode, flush=True)
    if process.returncode: raise SystemExit(process.returncode)
plan = json.loads((root / 'screen-plan.json').read_text())
records = []
for index, cell in enumerate(plan['cells']):
    for pair in range(1, plan['repeats'] + 1):
        paths = {v: list((root / 'runs').glob(f'cycle-c{index:03d}-p{pair:03d}-{v}-*/result.json')) for v in plan['variants']}
        assert all(len(found) == 1 for found in paths.values())
        paths = {v: found[0] for v, found in paths.items()}
        baseline, candidate = paths['baseline'].parent, paths['owf1'].parent
        science = run.profile.compare(baseline, candidate, exact_native=False)
        try:
            outputs = run.compare_outputs(baseline, candidate, cell['n'], 'all', effect_count=2)
            status = 'pass'
        except AssertionError as error:
            outputs, status = dict(detail=str(error)), 'mismatch'
        records.append(dict(cell=index, pair=pair, status=status, science=science, outputs=outputs,
            result_sha256={v: sha(path) for v, path in paths.items()}))
with (art / 'cycle-fw-confirm-paired-outputs1.json').open('x') as stream:
    json.dump(dict(schema='cycle-fw-paired-output-comparison-v1', source_sha256=sha(Path(__file__)),
        comparator_source_sha256=sha(Path(run.__file__)), plan_sha256=sha(root / 'screen-plan.json'),
        records=records), stream, indent=2)
    stream.write('\n')
paths = sorted((root / 'runs').glob('*/result.json'))
assert len(paths) == 20
command = [sys.executable, str(base / 'cycle_effect_oracle.py'), str(art / 'cycle-fw-confirm-decimal1.json'),
    '--oracle-receipt', str(art / 'cycle-fw-confirm-inference1.json'), *map(str, paths)]
with (art / 'cycle-fw-confirm-decimal1.txt').open('x') as stream:
    process = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
print('decimal', process.returncode, flush=True)
raise SystemExit(process.returncode)

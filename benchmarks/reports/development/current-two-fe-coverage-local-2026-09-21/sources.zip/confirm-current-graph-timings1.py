import json, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route
kind = sys.argv[1]
assert kind in ['nested', 'frequency']
original_kind, original_index, root_name = ('reference', 117, 'g21nestedconfirm1') if kind == 'nested' else ('frequency', 1, 'g21d2fwconfirm1')
original_path = repo / 'target/g21currentgraphs1' / f'current-graphs1-{original_kind}-plan.json'
original = json.loads(original_path.read_text())
cell = original['cells'][original_index]
freeze = json.loads((art / 'final-candidate-freeze1.json').read_text())
assert broad.sha(art / 'identity-owf1.json') == freeze['identity_sha256']
root = repo / 'target' / root_name
root.mkdir(exist_ok=False)
variants = ['sf1', 'owf1', 'fixest'] if kind == 'nested' else ['sf1', 'owf1']
extra = None if kind == 'nested' else dict(index=0, variant='baseline')
plan = dict(schema='current-ols-graph-timing-confirmation-v1', cells=[cell], baseline='sf1', candidate='owf1',
    variants=variants, repeats=5, original_index=original_index, original_plan_sha256=broad.sha(original_path),
    original_score_sha256=broad.sha(art / f'current-graphs1-{original_kind}-score1.json'),
    controller_sha256=broad.sha(Path(__file__)), isolation_source_sha256=broad.sha(Path(route.__file__)),
    candidate_freeze_sha256=broad.sha(art / 'final-candidate-freeze1.json'),
    purpose='Five fresh pairs for a failed screen, adding the earlier sf1 candidate to distinguish source changes from variable runtime. Preserve original failures; no kernel or tolerance change.')
if extra: plan['extra_control'] = extra
broad.write(root / 'screen-plan.json', plan)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
label = 'confirm-c000'
measured = (['baseline'] if extra else []) + variants
command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root), '--artifacts', str(art),
    '--label', label, '--variants', *measured, '--repeats', '5', '--timeout', '240', '--keep-going',
    '--record-reference-science-disagreement', '--record-reference-output-disagreement', *broad.arguments(cell)]
code, isolation = route.invoke(command, root / (label + '.stdout.txt'))
completion = root / (label + '-complete.json')
status = json.loads(completion.read_text())['status'] if completion.exists() else 'incomplete'
progress = [dict(index=0, cell=cell, label=label, command=command, process_returncode=code,
    comparison_status=status, timing_isolation=isolation)]
broad.write(root / 'screen-progress.json', progress)
broad.write(root / 'screen-complete.json', dict(status='attempts_complete', planned=1, attempted=1,
    process_returncode=code, plan_sha256=broad.sha(root / 'screen-plan.json')))
print('CURRENT_GRAPH_TIMING_CONFIRMATION', kind, code, status, isolation['status'], flush=True)
if code: raise SystemExit(code)

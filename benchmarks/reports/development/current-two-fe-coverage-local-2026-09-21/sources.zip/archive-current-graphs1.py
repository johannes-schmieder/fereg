import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science
output = repo / 'benchmarks/reports/development/current-two-fe-coverage-local-2026-09-21'
adjudication = json.loads((art / 'current-graph-adjudication1.json').read_text())
assert adjudication['candidate_complete_cells'] == 168
roots = [repo / 'target' / name for name in adjudication['application_counts']]
archive_science.archive(roots, output, compact=True, omit_output_arrays=True)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>').replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')
tables = {kind: {} for kind in ['sources', 'checks']}
with zipfile.ZipFile(output / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['baseline', 'sf1', 'owf1']:
        path = art / f'identity-{variant}.json'
        identity = json.loads(path.read_text()); add(path.name, path.read_bytes())
        raw = subprocess.check_output(['git', 'archive', identity['base_commit'], 'Cargo.toml', 'Cargo.lock',
            'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as tree:
            original = {entry.name: sha(tree.extractfile(entry).read()) for entry in tree.getmembers() if entry.isfile()}
        for relative, digest in identity['source'].items():
            raw = (art / variant / relative).read_bytes(); assert sha(raw) == digest
            if original.get(relative) != digest: add(variant + '/' + relative, raw)
    for name in ['milestone.py', 'ols_next_milestone.json', 'score.py', 'audit_milestone.py', 'audit_protection.py',
                 'audit_outputs.py', 'run.py', 'route_development.py', 'graph_oracle.py', 'cycle_effect_oracle.py', 'archive_science.py']:
        path = repo / 'benchmarks/two_fe_dense' / name
        if path.exists(): add(name, path.read_bytes())
    for relative in ['benchmarks/one_fe_profile/run.py', 'tests/python/test_cycle_effect_oracle.py']:
        add(relative, (repo / relative).read_bytes())
    for name in ['current-graph-coverage1.py', 'audit-current-graph-coverage1.py', 'confirm-current-graph-timings1.py',
                 'capture-cycle-fw-pairs1.py', 'audit-cycle-fw-pairs1.py', 'score-kernel-screen2.py',
                 'join-current-graphs1.py', 'failed-join-current-graphs1.py', 'archive-current-graphs1.py']:
        add(name, (art / name).read_bytes())
with zipfile.ZipFile(output / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    paths = [path for path in art.iterdir() if path.suffix in ['.json', '.txt'] and
        any(path.name.startswith(prefix) for prefix in ['current-graph', 'cycle-fw-', 'cycle-effect-'])]
    paths += [art / name for name in ['final-candidate-freeze1.json', 'm5-ring-cycle-inference1.json']]
    for path in sorted(paths):
        raw = path.read_bytes(); clean = portable(raw); bundle.writestr(path.name, clean)
        tables['checks'][path.name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
for kind, table in tables.items():
    (output / (kind + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')
verifier = (repo / 'benchmarks/reports/development/current-ols-controls-local-2026-09-21/verify.py').read_text()
verifier = verifier.replace("['baseline', 'owf1']", "['baseline', 'sf1', 'owf1']")
start = verifier.index("with zipfile.ZipFile(folder / 'checks.zip') as bundle:", verifier.index('known_sources ='))
end = verifier.index('\nreceipt =', start)
verifier = verifier[:start] + '''with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    hashes = json.loads((folder / 'checks-hashes.json').read_text())
    joined = json.loads(bundle.read('current-graph-adjudication1.json'))
    assert joined['controller_sha256'] in known_sources
    assert joined['candidate_complete_cells'] == len(joined['records']) == 168
    for name, digest in joined['evidence_sha256'].items():
        assert hashes[name]['original_sha256'] == digest, name
    for name in hashes:
        if name.endswith('inference1.json') and name != 'm5-ring-cycle-inference1.json':
            audit = json.loads(bundle.read(name))
            assert audit['complete'] and audit['controller_sha256'] in known_sources
            assert audit['oracle_source_sha256'] in known_sources
            cache = audit.get('oracle_cache_sha256')
            assert cache is None or cache in {entry['original_sha256'] for entry in hashes.values()}
    for name in ['cycle-effect-adjudication1.json', 'cycle-fw-confirm-decimal1.json']:
        audit = json.loads(bundle.read(name))
        assert audit['source_sha256'] in known_sources
        assert audit['independent_inference_receipt_sha256'] in {entry['original_sha256'] for entry in hashes.values()}
    freeze = json.loads(bundle.read('final-candidate-freeze1.json'))
    assert freeze['plugin'] == next(item['plugin'] for item in sources if item['variant'] == 'owf1')

''' + verifier[end:]
verifier = verifier.replace('current-ols-controls-archive-integrity-v1', 'current-two-fe-coverage-archive-integrity-v1')
verifier = verifier.replace('CURRENT_OLS_CONTROLS_ARCHIVE_INTEGRITY_PASS', 'CURRENT_TWO_FE_COVERAGE_ARCHIVE_INTEGRITY_PASS')
(output / 'verify.py').write_text(verifier)
(output / 'README.md').write_text('''# Current two-FE graph, weight and output coverage

The frozen owf1 candidate completes all 168 unchanged large coverage cells
using the original screen or explicit fresh confirmations. The original
screen attempted 996 calls: 994 passed and two baseline ring fits timed out.
Two frequency-weight cycle output comparisons stopped their cells after the
first pair. These original failures and missing repeats remain unchanged.
Three confirmation campaigns add fifty successful calls with clean isolation.

All 126 ordinary-fixest comparisons win using one fresh five-pair timing
confirmation. The unbalanced AW K6 nested-cluster cell originally had paired
ratio 1.37398; the fresh ratio is 0.68852, with 83 versus 121 ms medians.
All 168 candidate first-fit independent inference checks pass. Original or
fresh per-arm repeat audits complete each candidate cell. Independent saved-
output normal-equation and reconstruction checks pass for all completed fits.
Default reference disagreements remain visible in the inference receipts.

Frequency weights use the native baseline and independent frequency-correct
equations, supported by the preceding small literal-expansion matrix. Ordinary
fixest weighting does not supply Stata frequency-weight inference. Forty FW
cells have complete pairs within the 1.05 native limit using confirmations;
two baseline ring timeouts remain unranked. The degree-two K6 full-output
screen ratio 1.14758 is preserved; five fresh pairs give 0.91358, with candidate
369 ms versus baseline 404 ms. The comparison with sf1 is 0.98677.

The two FW cycle saved-effect disagreements are adjudicated independently.
A Decimal oracle eliminates the left partitions, grounds the resulting cycle
and solves its tridiagonal path. It uses original data and independently
estimated finite coefficients, never native FE state. Fifty and eighty digits
give bit-identical float arrays. Focused permutation/weight tests match dense
weighted equations and literal frequency expansion. Every fresh candidate
effect passes the original rtol=1e-7, atol=1e-9, with maximum errors below
4e-11; all ten baseline fits fail individual-effect checks near 5.8e-8.
Both arms pass inference and residual checks. Candidate K6/K50 medians are
312/920 ms versus baseline 4896/5563 ms. The ten paired output mismatches
remain failures; no tolerance or production solver was changed to hide them.

The source-bound adjudication identifies the evidence used for each cell.
This archive preserves all 1,046 calls, original timing failures, baseline
timeouts, stopped comparisons, fresh confirmations, the original four-fit
Decimal adjudication and all twenty fresh Decimal audits. A failed first
joiner attempt is retained; it incorrectly expected a timing field in
incomplete cells and changed no measurements. Complete baseline/sf1/owf1
source trees are reconstructible. Large arrays remain local with hashes;
raw licensed logs and binaries are excluded. This is Mac development evidence.
Serial weighted slope losses, routing and Linux confirmation remain open.
No push, installation or release is performed.
''')
print('CURRENT_TWO_FE_COVERAGE_ARCHIVE_PREPARED')

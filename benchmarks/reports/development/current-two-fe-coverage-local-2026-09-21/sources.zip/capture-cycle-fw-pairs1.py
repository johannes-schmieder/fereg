"""Collect complete pairs before separately applying the unchanged comparators.

The original runner stopped the two cells on a native saved-effect mismatch.
Each invocation here measures one unchanged native command. An outer sequence
alternates the native arms, and subsequent independent and paired audits retain
the output discrepancies. No comparison tolerance or estimator is modified.
"""
import json, subprocess, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
root = repo / 'target/g21cyclefwconfirm1'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route

if sys.argv[1:]:
    assert len(sys.argv) == 3 and sys.argv[1] == '--worker'
    index = int(sys.argv[2])
    plan = json.loads((root / 'screen-plan.json').read_text())
    assert broad.sha(Path(__file__)) == plan['controller_sha256']
    cell = plan['cells'][index]
    calls = []
    for rep in range(1, plan['repeats'] + 1):
        variants = plan['variants'] if rep % 2 else plan['variants'][::-1]
        for variant in variants:
            label = f'cycle-c{index:03d}-p{rep:03d}-{variant}'
            output = root / (label + '.stdout.txt')
            assert not output.exists()
            command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root),
                '--artifacts', str(art), '--label', label, '--variants', variant, '--repeats', '1',
                '--timeout', '240', '--keep-going', *broad.arguments(cell)]
            with output.open('x') as log:
                process = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
            calls.append(dict(pair=rep, variant=variant, label=label, command=command,
                process_returncode=process.returncode, stdout_sha256=broad.sha(output)))
            broad.write(root / f'cycle-c{index:03d}-calls.json', calls)
            print(rep, variant, process.returncode, flush=True)
    raise SystemExit(1 if any(call['process_returncode'] for call in calls) else 0)

original_path = repo / 'target/g21currentgraphs1/current-graphs1-frequency-plan.json'
original = json.loads(original_path.read_text())
indices = [33, 35]
cells = [original['cells'][index] for index in indices]
assert [(cell['design'], cell['weight_kind'], cell['k'], cell['case']) for cell in cells] == [
    ('cycle', 'fw', 6, 'cluster2_cross_all'), ('cycle', 'fw', 50, 'cluster2_cross_all')]
freeze = json.loads((art / 'final-candidate-freeze1.json').read_text())
assert broad.sha(art / 'identity-owf1.json') == freeze['identity_sha256']
assert broad.sha(art / 'identity-baseline.json') == original['baseline_identity_sha256']
assert broad.sha(repo / 'benchmarks/two_fe_dense/run.py') == freeze['cell_runner_sha256']
assert broad.sha(Path(route.__file__)) == freeze['isolation_source_sha256']
root.mkdir(exist_ok=False)
(root / 'data').symlink_to(repo / 'target/g21currentgraphs1/data', target_is_directory=True)
plan = dict(schema='cycle-fw-independent-pair-collection-v1', cells=cells, variants=['baseline', 'owf1'],
    baseline='baseline', candidate='owf1', repeats=5, original_indices=indices,
    controller_sha256=broad.sha(Path(__file__)), isolation_source_sha256=broad.sha(Path(route.__file__)),
    original_plan_sha256=broad.sha(original_path), candidate_freeze_sha256=broad.sha(art / 'final-candidate-freeze1.json'),
    prior_adjudication_sha256=broad.sha(art / 'cycle-effect-adjudication1.json'), purpose=__doc__)
broad.write(root / 'screen-plan.json', plan)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
progress = []
for index, cell in enumerate(cells):
    label = f'cycle-c{index:03d}'
    command = [sys.executable, str(Path(__file__)), '--worker', str(index)]
    code, isolation = route.invoke(command, root / (label + '.stdout.txt'))
    progress.append(dict(index=index, cell=cell, label=label, command=command, process_returncode=code,
        comparison_status='collected_for_independent_adjudication', timing_isolation=isolation))
    broad.write(root / 'screen-progress.json', progress)
    print('CYCLE_FW_PAIRS_COLLECTED', cell['k'], code, isolation['status'], flush=True)
broad.write(root / 'screen-complete.json', dict(status='attempts_complete', planned=2, attempted=len(progress),
    process_failures=sum(row['process_returncode'] != 0 for row in progress),
    plan_sha256=broad.sha(root / 'screen-plan.json')))

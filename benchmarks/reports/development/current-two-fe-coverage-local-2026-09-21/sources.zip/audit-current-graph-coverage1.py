import json, os, subprocess, sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
root = repo / 'target/g21currentgraphs1'
base = repo / 'benchmarks/two_fe_dense'
complete = json.loads((root / 'current-graphs1-complete.json').read_text())
assert complete['attempted'] == complete['planned'] == 168
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
records = []
for kind, count in [('reference', 126), ('frequency', 42)]:
    label = 'current-graphs1-' + kind
    commands = [
        ('score', [sys.executable, str(base / 'score.py'), str(root), label,
                   str(art / (label + '-score1.json'))]),
        ('inference', [sys.executable, str(base / 'audit_milestone.py'), str(root), label,
            str(art / (label + '-inference1.json')), '--oracle-cache', str(art / 'm5-ring-cycle-inference1.json')]),
        ('outputs', [sys.executable, str(base / 'audit_outputs.py'), str(root), label, 'owf1']),
    ]
    if kind == 'frequency':
        commands.append(('native-pairs', [sys.executable, str(base / 'audit_protection.py'), str(root), label,
                         str(art / (label + '-native-pairs1.json'))]))
    for check, command in commands:
        with (art / (label + '-' + check + '1.txt')).open('x') as stream:
            process = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
        records.append(dict(inventory=kind, check=check, process_returncode=process.returncode))
        print(kind, check, process.returncode, flush=True)
        if process.returncode:
            raise SystemExit(process.returncode)
    score = json.loads((art / (label + '-score1.json')).read_text())
    science = json.loads((art / (label + '-inference1.json')).read_text())
    print('CURRENT_GRAPH_RESULT', kind, 'science', science['native_complete'], '/', count,
          'eligible', score['timing_eligible'], 'threshold_met', score['timing_threshold_met'],
          'wins', score['wins'], 'ties', score['ties'], 'losses', score['losses'], 'worst', score['worst_ratio'], flush=True)
    for cell in score['cells']:
        if cell['issues'] or not cell['timing_eligible'] or cell.get('median_paired_ratio', float('inf')) > score['threshold']:
            print('GRAPH_REQUIRES_REVIEW', kind, cell['index'], cell.get('median_paired_ratio'),
                  cell['issues'], cell['timing_isolation'], flush=True)
with (art / 'current-graph-audit-complete1.json').open('x') as stream:
    json.dump(dict(status='attempts_complete', records=records), stream, indent=2)
    stream.write('\n')

from pathlib import Path
import hashlib,json,re,statistics,subprocess,sys
sys.dont_write_bytecode=True
r=Path('target/ppml-next-20260922');repo=Path.cwd()
sys.path.insert(0,str(repo/'benchmarks/next_subsystem'))
from audit import compare,runtime
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):
 with (r/name).open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
id=json.loads((r/'artifacts/identity-residual2.json').read_text())
match={p:sha(repo/p)==h for p,h in id['source'].items()};assert all(match.values())
(r/'residual-source.patch').write_bytes(subprocess.check_output(['git','diff','55e9c48f','--','crates/fereg-core/src/fe/borrowed_map.rs']))
(r/'residual-controller.patch').write_bytes(subprocess.check_output(['git','diff','55e9c48f','--','benchmarks/local_fixest_gap/measure.py']))
(r/'residual-first-source.rs').write_bytes((r/'artifacts/residual1/crates/fereg-core/src/fe/borrowed_map.rs').read_bytes())
(r/'residual-new-fixture.do').write_bytes((repo/'tests/stata/development/feppml_single_residual_schur.do').read_bytes())
names=set();tests={}
for f in ['tests-residual-checkpoint-final.txt','tests-residual-ppml-final.txt']:
 s=(r/f).read_text();n=re.findall(r'^test (.*?) \.\.\. ok$',s,re.M);names.update(n)
 assert not re.search(r'^test .*? \.\.\. FAILED$',s,re.M)
 tests[f]=dict(passed=len(n),sha256=sha(r/f))
fixtures=[];trace=[]
for label in ['residual2','residual2-explicit']:
 for rec in json.loads((r/'artifacts'/('fixtures-'+label+'.json')).read_text()):
  p=r/'artifacts/fixtures'/label/Path(rec['fixture']).stem
  log=(p/'run.log').read_text();assert '\n'+rec['fixture_sentinel']+'\n' in log and '\nACCESSOR_FIXTURE_COMPLETE\n' in log
  lines=[x for x in (p/'stdout.txt').read_text().splitlines() if x.startswith('FEREG_SOLVER_TRACE|')]
  fixtures.append(dict(rec,log_sha256=sha(p/'run.log'),stdout_sha256=sha(p/'stdout.txt'),script_sha256=sha(p/'run.do')))
  trace.extend(lines)
(r/'residual-fixture-solver-trace.txt').write_text('\n'.join(trace)+'\n')
accepted=[x for x in trace if 'phase=checkpoint_schur_attempt|outcome=certified|' in x and '|rhs=1|' in x];assert len(accepted)==6
attempts=[];pairs=[];stock=[];phases={};exact=0
for screen,cand in [('residual-screen','residual1'),('residual-confirm','residual2'),('residual-controls','residual2')]:
 s=json.loads((r/(screen+'-summary.json')).read_text());p=json.loads((r/screen/'progress.json').read_text());attempts.extend(p);phases[screen]=[]
 for i,c in enumerate(s['cells']):
  for pair in c['pairs']:
   assert pair['clean'] and pair['checks']['passed'];exact+=pair['exact']['passed'];pairs.append(pair['tracked_peak_bytes'][cand]-pair['tracked_peak_bytes']['means1'])
  assert all(x['checks']['passed'] for x in c['repeats'])
  for repetition in range(3):
   reference=next((x for x in p if x['case']==i and x['repetition']==repetition and x['variant']=='fixest'),None)
   if reference:
    candidate=next(x for x in p if x['case']==i and x['repetition']==repetition and x['variant']==cand)
    checked=compare(r/screen/candidate['result'],r/screen/reference['result'],c['cell']['model']);assert checked['passed']
    stock.append(dict(screen=screen,case=i,repetition=repetition,checks=checked))
  if c['cell']['model']=='ppml':
   vals={}
   for v in ['means1',cand]:
    samples=[runtime(r/screen/x['result'],'ppml') for x in p if x['case']==i and x['variant']==v]
    vals[v]={k:statistics.median(x[k] for x in samples) for k in samples[0] if k.startswith('time_') and all(x[k] is not None for x in samples)}
   phases[screen].append(dict(cell=c['cell'],medians=vals))
assert all(x['status']=='pass' and not x['overlaps'] and not x['monitor_errors'] for x in attempts)
save('residual-phase-medians.json',phases)
save('residual-stock-checks.json',stock)
save('residual-validation.json',dict(artifact=id['plugin'],source_inputs=len(match),source_matches=match,
 new_fixture_sha256=sha(r/'residual-new-fixture.do'),tests=tests,distinct_final_tests=len(names),fixture_records=fixtures,explicit_fixture_single_rhs_schur_acceptances=len(accepted),
 headline_attempts=len(attempts),native_pairs=len(pairs),exact_scientific_pairs=exact,candidate_stock_checks=len(stock),tracked_peak_change_bytes=dict(minimum=min(pairs),maximum=max(pairs)),
 allocation_audit=dict(status='preserved failure on documented source drift',sha256=sha(r/'residual-allocation-audit.txt'))))
print('VALIDATED',len(match),len(names),len(attempts),len(pairs),exact,min(pairs),max(pairs))

import json
from pathlib import Path
import sys
repo=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad
import route_development as route
artifacts=repo/'target/ols-next-20260921'; root=repo/'target/g21dl2'
root.mkdir(exist_ok=False)
selection=[(index,threads) for threads in [1,16] for index in [66,67,70,71,74,75,78,79]]
cells=[route.cells(threads)[index] for index,threads in selection]
plan=dict(schema='ols-direct-lsmr-cost-screen-v1',cells=cells,selection=selection,
    baseline='sf1',candidate='dl1',variants=['sf1','dl1'],repeats=3,
    controller_sha256=broad.sha(Path(__file__)),isolation_source_sha256=broad.sha(Path(route.__file__)),
    acceptance='Diagnostic removal of preceding automatic Schur/CMG work, with automatic LSMR numerical contracts unchanged. No routing rule selected.')
broad.write(root/'screen-plan.json',plan)
(root/'execution-source.py').write_bytes(Path(__file__).read_bytes())
records=[]
for index,cell in enumerate(cells):
    label=f'direct-c{index:03d}'
    command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),
        '--artifacts',str(artifacts),'--label',label,'--variants',*plan['variants'],
        '--repeats','3','--timeout','120','--keep-going',*broad.arguments(cell)]
    code,isolation=route.invoke(command,root/(label+'.stdout.txt'))
    complete=root/(label+'-complete.json')
    records.append(dict(index=index,cell=cell,label=label,command=command,process_returncode=code,
        timing_isolation=isolation,completion=json.loads(complete.read_text()) if complete.exists() else None))
    broad.write(root/'screen-progress.json',records)
    print(index+1,'/',len(cells),label,code,isolation['status'],flush=True)
broad.write(root/'screen-complete.json',dict(status='attempts_complete',attempted=len(records),planned=len(cells),
    plan_sha256=broad.sha(root/'screen-plan.json'),progress_sha256=broad.sha(root/'screen-progress.json')))

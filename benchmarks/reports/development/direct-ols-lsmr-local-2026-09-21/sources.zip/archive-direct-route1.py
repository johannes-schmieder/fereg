import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2]; artifacts=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import archive_science
roots=[repo/'target/g21dl1',repo/'target/g21dl2']
output=repo/'benchmarks/reports/development/direct-ols-lsmr-local-2026-09-21'
for root in roots:
    assert json.loads((root/'screen-complete.json').read_text())['attempted']==16
archive_science.archive(roots,output,compact=True,omit_output_arrays=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={kind:{} for kind in ['sources','checks']}
with zipfile.ZipFile(output/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    def add(name,raw):
        clean=portable(raw);bundle.writestr(name,clean)
        tables['sources'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
    for variant in ['sf1','dl1']:
        path=artifacts/f'identity-{variant}.json';identity=json.loads(path.read_text());add(path.name,path.read_bytes())
        raw=subprocess.check_output(['/opt/homebrew/bin/git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'],cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            base={entry.name:sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
        for relative,digest in identity['source'].items():
            data=(artifacts/variant/relative).read_bytes();assert sha(data)==digest
            if base.get(relative)!=digest: add(variant+'/'+relative,data)
    for name in ['audit_milestone.py','audit_outputs.py','graph_oracle.py','run.py','route_development.py','score.py','broad.py','archive_science.py']:
        add(name,(repo/'benchmarks/two_fe_dense'/name).read_bytes())
    for relative in ['benchmarks/one_fe_optimization/direct_ols_lsmr.py','benchmarks/one_fe_optimization/build.py']:
        add(relative,(repo/relative).read_bytes())
    for name in ['direct-route-screen1.py','direct-route-screen2.py','score-kernel-screen2.py','archive-direct-route1.py']:
        add(name,(artifacts/name).read_bytes())
with zipfile.ZipFile(output/'checks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for index in [1,2]:
        for kind in ['score','inference','outputs','screen']:
            for suffix in ['json','txt']:
                name=f'direct-route-{kind}{index}.{suffix}';path=artifacts/name
                if not path.exists(): continue
                raw=path.read_bytes();clean=portable(raw);bundle.writestr(name,clean)
                tables['checks'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
for kind,table in tables.items(): (output/(kind+'-hashes.json')).write_text(json.dumps(table,indent=2)+'\n')
verifier=(repo/'benchmarks/reports/development/two-fe-coverage-tail-local-2026-09-21/verify.py').read_text()
verifier=verifier.replace("['baseline', 'sf1']","['sf1', 'dl1']").replace('coverage-tail-archive-integrity-v1','direct-ols-lsmr-archive-integrity-v1').replace('COVERAGE_TAIL_ARCHIVE_INTEGRITY_PASS','DIRECT_OLS_LSMR_ARCHIVE_INTEGRITY_PASS')
verifier=verifier.replace("if name.endswith('-inference1.json') and name != 'wr2-memory-inference1.json':", "if name in ['direct-route-inference1.json', 'direct-route-inference2.json']:")
verifier=verifier.replace("assert audit['controller_sha256'] in known_sources, name", "assert audit['controller_sha256'] in known_sources, name\n            assert audit['oracle_source_sha256'] in known_sources, name")
(output/'verify.py').write_text(verifier)
rows=[]
for index in [1,2]:
    for record in json.loads((artifacts/f'direct-route-score{index}.json').read_text())['cells']:
        c=record['cell'];s=record['median_seconds']
        rows.append(f"| {c['design']} | {c['weight_kind']} | {c['k']} | {c['threads']} | {c['case']} | {1000*s['sf1']:.0f} | {1000*s['dl1']:.0f} | {record['median_native_ratio']:.4f} |")
(output/'README.md').write_text('''# Direct automatic LSMR cost diagnostic

The captured dl1 transform bypasses the initial Schur/CMG attempt for public
fast two-intercept OLS. It preserves automatic LSMR's stricter recurrence,
memory admission, certified continuation and publication checks. The checkout's
automatic routing rule is unchanged. Both fresh routing seeds remain unused.

Thirty-two training cells complete three sf1/dl1 pairs: 192 successful calls
with no detected competing process. All 64 independent native inference audits,
192 exact within-arm repeat checks and 48 independent candidate saved-output
audits pass. Paired samples match; finite exports and saved vectors can differ
within the existing scientific tolerances because the numerical route differs.
All paired timings and tracked allocation peaks are preserved in the scores.

Cycles favor direct automatic LSMR across unit/AW, K6/K50, T1/T16 and both output
requests. Their paired ratios range from 0.5291 to 0.7673. Ring results are
mixed: direct LSMR helps wide serial and unit threaded fits, but AW threaded
K6 regresses 14.6–16.7% and AW threaded K50 robust regresses 7.4%. A blanket
LSMR switch is rejected. Serial unit narrow ring differences are within 5%.

These screens isolate routing overhead; they do not establish a production
graph guard or cross-platform acceptance. A structural cycle-specific rule is
a possible next experiment. Ordinary explicit LSMR has a different internal
recurrence target and must not be identified with this automatic diagnostic.

| Graph | Weight | K | Threads | Request | sf1 ms | dl1 ms | Paired dl1/sf1 |
|---|---|---:|---:|---|---:|---:|---:|
'''+ '\n'.join(rows)+'''

`verify.py` checks archive integrity, independent-auditor binding and complete
sf1/dl1 source reconstruction. Large output vectors remain local with hashes;
raw licensed logs and compiled plugins are excluded. Final independent blocks,
broader routing validation and Linux confirmation remain open. No release,
installation or push is performed.
''')
print('DIRECT_OLS_LSMR_ARCHIVE_PREPARED')

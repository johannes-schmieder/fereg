import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
root = repo / 'target/g21c5'
root.mkdir(exist_ok=False)
command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/milestone.py'), str(root),
    '--artifacts', str(artifacts), '--label', 'screen', '--phase', 'screen',
    '--baseline', 'm4', '--candidate', 'm5', '--keep-going', '--indices',
    *map(str, range(112, 144))]
receipt = root / 'dispatch.json'
record = dict(scope='Approved ring/cycle graph, weight, width and output three-pair development screen.',
    controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), command=command)
receipt.write_text(json.dumps(record, indent=2) + '\n')
deadline = time.monotonic() + 600
while not (artifacts / 'identity-m5.json').exists():
    assert time.monotonic() < deadline, 'candidate build did not produce an identity'
    time.sleep(2)
assert json.loads((artifacts / 'identity-m5.json').read_text())['abi'] == 'pass'
with (root / 'controller.txt').open('x') as stream:
    result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
record['process_returncode'] = result.returncode
receipt.write_text(json.dumps(record, indent=2) + '\n')
print('CMG_BREADTH_SCREEN_ATTEMPTS_COMPLETE', result.returncode, flush=True)

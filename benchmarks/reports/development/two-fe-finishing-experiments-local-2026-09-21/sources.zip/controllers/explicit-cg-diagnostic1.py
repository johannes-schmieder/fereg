"""Reproduce the recorded weighted-dense CG failure without suppressing errors."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
failed = repo / 'target/g21rd1/runs/route-c001-r1-cg-cluster2_cross_all-n983040-k6-s8675309-shuffle0-t16-r1-m5'
request = json.loads((failed / 'request.json').read_text())
root = artifacts / 'explicit-cg-diagnostic1'
root.mkdir(exist_ok=False)
records = []
for variant in ['baseline', 'm5']:
    source = artifacts / variant
    out = root / variant
    out.mkdir()
    program = f'''version 19.0
clear all
set more off
set varabbrev off
set processors 8
sysdir set PLUS "{out}"
sysdir set PERSONAL "{out}"
capture adopath - SITE
capture adopath - "."
adopath ++ "{source}/stata"
adopath ++ "{source}/dist"
quietly use "{request['data']}", clear
capture noisily fereg y x1 x2 x3 x4 x5 x6 [aw=w], absorb(out_fe1=g1 out_fe2=g2) threads(16) solver(cg) poolsize(10) vce(cluster c1 c2) residuals(out_resid) memory(fast)
local result = _rc
display "CG_DIAGNOSTIC_RC|`result'"
display "CG_DIAGNOSTIC_COMPLETE"
exit, clear
'''
    (out / 'run.do').write_text(program)
    env = dict(os.environ, FEREG_PHASE_TIMING='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
    with (out / 'stdout.txt').open('x') as stream:
        result = subprocess.run(['<stata-installation>/StataMP.app/Contents/MacOS/stata-mp',
                                 '-b', 'do', 'run.do'], cwd=out, env=env,
                                stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    log = (out / 'run.log').read_text(errors='replace')
    codes = re.findall(r'^CG_DIAGNOSTIC_RC\|(\d+)\s*$', log, re.MULTILINE)
    assert len(codes) == 1
    records.append(dict(variant=variant, plugin=json.loads((artifacts / f'identity-{variant}.json').read_text())['plugin'],
                        process_returncode=result.returncode, application_returncode=int(codes[0]),
                        sentinel=any(line.strip() == 'CG_DIAGNOSTIC_COMPLETE' for line in log.splitlines()),
                        program_sha256=hashlib.sha256(program.encode()).hexdigest(),
                        failed_request_sha256=hashlib.sha256((failed / 'request.json').read_bytes()).hexdigest()))
    (root / 'attempts.json').write_text(json.dumps(records, indent=2) + '\n')
    print(variant, records[-1], flush=True)

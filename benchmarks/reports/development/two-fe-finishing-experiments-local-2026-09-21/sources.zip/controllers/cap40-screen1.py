import json
from pathlib import Path
import sys

repo = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route

artifacts = repo / 'target/ols-next-20260921'
root = repo / 'target/g21cap1'
root.mkdir(exist_ok=False)
indices = [0, 1, 2, 3, 24, 27, 56, 57, 58, 59, 64, 65, 66, 67]
cells = [route.cells()[i] for i in indices]
plan = dict(schema='ols-narrow-cap-screen-v1', cells=cells, indices=indices,
    baseline='m5', candidate='cap40',
    variants=['m5', 'cap40', 'fixest'], repeats=3,
    controller_sha256=broad.sha(Path(__file__)),
    isolation_source_sha256=broad.sha(Path(route.__file__)),
    acceptance='Exploratory screen; independent numerical audits precede any acceptance.')
broad.write(root / 'screen-plan.json', plan)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
records = []
for index, cell in enumerate(cells):
    label = f'cap-c{index:03d}'
    command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root),
        '--artifacts', str(artifacts), '--label', label, '--variants', *plan['variants'],
        '--repeats', '3', '--timeout', '60', '--keep-going',
        '--record-reference-science-disagreement', '--record-reference-output-disagreement',
        *broad.arguments(cell)]
    code, isolation = route.invoke(command, root / (label + '.stdout.txt'))
    complete = root / (label + '-complete.json')
    records.append(dict(index=index, original_index=indices[index], cell=cell, label=label,
        command=command, process_returncode=code, timing_isolation=isolation,
        completion=json.loads(complete.read_text()) if complete.exists() else None))
    broad.write(root / 'screen-progress.json', records)
    print(index + 1, '/', len(cells), label, code, isolation['status'], flush=True)
broad.write(root / 'screen-complete.json', dict(status='attempts_complete',
    attempted=len(records), planned=len(cells), plan_sha256=broad.sha(root / 'screen-plan.json'),
    progress_sha256=broad.sha(root / 'screen-progress.json')))

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
commands = []
for label, root, solver, weight in [('l', 'g21rlw', 'lsmr', 'aw'), ('a', 'g21r2', 'auto', 'none')]:
    command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(repo / 'target' / root),
        '--artifacts', str(artifacts), '--label', label, '--variants', 'm2', 'fixest',
        '--design', 'bottleneck_ring', '--n', '245760', '--widths', '6', '50',
        '--cases', 'cluster2_cross_all', '--threads', '16', '--repeats', '3',
        '--solver', solver, '--weight-kind', weight, '--weight-design', 'moderate' if weight == 'aw' else 'none',
        '--timeout', '60', '--keep-going', '--record-reference-science-disagreement',
        '--record-reference-output-disagreement']
    commands.append((root, command))
commands.append(('ss1-screen', [sys.executable, str(repo / 'benchmarks/one_fe_profile/slopes.py'),
    str(artifacts / 'ss1-screen'), '--artifacts', str(artifacts),
    '--fixest-archive', str(repo / 'target/one-fe-profile-20260919/fixest.tar.gz'),
    '--variants', 'm2', 'ss1', 'fixest', '--widths', '10', '50', '--threads', '1', '16', '--repeats', '3']))
receipt = artifacts / 'retention-slope-screen1-dispatch.json'
assert not receipt.exists()
record = dict(scope='Three-pair local development screens; no final milestone claim.',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    prerequisite_pids=[75052, 75580], commands=commands, results=[])
receipt.write_text(json.dumps(record, indent=2) + '\n')
for pid in record['prerequisite_pids']:
    while True:
        try: os.kill(pid, 0)
        except ProcessLookupError: break
        time.sleep(2)
for name in ['schur-retained-correction1.txt', 'slope-indexing-tests1.txt']:
    text = (artifacts / name).read_text()
    assert 'test result: ok.' in text and '0 failed' in text, name
for name in ['m2', 'ss1']:
    identity = json.loads((artifacts / f'identity-{name}.json').read_text())
    assert identity['abi'] == 'pass'
record['prerequisites_passed'] = True
receipt.write_text(json.dumps(record, indent=2) + '\n')
for name, command in commands:
    with (artifacts / f'{name}-controller.txt').open('x') as stream:
        result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    record['results'].append(dict(name=name, returncode=result.returncode))
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(name, result.returncode, flush=True)
print('RETENTION_SLOPE_SCREEN_ATTEMPTS_COMPLETE', flush=True)

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
root = repo / 'target/g21cp4'
root.mkdir(exist_ok=False)
cells = [('bottleneck_ring', 'aw', k) for k in [6, 50]]
cells += [('cycle', w, k) for w in ['none', 'aw'] for k in [6, 50]]
receipt = root / 'dispatch.json'
record = dict(scope='Diagnostic paired profiles, not headline performance evidence.',
    controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    cells=cells, results=[])
receipt.write_text(json.dumps(record, indent=2) + '\n')
deadline = time.monotonic() + 600
for variant in ['m4', 'm4-profile']:
    identity = artifacts / f'identity-{variant}.json'
    while not identity.exists():
        assert time.monotonic() < deadline, 'build did not produce an artifact identity'
        time.sleep(2)
    assert json.loads(identity.read_text())['abi'] == 'pass'
for index, (design, weight, k) in enumerate(cells):
    command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root),
        '--artifacts', str(artifacts), '--label', f'p{index:02}', '--variants', 'm4', 'm4-profile',
        '--design', design, '--n', '245760', '--widths', str(k), '--cases', 'cluster2_cross_all',
        '--threads', '16', '--repeats', '1', '--solver', 'auto', '--weight-kind', weight,
        '--weight-design', 'none' if weight == 'none' else 'moderate', '--trace',
        '--timeout', '60', '--keep-going']
    with (root / f'p{index:02}-controller.txt').open('x') as stream:
        code = subprocess.call(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    record['results'].append(dict(index=index, command=command, returncode=code))
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(index, design, weight, k, code, flush=True)
print('CMG_REUSE_PROFILE_ATTEMPTS_COMPLETE', flush=True)

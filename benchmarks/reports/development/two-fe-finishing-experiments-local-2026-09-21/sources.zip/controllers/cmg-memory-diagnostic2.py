import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
request = json.loads(next((repo / 'target/g21mc3/runs').glob('memory-low-*/request.json')).read_text())
root = artifacts / 'cmg-memory-diagnostic2'
root.mkdir(exist_ok=False)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
records = []
for variant in ['baseline', 'm5']:
    out = root / variant
    out.mkdir()
    source = artifacts / variant
    program = f'''version 19.0
clear all
set more off
set varabbrev off
set processors 8
sysdir set PLUS "{out}"
sysdir set PERSONAL "{out}"
capture adopath - SITE
capture adopath - "."
adopath ++ "{source}/stata"
adopath ++ "{source}/dist"
quietly use "{request['data']}", clear
capture noisily fereg y x1-x50 [aw=w], absorb(out_fe1=g1 out_fe2=g2) threads(16) solver(auto) poolsize(10) vce(cluster c1 c2) residuals(out_resid) memory(low)
local result = _rc
display "MEMORY_DIAGNOSTIC_RC|`result'"
display "MEMORY_DIAGNOSTIC_COMPLETE"
exit, clear
'''
    (out / 'run.do').write_text(program)
    env = dict(os.environ, FEREG_MEMORY_LIMIT_BYTES='936870912', FEREG_PHASE_TIMING='1')
    timed_out = False
    with (out / 'stdout.txt').open('x') as stream:
        try:
            result = subprocess.run(['<stata-installation>/StataMP.app/Contents/MacOS/stata-mp',
                                     '-b', 'do', 'run.do'], cwd=out, env=env,
                                    stdout=stream, stderr=subprocess.STDOUT, timeout=60)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    log = (out / 'run.log').read_text(errors='replace')
    codes = re.findall(r'^MEMORY_DIAGNOSTIC_RC\|(\d+)\s*$', log, re.MULTILINE)
    identity = json.loads((artifacts / f'identity-{variant}.json').read_text())
    records.append(dict(variant=variant, process_returncode=code, timeout_seconds=60,
        timed_out=timed_out, application_returncode=int(codes[0]) if len(codes) == 1 else None,
        sentinel=any(line.strip() == 'MEMORY_DIAGNOSTIC_COMPLETE' for line in log.splitlines()),
        plugin=identity['plugin'], program_sha256=hashlib.sha256(program.encode()).hexdigest(),
        controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        imposed_available_bytes=936870912))
    (root / 'attempts.json').write_text(json.dumps(records, indent=2) + '\n')
    print(records[-1], flush=True)

import csv, hashlib, json, statistics
from pathlib import Path
import numpy as np
art = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
progress = json.loads((art / 'sgn1-screen-progress1.json').read_text())
assert len(progress) == 6
records = []
for attempt in progress:
    root = art / attempt['root']
    plan = json.loads((root / 'plan.json').read_text())
    complete = json.loads((root / 'complete.json').read_text())
    assert complete['status'] == 'pass' and attempt['process_returncode'] == 0
    for index, cell in enumerate(plan['cells']):
        pairs = []
        for rep in range(plan['repeats']):
            paths = {v: root / 'runs' / f'c{index:03d}-r{rep}-{v}' / 'result.json' for v in plan['variants']}
            results = {v: json.loads(p.read_text()) for v, p in paths.items()}
            assert all(r['status'] == 'pass' and r['sentinel'] and r['process_returncode'] == 0 for r in results.values())
            assert len({r['input_sha256'] for r in results.values()}) == 1
            assert len({r['sample_sha256'] for r in results.values()}) == 1
            for variant in ['rrc1', 'sgn1']:
                identity = json.loads((art / f'identity-{variant}.json').read_text())
                assert results[variant]['measurement_fingerprint']['native'] == identity
            exact = {name: sha(paths['rrc1'].parent / name) == sha(paths['sgn1'].parent / name)
                for name in ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv']}
            assert all(exact.values()), (root, index, rep, exact)
            difference = None
            if cell['outputs'] != 'none':
                baseline = np.fromfile(paths['rrc1'].parent / 'outputs.bin', dtype='<f8')
                candidate = np.fromfile(paths['sgn1'].parent / 'outputs.bin', dtype='<f8')
                np.testing.assert_allclose(candidate, baseline, rtol=1e-7, atol=1e-9)
                exact['outputs.bin'] = np.array_equal(candidate, baseline)
                difference = float(np.max(np.abs(candidate - baseline)))
            setup_seconds = {v: float(next(row['value'] for row in csv.DictReader((paths[v].parent / 'fereg_solver.csv').open())
                if row['row'] == '1' and row['column'] == '9')) for v in ['rrc1', 'sgn1']}
            seconds = {v: r['seconds'] for v, r in results.items()}
            pairs.append(dict(rep=rep, seconds=seconds, setup_seconds=setup_seconds, native_ratio=seconds['sgn1'] / seconds['rrc1'],
                reference_ratio=seconds['sgn1'] / seconds['fixest'] if 'fixest' in seconds else None,
                exact_exports=exact, maximum_output_difference=difference,
                result_sha256={v: sha(p) for v, p in paths.items()},
                peaks={v: results[v]['metadata']['fereg_native_allocation_bytes'] for v in ['rrc1', 'sgn1']}))
        record = dict(root=root.name, index=index, cell=cell, isolation=attempt['timing_isolation']['status'], pairs=pairs,
            plan_sha256=sha(root / 'plan.json'), completion_sha256=sha(root / 'complete.json'),
            median_setup_seconds={v: statistics.median(p['setup_seconds'][v] for p in pairs) for v in ['rrc1', 'sgn1']},
            median_seconds={v: statistics.median(p['seconds'][v] for p in pairs) for v in plan['variants']},
            median_native_ratio=statistics.median(p['native_ratio'] for p in pairs),
            median_reference_ratio=statistics.median(p['reference_ratio'] for p in pairs) if 'fixest' in plan['variants'] else None)
        records.append(record)
        print(root.name, cell['case'], record['isolation'], record['median_seconds'], record['median_native_ratio'], record['median_reference_ratio'])
with (art / 'sgn1-screen-audit1.json').open('x') as stream:
    json.dump(dict(schema='slope-geometry-refinement-screen-audit-v1', source_sha256=sha(Path(__file__)),
        progress_sha256=sha(art / 'sgn1-screen-progress1.json'), records=records), stream, indent=2)

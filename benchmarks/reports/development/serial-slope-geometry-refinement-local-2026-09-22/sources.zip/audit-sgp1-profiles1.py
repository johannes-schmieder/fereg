import csv, hashlib, json
from pathlib import Path

art = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
records = []
for label in ['aw-k10', 'pw-k6']:
    root = art / f'sgp1-profile-{label}-1'
    plan = json.loads((root / 'plan.json').read_text())
    assert json.loads((root / 'complete.json').read_text())['status'] == 'pass'
    runs = {v: root / 'runs' / f'c000-r0-{v}' for v in plan['variants']}
    results = {v: json.loads((p / 'result.json').read_text()) for v, p in runs.items()}
    assert all(r['status'] == 'pass' and r['sentinel'] and r['process_returncode'] == 0 for r in results.values())
    assert len({r['sample_sha256'] for r in results.values()}) == 1
    assert len({r['input_sha256'] for r in results.values()}) == 1
    phases = {}
    for v in plan['variants']:
        assert results[v]['measurement_fingerprint']['native'] == json.loads((art / f'identity-{v}.json').read_text())
        phases[v] = {}
        for line in (runs[v] / 'stderr.txt').read_text().splitlines():
            if line.startswith(('FEREG_PHASE|', 'SLOPE_PROFILE|')):
                parts = line.split('|')
                phases[v][parts[0] + '/' + parts[1]] = dict(p.split('=', 1) for p in parts[2:])
    cache_traces = {}
    setup_seconds = {}
    for v, path in runs.items():
        cache_traces[v] = [dict(piece.split('=', 1) for piece in line.split('|')[2:])
            for line in (path / 'stderr.txt').read_text().splitlines()
            if line.startswith('SLOPE_PROFILE|packed_score_cache|')]
        setup_seconds[v] = float(next(row['value'] for row in csv.DictReader((path / 'fereg_solver.csv').open())
            if row['row'] == '1' and row['column'] == '9'))
    measured_cache_traces = {v: [trace for trace in traces if int(trace['n']) == plan['cells'][0]['n']]
        for v, traces in cache_traces.items()}
    exact = {name: len({sha(p / name) for p in runs.values()}) == 1
        for name in ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv', 'outputs.bin']}
    assert all(exact.values()), exact
    assert 'SLOPE_PROFILE/direct_recovery' in phases['sgp1']
    assert 'SLOPE_PROFILE/slope_geometry' in phases['sgp1']
    assert int(phases['sgp1']['SLOPE_PROFILE/slope_geometry']['n']) == plan['cells'][0]['n']
    records.append(dict(root=root.name, exact=exact, phases=phases, cache_traces=cache_traces,
        measured_cache_traces=measured_cache_traces, setup_seconds=setup_seconds,
        result_sha256={v: sha(p / 'result.json') for v, p in runs.items()},
        stderr_sha256={v: sha(p / 'stderr.txt') for v, p in runs.items()}))
out = art / 'sgp1-profile-check1.json'
assert not out.exists()
out.write_text(json.dumps(dict(schema='slope-geometry-profile-check-v1', status='pass',
    source_sha256=sha(Path(__file__)), records=records,
    limitation='Single diagnostic traces; not headline timing evidence. Packed-cache events are separated by observation count: a warm-up event cannot describe a measured strided-cache call.'), indent=2) + '\n')
print('SLOPE_GEOMETRY_PROFILE_CHECK_PASS', len(records))

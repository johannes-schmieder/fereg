import hashlib, json, os, subprocess
from pathlib import Path
art = Path(__file__).resolve().parent
source = art / 'sgn1'
identity_path = art / 'identity-sgn1.json'
identity = json.loads(identity_path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(source / 'dist/fereg_macos.plugin') == identity['plugin']
tests = [
    'single_slope::tests',
    'single_slope_cache_is_ols_only_and_preserves_full_fit',
    'saved_slope_recovery_admits_each_attempt_and_keeps_map_fallback',
]


env = dict(os.environ, DEVELOPER_DIR='/Library/Developer/CommandLineTools',
    CARGO_NET_OFFLINE='true', CARGO_TARGET_DIR=str(art / 'cargo-sgn1'),
    FEREG_GIT_COMMIT=identity['base_commit'][:8], FEREG_BUILD_DATE='2026-09-22')
receipt = art / 'sgn1-tests1.json'
assert not receipt.exists()
records = []
for index, test in enumerate(tests):
    log = art / f'sgn1-test{index + 1}-1.txt'
    command = ['cargo', 'test', '--locked', '--offline', '--release', '-p', 'fereg-core',
        '--target', 'aarch64-apple-darwin', '--lib', test, '--', '--nocapture']
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=source, env=env, stdout=stream, stderr=subprocess.STDOUT)
    passed = result.returncode == 0 and 'test result: ok.' in log.read_text() and '0 passed; 0 failed;' not in log.read_text()
    records.append(dict(test=test, command=command, returncode=result.returncode, passed=passed,
        log=log.name, log_sha256=sha(log)))
    receipt.write_text(json.dumps(dict(schema='slope-geometry-refinement-tests-v1',
        controller_sha256=sha(Path(__file__)), identity_sha256=sha(identity_path), plugin=identity['plugin'],
        status='pass' if len(records) == len(tests) and all(r['passed'] for r in records) else 'incomplete_or_failed',
        tests=records), indent=2) + '\n')
    print(test, result.returncode, passed, flush=True)
    if not passed: raise SystemExit(1)
print('SLOPE_GEOMETRY_REFINEMENT_TESTS_PASS', flush=True)

#![forbid(unsafe_code)]
#![allow(dead_code)]
mod error;
mod psd;
fn main() {
 let args:Vec<String>=std::env::args().collect();
 let n:usize=args[2].parse().unwrap();let clusters:usize=args[3].parse().unwrap();
 let bytes=std::fs::read(&args[1]).unwrap();
 let values:Vec<f64>=bytes.chunks_exact(8).map(|x|f64::from_le_bytes(x.try_into().unwrap())).collect();
 let start=std::time::Instant::now();
 let (_,report)=psd::inspect_published_ppml_covariance(&values,n,clusters,1e-8).unwrap();
 println!("inspection={report:?}");
 eprintln!("INSPECT_SECONDS|{}", start.elapsed().as_secs_f64());
}

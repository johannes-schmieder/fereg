import sys,json,hashlib,zipfile
from pathlib import Path
r=Path('target/ppml-breadth-20260923');out=Path('benchmarks/reports/development/ppml-slope-opportunity-local-2026-09-23/memory-correction.zip')
sys.path.insert(0,'benchmarks/next_subsystem');from archive import archive
extras=['memory-request-audit.json','memory-correction-summary.json','explicit-fast-pilot-audit.json','explicit-fast-pilot-audit.log','explicit-fast-pilot-driver.log','harness-memory-tests.log','ppml_surface-before-memory-fix.py','ppml_surface-final.py','test_ppml_surface-final.py','seal-correction.py']
archive(r,out,['explicit-fast-pilot'],extras)
with zipfile.ZipFile(out) as z:
 m=json.loads(z.read('archive-hashes.json'))
 for p,h in m.items():assert hashlib.sha256(z.read(p)).hexdigest()==h['archived_sha256']
 assert len(z.namelist())==len(m)+1
print('VERIFIED',len(m),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())

import sys,hashlib,json,zipfile
from pathlib import Path
r=Path('target/ppml-breadth-20260923');out=Path('benchmarks/reports/development/ppml-slope-opportunity-local-2026-09-23/receipts.zip')
sys.path.insert(0,'benchmarks/next_subsystem');from archive import archive
for c in json.loads((r/'native-profile-audit.json').read_text())['records']:assert all(x['passed'] for x in c['public_states'].values())
extras=sorted(p.name for p in r.iterdir() if p.is_file() and not p.name.startswith('.'))
archive(r,out,['pilot','screen','native-profile','strict-pilot','strict-pilot-v2','strict-screen'],extras)
with zipfile.ZipFile(out) as z:
 manifest=json.loads(z.read('archive-hashes.json'))
 for p,h in manifest.items():assert hashlib.sha256(z.read(p)).hexdigest()==h['archived_sha256'],p
 assert len(z.namelist())==len(manifest)+1
print('VERIFIED',len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())

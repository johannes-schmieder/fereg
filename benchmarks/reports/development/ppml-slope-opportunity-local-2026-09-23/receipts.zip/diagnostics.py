import subprocess
from pathlib import Path
r=Path('target/ppml-breadth-20260923');py='target/one-fe-profile-20260919/python/bin/python'
for label,cells,seed,variants,trace in [('native-profile','profile',202609291,['ppmlbreadth_profile'],True),('strict-pilot','strict-pilot',202609289,['parproj1','fixest'],False)]:
 args=[py,'benchmarks/next_subsystem/run.py',str(r/label),'--ppml-surface','--artifacts','target/ppml-next-20260922/artifacts','--variants',*variants,'--fixest-archive','target/one-fe-profile-20260919/fixest.tar.gz','--cells',str(r/f'{cells}-cells.json'),'--seed',str(seed),'--repeats','1']
 if trace:args+=['--trace']
 with (r/f'{label}-driver.log').open('x') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)

import json,hashlib,shutil,subprocess
from pathlib import Path
r=Path('target/ppml-breadth-20260923');a=Path('target/ppml-next-20260922/artifacts');blocks=['pilot','screen','native-profile','strict-pilot','strict-pilot-v2','strict-screen'];application=[];means={}
for b in blocks:
 rows=json.loads((r/b/'progress.json').read_text());application.append(dict(block=b,attempts=len(rows),passes=sum(x['status']=='pass' for x in rows),failures=[x for x in rows if x['status']!='pass'],overlaps=sum(len(x['overlaps']) for x in rows),monitor_errors=sum(len(x['monitor_errors']) for x in rows)))
 assert all(not x['overlaps'] and not x['monitor_errors'] for x in rows)
 for p in (r/b/'runs').glob('*/means.bin'):means[str(p.relative_to(r))]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(r/'application-audit.json').write_text(json.dumps(application,indent=2)+'\n');(r/'mean-hashes.json').write_text(json.dumps(means,indent=2)+'\n')
phases=[]
for i in range(3):
 sums={};counts={};last={}
 for line in (r/'native-profile'/f'runs/c{i}-r0-ppmlbreadth_profile/stderr.txt').read_text().splitlines():
  if not line.startswith('FEREG_PHASE|'):continue
  fields=line.split('|');d=dict(p.split('=',1) for p in fields[2:])
  if fields[1]=='ppml_map' or fields[1]=='owned_fe' and d.get('phase')=='projection':
   if d['rows']!='30720':continue
   key=fields[1]+':'+d['phase']+':rhs'+d['rhs'];sums[key]=sums.get(key,0)+float(d['seconds']);counts[key]=counts.get(key,0)+1
  elif fields[1] in ('linear_session','retained_assembly','retained_bread') and d.get('rows')=='30720':
   key=fields[1]+':'+d['name'];sums[key]=sums.get(key,0)+float(d['seconds']);counts[key]=counts.get(key,0)+1
 phases.append(dict(case=i,seconds=sums,counts=counts))
(r/'native-phase-summary.json').write_text(json.dumps(phases,indent=2)+'\n')
for v in ['parproj1','ppmlbreadth_profile']:
 shutil.copy2(a/f'identity-{v}.json',r/f'identity-{v}.json');shutil.copy2(a/f'build-{v}.log',r/f'artifact-build-{v}.log')
 for f in ['map','projection','certificate']:
  shutil.copy2(a/v/f'crates/fereg-core/src/fe/{f}.rs',r/f'{v}-{f}.rs')
 shutil.copy2(a/v/'crates/fereg-core/src/ols/linear_session.rs',r/f'{v}-linear_session.rs')
 shutil.copy2(a/v/'crates/fereg-core/src/ols/prepared_fit.rs',r/f'{v}-prepared_fit.rs')
i=json.loads((a/'identity-parproj1.json').read_text());m=[p for p,h in i['source'].items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h];assert not m
(r/'source-binding.json').write_text(json.dumps(dict(commit='31a7f201',matched=len(i['source']),mismatches=m,plugin=i['plugin']),indent=2)+'\n')
for name in ['run','surface','ppml_surface','ppml_audit','profile','designs','oracles','audit','archive','test_surface','test_ppml_surface']:
 shutil.copy2(Path('benchmarks/next_subsystem')/f'{name}.py',r/f'{name}.py')
shutil.copy2('benchmarks/systematic/oracle.py',r/'systematic-oracle.py');shutil.copy2('benchmarks/systematic/common.py',r/'systematic-common.py');shutil.copy2('benchmarks/one_fe_optimization/build.py',r/'build.py');shutil.copy2('target/parallel-certificate-20260923/stock-reference.json',r/'stock-reference.json')
import numpy,scipy,pandas
(r/'python-dependencies.json').write_text(json.dumps(dict(numpy=numpy.__version__,scipy=scipy.__version__,pandas=pandas.__version__),indent=2)+'\n')
print('APPLICATIONS',application)
print('BINDING',len(i['source']))

import sys,hashlib,json,zipfile
from pathlib import Path
r=Path(__file__).parent;out=Path('benchmarks/reports/development/ppml-slope-extrapolation-local-2026-09-23/receipts.zip')
sys.path.insert(0,'benchmarks/next_subsystem');from archive import archive
extras=sorted(p.name for p in r.iterdir() if p.is_file() and not p.name.startswith('.'))
archive(r,out,['pilot','screen','native-profile'],extras)
with zipfile.ZipFile(out) as z:
 m=json.loads(z.read('archive-hashes.json'))
 assert len(z.namelist())==len(m)+1
 for name,h in m.items():assert hashlib.sha256(z.read(name)).hexdigest()==h['archived_sha256'],name
print('VERIFIED',len(m),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())

import json,sys,statistics,hashlib
from pathlib import Path
r=Path(__file__).parent;sys.path.insert(0,'benchmarks/next_subsystem');from audit import compare,exact_exports
summary=[];repeats=[];means={}
for b in ['pilot','screen']:
 p=json.loads((r/b/'progress.json').read_text());plan=json.loads((r/b/'plan.json').read_text());a=json.loads((r/f'{b}-audit.json').read_text())
 for i,c in enumerate(a['records']):
  assert all(x['passed'] for x in c['public_states'].values()) and all(x['checks']['passed'] for x in c['pairs'])
  assert all(x['passed'] for x in c['oracles'].values())
  times={v:[x['seconds']*1000 for x in p if x['case']==i and x['variant']==v] for v in plan['variants']}
  ratios=[y/x for x,y in zip(times['ppmlproj1'],times['slope_it_probe2'])]
  row=dict(block=b,case=i,milliseconds=times,paired_ratio=dict(minimum=min(ratios),median=statistics.median(ratios),maximum=max(ratios)))
  summary.append(row);print(row,flush=True)
  for v in plan['variants']:
   first=r/b/f'runs/c{i}-r0-{v}'
   for j in range(1,plan['repeats']):
    other=r/b/f'runs/c{i}-r{j}-{v}';checks=compare(first,other,'ppml');exact=exact_exports(first,other);means_equal=(first/'means.bin').read_bytes()==(other/'means.bin').read_bytes()
    assert checks['passed'] and exact['passed'] and means_equal
    repeats.append(dict(block=b,case=i,variant=v,repetition=j,checks=checks,exact=exact,exact_means=means_equal))
 for p in (r/b/'runs').glob('*/means.bin'):means[str(p.relative_to(r))]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for name,obj in [('timing-summary',summary),('repeat-audit',repeats),('mean-hashes',means)]:
 (r/f'{name}.json').write_text(json.dumps(obj,indent=2)+'\n')

import subprocess
from pathlib import Path
r=Path(__file__).parent
for v,experiment in [('slope_cert_profile',False),('slope_it_profile',True)]:
 command=['python3','benchmarks/one_fe_optimization/build.py','target/ppml-next-20260922/artifacts',v,'--revision','1de0b1bb','--profile-ppml-session','--profile-owned-fe']
 if experiment:command+=['--ppml-slope-irons-tuck']
 with (r/f'build-{v}-driver.log').open('x') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('BUILD_DONE',v,flush=True)

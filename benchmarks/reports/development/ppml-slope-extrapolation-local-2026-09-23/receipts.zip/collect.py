import json,hashlib,shutil
from pathlib import Path
r=Path(__file__).parent;a=Path('target/ppml-next-20260922/artifacts');applications=[]
for b in ['pilot','screen','native-profile']:
 rows=json.loads((r/b/'progress.json').read_text());assert all(x['status']=='pass' and not x['overlaps'] and not x['monitor_errors'] for x in rows)
 applications.append(dict(block=b,attempts=len(rows),passes=len(rows),timeouts=0,overlaps=0,monitor_errors=0))
for b in ['pilot','screen','profile']:
 for x in json.loads((r/f'{b}-audit.json').read_text())['records']:
  assert all(c['passed'] for c in x['public_states'].values()) and all(c['checks']['passed'] for c in x['pairs'])
  assert all(c['passed'] for c in x['oracles'].values())
(r/'application-audit.json').write_text(json.dumps(applications,indent=2)+'\n')
for v in ['ppmlproj1','slope_it_probe2','slope_cert_profile2','slope_it_profile']:
 for kind,ext in [('identity','json'),('build','log')]:shutil.copy2(a/f'{kind}-{v}.{ext}',r/f'artifact-{kind}-{v}.{ext}')
 for f in ['fe/map.rs','fe/borrowed_map.rs','fe/projection.rs','ols/linear_session.rs','ols/prepared_fit.rs']:
  shutil.copy2(a/v/'crates/fereg-core/src'/f,r/(v+'-'+f.replace('/','-')))
shutil.copy2(a/'build-slope_it_probe.log',r/'failed-first-compile.log')
for name in ['run','surface','ppml_surface','ppml_audit','profile','designs','oracles','summarize','audit','archive','reusable_slope_experiment']:
 shutil.copy2(Path('benchmarks/next_subsystem')/f'{name}.py',r/f'{name}.py')
shutil.copy2('benchmarks/one_fe_optimization/build.py',r/'experimental-build.py')
for name in ['oracle','common']:shutil.copy2(Path('benchmarks/systematic')/f'{name}.py',r/f'systematic-{name}.py')
for name in ['stock-reference','python-dependencies']:shutil.copy2(Path('target/ppml-breadth-20260923')/f'{name}.json',r/f'{name}.json')
i=json.loads((a/'identity-ppmlproj1.json').read_text());bad=[p for p,h in i['source'].items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h];assert not bad
(r/'source-binding.json').write_text(json.dumps(dict(commit='1de0b1bb',matched=len(i['source']),mismatches=bad,plugin=i['plugin'],production_changed=False),indent=2)+'\n')
ranks=[]
for j,c in enumerate(json.loads((r/'pilot-audit.json').read_text())['records']):
 entry=dict(case=j,oracle=c['oracle_info'],variants={})
 for v in ['ppmlproj1','slope_it_probe2','fixest']:
  m=json.loads((r/'pilot'/f'runs/c{j}-r0-{v}/result.json').read_text())['metadata'];rank=m['df_k'] if v=='fixest' else m['rank']+m['df_a'];assert rank==c['oracle_info']['fe_rank']+4
  if v!='fixest':assert m['df_structural']==c['oracle_info']['df_r']==m['df_resid']
  entry['variants'][v]=dict(total_rank=rank,df_structural=m.get('df_structural'))
 ranks.append(entry)
(r/'independent-rank-audit.json').write_text(json.dumps(ranks,indent=2)+'\n')
print('APPLICATIONS',applications,'PRODUCTION_BINDING',len(i['source']))

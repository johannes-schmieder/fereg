from pathlib import Path
import json
r=Path(__file__).parent;prior=Path('target/ppml-parallel-projection-20260923')
for name in ['pilot','pairs']:(r/(name+'-cells.json')).write_bytes((prior/(name+'-cells.json')).read_bytes())
(r/'predeclared.json').write_text(json.dumps(dict(base='1de0b1bb',baseline='ppmlproj1',experiment='slope_it_probe',seeds=dict(pilot=202609297,screen=202609298),hypothesis='After four ordinary MAP sweeps, propose per-RHS Irons-Tuck extrapolation using the existing categorical helper. Require fresh 2-norm improvement and nonworsening infinity norm. First unhelpful/degenerate step resumes ordinary scheduled MAP for the rest of this call.',limits='Diagnostic transient buffers only; no production admission or allocation-free claim. One bounded experiment, no seed/clamp tuning. Must pass independent means/span/Hessian/score and retained final-Hessian certificates. Do not substitute generic CG.'),indent=2)+'\n')

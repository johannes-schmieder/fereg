import subprocess,sys
from pathlib import Path
r=Path(__file__).parent;py='target/one-fe-profile-20260919/python/bin/python'
for label in sys.argv[1:]:
 seed=202609297 if label=='pilot' else 202609298
 cells='pilot' if label=='pilot' else 'pairs'
 command=[py,'benchmarks/next_subsystem/run.py',str(r/label),'--ppml-surface','--artifacts','target/ppml-next-20260922/artifacts','--variants','ppmlproj1','slope_it_probe2','fixest','--fixest-archive','target/one-fe-profile-20260919/fixest.tar.gz','--cells',str(r/f'{cells}-cells.json'),'--seed',str(seed),'--repeats','1' if label=='pilot' else '3']
 with (r/f'{label}-driver.log').open('x') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)

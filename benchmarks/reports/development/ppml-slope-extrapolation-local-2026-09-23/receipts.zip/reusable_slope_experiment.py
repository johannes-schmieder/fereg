"""Isolated PPML slope Irons-Tuck diagnostic; no production routing/admission claim.

This deliberately allocates temporary matrices per absorption. A successful
experiment still needs fit-lifetime admission and allocation-free ownership
before production use. No certificate, sample, convergence or memory check is
relaxed. CG is excluded because its slope model-space boundary is unresolved.
"""

def instrument(root):
    path = root / 'crates/fereg-core/src/fe/borrowed_map.rs'
    text = path.read_text()
    marker = 'fn borrowed_irons_tuck_candidate_in_place('
    assert text.count(marker) == 1
    path.write_text(text.replace(marker, 'pub(super) ' + marker))
    path = root / 'crates/fereg-core/src/fe/map.rs'
    text = path.read_text()
    start = text.index('impl ReusableMapAbsorber')
    end = text.index('    fn project_structural_constant(', start)
    body = text[start:end]
    marker = '        for iteration in 1..=config.max_iterations {\n'
    assert body.count(marker) == 1
    body = body.replace(marker, '''        // Diagnostic only: fresh storage per call, no state crosses a weight frame.
        let mut experiment_active = self.design.effects().len() >= 2
            && self.design.effects().iter().any(|effect| !effect.slopes().is_empty())
            && values.nrows() >= 128 && rhs <= 64;
        let mut experiment_state = None;
        let mut experiment_accepted = 0_usize;
        for iteration in 1..=config.max_iterations {
            if experiment_active && iteration == 5 {
                experiment_state = Some((DenseMatrix::zeros(values.nrows(), rhs)?,
                    DenseMatrix::zeros(values.nrows(), rhs)?,
                    vec![0.0; rhs], vec![0.0; rhs], vec![0.0; rhs]));
            }
            if let Some((x0, x1, _, _, _)) = experiment_state.as_mut() {
                let destination = if iteration % 2 == 1 { x0 } else { x1 };
                destination.as_mut_slice().copy_from_slice(values.as_slice());
            }
''')
    marker = '            if self.design.effects().len() <= 1\n'
    assert body.count(marker) == 1
    body = body.replace(marker, '''            if experiment_state.is_some() && iteration % 2 == 0 {
                let baseline = self.certify(&values, weights, rhs, config.tolerance)?;
                let mut accepted_certificate = baseline.clone();
                if !baseline.passed {
                    let state = experiment_state.as_mut().unwrap();
                    experiment_active = super::borrowed_map::borrowed_irons_tuck_candidate_in_place(
                        &mut state.0, &state.1, &values, &mut state.2, &mut state.3, &mut state.4,
                    )?;
                    if experiment_active {
                        let state = experiment_state.take().unwrap();
                        let candidate = self.certify(&state.0, weights, rhs, config.tolerance)?;
                        experiment_active = candidate.relative_two_norm < baseline.relative_two_norm
                            && candidate.relative_infinity_norm <= baseline.relative_infinity_norm;
                        if experiment_active {
                            values.as_mut_slice().copy_from_slice(state.0.as_slice());
                            accepted_certificate = candidate;
                            experiment_accepted += 1;
                        }
                        // Reuse this call's buffers only while candidates improve.
                        if experiment_active { experiment_state = Some(state); }
                    }
                    if !experiment_active { experiment_state = None; }
                }
                if std::env::var_os("FEREG_PHASE_TIMING").is_some() {
                    eprintln!("FEREG_PHASE|ppml_slope_it|rows={}|rhs={}|iteration={}|accepted={}|active={}",
                        values.nrows(), rhs, iteration, experiment_accepted, experiment_active);
                }
                if accepted_certificate.passed {
                    return CertifiedBorrowedMap::from_certified_parts(values,
                        reusable_map_report(SolveStopReason::Certified, iteration,
                            accepted_certificate, setup_seconds, solve_started.elapsed().as_secs_f64()));
                }
                continue;
            }
''' + marker)
    path.write_text(text[:start] + body + text[end:])

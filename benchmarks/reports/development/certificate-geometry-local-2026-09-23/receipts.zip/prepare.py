import json
from pathlib import Path
root=Path('target/certificate-cache-20260923');old=Path('target/owned-certificate-20260922')
for group in ['pair','fresh','weak-native','control','pilot']:
 data=json.loads((old/f'{group}-cells.json').read_text())
 if group=='fresh':
  for c in data:
   if c.get('n')==76800:c['n']=92160
 if group=='pilot':
  for c in data:c['n']=2400
 (root/f'{group}-cells.json').write_text(json.dumps(data,indent=2)+'\n')
p={'baseline':'mapinit1','base_source':'51ae723d','candidate':'certcache1','overlays':[f'crates/fereg-core/src/fe/{s}.rs' for s in ['certificate','map','auto','accelerated_map']], 'hypothesis':'Retain identical normalized QR geometry only within generic auto MAP/CG current design and weight scope. Fresh residual span and raw moments unchanged. Optional budget refusal and cache release preserve routes.', 'repeats':3,'seeds':dict(zip(['pairs','fresh','weak','controls','pilots','profiles'],range(202609271,202609277))), 'stop':'One bounded candidate; retain only reliable practical gain with exact science and admitted memory. Do not tune case-specific guards, tile widths or stock stopping accuracy. Weak native only; no disconnected campaign restart.'}
(root/'predeclared.json').write_text(json.dumps(p,indent=2)+'\n')

from pathlib import Path
p=Path('crates/fereg-core/src/fe/certificate.rs');s=p.read_text()
a=s.index('            let mut normalized_columns = fallible_empty(');b=s.index('            for rhs in 0..residuals.ncols()',a)
old=s[a:b]
helper=old[:old.index('            let orthonormal_basis')]
helper='\n'.join(line[12:] if line.startswith('            ') else line for line in helper.splitlines())
helper='''fn level_basis(effect: &crate::fe::EffectTerm, weights: &[f64], level: usize) -> Result<Vec<Vec<f64>>> {
    let channels = effect.channels();
    let observations = effect.level_index().members(level);
'''+''.join('    '+line+'\n' for line in helper.splitlines())+'''    pivoted_reorthogonalized_qr(normalized_columns)
}

'''
s=s[:a]+'''            let fresh_basis;
            let orthonormal_basis = if let Some(bases) = cached_bases {
                &bases[group]
            } else {
                fresh_basis = level_basis(effect, weights, level)?;
                &fresh_basis
            };
            group += 1;
'''+s[b:]
s=s.replace('for basis in &orthonormal_basis {','for basis in orthonormal_basis {',1)
s=s.replace('    let mut relative_count = 0_usize;\n', '    let mut relative_count = 0_usize;\n    let mut group = 0;\n',1)
s=s.replace('        let channels = effect.channels();\n        for level', '        for level',1)
needle=') -> Result<FeCertificate> {\n    if residuals.nrows()'
s=s.replace(needle,''') -> Result<FeCertificate> {
    certify_with_bases(design, weights, residuals, reference_norms, tolerance, None)
}

fn certify_with_bases(
    design: &FeDesign,
    weights: &[f64],
    residuals: &DenseMatrix,
    reference_norms: &[f64],
    tolerance: f64,
    cached_bases: Option<&[Vec<Vec<f64>>]>,
) -> Result<FeCertificate> {
    if residuals.nrows()''',1)
insert='''/// One absorption call's immutable design and weight frame. Only geometry is
/// retained; every check still reads the current residuals and reference norms.
/// A new context is required after changing weights, sample or generation.
pub(super) struct CertificateContext<'a> {
    pub(super) design: &'a FeDesign,
    pub(super) weights: &'a [f64],
    bases: Option<Vec<Vec<Vec<f64>>>>,
}

impl<'a> CertificateContext<'a> {
    pub(super) fn new(design: &'a FeDesign, weights: &'a [f64]) -> Self {
        Self { design, weights, bases: None }
    }

    /// Upper bound for retained numeric banks and both levels of descriptors.
    /// Construction scratch is already in the generic certificate workspace;
    /// numeric columns move from QR into this bank without a second copy.
    pub(super) fn cache_bytes(&self) -> Result<u128> {
        let mut bytes = 0_u128;
        for effect in self.design.effects() {
            let cells = (self.design.nobs() as u128).checked_mul(effect.channels() as u128);
            let descriptors = (effect.n_levels() as u128).checked_mul(
                (std::mem::size_of::<Vec<Vec<f64>>>() as u128)
                    + (effect.channels() as u128) * std::mem::size_of::<Vec<f64>>() as u128);
            bytes = cells.and_then(|n| n.checked_mul(8))
                .and_then(|n| n.checked_add(descriptors?))
                .and_then(|n| n.checked_add(bytes))
                .ok_or_else(|| FeregError::new(ErrorCode::Allocation, "certificate cache size overflows"))?;
        }
        Ok(bytes)
    }

    /// Caller must admit cache_bytes plus the existing certificate workspace.
    /// Allocation failure leaves this context uncached and its input untouched.
    pub(super) fn cache(&mut self) -> Result<()> {
        let groups = self.design.effects().iter().try_fold(0_usize, |n, effect| {
            n.checked_add(effect.n_levels()).ok_or_else(||
                FeregError::new(ErrorCode::Allocation, "certificate cache group count overflows"))
        })?;
        let mut bases = fallible_empty(groups, "unable to reserve certificate cache groups")?;
        for effect in self.design.effects() {
            for level in 0..effect.n_levels() {
                bases.push(level_basis(effect, self.weights, level)?);
            }
        }
        self.bases = Some(bases);
        Ok(())
    }

    pub(super) fn clear(&mut self) { self.bases = None; }

    pub(super) fn certify(&self, residuals: &DenseMatrix, reference_norms: &[f64], tolerance: f64) -> Result<FeCertificate> {
        certify_with_bases(self.design, self.weights, residuals, reference_norms, tolerance, self.bases.as_deref())
    }
}

'''
pos=s.index('/// Column-pivoted, twice-reorthogonalized');s=s[:pos]+insert+helper+s[pos:];p.write_text(s)
# Public wrappers keep old entry points; internals bind inputs to the context.
for name,fn,extra in [('map','absorb_map',''),('accelerated_map','absorb_accelerated_map',', solver')]:
 p=Path(f'crates/fereg-core/src/fe/{name}.rs');s=p.read_text();s='use super::certificate::CertificateContext;\n'+s
 start=s.index('pub fn '+fn+'(');end=s.index(') -> Result<SolveReport> {',start)+len(') -> Result<SolveReport> {')
 signature=s[start:end]
 internal=signature.replace('pub fn '+fn,'pub(super) fn '+fn+'_with_context').replace('    design: &FeDesign,\n    weights: &[f64],','    context: &CertificateContext<\'_>,')
 wrapper=signature+f'\n    {fn}_with_context(&CertificateContext::new(design, weights), values, config{extra})\n}}\n\n'+internal+'\n    let (design, weights) = (context.design, context.weights);'
 s=s[:start]+wrapper+s[end:]
 # limit replacement to production solver body (not separate reusable MAP / tests)
 bound=s.index('/// Reusable') if name=='map' else s.index('fn apply_symmetric_projection(')
 body=s[:bound];tail=s[bound:]
 import re
 body=re.sub(r'certify_residuals_with_reference_norms\(\n\s*design,\n\s*weights,', 'context.certify(',body)
 if name=='accelerated_map':
  body=body.replace('absorb_conjugate_gradient(design, weights, values, config)', 'absorb_conjugate_gradient(context, values, config)')
  body=body.replace('fn absorb_conjugate_gradient(\n    design: &FeDesign,\n    weights: &[f64],','fn absorb_conjugate_gradient(\n    context: &CertificateContext<\'_>,')
  body=body.replace(') -> Result<SolveReport> {\n    let started = Instant::now();',') -> Result<SolveReport> {\n    let (design, weights) = (context.design, context.weights);\n    let started = Instant::now();')
  body=body.replace('    certify_residuals_with_reference_norms, project_effect_in_place, weighted_column_norms,','    project_effect_in_place, weighted_column_norms,')
 s=body+tail;p.write_text(s)
p=Path('crates/fereg-core/src/fe/auto.rs');s=p.read_text();s='''use super::certificate::CertificateContext;
use super::map::absorb_map_with_context;
use super::accelerated_map::absorb_accelerated_map_with_context;
'''+s
start=s.index('fn absorb_auto(');end=s.index('\nfn admit_generic_solver(',start);body=s[start:end]
needle='    let initial = certify_residuals_with_reference_norms(\n        design,\n        weights,'
body=body.replace(needle,'''    let cache_started = std::time::Instant::now();
    let mut context = CertificateContext::new(design, weights);
    let mut retained = 0;
    // Repeated auto checks can amortize QR geometry. Categorical-only paths,
    // empty RHSs and invalid configurations keep their original behavior.
    if values.ncols() > 0 && values.nrows() == design.nobs()
        && design.effects().iter().any(|effect| !effect.slopes().is_empty())
        && config.map.tolerance.is_finite() && config.map.tolerance > 0.0
        && config.map.max_iterations > 1 && config.map.check_every > 0
    {
        if let Ok(bytes) = context.cache_bytes() {
            let peak = attempted_peak.with_retained(bytes)?;
            if config.solver_memory_budget.map_or(true, |budget| budget.fits(peak.bytes().unwrap() as u128)) {
                attempted_peak = peak;
                match context.cache() {
                    Ok(()) => retained = bytes,
                    Err(error) if error.code == ErrorCode::Allocation => {},
                    Err(error) => return Err(error),
                }
            }
        }
    }
    let cache_seconds = cache_started.elapsed().as_secs_f64();
    let initial = context.certify(''')
body=body.replace('let mut pilot = absorb_map(\n        design,\n        weights,','let mut pilot = absorb_map_with_context(\n        &context,')
body=body.replace('    pilot.solver_workspace_peak = attempted_peak;','    pilot.setup_seconds += cache_seconds;\n    pilot.solver_workspace_peak = attempted_peak;')
body=body.replace('    if auto_selects_lsmr(contraction, design.total_coefficients()) {','''    if auto_selects_lsmr(contraction, design.total_coefficients()) {
        // LSMR owns different geometry. Release this optional cache before its
        // admission so previously affordable routes and fallbacks stay valid.
        context.clear();
        retained = 0;''')
body=body.replace('    attempted_peak = attempted_peak.max(continuation_peak);\n    let mut cg = absorb_accelerated_map(\n        design,\n        weights,','''    let cached_peak = continuation_peak.with_retained(retained)?;
    if config.solver_memory_budget.map_or(true, |budget| budget.fits(cached_peak.bytes().unwrap() as u128)) {
        attempted_peak = attempted_peak.max(cached_peak);
    } else {
        context.clear();
        attempted_peak = attempted_peak.max(continuation_peak);
    }
    let mut cg = absorb_accelerated_map_with_context(
        &context,''')
s=s[:start]+body+s[end:];p.write_text(s)

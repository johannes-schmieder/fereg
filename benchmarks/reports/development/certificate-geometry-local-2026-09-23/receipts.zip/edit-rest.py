from pathlib import Path
# Public wrappers keep old entry points; internals bind inputs to the context.
for name,fn,extra in [('map','absorb_map',''),('accelerated_map','absorb_accelerated_map',', solver')]:
 p=Path(f'crates/fereg-core/src/fe/{name}.rs');s=p.read_text();s='use super::certificate::CertificateContext;\n'+s
 start=s.index('pub fn '+fn+'(');end=s.index(') -> Result<SolveReport> {',start)+len(') -> Result<SolveReport> {')
 signature=s[start:end]
 internal=signature.replace('pub fn '+fn,'pub(super) fn '+fn+'_with_context').replace('    design: &FeDesign,\n    weights: &[f64],','    context: &CertificateContext<\'_>,')
 wrapper=signature+f'\n    {fn}_with_context(&CertificateContext::new(design, weights), values, config{extra})\n}}\n\n'+internal+'\n    let (design, weights) = (context.design, context.weights);'
 s=s[:start]+wrapper+s[end:]
 # limit replacement to production solver body (not separate reusable MAP / tests)
 bound=s.index('/// Session-owned') if name=='map' else s.index('fn apply_symmetric_projection(')
 body=s[:bound];tail=s[bound:]
 import re
 body=re.sub(r'certify_residuals_with_reference_norms\(\n\s*design,\n\s*weights,', 'context.certify(',body)
 if name=='accelerated_map':
  body=body.replace('absorb_conjugate_gradient(design, weights, values, config)', 'absorb_conjugate_gradient(context, values, config)')
  body=body.replace('fn absorb_conjugate_gradient(\n    design: &FeDesign,\n    weights: &[f64],','fn absorb_conjugate_gradient(\n    context: &CertificateContext<\'_>,')
  body=body.replace(') -> Result<SolveReport> {\n    let started = Instant::now();',') -> Result<SolveReport> {\n    let (design, weights) = (context.design, context.weights);\n    let started = Instant::now();')
  body=body.replace('    certify_residuals_with_reference_norms, project_effect_in_place, weighted_column_norms,','    project_effect_in_place, weighted_column_norms,')
 s=body+tail;p.write_text(s)
p=Path('crates/fereg-core/src/fe/auto.rs');s=p.read_text();s='''use super::certificate::CertificateContext;
use super::map::absorb_map_with_context;
use super::accelerated_map::absorb_accelerated_map_with_context;
'''+s
start=s.index('fn absorb_auto(');end=s.index('\nfn admit_generic_solver(',start);body=s[start:end]
needle='    let initial = certify_residuals_with_reference_norms(\n        design,\n        weights,'
body=body.replace(needle,'''    let cache_started = std::time::Instant::now();
    let mut context = CertificateContext::new(design, weights);
    let mut retained = 0;
    // Repeated auto checks can amortize QR geometry. Categorical-only paths,
    // empty RHSs and invalid configurations keep their original behavior.
    if values.ncols() > 0 && values.nrows() == design.nobs()
        && design.effects().iter().any(|effect| !effect.slopes().is_empty())
        && config.map.tolerance.is_finite() && config.map.tolerance > 0.0
        && config.map.max_iterations > 1 && config.map.check_every > 0
    {
        if let Ok(bytes) = context.cache_bytes() {
            let peak = attempted_peak.with_retained(bytes)?;
            if config.solver_memory_budget.map_or(true, |budget| budget.fits(peak.bytes().unwrap() as u128)) {
                attempted_peak = peak;
                match context.cache() {
                    Ok(()) => retained = bytes,
                    Err(error) if error.code == ErrorCode::Allocation => {},
                    Err(error) => return Err(error),
                }
            }
        }
    }
    let cache_seconds = cache_started.elapsed().as_secs_f64();
    let initial = context.certify(''')
body=body.replace('let mut pilot = absorb_map(\n        design,\n        weights,','let mut pilot = absorb_map_with_context(\n        &context,')
body=body.replace('    pilot.solver_workspace_peak = attempted_peak;','    pilot.setup_seconds += cache_seconds;\n    pilot.solver_workspace_peak = attempted_peak;')
body=body.replace('    if auto_selects_lsmr(contraction, design.total_coefficients()) {','''    if auto_selects_lsmr(contraction, design.total_coefficients()) {
        // LSMR owns different geometry. Release this optional cache before its
        // admission so previously affordable routes and fallbacks stay valid.
        context.clear();
        retained = 0;''')
body=body.replace('    attempted_peak = attempted_peak.max(continuation_peak);\n    let mut cg = absorb_accelerated_map(\n        design,\n        weights,','''    let cached_peak = continuation_peak.with_retained(retained)?;
    if config.solver_memory_budget.map_or(true, |budget| budget.fits(cached_peak.bytes().unwrap() as u128)) {
        attempted_peak = attempted_peak.max(cached_peak);
    } else {
        context.clear();
        attempted_peak = attempted_peak.max(continuation_peak);
    }
    let mut cg = absorb_accelerated_map_with_context(
        &context,''')
s=s[:start]+body+s[end:];p.write_text(s)

import json,os,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad
import route_development as route
root=repo/'target/g21phi1';artifacts=repo/'target/ols-next-20260921'
original=json.loads((repo/'target/g21protect/protect1-plan.json').read_text())
cell=original['cells'][59]
assert (cell['n'],cell['k'],cell['weight_kind'])==(16384,6,'none')
plan=dict(schema='native-protection-single-command-clock-v1',phase='confirmation',inventory_kind='controls',
    cells=[cell],repetitions=5,variants=['baseline','sf1'],manifest=original['manifest'],
    original_plan_sha256=broad.sha(repo/'target/g21protect/protect1-plan.json'),original_index=59,
    controller_sha256=broad.sha(Path(__file__)),isolation_source_sha256=broad.sha(Path(route.__file__)),
    clock_identity_sha256=broad.sha(root/'controller/clock-identity.json'),
    purpose='Repeat the failed rounded timing cell using both unchanged ordinary timing and a calibrated monotonic bracket around the same single command. No overhead subtraction.')
assert not (root/'fine-plan.json').exists()
broad.write(root/'fine-plan.json',plan)
(root/'execution-source.py').write_bytes(Path(__file__).read_bytes())
os.environ['TWO_FE_HIGHRES_CLOCK']=str(root/'clock/clock.plugin')
label='fine-c000'
command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),'--artifacts',str(artifacts),
    '--label',label,'--variants',*plan['variants'],'--repeats','5',*broad.arguments(cell)]
code,isolation=route.invoke(command,root/(label+'.stdout.txt'))
complete=root/(label+'-complete.json')
broad.write(root/'fine-progress.json',[dict(index=0,cell=cell,label=label,process_returncode=code,
    comparison_status=json.loads(complete.read_text())['status'] if complete.exists() else 'incomplete',
    timing_isolation=isolation)])
broad.write(root/'fine-complete.json',dict(status='attempts_complete',planned=1,attempted=1,
    process_returncode=code,plan_sha256=broad.sha(root/'fine-plan.json')))
print('PROTECTION_FINE_CLOCK_COMPLETE',code,isolation['status'],flush=True)

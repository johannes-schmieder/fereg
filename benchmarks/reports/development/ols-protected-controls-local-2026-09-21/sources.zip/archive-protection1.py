import hashlib,io,json,math,statistics,subprocess,sys,tarfile,zipfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2];artifacts=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import archive_science
output=repo/'benchmarks/reports/development/ols-protected-controls-local-2026-09-21'
roots=[repo/'target/g21protect',repo/'target/g21phi1']
assert json.loads((roots[0]/'protect1-complete.json').read_text())['attempted']==111
archive_science.archive(roots,output,compact=True,omit_output_arrays=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def portable(raw):return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={kind:{} for kind in ['sources','checks']}
with zipfile.ZipFile(output/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 def add(name,raw):
  clean=portable(raw);bundle.writestr(name,clean);tables['sources'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
 for variant in ['baseline','sf1']:
  p=artifacts/f'identity-{variant}.json';identity=json.loads(p.read_text());add(p.name,p.read_bytes())
  raw=subprocess.check_output(['/opt/homebrew/bin/git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'],cwd=repo)
  with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
   base={entry.name:sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
  for relative,digest in identity['source'].items():
   data=(artifacts/variant/relative).read_bytes();assert sha(data)==digest
   if base.get(relative)!=digest:add(variant+'/'+relative,data)
 for name in ['broad.py','score.py','audit_protection.py','audit_outputs.py','run.py','route_development.py','highres.py','highres_clock.c','archive_science.py']:
  add(name,(repo/'benchmarks/two_fe_dense'/name).read_bytes())
 for relative in ['benchmarks/one_fe_profile/run.py','plugin/stplugin.c','plugin/stplugin.h','plugin/exports_macos.txt','tests/python/test_native_protection_audit.py']:
  add(relative,(repo/relative).read_bytes())
 for name in ['protection-fine-clock1.py','score-protection-fine1.py','archive-protection1.py']:
  add(name,(artifacts/name).read_bytes())
 for path in (roots[1]/'clock').iterdir():
  if path.suffix in ['.txt','.json','.do','.patch']:add('clock/'+path.name,path.read_bytes())
with zipfile.ZipFile(output/'checks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 for name in ['protection-manifest1.json','protection-controls1.txt','protection-auditor-tests1.txt','protection-score1.json','protection-score1.txt','protection-science1.json','protection-science1.txt','protection-outputs1.txt','protection-clock-prepare1.txt','protection-fine-clock1.txt','protection-fine-science1.json','protection-fine-science1.txt','protection-fine-score1.json','protection-fine-score1.txt']:
  raw=(artifacts/name).read_bytes();clean=portable(raw);bundle.writestr(name,clean);tables['checks'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
for kind,table in tables.items():(output/(kind+'-hashes.json')).write_text(json.dumps(table,indent=2)+'\n')
verifier=(repo/'benchmarks/reports/development/two-fe-coverage-tail-local-2026-09-21/verify.py').read_text()
start=verifier.index('with zipfile.ZipFile(folder / \'checks.zip\') as bundle:',verifier.index('known_sources ='))
end=verifier.index('\nreceipt =',start)
verifier=verifier[:start]+'''with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    for name in ['protection-science1.json', 'protection-fine-science1.json']:
        audit = json.loads(bundle.read(name))
        assert audit['passing'] == audit['planned']
        assert audit['controller_sha256'] in known_sources
        assert audit['numerical_comparator_sha256'] in known_sources
    confirmation = json.loads(bundle.read('protection-fine-score1.json'))
    assert confirmation['controller_sha256'] in known_sources
    assert confirmation['all_control_limits_with_confirmation_met']
''' + verifier[end:]
verifier=verifier.replace('coverage-tail-archive-integrity-v1','native-protection-archive-integrity-v1').replace('COVERAGE_TAIL_ARCHIVE_INTEGRITY_PASS','NATIVE_PROTECTION_ARCHIVE_INTEGRITY_PASS')
(output/'verify.py').write_text(verifier)
score=json.loads((artifacts/'protection-score1.json').read_text());groups={}
for c in score['cells']:groups.setdefault(c['cell']['group'],[]).append(c)
rows=[]
for name,cells in groups.items():
 ratios=[c['median_paired_ratio'] for c in cells];gm=math.exp(statistics.mean(math.log(v) for v in ratios))
 rows.append(f'| {name} | {len(cells)} | {gm:.4f} | {max(ratios):.4f} |')
(output/'README.md').write_text('''# Protected native controls: local development checkpoint

All 111 predeclared controls complete three native pairs on the Mac, using
baseline `0efa78bd` and captured candidate sf1. All 666 application calls pass,
with no detected competing process in any cell. The unchanged inventory covers
frequency weights, difficult weight distributions, tiny weighted bridges,
thread/width/sample boundaries, low memory, one-FE fits and dense inference.
The manifest's baseline identity is updated explicitly; every expanded cell
matches the protected inventory.

All 333 native scientific comparisons pass the registered numerical and exact
sample/status/DoF rules. There are 252 bit-identical six-bundle pairs. All 129
candidate saved-output audits pass independent weighted normal equations,
normalization, RSS and reconstruction checks; 78 paired output vectors are
bit-identical. These baseline comparisons complement the earlier independent
inference oracles; they are not a new full explicit-dummy qualification matrix.
The protection-auditor fixtures pass an identical pair and reject missing or
failed calls, changed samples/RSS/coefficients/covariance/DoF/status/outputs.

| Family | Cells | Geometric mean paired ratio | Original worst ratio |
|---|---:|---:|---:|
'''+ '\n'.join(rows)+'''

One original rounded timing fails the 1.05 limit: unit IID at N=16,384 and K=6
has median paired ratio 1.06897, with 31/30 ms marginal medians. That failed
receipt remains unchanged. A fresh five-pair confirmation brackets the same
single public command with the existing monotonic clock. Its median paired
ratio is 1.04412, and its unchanged ordinary timer gives 1.03571. All ten calls
and five scientific comparisons pass with clean isolation. Empty-bracket means
are below one microsecond and no overhead is subtracted. Individual ratios
vary from 0.895 to 1.189, so this is confirmation against the declared median
limit, not evidence of a precise speed gain. All 111 control limits are met
using that confirmation for the one failed cell; no kernel change is made.

Tracked allocation peaks increase in eighteen cells, by at most 25,772,088
bytes, chiefly in difficult-weight saved-output fits. All original paired
peaks remain in the score. This is not a memory-neutral or complete allocation-
proof claim; constrained-memory and inventory gaps remain separately recorded.

The archive preserves all 676 calls, the failed original timing, its separate
confirmation, exact source identities, test/auditor sources and both clock
provenances. `verify.py` reconstructs baseline/sf1 and verifies archive hashes
and auditor bindings. Large output vectors remain local with explicit hashes;
raw licensed logs and compiled plugins are excluded. Broader primary/holdout
final blocks, routing work and Linux confirmation remain open. No release,
installation or push is performed.
''')
print('PROTECTION_ARCHIVE_PREPARED')

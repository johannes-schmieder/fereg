import hashlib,json,math,statistics
from pathlib import Path
repo=Path(__file__).resolve().parents[2]; artifacts=repo/'target/ols-next-20260921'; root=repo/'target/g21phi1'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
plan=json.loads((root/'fine-plan.json').read_text());progress=json.loads((root/'fine-progress.json').read_text())
science=json.loads((artifacts/'protection-fine-science1.json').read_text());assert science['passing']==1
assert progress[0]['process_returncode']==0 and progress[0]['timing_isolation']['status']=='no_detected_overlap'
pairs=[]
for rep in range(1,6):
 paths={variant:next((root/'runs').glob(f'*-r{rep}-{variant}/result.json')) for variant in plan['variants']}
 results={variant:json.loads(path.read_text()) for variant,path in paths.items()}
 for r in results.values():
  assert r['status']=='pass' and r['sentinel'] and r['process_returncode']==0
  m=r['metadata'];assert m['highres_seconds']>0 and math.isfinite(m['highres_seconds'])
  assert 0<=m['clock_empty_min']<=m['clock_empty_mean']<=m['clock_empty_max']<.01
 seconds={v:r['metadata']['highres_seconds'] for v,r in results.items()}
 pairs.append(dict(rep=rep,seconds=seconds,ratio=seconds['sf1']/seconds['baseline'],
  ordinary_seconds={v:r['seconds'] for v,r in results.items()},
  clocks={v:{k:r['metadata'][k] for k in ['clock_empty_min','clock_empty_mean','clock_empty_max']} for v,r in results.items()},
  result_sha256={v:sha(path) for v,path in paths.items()}))
original=json.loads((artifacts/'protection-score1.json').read_text())
ratio=statistics.median(p['ratio'] for p in pairs)
assert original['completely_measured']==original['timing_eligible']==111
assert [c['index'] for c in original['cells'] if c['median_paired_ratio']>1.05]==[59]
receipt=dict(schema='native-protection-fine-clock-confirmation-v1',controller_sha256=sha(Path(__file__)),
 plan_sha256=sha(root/'fine-plan.json'),progress_sha256=sha(root/'fine-progress.json'),
 original_score_sha256=sha(artifacts/'protection-score1.json'),science_sha256=sha(artifacts/'protection-fine-science1.json'),
 original_index=59,original_median_paired_ratio=original['cells'][59]['median_paired_ratio'],
 pairs=pairs,median_paired_ratio=ratio,threshold=1.05,threshold_met=ratio<=1.05,
 unchanged_ordinary_median_ratio=statistics.median(p['ordinary_seconds']['sf1']/p['ordinary_seconds']['baseline'] for p in pairs),
 median_seconds={v:statistics.median(p['seconds'][v] for p in pairs) for v in plan['variants']},
 all_control_limits_with_confirmation_met=ratio<=1.05 and all(c['median_paired_ratio']<=1.05 for c in original['cells'] if c['index']!=59),
 scope='Development native-control screen plus one fresh five-pair single-command confirmation. Original failed timing remains unchanged; no final-block or milestone acceptance.')
out=artifacts/'protection-fine-score1.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2)+'\n')
print('PROTECTION_FINE_SCORE',ratio,receipt['all_control_limits_with_confirmation_met'])

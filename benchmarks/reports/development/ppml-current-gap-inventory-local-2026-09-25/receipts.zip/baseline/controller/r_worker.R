args <- commandArgs(trailingOnly = TRUE)
suppressPackageStartupMessages(library(fixest))

suppressPackageStartupMessages(library(jsonlite))
suppressPackageStartupMessages(library(digest))
c <- fromJSON(args[[1]], simplifyVector = TRUE)
cell <- c$cell
output <- c$output
setFixest_nthreads(cell$threads)
read_input <- function(path) {
    meta <- fromJSON(sub("\\.dta$", ".json", path))
    con <- file(sub("\\.dta$", ".bin", path), "rb")
    on.exit(close(con))
    cols <- lapply(meta$columns, function(name) readBin(con, "double", n=meta$n, size=8, endian="little"))
    names(cols) <- meta$columns
    as.data.frame(cols)
}
formula <- as.formula(paste("y ~", cell$rhs_r,
                            "|", cell$effects_r))
vce <- if (length(cell$clusters)) as.formula(paste("~", paste(cell$clusters, collapse=" + "))) else "hetero"
correction_spec <- ssc(K.adj=FALSE, G.adj=TRUE, G.df="min")
fit_model <- function(data) {
    if (isTRUE(cell$fixest_strict)) {
        return(fepois(formula, data=data, nthreads=cell$threads, vcov=vce,
                      ssc=correction_spec, notes=FALSE,
                      glm.tol=if (is.null(cell$fixest_glm_tol)) 1e-10 else cell$fixest_glm_tol,
                      fixef.tol=1e-11))
    }
    if (cell$model == "ols") {
        feols(formula, data=data, nthreads=cell$threads, vcov="iid", notes=FALSE)
    } else {
        fepois(formula, data=data, nthreads=cell$threads, vcov=vce, ssc=correction_spec, notes=FALSE)
    }
}
recover_outputs <- function(fit, data) {
    mu <- predict(fit, type="response")
    if (cell$outputs != "all") return(list(mu=mu, channels=NULL))
    eta <- predict(fit, type="link")
    X <- model.matrix(fit, type="rhs")[,cell$r_coefficient_names,drop=FALSE]
    xb <- as.vector(X %*% coef(fit)[cell$r_coefficient_names])
    effects <- fixef(fit, sorted=FALSE, notes=FALSE, nthreads=cell$threads, fixef.tol=1e-11)
    contributions <- lapply(cell$effects, function(name) unname(effects[[name]][fit$fixef_id[[name]]]))
    channels <- c(list(xb, eta-xb, eta, data$y[obs(fit)]-mu), contributions)
    list(mu=mu, channels=channels)
}
if (c$phase == "warm") {
    warm <- read_input(c$warm)
    invisible(recover_outputs(fit_model(warm), warm))
    rm(warm)
    invisible(gc())
}
data <- read_input(c$data)
info <- fromJSON(sub("\\.dta$", ".json", c$data))
for (name in names(info$column_sha256)) {
    bytes <- writeBin(as.double(data[[name]]), raw(), size=8, endian="little")
    stopifnot(digest(bytes, algo="sha256", serialize=FALSE) == info$column_sha256[[name]])
}
rm(bytes)
invisible(gc())
writeLines("READY", file.path(output, "READY"))
Sys.sleep(.1)
writeLines("START", file.path(output, "START"))
while (!file.exists(file.path(output, "START.CHECKED"))) Sys.sleep(.001)
if (isTRUE(c$trace)) Rprof(file.path(output,"Rprof.out"), interval=.001)
start <- proc.time()[["elapsed"]]
error <- NULL
fit <- tryCatch(fit_model(data), error=function(e) { error <<- conditionMessage(e); NULL })
fit_seconds <- proc.time()[["elapsed"]] - start
saved <- tryCatch(if (is.null(fit)) NULL else recover_outputs(fit, data),
                     error=function(e) { error <<- conditionMessage(e); fit <<- NULL; NULL })
saved_mu <- saved$mu
seconds <- proc.time()[["elapsed"]] - start
if (isTRUE(c$trace)) {
 Rprof(NULL)
 write.csv(summaryRprof(file.path(output,"Rprof.out"))$by.self, file.path(output,"Rprof-summary.csv"))
}
writeLines("DONE", file.path(output, "DONE"))
meta <- list(rc=if (is.null(fit)) 1 else 0, seconds=seconds,
             fit_seconds=fit_seconds, R_version=as.character(getRversion()), fixest_version=as.character(packageVersion("fixest")),
             requested_threads=cell$threads, effective_threads=getFixest_nthreads(), error=error)
if (!is.null(fit)) {
    stopifnot(length(saved_mu)==nobs(fit), all(is.finite(saved_mu)), all(saved_mu>0))
    con <- file(file.path(output,"means.bin"),"wb")
    writeBin(as.double(saved_mu),con,size=8,endian="little")
    close(con)
    if (!is.null(saved$channels)) {
        con <- file(file.path(output,"outputs.bin"),"wb")
        for (values in saved$channels) writeBin(as.double(values),con,size=8,endian="little")
        close(con)
    }
    b <- coef(fit)[cell$r_coefficient_names]
    stopifnot(all(is.finite(b)))
    names(b) <- cell$coefficient_names
    standard_errors <- se(fit)[cell$r_coefficient_names]
    correction <- if (length(cell$clusters)) 1 else nobs(fit)/(nobs(fit)-1)
    standard_errors <- standard_errors * sqrt(correction)
    meta$covariance_normalization <- if (length(cell$clusters)) "CGM common Gmin/(Gmin-1), no K adjustment" else "HC0 multiplied by N/(N-1)"
    meta$covariance_multiplier <- correction
    write.csv(data.frame(name=names(b), value=unname(b), se=unname(standard_errors)),
              file.path(output,"coefficients.csv"), row.names=FALSE)
    V <- vcov(fit)[cell$r_coefficient_names,cell$r_coefficient_names,drop=FALSE] * correction
    dimnames(V) <- list(cell$coefficient_names,cell$coefficient_names)
    rows <- expand.grid(row=rownames(V), column=colnames(V), stringsAsFactors=FALSE)
    rows$value <- as.vector(V)
    write.csv(rows, file.path(output,"covariance.csv"), row.names=FALSE)
    meta$N <- nobs(fit)
    meta$loglik <- as.numeric(logLik(fit))
    meta$deviance <- as.numeric(deviance(fit))
    meta$converged <- if (is.null(fit$convStatus)) TRUE else fit$convStatus
    meta$df_k <- fit$nparams
    if (cell$model == "ols") meta$rss <- sum(resid(fit)^2)
    selected <- obs(fit)
    write.csv(data.frame(obs_id=data$obs_id[selected]), file.path(output,"sample.csv"), row.names=FALSE)
    meta$sample_kind <- "observation_ids"
}
write_json(meta, file.path(output,"metadata.json"), auto_unbox=TRUE, pretty=TRUE, na="null", digits=NA)
cat(sprintf("SYSTEMATIC_WORKER_COMPLETE rc=%d\n", meta$rc))

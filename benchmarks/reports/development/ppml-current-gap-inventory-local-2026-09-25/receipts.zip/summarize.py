"""Source-bound summary of the already completed development baseline."""
from pathlib import Path
import hashlib
import json
import statistics

root = Path(__file__).parent
screen = root / 'baseline'
read = lambda p: json.loads(p.read_text())
audit = read(root / 'baseline-audit.json')
progress = read(screen / 'progress.json')
identity = read(Path('target/ppml-next-20260922/artifacts/identity-pairedscan2.json'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h
           for p, h in identity['source'].items())
rows = []
for i, record in enumerate(audit['records']):
    samples = {v: sorted([p for p in progress if p['case'] == i and p['variant'] == v],
                         key=lambda p: p['repetition']) for v in ('pairedscan2', 'fixest')}
    times = {v: [round(p['seconds'] * 1000, 6) for p in ps] for v, ps in samples.items()}
    medians = {v: statistics.median(t) for v, t in times.items()}
    native = [read(screen / p['result'] / 'result.json')['metadata'] for p in samples['pairedscan2']]
    phases = {k: statistics.median([m[k] for m in native]) * 1000
              for k in native[0] if k.startswith('feppml_time_') and k != 'feppml_time_timeit'}
    rows.append(dict(case=i, cell=record['cell'], milliseconds=times, medians_ms=medians,
                     ratio=medians['pairedscan2']/medians['fixest'],
                     target_ms=0.9*medians['fixest'],
                     saving_required_ms=medians['pairedscan2']-0.9*medians['fixest'],
                     native_phase_medians_ms=phases,
                     public_states_passed=sum(v['passed'] for v in record['public_states'].values()),
                     direct_stock_pairs_passed=sum(p['checks']['passed'] for p in record['pairs']),
                     independent_explicit_design_checks_run=False))
summary = dict(source_checkpoint='7cd9c579', artifact='pairedscan2', plugin_sha256=identity['plugin'],
               computational_inputs_checked=len(identity['source']),
               stock_archive_sha256=hashlib.sha256(Path('target/one-fe-profile-20260919/fixest.tar.gz').read_bytes()).hexdigest(),
               seed=202609347, repeats=3, cases=rows, attempts=len(progress),
               monitors_clean=all(not p['overlaps'] and not p['monitor_errors'] for p in progress),
               limitations=['Development timing only; not qualification or new independent explicit-design oracle evidence.',
                            'Factor and numeric cells share dimensions/topology, not identical weights or mathematical designs.',
                            'Phase medians need not sum to the median full-command time.'])
with (root / 'measurement-summary.json').open('x') as f:
    json.dump(summary, f, indent=2, allow_nan=False)
    f.write('\n')
print(json.dumps({k:summary[k] for k in ('attempts','monitors_clean','computational_inputs_checked')}))

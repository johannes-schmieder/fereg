import csv,json,statistics
from pathlib import Path
r=Path('target/parallel-projection-20260923');records=[]
clock_columns={'fereg_solver.csv':{9,10},'feppml_solver.csv':{14,15,16}}
for block in ['pairs','fresh','weak-native','controls']:
 root=r/block;plan=json.loads((root/'plan.json').read_text())
 for case,cell in enumerate(plan['cells']):
  name='fereg_solver.csv' if cell['model']=='ols' else 'feppml_solver.csv'
  for rep in range(plan['repeats']):
   parts=[]
   for v in ['parcert1','parproj1']:
    with (root/f'runs/c{case}-r{rep}-{v}'/name).open() as f:
     parts.append([(int(x['row']),int(x['column']),x['value'].strip()) for x in csv.DictReader(f) if int(x['column']) not in clock_columns[name]])
   assert parts[0] and parts[0]==parts[1],(block,case,rep)
   records.append(dict(block=block,case=case,repetition=rep,fields=len(parts[0]),exact=True))
(r/'solver-field-audit.json').write_text(json.dumps(dict(clock_columns={k:sorted(v) for k,v in clock_columns.items()},records=records),indent=2)+'\n')
print('EXACT_SOLVER_PAIRS',len(records))
profiles=[]
for c in range(2):
 for v in ['parcert_profile','parproj_profile']:
  root=r/'native-profile'/f'runs/c{c}-r0-{v}';sums={};counts={};pieces={}
  for line in (root/'stderr.txt').read_text().splitlines():
   if not line.startswith('FEREG_PHASE|owned_'):continue
   fields=line.split('|');d=dict(s.split('=',1) for s in fields[2:]);
   if int(d['rows'])!=61440:continue
   if fields[1]=='owned_fe':
    key=f"{d['phase']}:rhs{d['rhs']}";sums[key]=sums.get(key,0)+float(d['seconds']);counts[key]=counts.get(key,0)+1
   elif fields[1]=='owned_certificate':
    key=d['rhs'];p=pieces.setdefault(key,{})
    for k,x in d.items():
     if k not in ['rows','rhs']:p[k]=p.get(k,0)+float(x)
  profiles.append(dict(case=c,variant=v,seconds=sums,counts=counts,certificate_parts=pieces))
(r/'native-phase-summary.json').write_text(json.dumps(profiles,indent=2)+'\n')
for p in profiles:print(p['case'],p['variant'],p['seconds'],p['counts'])
for b in ['pairs','fresh','pilot']:
 audit=json.loads((r/f'{b}-audit.json').read_text())
 for i,record in enumerate(audit['records']):
  print('SCIENCE',b,i,record.keys())
  for k,v in record.items():
   if isinstance(v,dict) and k!='cell': print(k,str(v)[:350])

import sys,hashlib,json,zipfile
from pathlib import Path
r=Path('target/parallel-projection-20260923');out=Path('benchmarks/reports/development/parallel-projection-local-2026-09-23/receipts.zip')
sys.path.insert(0,'benchmarks/next_subsystem');from archive import archive
extras=sorted(p.name for p in r.iterdir() if p.is_file() and not p.name.startswith('.'))
archive(r,out,['pairs','fresh','weak-native','controls','pilot','native-profile'],extras)
with zipfile.ZipFile(out) as z:
 manifest=json.loads(z.read('archive-hashes.json'))
 for p,h in manifest.items():assert hashlib.sha256(z.read(p)).hexdigest()==h['archived_sha256'],p
 assert len(z.namelist())==len(manifest)+1
print('VERIFIED',len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())

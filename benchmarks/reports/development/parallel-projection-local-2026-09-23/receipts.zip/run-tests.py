import subprocess
from pathlib import Path
r=Path('target/parallel-projection-20260923')
for label,args in [('projection-final',['-p','fereg-core','--lib','fe::projection::tests::']),('map-final',['-p','fereg-core','--lib','fe::map::tests::']),('accelerated-final',['-p','fereg-core','--lib','fe::accelerated_map::tests::']),('certificate-final',['-p','fereg-core','--lib','fe::certificate::tests::']),('independent-final',['-p','fereg-testkit','--test','fe_certificate_oracle','--test','intercept_slope_oracle'])]:
 with (r/f'{label}-tests.log').open('w') as f:subprocess.run(['cargo','test',*args],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('PASS',label,flush=True)

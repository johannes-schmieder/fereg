import json,csv,shutil,hashlib,statistics
from pathlib import Path
r=Path('target/parallel-projection-20260923');a=Path('target/ppml-next-20260922/artifacts');head=['pairs','fresh','weak-native','controls'];applications=[];pairs=0;repeats=0;stock=0
for b in head+['pilot','native-profile']:
 p=json.loads((r/b/'progress.json').read_text())
 assert all(x['status']=='pass' and not x['overlaps'] and not x['monitor_errors'] for x in p)
 applications.append(dict(block=b,calls=len(p),pass_count=len(p),timeouts=0,overlaps=0,monitor_errors=0))
for b in head:
 s=json.loads((r/f'{b}-summary.json').read_text())
 for c in s['cells']:
  pairs+=len(c['pairs']);repeats+=len(c['repeats'])
  assert all(p['clean'] and p['checks']['passed'] and p['exact']['passed'] for p in c['pairs'])
  assert all(x['checks']['passed'] for x in c['repeats'])
for b in ['pairs','fresh']:
 for c in json.loads((r/f'{b}-audit.json').read_text())['records']:
  for p in c['pairs']:
   assert p['checks']['passed']
   stock+=p['variant']=='fixest'
for c in json.loads((r/'pilot-audit.json').read_text())['records']:
 assert all(o['passed'] for o in c['oracles'].values())
(r/'application-audit.json').write_text(json.dumps(applications,indent=2)+'\n')
(r/'acceptance-summary.json').write_text(json.dumps(dict(headline_calls=sum(x['calls'] for x in applications if x['block'] in head),native_exact_pairs=pairs,repeat_checks=repeats,stock_headline_comparisons=stock,rust_distinct_tests=50,harness_tests=5,licensed_fixtures=4,source_inputs=529,static_allocation_audit_exit=1,weak_stock_pilot='All three independent pilots pass on this seed; prior weak-stock covariance failures remain unresolved and weak stock timings stay unranked.'),indent=2)+'\n')
phases=[]
for i in range(2):
 for v in ['parcert_profile','parproj_profile']:
  rows=[];general={};projection={}
  for line in (r/'native-profile'/f'runs/c{i}-r0-{v}'/'stderr.txt').read_text().splitlines():
   if not line.startswith('FEREG_PHASE|'):continue
   p=line.split('|');d=dict(x.split('=',1) for x in p[2:])
   if p[1]=='owned_projection_parallel' and int(d['rows'])==61440:
    assert int(d['threads'])==4;rows.append(d)
    z=projection.setdefault(d['rhs'],dict(calls=0,groups=0.,subtract=0.))
    z['calls']+=1
    for k in ['groups','subtract']:z[k]+=float(d[k])
   if p[1] in ['fit','ols_prepare','ols_prepare_moments','score_design','robust']:general[p[1]]=d
  if v=='parproj_profile':assert len(rows)==(39 if i==0 else 60)
  phases.append(dict(case=i,variant=v,parallel_projection_calls=len(rows),parallel_projection=projection,last_full_fit_phases=general))
(r/'profile-team-audit.json').write_text(json.dumps(phases,indent=2)+'\n')
for v in ['parproj1','parproj_profile']:
 shutil.copy2(a/f'identity-{v}.json',r/f'identity-{v}.json')
 for f in ['projection','auto','map','accelerated_map','certificate']:
  shutil.copy2(a/v/f'crates/fereg-core/src/fe/{f}.rs',r/f'{v}-{f}.rs')
for v in ['parproj1','parproj_profile','parcert1','parcert_profile']:
 shutil.copy2(a/f'build-{v}.log',r/f'artifact-build-{v}.log')
fixtures=json.loads((a/'fixtures-parproj1parallel-projection.json').read_text());(r/'fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n')
for f in fixtures:
 assert f['status']=='pass' and f['process_returncode']==0 and f['terminal_sentinel']
 name=Path(f['fixture']).name;p=Path('tests/stata')/f['fixture']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'];shutil.copy2(p,r/name)
 (r/Path(name).with_suffix('.protocol')).write_text(f['fixture_sentinel']+'\nACCESSOR_FIXTURE_COMPLETE\n')
shutil.copy2('target/parallel-certificate-20260923/stock-reference.json',r/'stock-reference.json')
print('ACCEPTANCE',pairs,repeats,stock,applications)
print('PROJECTION_PHASES',[(x['case'],x['variant'],x['parallel_projection']) for x in phases])

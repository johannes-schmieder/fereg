from pathlib import Path
p=Path('crates/fereg-core/src/fe/projection.rs');s=p.read_text();where='    #[test]\n    fn removes_weighted_group_intercepts_and_slopes()'
addition='''    #[test]
    fn parallel_groups_preserve_scalar_bits_across_rank_units_and_teams() {
        for workers in [2, 4, 8] {
            rayon::ThreadPoolBuilder::new().num_threads(workers).build().unwrap().install(|| {
                let n = 257;
                for intercept in [false, true] {
                    for scale in [1e-60, 1.0, 1e60] {
                        for rhs in [1, 7, 32, 33, 65] {
                            let x: Vec<_> = (0..n).map(|r| scale * ((r * 13 % 37) as f64 - 18.0)).collect();
                            let effect = EffectTerm::new((0..n).map(|r| (r % 11) as u32).collect(), 13, intercept,
                                vec![x.clone(), x.iter().map(|x| 2.0*x).collect(), vec![0.0; n]]).unwrap();
                            let weights: Vec<_> = (0..n).map(|r| 0.25 + (r % 9) as f64 / 4.0).collect();
                            let mut expected = DenseMatrix::zeros(n, rhs).unwrap();
                            for r in 0..n { for j in 0..rhs { expected[(r,j)] = ((r*17+j*3)%41) as f64 - 20.0; } }
                            let mut actual = expected.clone();
                            let mut serial = ProjectionWorkspace::new(4, rhs).unwrap();
                            let mut parallel = ParallelProjectionPlan { channels: 4, rhs, levels: 13, workers }.allocate().unwrap();
                            for _ in 0..3 {
                                scalar_project_effect_in_place(&effect, &weights, &mut expected, &mut serial).unwrap();
                                project_parallel(&effect, &weights, &mut actual, &mut parallel).unwrap();
                                for (a,b) in actual.as_slice().iter().zip(expected.as_slice()) { assert_eq!(a.to_bits(), b.to_bits()); }
                            }
                        }
                    }
                }
            });
        }
    }

    #[test]
    fn parallel_weighted_projection_matches_independent_two_column_formula() {
        let n = 311;
        let x: Vec<_> = (0..n).map(|r| (r % 13) as f64 - 6.0).collect();
        let weights: Vec<_> = (0..n).map(|r| 0.5 + (r % 7) as f64).collect();
        let y: Vec<_> = (0..n).map(|r| ((r*11)%23) as f64 + 0.7*x[r]).collect();
        let effect = EffectTerm::new((0..n).map(|r| (r%5) as u32).collect(), 7, true, vec![x.clone()]).unwrap();
        let mut expected = y.clone();
        for level in 0..5 {
            let rows: Vec<_> = (0..n).filter(|r| r%5 == level).collect();
            let sw: f64 = rows.iter().map(|&r| weights[r]).sum();
            let mx: f64 = rows.iter().map(|&r| weights[r]*x[r]).sum::<f64>() / sw;
            let my: f64 = rows.iter().map(|&r| weights[r]*y[r]).sum::<f64>() / sw;
            let slope = rows.iter().map(|&r| weights[r]*(x[r]-mx)*(y[r]-my)).sum::<f64>()
                / rows.iter().map(|&r| weights[r]*(x[r]-mx).powi(2)).sum::<f64>();
            for r in rows { expected[r] -= my + slope*(x[r]-mx); }
        }
        for workers in [1,2,4,8] {
            rayon::ThreadPoolBuilder::new().num_threads(workers).build().unwrap().install(|| {
                let mut actual = DenseMatrix::from_columns(&[y.clone()]).unwrap();
                let mut workspace = ParallelProjectionPlan {channels:2,rhs:1,levels:7,workers}.allocate().unwrap();
                project_parallel(&effect,&weights,&mut actual,&mut workspace).unwrap();
                for (a,b) in actual.as_slice().iter().zip(&expected) { assert!((a-b).abs()<2e-13, "{a} {b}"); }
            });
        }
    }

    #[test]
    fn optional_projection_checks_capacity_overflow_and_validation_before_mutation() {
        let plan = ParallelProjectionPlan { channels:2, rhs:3, levels:7, workers:4 };
        let workspace = plan.allocate().unwrap();
        let actual = workspace.coefficients.capacity()*8 + workspace.workers.capacity()*std::mem::size_of::<ProjectionWorker>()
            + workspace.workers.iter().map(|w| w.gram.capacity()*8).sum::<usize>();
        assert_eq!(actual as u128, plan.bytes().unwrap());
        assert!(ParallelProjectionPlan {levels:usize::MAX,..plan}.bytes().is_err());
        let design = FeDesign::new(6,vec![EffectTerm::new(vec![0,0,0,1,1,1],2,true,vec![vec![0.,1.,2.,0.,1.,2.]]).unwrap()]).unwrap();
        let input = DenseMatrix::from_columns(&[vec![1.,4.,2.,5.,3.,7.]]).unwrap();
        for bad_plan in [Some(ParallelProjectionPlan {levels:1,..plan}),None] {
            let mut w = AutoProjectionWorkspace::new(&design,1,bad_plan).unwrap();
            let mut values = input.clone();
            assert!(w.project(&design.effects()[0], &[1.,1.,-1.,1.,1.,1.], &mut values).is_err());
            assert_eq!(values,input);
            if bad_plan.is_some() {
                assert!(w.project(&design.effects()[0], &[1.;6], &mut values).is_err());
                assert_eq!(values,input);
            }
        }
        let mut fallback = AutoProjectionWorkspace::new(&design,1,Some(ParallelProjectionPlan {levels:usize::MAX,..plan})).unwrap();
        assert!(fallback.parallel.is_none());
        let mut values = input;
        fallback.project(&design.effects()[0], &[1.;6], &mut values).unwrap();
    }

    #[test]
    fn automatic_projection_plan_respects_team_size_and_design_scope() {
        for workers in [1,4] {
            rayon::ThreadPoolBuilder::new().num_threads(workers).build().unwrap().install(|| {
                for n in [16_383,16_384] { for slopes in [false,true] {
                    let effect=EffectTerm::new(vec![0;n],1,true,if slopes {vec![vec![1.;n]]} else {vec![]}).unwrap();
                    let design=FeDesign::new(n,vec![effect]).unwrap();
                    assert_eq!(ParallelProjectionPlan::for_design(&design,1).unwrap().is_some(),workers>1 && n>=16_384 && slopes);
                    assert!(ParallelProjectionPlan::for_design(&design,0).unwrap().is_none());
                } }
            });
        }
    }

'''
assert s.count(where)==1;s=s.replace(where,addition+where);p.write_text(s)
p=Path('crates/fereg-core/src/fe/auto.rs');s=p.read_text();s=s.replace('fn parallel_certificate_exact_budget_keeps_the_serial_cache_when_scratch_does_not_fit()', 'fn parallel_projection_exact_budget_preserves_geometry_and_certificate_priority()')
s=s.replace('                for budget in [cached, cached + parallel - 1, cached + parallel] {','''                let projection = ParallelProjectionPlan::for_design(&design,1).unwrap().unwrap().bytes().unwrap();
                for budget in [cached, cached + parallel - 1, cached + parallel,
                    cached + parallel + projection - 1, cached + parallel + projection] {''')
s=s.replace('''                        } else {
                            cached + parallel
                        } as u64)''','''                        } else if budget < cached + parallel + projection {
                            cached + parallel
                        } else {
                            cached + parallel + projection
                        } as u64)''');p.write_text(s)

from pathlib import Path
p=Path('crates/fereg-core/src/fe/projection.rs');s=p.read_text();s=s.replace('use crate::fe::EffectTerm;', 'use crate::fe::{EffectTerm, FeDesign};\nuse rayon::prelude::*;')
a=s.index('        workspace.gram[..gram_length].fill(0.0);');b=s.index('        // Batch independent RHSs',a)
form=s[a:b]
# Extract the same group arithmetic with slices already sized to the actual channels/RHSs.
form=form.replace('workspace.gram[..gram_length]', 'gram').replace('workspace.right_hand_sides[..rhs_length]', 'coefficients').replace('workspace.gram[index]', 'gram[index]').replace('workspace.right_hand_sides[start..start + rhs_count]', 'coefficients[start..start + rhs_count]')
form=form.replace('&mut gram','gram').replace('&mut coefficients,','coefficients,').replace('        )?;\n', '        )?;\n',1)
form='\n'.join(line[4:] if line.startswith('    ') else line for line in form.splitlines())
helper='''#[inline]
fn group_coefficients(effect: &EffectTerm, weights: &[f64], values: &DenseMatrix, level: usize,
    gram: &mut [f64], coefficients: &mut [f64]) -> Result<()> {
    let channels = effect.channels();
    let rhs_count = values.ncols();
'''+form+'''\n    Ok(())
}

'''
s=s[:a]+'''        group_coefficients(effect, weights, values, level,
            &mut workspace.gram[..gram_length], &mut workspace.right_hand_sides[..rhs_length])?;

'''+s[b:]
a=s.index('            for (tile_index, tile) in row.chunks_mut(32).enumerate() {');b=s.index('\n        }\n    }\n    Ok(())',a)
sub=s[a:b].replace('effect.basis_value(channel, *observation)', 'effect.basis_value(channel, observation)').replace('&workspace.right_hand_sides[start..start + tile.len()]','&coefficients[start..start + tile.len()]')
sub='\n'.join(line[8:] if line.startswith('        ') else line for line in sub.splitlines())
helper+='''#[inline]
fn subtract_row(effect: &EffectTerm, observation: usize, row: &mut [f64], coefficients: &[f64], rhs_count: usize) {
    let channels = effect.channels();
'''+sub+'\n}\n\n'
s=s[:a]+'''            subtract_row(effect, *observation, row, &workspace.right_hand_sides, rhs_count);'''+s[b:]
# Keep existing public validation order; parallel entry reuses it.
a=s.index('    if weights.len() != values.nrows()');b=s.index('\n    for level in 0..effect.n_levels()',a);validation=s[a:b]
helper+='''fn validate_projection(effect: &EffectTerm, weights: &[f64], values: &DenseMatrix, workspace: &ProjectionWorkspace) -> Result<()> {
'''+validation+'\n    Ok(())\n}\n\n'
s=s[:a]+'''    validate_projection(effect, weights, values, workspace)?;
    let channels = effect.channels();
    let rhs_count = values.ncols();
'''+s[b:]
pos=s.index('\n#[cfg(test)]');s=s[:pos]+'\n'+helper+s[pos:]
# Internal ownership separates the optional auto workspace from public/reusable MAP workspaces.
pos=s.index('\n#[cfg(test)]')
new='''#[derive(Debug, Clone, Copy)]
pub(super) struct ParallelProjectionPlan {
    channels: usize,
    rhs: usize,
    levels: usize,
    workers: usize,
}

struct ProjectionWorker {
    gram: Vec<f64>,
    error: Option<FeregError>,
}

struct ParallelProjectionWorkspace {
    plan: ParallelProjectionPlan,
    coefficients: Vec<f64>,
    workers: Vec<ProjectionWorker>,
}

pub(super) struct AutoProjectionWorkspace {
    serial: ProjectionWorkspace,
    parallel: Option<ParallelProjectionWorkspace>,
}

impl ParallelProjectionPlan {
    pub(super) fn for_design(design: &FeDesign, rhs: usize) -> Result<Option<Self>> {
        if design.nobs() < 16_384 || rhs == 0 || rayon::current_thread_index().is_none()
            || rayon::current_num_threads() <= 1
            || !design.effects().iter().any(|e| !e.slopes().is_empty()) {
            return Ok(None);
        }
        let plan = Self { channels: design.max_channels(), rhs,
            levels: design.effects().iter().map(|e| e.n_levels()).max().unwrap_or(0),
            workers: rayon::current_num_threads() };
        plan.bytes()?;
        Ok(Some(plan))
    }

    fn cells(self) -> Result<(usize, usize)> {
        let fail = || FeregError::new(ErrorCode::Allocation, "parallel projection dimensions overflow");
        Ok((self.levels.checked_mul(self.channels).and_then(|n| n.checked_mul(self.rhs)).ok_or_else(fail)?,
            self.channels.checked_mul(self.channels).ok_or_else(fail)?))
    }

    pub(super) fn bytes(self) -> Result<u128> {
        let (coefficients, gram) = self.cells()?;
        (gram as u128).checked_mul(self.workers as u128)
            .and_then(|n| n.checked_add(coefficients as u128))
            .and_then(|n| n.checked_mul(8))
            .and_then(|n| n.checked_add(self.workers as u128 * std::mem::size_of::<ProjectionWorker>() as u128))
            .ok_or_else(|| FeregError::new(ErrorCode::Allocation, "parallel projection bytes overflow"))
    }

    fn allocate(self) -> Result<ParallelProjectionWorkspace> {
        let (coefficients, gram) = self.cells()?;
        let coefficients = fallible_zeros(coefficients)?;
        let mut workers = Vec::new();
        workers.try_reserve_exact(self.workers).map_err(|_| FeregError::new(ErrorCode::Allocation, "unable to reserve parallel projection workers"))?;
        for _ in 0..self.workers {
            workers.push(ProjectionWorker { gram: fallible_zeros(gram)?, error: None });
        }
        let actual = coefficients.capacity() as u128 * 8
            + workers.capacity() as u128 * std::mem::size_of::<ProjectionWorker>() as u128
            + workers.iter().map(|w| w.gram.capacity() as u128 * 8).sum::<u128>();
        if actual > self.bytes()? {
            return Err(FeregError::new(ErrorCode::Allocation, "parallel projection capacity exceeds admission"));
        }
        Ok(ParallelProjectionWorkspace { plan: self, coefficients, workers })
    }
}

impl AutoProjectionWorkspace {
    /// The caller admits the optional bank beside the existing serial workspace.
    pub(super) fn new(design: &FeDesign, rhs: usize, plan: Option<ParallelProjectionPlan>) -> Result<Self> {
        let serial = ProjectionWorkspace::new(design.max_channels(), rhs)?;
        let parallel = match plan.map(ParallelProjectionPlan::allocate).transpose() {
            Ok(workspace) => workspace,
            Err(error) if error.code == ErrorCode::Allocation => None,
            Err(error) => return Err(error),
        };
        Ok(Self { serial, parallel })
    }

    pub(super) fn project(&mut self, effect: &EffectTerm, weights: &[f64], values: &mut DenseMatrix) -> Result<()> {
        if let Some(parallel) = self.parallel.as_mut() {
            validate_projection(effect, weights, values, &self.serial)?;
            if values.ncols() > 0 && effect.n_levels() > 0 {
                return project_parallel(effect, weights, values, parallel);
            }
        }
        project_effect_in_place(effect, weights, values, &mut self.serial)
    }
}

fn project_parallel(effect: &EffectTerm, weights: &[f64], values: &mut DenseMatrix,
    workspace: &mut ParallelProjectionWorkspace) -> Result<()> {
    let channels = effect.channels();
    let rhs = values.ncols();
    if channels > workspace.plan.channels || rhs > workspace.plan.rhs
        || effect.n_levels() > workspace.plan.levels || workspace.workers.is_empty() {
        return Err(FeregError::new(ErrorCode::InvalidArgument, "parallel projection workspace is smaller than the request"));
    }
    let group_width = channels * rhs;
    let chunk_levels = effect.n_levels().div_ceil(workspace.workers.len());
    let coefficients = &mut workspace.coefficients[..effect.n_levels() * group_width];
    // Contiguous level chunks preserve first-error order. No input row is
    // modified until all groups have completed the original small-system solve.
    for worker in &mut workspace.workers { worker.error = None; }
    coefficients.par_chunks_mut(chunk_levels * group_width)
        .zip(workspace.workers.par_iter_mut()).enumerate()
        .for_each(|(chunk, (output, worker))| {
            for (local, coefficient) in output.chunks_exact_mut(group_width).enumerate() {
                if let Err(error) = group_coefficients(effect, weights, values,
                    chunk * chunk_levels + local, &mut worker.gram[..channels * channels], coefficient) {
                    worker.error = Some(error);
                    break;
                }
            }
        });
    for worker in &mut workspace.workers {
        if let Some(error) = worker.error.take() { return Err(error); }
    }
    values.as_mut_slice().par_chunks_mut(rhs).enumerate().for_each(|(row, values)| {
        let start = effect.codes()[row] as usize * group_width;
        subtract_row(effect, row, values, &coefficients[start..start+group_width], rhs);
    });
    Ok(())
}
'''
s=s[:pos]+new+s[pos:];p.write_text(s)
# Internal MAP/CG entry points accept a preadmitted optional projection plan.
p=Path('crates/fereg-core/src/fe/map.rs');s=p.read_text();s='use super::projection::{AutoProjectionWorkspace, ParallelProjectionPlan};\n'+s;s=s.replace('absorb_map_with_context(&CertificateContext::new(design, weights), values, config)', 'absorb_map_with_context(&CertificateContext::new(design, weights), values, config, None)',1)
a=s.index('pub(super) fn absorb_map_with_context(');b=s.index('/// Session-owned',a);body=s[a:b].replace('    config: MapConfig,\n)', '    config: MapConfig,\n    projection_plan: Option<ParallelProjectionPlan>,\n)',1).replace('ProjectionWorkspace::new(design.max_channels(), values.ncols())?', 'AutoProjectionWorkspace::new(design, values.ncols(), projection_plan)?',1).replace('project_effect_in_place(effect, weights, values, &mut workspace)?;', 'workspace.project(effect, weights, values)?;');s=s[:a]+body+s[b:];p.write_text(s)
p=Path('crates/fereg-core/src/fe/accelerated_map.rs');s=p.read_text();s='use super::projection::{AutoProjectionWorkspace, ParallelProjectionPlan};\n'+s;s=s.replace('        solver,\n    )','        solver,\n        None,\n    )',1)
s=s.replace('    solver: FeSolverKind,\n) -> Result<SolveReport> {\n    let (design, weights)', '    solver: FeSolverKind,\n    projection_plan: Option<ParallelProjectionPlan>,\n) -> Result<SolveReport> {\n    let (design, weights)',1)
s=s.replace('absorb_conjugate_gradient(context, values, config)', 'absorb_conjugate_gradient(context, values, config, projection_plan)',1)
a=s.index('fn absorb_conjugate_gradient(');s=s[:a]+s[a:].replace('    config: MapConfig,\n)', '    config: MapConfig,\n    projection_plan: Option<ParallelProjectionPlan>,\n)',1)
s=s.replace('ProjectionWorkspace::new(design.max_channels(), values.ncols())?', 'AutoProjectionWorkspace::new(design, values.ncols(), projection_plan)?')
s=s.replace('workspace: &mut ProjectionWorkspace,','workspace: &mut AutoProjectionWorkspace,').replace('project_effect_in_place(effect, weights, values, workspace)?;', 'workspace.project(effect, weights, values)?;')
s=s.replace('    project_effect_in_place, weighted_column_norms, FeDesign, FeSolverKind, MapConfig,\n    ProjectionWorkspace, SolveReport, SolveStopReason,','    weighted_column_norms, FeDesign, FeSolverKind, MapConfig, SolveReport, SolveStopReason,')
p.write_text(s)

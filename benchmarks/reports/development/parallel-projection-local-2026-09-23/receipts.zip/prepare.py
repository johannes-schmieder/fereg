import json,shutil,hashlib,sys
from pathlib import Path
r=Path('target/parallel-projection-20260923');old=Path('target/parallel-certificate-20260923');art=Path('target/ppml-next-20260922/artifacts')
for name in ['pair','fresh','weak-native','control','pilot']:
 shutil.copy2(old/f'{name}-cells.json',r/f'{name}-cells.json')
p=json.loads((old/'predeclared.json').read_text());p.update(base_commit='9a1d8db2',baseline='parcert1',candidate='parproj1',overlays=[f'crates/fereg-core/src/fe/{x}.rs' for x in ['projection','map','accelerated_map','auto']],hypothesis='Compute unchanged raw Gram/RHS systems in disjoint level chunks, then subtract disjoint rows on the installed worker team. Optional coefficient bank comes after geometry and certificate scratch in admission priority.')
p['seeds']={k:v+6 for k,v in p['seeds'].items()};(r/'predeclared.json').write_text(json.dumps(p,indent=2)+'\n')
for name in ['parcert1','parcert_profile']:
 shutil.copy2(art/f'identity-{name}.json',r/f'identity-{name}.json')
 for f in ['projection','certificate','auto','map','accelerated_map']:
  shutil.copy2(art/name/f'crates/fereg-core/src/fe/{f}.rs',r/f'{name}-{f}.rs')
for name in ['run','surface','surface_audit','designs','profile','oracles','summarize','audit','archive']:
 shutil.copy2(Path('benchmarks/next_subsystem')/f'{name}.py',r/f'{name}.py')
shutil.copy2('benchmarks/one_fe_optimization/build.py',r/'build.py')
s=(old/'run-blocks.py').read_text().replace(str(old),str(r)).replace('parcert1','parproj1').replace('certcache3','parcert1').replace('parcert_profile','parproj_profile').replace('certcache_profile','parcert_profile')
for n in range(202609278,202609283):s=s.replace(str(n),str(n+6))
(r/'run-blocks.py').write_text(s)
probe=r/'instrument-check';(probe/'crates/fereg-core/src/fe').mkdir(parents=True,exist_ok=True)
for f in ['projection','certificate']:shutil.copy2(f'crates/fereg-core/src/fe/{f}.rs',probe/f'crates/fereg-core/src/fe/{f}.rs')
sys.path.insert(0,'benchmarks/next_subsystem');from profile import instrument_owned_fe
instrument_owned_fe(probe);print('instrumentation passed')

from pathlib import Path
import subprocess
for name in ['projection','map','accelerated_map','auto']:
 p=Path(f'crates/fereg-core/src/fe/{name}.rs');old=p.read_text()
 subprocess.run(['$HOME/.rustup/toolchains/1.85.1-aarch64-apple-darwin/bin/rustfmt','--edition','2021',str(p)],check=True)
 new=p.read_text()
 if name=='map':
  marker='/// Session-owned';new=new[:new.index(marker)]+old[old.index(marker):]
 if name=='accelerated_map':
  marker='#[cfg(test)]';new=new[:new.index(marker)]+old[old.index(marker):]
 if name=='projection':
  a='    #[test]\n    fn rhs_tiles_preserve_scalar_projection_bits()';b='    #[test]\n    fn parallel_groups_preserve_scalar_bits_across_rank_units_and_teams()'
  new=new[:new.index(a)]+old[old.index(a):old.index(b)]+new[new.index(b):]
  a='    #[test]\n    fn removes_weighted_group_intercepts_and_slopes()';new=new[:new.index(a)]+old[old.index(a):]
 p.write_text(new)

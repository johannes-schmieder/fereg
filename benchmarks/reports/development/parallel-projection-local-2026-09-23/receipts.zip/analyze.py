import subprocess,json,csv,statistics
from pathlib import Path
r=Path('target/parallel-projection-20260923');py='target/one-fe-profile-20260919/python/bin/python'
for b in ['fresh','weak-native','controls','pilot']:
 subprocess.run([py,'benchmarks/next_subsystem/summarize.py',str(r/b),str(r/f'{b}-summary.json'),'parcert1','parproj1'],check=True)
for b in ['fresh','pilot']:
 subprocess.run([py,'benchmarks/next_subsystem/surface_audit.py',str(r/b),str(r/f'{b}-audit.json'),*(['--independent'] if b=='pilot' else [])],check=True)
s=(Path('target/parallel-certificate-20260923/evidence-summary.py')).read_text().replace('parallel-certificate-20260923','parallel-projection-20260923').replace('parcert1','parproj1').replace('certcache3','parcert1').replace('parcert_profile','parproj_profile').replace('certcache_profile','parcert_profile')
(r/'evidence-summary.py').write_text(s)
subprocess.run([py,str(r/'evidence-summary.py')],check=True)
for b in ['pairs','fresh','weak-native','controls']:
 summary=json.loads((r/f'{b}-summary.json').read_text());progress=json.loads((r/b/'progress.json').read_text())
 for i,c in enumerate(summary['cells']):
  assert all(p['checks']['passed'] and p['exact']['passed'] for p in c['pairs']);assert all(p['checks']['passed'] for p in c['repeats'])
  med={v:round(statistics.median(p['seconds'] for p in progress if p['case']==i and p['variant']==v)*1000,1) for v in set(p['variant'] for p in progress)}
  delta=[p['tracked_peak_bytes']['parproj1']-p['tracked_peak_bytes']['parcert1'] for p in c['pairs']]
  diff=[round((next(p['seconds'] for p in progress if p['case']==i and p['variant']=='parproj1' and p['repetition']==j)-next(p['seconds'] for p in progress if p['case']==i and p['variant']=='parcert1' and p['repetition']==j))*1000,1) for j in range(3)]
  print('TIMING',b,i,med,c['ratios'],'HEAP',delta,'MS_DELTA',diff)

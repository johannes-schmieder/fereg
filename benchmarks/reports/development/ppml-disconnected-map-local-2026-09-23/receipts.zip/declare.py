import json
from pathlib import Path
r=Path(__file__).parent
base=json.loads(Path('target/ppml-certificate-geometry-20260923/fresh-cells.json').read_text())[3]
cells=[dict(base,n=960,k=3),dict(base,n=1920,k=4)]
(r/'small-cells.json').write_text(json.dumps(cells,indent=2)+'\n')
(r/'predeclared.json').write_text(json.dumps(dict(base='190946a1',baseline='ppmlgeom1',seed=202609305,cases=cells,purpose='Reduce disconnected multi-slope MAP iteration exhaustion and establish independent explicit-design science. No headline rankings, no resumption of the stopped full-size timing block.',limits='One native/strict-stock call per small case; 20-second command timeout. If failure is reproduced, localize the failing weighted linear frame in an isolated diagnostic. Do not relax tolerances, change rank or revive CG. Any remedy requires new candidate admission and independent validation. ADR0120 extrapolation stays closed unless a newly declared experiment is justified by both lower certificate cost and this failure.'),indent=2)+'\n')

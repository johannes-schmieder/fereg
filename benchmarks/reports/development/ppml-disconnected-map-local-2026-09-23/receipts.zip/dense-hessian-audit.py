import sys,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy import linalg
sys.path[:0]=['benchmarks/next_subsystem','benchmarks/systematic']
from ppml_audit import design,explicit_poisson,means
from oracles import oracle_sample
from audit import distance
r=Path(__file__).parent;root=r/'small';plan=json.loads((root/'plan.json').read_text());out=[]
for i,cell in enumerate(plan['cells']):
 full=pd.read_stata(root/f'data/c{i}-full.dta',convert_categoricals=False);frame,sample=oracle_sample(full,cell)
 F=design(frame,cell);X=frame[[f'x{j}' for j in range(1,cell['k']+1)]].to_numpy();y=frame.y.to_numpy();expected=explicit_poisson(y,X,F)
 stock=root/f'runs/c{i}-r0-fixest';mu_stock=means(stock,sample,len(full),frame.obs_id.to_numpy())
 names=[f'x{j}' for j in range(1,cell['k']+1)];V_stock=pd.read_csv(stock/'covariance.csv').pivot(index='row',columns='column',values='value').loc[names,names].to_numpy()
 record=dict(case=i,variants={})
 for tag,mu in [('independent_mean',expected['mu']),('stock_mean',mu_stock)]:
  root_w=np.sqrt(mu);WF=F.toarray()*root_w[:,None];scales=np.linalg.norm(WF,axis=0);WF/=scales
  U,s,_=linalg.svd(WF,full_matrices=False);threshold=np.finfo(float).eps*max(WF.shape)*s[0];rank=int(sum(s>threshold));assert rank==expected['fe_rank']
  Z=X-U[:,:rank]@(U[:,:rank].T@(root_w[:,None]*X))/root_w[:,None]
  bread=np.linalg.inv(Z.T@(mu[:,None]*Z));V=bread@(Z.T@((y-mu)[:,None]**2*Z))@bread*len(y)/(len(y)-1)
  Q,R,pivot=linalg.qr(WF,mode='economic',pivoting=True);qr_rank=int(sum(abs(np.diag(R))>threshold));assert qr_rank==rank
  Zq=X-Q[:,:rank]@(Q[:,:rank].T@(root_w[:,None]*X))/root_w[:,None]
  Bq=np.linalg.inv(Zq.T@(mu[:,None]*Zq));Vq=Bq@(Zq.T@((y-mu)[:,None]**2*Zq))@Bq*len(y)/(len(y)-1)
  record['variants'][tag]=dict(rank=rank,condition=float(s[0]/s[rank-1]),smallest_retained=float(s[rank-1]),largest_dropped=float(s[rank]),stock=distance(V_stock,V,1e-6),lsmr_oracle=distance(expected['V'],V,1e-6),qr_vs_svd=distance(Vq,V,1e-10),matrix=V.tolist())
 out.append(record);print(record,flush=True)
(r/'dense-hessian-audit.json').write_text(json.dumps(out,indent=2)+'\n')

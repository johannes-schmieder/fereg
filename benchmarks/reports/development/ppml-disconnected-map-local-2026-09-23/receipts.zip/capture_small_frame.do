version 18.0
clear all
set more off
use "$REPO/target/ppml-disconnected-map-20260923/small/data/c0-full.dta", clear
capture noisily feppml y x1 x2 x3, absorb(g1##c.(z1) g2##c.(z2) g3) threads(4) solver(auto) poolsize(10) vce(robust) memory(fast) mu(saved_mu)
local actual_rc = _rc
display as result "CAPTURE_SMALL_FRAME_RC|rc=`actual_rc'"
assert `actual_rc' == 459
display as result "END_FIXTURE|capture_small_frame|rc=0"

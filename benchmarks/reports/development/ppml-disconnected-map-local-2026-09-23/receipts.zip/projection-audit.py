"""Independent dense projection audit of the isolated failed MAP frame."""
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy import linalg

root = Path(__file__).resolve().parent
capture = root / 'captured/map-0'
meta = json.loads((capture / 'frame.json').read_text())
data = np.loadtxt(capture / 'frame.csv', delimiter=',')
n, rhs = meta['rows'], meta['rhs']
assert data.shape[0] == n and np.isfinite(data).all()
w = data[:, 0]
assert np.all(w > 0)
rw = np.sqrt(w)
original = data[:, 1:1 + rhs]
residual = data[:, 1 + rhs:1 + 2 * rhs]
col = 1 + 2 * rhs
blocks, groups = [], []
for levels, channels, intercept in zip(meta['levels'], meta['channels'], meta['intercepts']):
    codes = data[:, col].astype(int)
    assert np.array_equal(codes, data[:, col]) and np.all((0 <= codes) & (codes < levels))
    col += 1
    slopes = channels - int(intercept)
    basis = data[:, col:col + slopes]
    col += slopes
    if intercept:
        basis = np.column_stack((np.ones(n), basis))
    F = np.zeros((n, levels * channels))
    F[np.arange(n)[:, None], codes[:, None] * channels + np.arange(channels)] = basis
    blocks.append(F)
    for level in range(levels):
        rows = np.flatnonzero(codes == level)
        groups.append((rows, rw[rows, None] * basis[rows]))
assert col == data.shape[1]
F = np.column_stack(blocks)
WF = rw[:, None] * F
scales = np.linalg.norm(WF, axis=0)
active = scales > 0
WF = WF[:, active] / scales[active]
U, singular, _ = linalg.svd(WF, full_matrices=False)
threshold = np.finfo(float).eps * max(WF.shape) * singular[0]
rank = int(np.count_nonzero(singular > threshold))
Q, R, _ = linalg.qr(WF, mode='economic', pivoting=True)
assert int(np.count_nonzero(np.abs(np.diag(R)) > threshold)) == rank
U, Q = U[:, :rank], Q[:, :rank]
WO = rw[:, None] * original
WR = rw[:, None] * residual
expected = WO - U @ (U.T @ WO)
qr_expected = WO - Q @ (Q.T @ WO)
assert np.allclose(expected, qr_expected, rtol=1e-10, atol=1e-10)
reference_norm = np.linalg.norm(WO, axis=0)
scaling = np.maximum(reference_norm, np.linalg.norm(WR, axis=0))


def certificate(values):
    denominator = np.maximum(reference_norm, np.linalg.norm(values, axis=0))
    relative = []
    for rows, basis in groups:
        if len(rows) == 0:
            relative.extend([0.] * rhs)
            continue
        scales = np.linalg.norm(basis, axis=0)
        normalized = basis[:, scales > 0] / scales[scales > 0]
        local_q, local_r, _ = linalg.qr(normalized, mode='economic', pivoting=True)
        local_rank = int(np.count_nonzero(np.abs(np.diag(local_r)) > np.finfo(float).eps * max(normalized.shape) * 8))
        projected = local_q[:, :local_rank].T @ values[rows]
        relative.extend(np.linalg.norm(projected, axis=0) / denominator)
    return {'infinity': float(np.max(relative)), 'two': float(np.sqrt(np.mean(np.square(relative))))}

failed_cert = certificate(WR)
trace = (root / 'capture-trace.protocol').read_text().splitlines()
final = next(line for line in trace if '|iteration=16000|' in line)
fields = dict(part.split('=', 1) for part in final.split('|')[2:])
for metric in ('two', 'infinity'):
    assert np.isclose(failed_cert[metric], float(fields[metric]), rtol=1e-10, atol=1e-15)
expected_cert = certificate(expected)
assert expected_cert['infinity'] < 1e-12
error = WR - expected
outside_span = error - U @ (U.T @ error)
assert np.max(np.linalg.norm(outside_span, axis=0) / scaling) < 1e-10
result = {
    'frame_sha256': hashlib.sha256((capture / 'frame.csv').read_bytes()).hexdigest(),
    'rows': n, 'rhs': rhs, 'weight_unique_count': int(len(np.unique(w))),
    'weight_min': float(w.min()), 'weight_max': float(w.max()),
    'explicit_columns': F.shape[1], 'nonzero_columns': WF.shape[1], 'rank': rank,
    'condition': float(singular[0] / singular[rank - 1]),
    'smallest_retained_singular': float(singular[rank - 1]),
    'largest_dropped_singular': float(singular[rank]),
    'qr_svd_residual_max_difference': float(np.max(np.abs(expected - qr_expected))),
    'failed_map_certificate': failed_cert, 'independent_residual_certificate': expected_cert,
    'weighted_error_norm_per_rhs': np.linalg.norm(error, axis=0).tolist(),
    'error_over_reference_norm_per_rhs': (np.linalg.norm(error, axis=0) / reference_norm).tolist(),
    'outside_span_error_over_reference_norm_per_rhs': (np.linalg.norm(outside_span, axis=0) / reference_norm).tolist(),
    'maximum_unweighted_residual_error': float(np.max(np.abs(error / rw[:, None]))),
    'passed': True,
}
(root / 'projection-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

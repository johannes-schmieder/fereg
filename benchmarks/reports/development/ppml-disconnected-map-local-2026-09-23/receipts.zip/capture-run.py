import sys,json,hashlib,os,re
from pathlib import Path
sys.path.insert(0,'scripts');from run_stata_tests import run_fixture,expected_sentinel
r=Path(__file__).parent;repo=Path('.').resolve();plugin=repo/'target/ppml-next-20260922/artifacts/disconnected_capture1/dist/fereg_macos.plugin';data=r/'small/data/c0-full.dta';fixture=r/'capture_small_frame.do'
fixture.write_text(f'''version 18.0
clear all
set more off
use "{data.resolve()}", clear
capture noisily feppml y x1 x2 x3, absorb(g1##c.(z1) g2##c.(z2) g3) threads(4) solver(auto) poolsize(10) vce(robust) memory(fast) mu(saved_mu)
local actual_rc = _rc
display as result "CAPTURE_SMALL_FRAME_RC|rc=`actual_rc'"
assert `actual_rc' == 459
display as result "END_FIXTURE|capture_small_frame|rc=0"
''')
env={k:os.environ[k] for k in ['HOME','PATH','TMPDIR'] if k in os.environ}
env.update(FEREG_CAPTURE_MAP_DIR=str((r/'captured').resolve()),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
h=hashlib.sha256(plugin.read_bytes()).hexdigest()
result=run_fixture('/Applications/Stata/StataMP.app/Contents/MacOS/stata-mp',fixture.resolve(),repo,plugin=plugin,plugin_sha256=h,log_dir=r/'capture-licensed-logs',environment=env,require_status=True)
record=dict(purpose='Capture the failing current weight/response frame diagnostically; no production timing or allocation claim.',plugin=h,data_sha256=hashlib.sha256(data.read_bytes()).hexdigest(),process_returncode=result.process_returncode,stata_rc=result.stata_rc,error=result.error,terminal_sentinel=expected_sentinel(fixture) in result.log_text)
(r/'capture-result.json').write_text(json.dumps(record,indent=2)+'\n')
lines=[x for x in result.log_text.splitlines() if x.startswith(('fereg:','CAPTURE_SMALL_FRAME_RC|','END_FIXTURE|'))]
(r/'capture-result.protocol').write_text('\n'.join(lines)+'\n')
(r/'capture-trace.protocol').write_text('\n'.join(x for x in result.process_output.splitlines() if x.startswith('FEREG_MAP_PROBE|'))+'\n')
print(record)
if result.error:raise RuntimeError(result.error)

from pathlib import Path

def instrument(root):
 p=root/'crates/fereg-core/src/fe/map.rs';s=p.read_text()
 marker='        let setup_started = Instant::now();'
 assert s.count(marker)==1
 s=s.replace(marker,'''        static DEVELOPMENT_MAP_CALL: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
        let development_call = DEVELOPMENT_MAP_CALL.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let development_original = values.clone();
        eprintln!("FEREG_MAP_PROBE|begin|call={}|rows={}|rhs={}|tolerance={:.17e}|limit={}", development_call, values.nrows(), rhs, config.tolerance, config.max_iterations);
''' + marker,1)
 marker='        if initial.passed {';start=s.index('        let mut geometry_valid = false;');i=s.index(marker,start)
 s=s[:i]+'''        eprintln!("FEREG_MAP_PROBE|check|call={}|iteration=0|two={:.17e}|infinity={:.17e}|passed={}", development_call, initial.relative_two_norm, initial.relative_infinity_norm, initial.passed);
'''+s[i:]
 marker='                if certificate.passed {';i=s.index(marker,start)
 s=s[:i]+'''                if iteration.is_power_of_two() || iteration == config.max_iterations || certificate.passed {
                    eprintln!("FEREG_MAP_PROBE|check|call={}|iteration={}|two={:.17e}|infinity={:.17e}|passed={}", development_call, iteration, certificate.relative_two_norm, certificate.relative_infinity_norm, certificate.passed);
                }
'''+s[i:]
 marker='        Err(FeregError::new(\n            ErrorCode::InvalidData,\n            "reusable MAP exhausted'
 assert s.count(marker)==1
 s=s.replace(marker,'''        development_capture_map(development_call, &self.design, weights, &development_original, &values, config);
'''+marker,1)
 s+='''
// Isolated diagnostic only: dump the actual failing weight/RHS frame.
fn development_capture_map(call: usize, design: &FeDesign, weights: &[f64], original: &DenseMatrix, residuals: &DenseMatrix, config: MapConfig) {
    use std::io::Write;
    let root = std::env::var("FEREG_CAPTURE_MAP_DIR").expect("diagnostic capture directory");
    let root = std::path::Path::new(&root).join(format!("map-{call}"));
    std::fs::create_dir_all(&root).unwrap();
    let mut meta = std::fs::File::create(root.join("frame.json")).unwrap();
    let levels: Vec<_> = design.effects().iter().map(|e| e.n_levels()).collect();
    let channels: Vec<_> = design.effects().iter().map(|e| e.channels()).collect();
    let intercepts: Vec<_> = design.effects().iter().map(|e| e.has_intercept()).collect();
    writeln!(meta, "{{\\"call\\":{},\\"rows\\":{},\\"rhs\\":{},\\"levels\\":{:?},\\"channels\\":{:?},\\"intercepts\\":{:?},\\"tolerance\\":{:.17e},\\"iterations\\":{}}}", call, design.nobs(), original.ncols(), levels, channels, intercepts, config.tolerance, config.max_iterations).unwrap();
    let mut data = std::io::BufWriter::new(std::fs::File::create(root.join("frame.csv")).unwrap());
    for row in 0..design.nobs() {
        write!(data, "{:.17e}", weights[row]).unwrap();
        for matrix in [original, residuals] { for column in 0..matrix.ncols() {
            write!(data, ",{:.17e}", matrix[(row,column)]).unwrap();
        }}
        for effect in design.effects() {
            write!(data, ",{}", effect.codes()[row]).unwrap();
            for slope in effect.slopes() { write!(data, ",{:.17e}", slope[row]).unwrap(); }
        }
        writeln!(data).unwrap();
    }
    eprintln!("FEREG_MAP_PROBE|captured|call={}", call);
}
'''
 p.write_text(s)

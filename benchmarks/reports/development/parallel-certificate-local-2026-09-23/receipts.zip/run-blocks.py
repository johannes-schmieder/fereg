import subprocess
from pathlib import Path
r=Path('target/parallel-certificate-20260923');py='target/one-fe-profile-20260919/python/bin/python'
for label,cells,seed,variants,surface,repeats,trace in [
 ('fresh','fresh',202609278,['certcache3','parcert1','fixest'],True,3,False),
 ('weak-native','weak-native',202609279,['certcache3','parcert1'],True,3,False),
 ('controls','control',202609280,['certcache3','parcert1'],False,3,False),
 ('pilot','pilot',202609281,['certcache3','parcert1','fixest'],True,1,False),
 ('native-profile','pair',202609282,['certcache_profile','parcert_profile'],True,1,True),
]:
 command=[py,'benchmarks/next_subsystem/run.py',str(r/label),'--artifacts','target/ppml-next-20260922/artifacts','--variants',*variants,'--fixest-archive','target/one-fe-profile-20260919/fixest.tar.gz','--cells',str(r/f'{cells}-cells.json'),'--seed',str(seed),'--repeats',str(repeats)]
 if surface:command+=['--surface']
 if trace:command+=['--trace']
 print('START',label,flush=True)
 with (r/f'{label}-driver.log').open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)

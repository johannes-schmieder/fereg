from pathlib import Path
p=Path('crates/fereg-core/src/fe/certificate.rs');s=p.read_text();pos=s.index('    #[test]\n    fn scoped_geometry_is_exact')
t='''    #[test]
    fn parallel_groups_match_serial_bits_and_independent_weighted_two_column_projection() {
        let n = 84;
        let z: Vec<_> = (0..n).map(|r| (r / 7) as f64 - 5.5).collect();
        let design = FeDesign::new(n, vec![EffectTerm::new(
            (0..n).map(|r| (r % 7) as u32).collect(), 8, true,
            vec![z.clone(), z.clone(), vec![0.0; n]],
        ).unwrap()]).unwrap();
        for weights in [vec![1.0; n], (0..n).map(|r| 0.5 + (r % 5) as f64).collect()] {
            let mut values = DenseMatrix::zeros(n, 7).unwrap();
            for r in 0..n { for c in 0..7 { values[(r,c)] = ((r * 13 + c * 7) as f64).sin(); }}
            let reference = weighted_column_norms(&values, &weights).unwrap();
            let serial = certify_residuals_with_reference_norms(&design, &weights, &values, &reference, 1e-8).unwrap();
            let mut expected_inf = 0.0_f64;
            let mut expected_square_sum = 0.0;
            for level in 0..8 { for rhs in 0..7 {
                let mut sw = 0.0; let mut sz = 0.0; let mut szz = 0.0;
                let mut sr = 0.0; let mut szr = 0.0;
                for r in (level..n).step_by(7).filter(|_| level < 7) {
                    sw += weights[r]; sz += weights[r]*z[r]; szz += weights[r]*z[r]*z[r];
                    sr += weights[r]*values[(r,rhs)]; szr += weights[r]*z[r]*values[(r,rhs)];
                }
                let ratio = if sw == 0.0 { 0.0 } else {
                    ((szz*sr*sr - 2.0*sz*sr*szr + sw*szr*szr) / (sw*szz-sz*sz)).sqrt() / reference[rhs]
                };
                expected_inf = expected_inf.max(ratio); expected_square_sum += ratio*ratio;
            }}
            assert!((serial.relative_infinity_norm-expected_inf).abs() < 1e-14);
            assert!((serial.relative_two_norm-(expected_square_sum/56.0).sqrt()).abs() < 1e-14);
            for threads in [1,2,4,8] {
                rayon::ThreadPoolBuilder::new().num_threads(threads).build().unwrap().install(|| {
                    let mut context = CertificateContext::new(&design, &weights);
                    context.cache().unwrap();
                    // Exercise the kernel below its production scheduling floor.
                    context.set_parallel_rhs(7);
                    for _ in 0..3 {
                        assert_eq!(context.certify(&values, &reference, 1e-8).unwrap(), serial);
                    }
                    context.clear();
                    assert_eq!(context.parallel_rhs, 0);
                });
            }
        }
    }

'''
s=s[:pos]+t+s[pos:];p.write_text(s)
p=Path('crates/fereg-core/src/fe/auto.rs');s=p.read_text();pos=s.index('    #[test]\n    fn generic_auto_enforces_joint_budget')
t='''    #[test]
    fn parallel_certificate_exact_budget_keeps_the_serial_cache_when_scratch_does_not_fit() {
        rayon::ThreadPoolBuilder::new().num_threads(4).build().unwrap().install(|| {
            let n = 48 * 342;
            let left: Vec<_> = (0..n).map(|r| (r % 4) as u32).collect();
            let right: Vec<_> = (0..n).map(|r| ((r/4)%3) as u32).collect();
            let slope: Vec<_> = (0..n).map(|r| ((r/12)%4) as f64 - 1.5).collect();
            let outcome: Vec<_> = (0..n).map(|r| 2.0*left[r] as f64 + 3.0*right[r] as f64*slope[r] + [1.0,-1.0,-1.0,1.0][(r/12)%4]).collect();
            let design = FeDesign::new(n, vec![EffectTerm::new(left, 4, true, vec![]).unwrap(), EffectTerm::new(right, 3, false, vec![slope]).unwrap()]).unwrap();
            let weights = vec![1.0; n];
            let config = AbsorbConfig::default();
            let required = generic_fe_solver_bytes(&design, 1, FeSolverKind::Map, config.lsmr).unwrap();
            let mut context = CertificateContext::new(&design, &weights);
            context.cache().unwrap();
            let cached = required + context.cache_bytes().unwrap();
            let parallel = context.parallel_workspace_bytes(1).unwrap();
            assert_eq!(parallel, 4*2*8);
            let mut reference = None;
            for budget in [cached, cached + parallel - 1, cached + parallel] {
                let mut values = DenseMatrix::from_columns(&[outcome.clone()]).unwrap();
                let report = absorb_fixed_effects(&design, &weights, &mut values, AbsorbConfig {
                    solver_memory_budget: Some(FeSolverMemoryBudget { execution_bytes: 137, usable_bytes: 137+budget }), ..config
                }).unwrap();
                assert_eq!(report.used_solver, FeSolverKind::Map);
                assert_eq!(report.solver_workspace_peak.bytes(), Some(if budget < cached+parallel { cached } else { cached+parallel } as u64));
                let result = (values, report.certificate, report.iterations, report.pilot_contraction);
                if let Some(previous) = &reference { assert_eq!(&result, previous); }
                reference = Some(result);
            }
        });
    }

'''
s=s[:pos]+t+s[pos:];p.write_text(s)

from pathlib import Path
p=Path('crates/fereg-core/src/fe/certificate.rs');s=p.read_text();s='use rayon::prelude::*;\n'+s
s=s.replace('tolerance, None)\n}', 'tolerance, None, false)\n}',1)
s=s.replace('    cached_bases: Option<&[Vec<Vec<f64>>]>,\n)', '    cached_bases: Option<&[Vec<Vec<f64>>]>,\n    parallel: bool,\n)',1)
needle='    let mut absolute_infinity_norm = 0.0_f64;'
insert='''    if parallel {
        if let Some(bases) = cached_bases {
            let groups = design.effects().iter().map(|effect| effect.n_levels()).max().unwrap_or(0);
            let cells = residuals.ncols().checked_add(1).and_then(|width| groups.checked_mul(width));
            if let Some(cells) = cells {
                // Parallelism is optional. A failed scratch reservation retains
                // the already admitted serial certificate and its check order.
                if let Ok(mut scratch) = fallible_filled(cells, 0.0, "unable to reserve parallel certificate results") {
                    return certify_parallel_groups(design, weights, residuals, &rhs_scales, tolerance, bases, &mut scratch);
                }
            }
        }
    }

''';s=s.replace(needle,insert+needle,1)
a=s.index('                let denominator = rhs_scales[rhs];');b=s.index('                if !relative.is_finite()',a)
old=s[a:b];s=s[:a]+'''                let relative = relative_projection(observations, orthonormal_basis, weights, residuals, rhs, rhs_scales[rhs]);
'''+s[b:]
code=old.replace('                let denominator = rhs_scales[rhs];\n','').replace('                let relative = projected_square_norm.sqrt();','                projected_square_norm.sqrt()');code='\n'.join(line[12:] if line.startswith('            ') else line for line in code.splitlines())
helper='''fn relative_projection(observations: &[usize], orthonormal_basis: &[Vec<f64>], weights: &[f64], residuals: &DenseMatrix, rhs: usize, denominator: f64) -> f64 {
'''+code+'\n}\n\n'+'''/// Independent groups write disjoint slots; the caller merges every RHS in
/// the original effect/level/RHS order, including the RMS FMA recurrence.
fn certify_parallel_groups(
    design: &FeDesign, weights: &[f64], residuals: &DenseMatrix, rhs_scales: &[f64],
    tolerance: f64, bases: &[Vec<Vec<f64>>], scratch: &mut [f64],
) -> Result<FeCertificate> {
    let rhs_count = residuals.ncols();
    let width = rhs_count + 1;
    let mut group = 0;
    let mut absolute_infinity_norm = 0.0_f64;
    let mut relative_infinity_norm = 0.0_f64;
    let mut relative_square_sum = 0.0_f64;
    let mut relative_count = 0;
    for effect in design.effects() {
        let results = &mut scratch[..effect.n_levels() * width];
        results.par_chunks_mut(width).enumerate().for_each(|(level, output)| {
            let observations = effect.level_index().members(level);
            for rhs in 0..rhs_count {
                output[rhs] = relative_projection(observations, &bases[group + level], weights, residuals, rhs, rhs_scales[rhs]);
            }
            output[rhs_count] = raw_moment_maximum(observations, effect, weights, residuals);
        });
        for output in results.chunks_exact(width) {
            for &relative in &output[..rhs_count] {
                if !relative.is_finite() {
                    return Err(FeregError::new(ErrorCode::InvalidData, "fixed-effect projection certificate is not finite"));
                }
                relative_infinity_norm = relative_infinity_norm.max(relative);
                relative_square_sum = relative.mul_add(relative, relative_square_sum);
                relative_count += 1;
            }
            absolute_infinity_norm = absolute_infinity_norm.max(output[rhs_count]);
        }
        group += effect.n_levels();
    }
    Ok(FeCertificate {
        absolute_infinity_norm,
        relative_infinity_norm,
        relative_two_norm: if relative_count == 0 { 0.0 } else { (relative_square_sum / relative_count as f64).sqrt() },
        passed: relative_infinity_norm <= tolerance,
    })
}

'''
pos=s.index('/// One absorption call');s=s[:pos]+helper+s[pos:]
s=s.replace('    bases: Option<Vec<Vec<Vec<f64>>>>,','    bases: Option<Vec<Vec<Vec<f64>>>>,\n    parallel_rhs: usize,',1).replace('            bases: None,','            bases: None,\n            parallel_rhs: 0,',1)
needle='    pub(super) fn clear(&mut self) {\n        self.bases = None;'
s=s.replace(needle,'''    /// Additional scratch for ordered results from one effect at a time.
    /// Only an already installed team may evaluate immutable native inputs.
    pub(super) fn parallel_workspace_bytes(&self, rhs: usize) -> Result<u128> {
        if self.bases.is_none() || rhs == 0 || self.design.nobs() < 16_384
            || rayon::current_thread_index().is_none() || rayon::current_num_threads() <= 1 {
            return Ok(0);
        }
        let levels = self.design.effects().iter().map(|e| e.n_levels()).max().unwrap_or(0);
        (rhs as u128).checked_add(1).and_then(|r| r.checked_mul(levels as u128))
            .and_then(|cells| cells.checked_mul(8)).ok_or_else(||
                FeregError::new(ErrorCode::Allocation, "parallel certificate workspace overflows"))
    }

    /// Caller admits the workspace before enabling any parallel certificate.
    pub(super) fn set_parallel_rhs(&mut self, rhs: usize) { self.parallel_rhs = rhs; }

    pub(super) fn clear(&mut self) {
        self.parallel_rhs = 0;
        self.bases = None;''',1)
s=s.replace('            self.bases.as_deref(),\n', '            self.bases.as_deref(),\n            residuals.ncols() > 0 && residuals.ncols() <= self.parallel_rhs,\n',1)
p.write_text(s)
p=Path('crates/fereg-core/src/fe/auto.rs');s=p.read_text();needle='    let cache_seconds = cache_started.elapsed().as_secs_f64();'
s=s.replace(needle,'''    let mut parallel_bytes = 0;
    if let Ok(bytes) = context.parallel_workspace_bytes(values.ncols()) {
        if bytes > 0 {
            if let Ok(peak) = attempted_peak.with_retained(bytes) {
                if config.solver_memory_budget.map_or(true, |budget| budget.fits(peak.bytes().unwrap() as u128)) {
                    context.set_parallel_rhs(values.ncols());
                    parallel_bytes = bytes;
                    attempted_peak = peak;
                }
            }
        }
    }
'''+needle,1)
s=s.replace('        context.clear();\n        retained = 0;', '        context.clear();\n        retained = 0;\n        parallel_bytes = 0;',1)
needle='''        attempted_peak = attempted_peak.max(cached_peak);
    } else {
        context.clear();'''
s=s.replace(needle,'''        if let Some(parallel_peak) = cached_peak.with_retained(parallel_bytes).ok().filter(|peak| {
            config.solver_memory_budget.map_or(true, |budget| budget.fits(peak.bytes().unwrap() as u128))
        }) {
            attempted_peak = attempted_peak.max(parallel_peak);
        } else {
            context.set_parallel_rhs(0);
            attempted_peak = attempted_peak.max(cached_peak);
        }
    } else {
        context.clear();''',1)
p.write_text(s)

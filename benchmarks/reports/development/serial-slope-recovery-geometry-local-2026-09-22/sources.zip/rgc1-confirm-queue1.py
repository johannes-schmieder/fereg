import subprocess,sys
from pathlib import Path
art=Path(__file__).resolve().parent
for block in [1,2]:
 with (art/f'rgc1-confirm{block}.txt').open('x') as stream:
  result=subprocess.run([sys.executable,str(art/'rgc1-confirm1.py'),str(block)],stdout=stream,stderr=subprocess.STDOUT)
 print(block,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)

import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo = Path(__file__).resolve().parents[2]; art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science
out = repo / 'benchmarks/reports/development/serial-slope-data-passes-local-2026-09-22'
progress_names = ['st1-screen-progress1.json', 'rn1-screen-progress1.json', 'rn1-confirm1-progress1.json', 'rn1-confirm2-progress1.json']
roots = [art / r['root'] for name in progress_names for r in json.loads((art / name).read_text())]
profile_roots = [art / f'ssdiag1-profile-{label}-1' for label in ['aw-k10', 'pw-k6']]
profile_roots += [art / f'rn1-profile-{label}-1' for label in ['aw-k10', 'pw-k6', 'aw-k50']]
roots += profile_roots
archive_science.archive(roots, out, compact=True, omit_output_arrays=True)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>').replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')
tables = {'sources': {}, 'checks': {}}
with zipfile.ZipFile(out / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['owf1', 'ssdiag1', 'st1', 'rn1']:
        p = art / f'identity-{variant}.json'; identity = json.loads(p.read_text()); add(p.name, p.read_bytes())
        raw = subprocess.check_output(['git', 'archive', identity['base_commit'], 'Cargo.toml', 'Cargo.lock', 'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as tree:
            base = {e.name: sha(tree.extractfile(e).read()) for e in tree.getmembers() if e.isfile()}
        for relative, digest in identity['source'].items():
            raw = (art / variant / relative).read_bytes(); assert sha(raw) == digest
            if base.get(relative) != digest: add(variant + '/' + relative, raw)
    for name in ['st1-tests1.py', 'st1-screen1.py', 'audit-st1-screen1.py',
        'rn1-tests1.py', 'rn1-screen1.py', 'audit-rn1-screen1.py', 'rn1-confirm1.py',
        'rn1-confirm-queue1.py', 'audit-rn1-confirm1.py', 'ssdiag1-profile1.py',
        'audit-ssdiag1-profile1.py', 'rn1-profile1.py', 'audit-rn1-profiles1.py', 'archive-slope-passes1.py']:
        add(name, (art / name).read_bytes())
    for relative in ['one_fe_optimization/build.py', 'one_fe_optimization/prepare_profile.py', 'one_fe_optimization/completion_profile.py', 'one_fe_breadth/profile.py', 'one_fe_profile/slope_instrument.py', 'one_fe_profile/inference_instrument.py', 'one_fe_profile/recovery_instrument.py',
        'one_fe_profile/slopes.py', 'one_fe_profile/slope_breadth.py', 'one_fe_profile/run.py', 'one_fe_breadth/run.py',
        'systematic/generate.py', 'two_fe_dense/route_development.py', 'two_fe_dense/archive_science.py',
        *['local_fixest_gap/' + name for name in ['common.py', 'measure.py', 'r_worker.R', 'stata_worker.do']]]:
        add(relative, (repo / 'benchmarks' / relative).read_bytes())
with zipfile.ZipFile(out / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add_check(name, raw, **extra):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean), **extra)
    for p in sorted([*art.glob('st1-*'), *art.glob('rn1-*'), *art.glob('ssdiag1-*')]):
        if p.is_file() and p.suffix in ['.json', '.txt'] and 'archive' not in p.name:
            add_check(p.name, p.read_bytes())
    for name, relative in [('build-st1.log', 'st1-build-root/build-st1.log'), ('build-rn1.log', 'build-rn1.log'), ('build-ssdiag1.log', 'build-ssdiag1.log')]:
        add_check(name, (art / relative).read_bytes())
    for root in profile_roots:
        for p in sorted((root / 'runs').glob('*/stderr.txt')):
            raw = p.read_bytes()
            filtered = ('\n'.join(line for line in raw.decode().splitlines() if line.startswith(('FEREG_PHASE|', 'SLOPE_PROFILE|'))) + '\n').encode()
            add_check(root.name + '/' + p.parent.name + '/native-trace.txt', filtered, original_stream_sha256=sha(raw))
for kind, table in tables.items(): (out / (kind + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')
template = (repo / 'benchmarks/reports/development/cycle-routing-validation-local-2026-09-22/verify.py').read_text()
template = template.replace("['owf1', 'cy2']", "['owf1', 'ssdiag1', 'st1', 'rn1']")
start = template.index("with zipfile.ZipFile(folder / 'checks.zip') as bundle:", template.index('known_sources ='))
end = template.index('\nreceipt =', start)
checks = """with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    hashes = json.loads((folder / 'checks-hashes.json').read_text())
    for variant, count in [('st1', 5), ('rn1', 4)]:
        tests = json.loads(bundle.read(f'{variant}-tests1.json'))
        assert tests['controller_sha256'] in known_sources
        assert tests['identity_sha256'] == source_hashes[f'identity-{variant}.json']['original_sha256']
        assert tests['status'] == 'pass' and len(tests['tests']) == count
        for test in tests['tests']:
            assert test['passed'] and test['returncode'] == 0
            assert test['log_sha256'] == hashes[test['log']]['original_sha256']
    for label, count in [('st1-screen', 8), ('rn1-screen', 8), ('rn1-confirm1', 7), ('rn1-confirm2', 7)]:
        audit = json.loads(bundle.read(f'{label}-audit1.json'))
        assert audit['source_sha256'] in known_sources
        assert len(audit['records']) == count
        assert all(r['isolation'] == 'no_detected_overlap' for r in audit['records'])
        assert audit['progress_sha256'] == hashes[f'{label}-progress1.json']['original_sha256']
        assert all(all(p['exact_exports'].values()) for r in audit['records'] for p in r['pairs'])
    profile = json.loads(bundle.read('ssdiag1-profile-audit1.json'))
    assert profile['status'] == 'pass' and len(profile['records']) == 4
    assert profile['source_sha256'] in known_sources
    profile = json.loads(bundle.read('rn1-profile-check1.json'))
    assert profile['status'] == 'pass' and len(profile['records']) == 3
    assert profile['source_sha256'] in known_sources
"""
template = template[:start] + checks + template[end:]
template = template.replace('cycle-routing-validation-archive-integrity-v1', 'slope-data-passes-archive-integrity-v1').replace('CYCLE_ROUTING_VALIDATION_ARCHIVE_INTEGRITY_PASS', 'SLOPE_DATA_PASSES_ARCHIVE_INTEGRITY_PASS').replace("folder / 'integrity2.json'", "folder / 'integrity.json'")
(out / 'verify.py').write_text(template)
rows = []
for label, baseline, candidate in [('st1-screen', 'owf1', 'st1'), ('rn1-screen', 'st1', 'rn1'), ('rn1-confirm1', 'owf1', 'rn1'), ('rn1-confirm2', 'owf1', 'rn1')]:
    audit = json.loads((art / f'{label}-audit1.json').read_text())
    for r in audit['records']:
        c = r['cell']; seconds = r['median_seconds']
        rows.append(f"| {label} | {c['weight_kind']} | {c['k']} | {c['threads']} | {c['case']} | {seconds[baseline]:.3f} | {seconds[candidate]:.3f} | {seconds.get('fixest', 'native only')} | {r['median_native_ratio']:.4f} |")
(out / 'timings.md').write_text('| Block | Weight | K | T | Case | Prior seconds | Draft seconds | fixest seconds | Paired draft/prior |\n|---|---|---:|---:|---|---:|---:|---|---:|\n' + '\n'.join(rows) + '\n')
print('SLOPE_DATA_PASSES_ARCHIVE_PREPARED')

import hashlib, json
from pathlib import Path

art = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
records = []
for label in ['aw-k10', 'pw-k6']:
    root = art / f'ssdiag1-profile-{label}-1'
    plan = json.loads((root / 'plan.json').read_text())
    complete = json.loads((root / 'complete.json').read_text())
    assert complete['status'] == 'pass'
    for index, cell in enumerate(plan['cells']):
        runs = {v: root / 'runs' / f'c{index:03d}-r0-{v}' for v in plan['variants']}
        results = {v: json.loads((p / 'result.json').read_text()) for v, p in runs.items()}
        assert all(r['status'] == 'pass' and r['sentinel'] and r['process_returncode'] == 0 for r in results.values())
        assert len({r['input_sha256'] for r in results.values()}) == 1
        assert len({r['sample_sha256'] for r in results.values()}) == 1
        for v in ['owf1', 'ssdiag1']:
            assert results[v]['measurement_fingerprint']['native'] == json.loads((art / f'identity-{v}.json').read_text())
        exact = {name: sha(runs['owf1'] / name) == sha(runs['ssdiag1'] / name)
            for name in ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv', 'outputs.bin']}
        assert all(exact.values()), exact
        phases = {}
        for line in (runs['ssdiag1'] / 'stderr.txt').read_text().splitlines():
            if line.startswith(('FEREG_PHASE|', 'SLOPE_PROFILE|')):
                parts = line.split('|')
                phases[parts[0] + '/' + parts[1]] = dict(p.split('=', 1) for p in parts[2:])
        reference = json.loads((runs['fixest'] / 'profile.json').read_text())
        records.append(dict(root=root.name, cell=cell, exact=exact, phases=phases, reference=reference,
            diagnostic_seconds={v: r['seconds'] for v, r in results.items()},
            result_sha256={v: sha(p / 'result.json') for v, p in runs.items()},
            stderr_sha256=sha(runs['ssdiag1'] / 'stderr.txt'),
            reference_profile_sha256=sha(runs['fixest'] / 'profile.json')))
out = art / 'ssdiag1-profile-audit1.json'
assert not out.exists()
out.write_text(json.dumps(dict(schema='serial-weighted-slope-full-profile-v1', status='pass',
    source_sha256=sha(Path(__file__)), records=records,
    limitation='Single instrumented diagnostic calls; not headline timing evidence.'), indent=2) + '\n')
print('SERIAL_WEIGHTED_SLOPE_FULL_PROFILE_PASS', len(records))

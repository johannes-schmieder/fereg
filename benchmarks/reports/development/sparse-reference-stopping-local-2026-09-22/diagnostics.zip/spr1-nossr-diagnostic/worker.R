args <- commandArgs(trailingOnly = TRUE)
suppressPackageStartupMessages(library(fixest))

suppressPackageStartupMessages(library(jsonlite))
suppressPackageStartupMessages(library(digest))
c <- fromJSON(args[[1]], simplifyVector = TRUE)
cell <- c$cell
output <- c$output
setFixest_nthreads(cell$threads)
read_input <- function(path) {
    meta <- fromJSON(sub("\\.dta$", ".json", path))
    con <- file(sub("\\.dta$", ".bin", path), "rb")
    on.exit(close(con))
    cols <- lapply(meta$columns, function(name) readBin(con, "double", n=meta$n, size=8, endian="little"))
    names(cols) <- meta$columns
    as.data.frame(cols)
}
formula <- as.formula(paste("y ~", if (cell$k == 0) "1" else paste(paste0("x", seq_len(cell$k)), collapse=" + "),
                            "|", paste(cell$effects, collapse=" + ")))
fit_model <- function(data) {
    if (cell$model == "ols") {
        if (cell$weight_kind == "none") {
feols(formula, data=data, demeaned=TRUE, nthreads=cell$threads, fixef.tol=cell$fixest_tolerance, vcov=if (startsWith(cell$r_vce, "~")) as.formula(cell$r_vce) else cell$r_vce,
              ssc=ssc(K.adj=TRUE, K.fixef=cell$reference_fixef_dof, K.exact=isTRUE(cell$exact_dof), G.adj=TRUE, G.df="min", t.df="min"), notes=FALSE)
} else {
feols(formula, data=data, demeaned=TRUE, weights=~w, nthreads=cell$threads, fixef.tol=cell$fixest_tolerance, vcov=if (startsWith(cell$r_vce, "~")) as.formula(cell$r_vce) else cell$r_vce,
              ssc=ssc(K.adj=TRUE, K.fixef=cell$reference_fixef_dof, K.exact=isTRUE(cell$exact_dof), G.adj=TRUE, G.df="min", t.df="min"), notes=FALSE)
}
    } else {
        fepois(formula, data=data, nthreads=cell$threads, vcov="hetero", ssc=ssc(K.adj=FALSE), notes=FALSE)
    }
}
recover_outputs <- function(fit, data) {
    if (is.null(fit) || cell$outputs == "none") return(NULL)
    effects <- fixef(fit, sorted=FALSE, notes=FALSE, fixef.tol=cell$fixest_recovery_tolerance)
    left <- unname(effects$g1[fit$fixef_id$g1])
    if (length(cell$effects) == 1) {
        intercept <- if (cell$weight_kind == "none") mean(left) else weighted.mean(left, data$w[obs(fit)])
        saved_outputs <- list(left - intercept)
        if (cell$outputs == "all") saved_outputs <- c(saved_outputs,
            list(resid(fit), fitted(fit) - left + intercept, fitted(fit)))
        return(saved_outputs)
    }
    right <- unname(effects$g2[fit$fixef_id$g2])
    contribution <- left + right
    component <- as.integer(data$component[obs(fit)])
    if (cell$weight_kind == "none") {
        intercept <- mean(contribution)
        centers <- as.vector(rowsum(right, component, reorder=FALSE)) /
                   as.vector(rowsum(rep(1, length(right)), component, reorder=FALSE))
    } else {
        weight <- data$w[obs(fit)]
        intercept <- weighted.mean(contribution, weight)
        centers <- as.vector(rowsum(weight * right, component, reorder=FALSE)) /
                   as.vector(rowsum(weight, component, reorder=FALSE))
    }
    centers <- centers[match(component, unique(component))]
    saved_outputs <- list(left + centers - intercept, right - centers)
    if (cell$outputs == "all") {
        residual <- resid(fit)
        prediction <- fitted(fit)
        finite <- prediction - contribution + intercept
        saved_outputs <- c(saved_outputs, list(residual, finite, prediction))
    }
    saved_outputs
}

data <- read_input(c$data)
info <- fromJSON(sub("\\.dta$", ".json", c$data))
for (name in names(info$column_sha256)) stopifnot(digest(writeBin(as.double(data[[name]]), raw(), size=8, endian="little"), algo="sha256", serialize=FALSE)==info$column_sha256[[name]])
fit <- fit_model(data)
saved <- recover_outputs(fit,data)
write_values <- function(name, values) {
 con <- file(file.path(output,paste0(name,".bin")),"wb")
 writeBin(as.double(values),con,size=8,endian="little"); close(con)
}
write_values("outputs",unlist(saved))
write_values("demeaned",c(fit$y_demeaned,fit$X_demeaned))
write_values("sumFE",fit$sumFE)
write_values("beta",coef(fit)); write_values("covariance",vcov(fit))
write_json(list(iterations=fit$iterations, diagnostic_exit=fit$diagnostic_exit, convStatus=fit$convStatus, message=fit$message,
 nparams=fit$nparams, df_K=attr(vcov(fit,attr=TRUE),"df.K"),
 fixef_sizes=fit$fixef_sizes, fixef_alg=fit$fixef.algo,
 reference_binary_sha256=digest(file=file.path(find.package("fixest"),"libs/fixest.so"),algo="sha256")),
 file.path(output,"diagnostic.json"), pretty=TRUE,auto_unbox=TRUE,digits=NA)
cat("SPARSE_REFERENCE_DIAGNOSTIC_COMPLETE\n")

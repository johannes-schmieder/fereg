import hashlib,json,os,subprocess
from pathlib import Path
repo=Path.cwd(); art=repo/'target/ols-next-20260921'; stock=art/'spr1-stock-diagnostic'; clone=art/'spr1-fixest-diagnostic2'
worker=(stock/'worker.R').read_text().replace('list(iterations=fit$iterations, convStatus=', 'list(iterations=fit$iterations, diagnostic_exit=fit$diagnostic_exit, convStatus=')
records=[]
for mode,disable in [('trace','0'),('nossr','1')]:
    root=art/f'spr1-{mode}-diagnostic'; root.mkdir(exist_ok=False); (root/'worker.R').write_text(worker)
    env=os.environ.copy(); env.update(R_LIBS_USER=str(clone/'R')+':<reference-library>',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',FEREG_DIAGNOSTIC_DISABLE_FIXEST_SSR=disable)
    for index in [704,722,737,773,791,806]:
        request=json.loads((stock/str(index)/'request.json').read_text()); folder=root/str(index); folder.mkdir()
        request['output']=str(folder); p=folder/'request.json'; p.write_text(json.dumps(request,indent=2)+'\n')
        with (folder/'stdout.txt').open('w') as log:
            result=subprocess.run(['/opt/homebrew/bin/Rscript',str(root/'worker.R'),str(p)],env=env,stdout=log,stderr=subprocess.STDOUT)
        records.append(dict(mode=mode,index=index,returncode=result.returncode,disable_ssr=disable))
        print(mode,index,result.returncode,flush=True)
        if result.returncode: raise SystemExit(result.returncode)
(art/'spr1-experiment-complete.json').write_text(json.dumps(dict(status='completed',records=records,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')

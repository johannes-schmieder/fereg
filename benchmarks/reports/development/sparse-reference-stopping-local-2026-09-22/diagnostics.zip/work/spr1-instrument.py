import difflib, hashlib, json, tarfile
from pathlib import Path
repo=Path.cwd(); art=repo/'target/ols-next-20260921'; root=art/'spr1-fixest-diagnostic'; root.mkdir(exist_ok=False)
archive=repo/'target/one-fe-profile-20260919/fixest.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='17372a789aaf9a3b04e8e0324feaf0f3c3c16f517baeb75e46289340332f0ee9'
with tarfile.open(archive) as tar: tar.extractall(root,filter='data')
source=root/'fixest'; hashes={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}
def edit(relative, changes):
    p=source/relative; before=p.read_text(); after=before
    for old,new in changes:
        assert after.count(old)==1,(relative,old,after.count(old))
        after=after.replace(old,new)
    p.write_text(after)
    (root/(relative.replace('/','-')+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
edit('src/demeaning.cpp',[
 ('struct PARAM_DEMEAN{','struct PARAM_DEMEAN{\n  bool diagnostic_disable_ssr;\n  int *diagnostic_exit;'),
 ('  int iter = 0;\n  bool numconv = false;', '  int iter = 0;\n  bool numconv = false;\n  int diagnostic_exit = 0;'),
 ('    if(numconv) break;\n    \n    if(iter >=', '    if(numconv){ diagnostic_exit = 2; break; }\n    \n    if(iter >='),
 ('        if(numconv) break;\n        compute_fe', '        if(numconv){ diagnostic_exit = 3; break; }\n        compute_fe'),
 ('      if(stopping_crit(ssr_old, ssr, diffMax)){\n        break;', '      if(!args->diagnostic_disable_ssr && stopping_crit(ssr_old, ssr, diffMax)){\n        diagnostic_exit = 1;\n        break;'),
 ('  bool conv = iter == iterMax ? false : true;', '  if(diagnostic_exit == 0) diagnostic_exit = *pStopNow ? 4 : (iter == iterMax ? 5 : 6);\n  args->diagnostic_exit[v] = diagnostic_exit;\n  bool conv = iter == iterMax ? false : true;'),
 ('  int *p_iterations_all = iterations_all.data();', '  int *p_iterations_all = iterations_all.data();\n  vector<int> diagnostic_exit(n_vars, 0);'),
 ('  PARAM_DEMEAN args;','  PARAM_DEMEAN args;\n  args.diagnostic_exit = diagnostic_exit.data();\n  const char *diagnostic_mode = std::getenv("FEREG_DIAGNOSTIC_DISABLE_FIXEST_SSR");\n  args.diagnostic_disable_ssr = diagnostic_mode && std::string(diagnostic_mode) == "1";'),
 ('  res["iterations"] = iter_final;', '  res["iterations"] = iter_final;\n  res["diagnostic_exit"] = diagnostic_exit;')])
edit('R/estimation.R', [('    res$iterations = vars_demean$iterations', '    res$diagnostic_exit = vars_demean$diagnostic_exit\n    res$iterations = vars_demean$iterations')])
edit('src/Makevars', [('PKG_CXXFLAGS = ', 'PKG_CXXFLAGS = -I/opt/homebrew/opt/libomp/include -Xclang -fopenmp '),('PKG_LIBS = ', 'PKG_LIBS = -L/opt/homebrew/opt/libomp/lib -lomp ')])
(root/'source-identity.json').write_text(json.dumps(dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),original_files=hashes,diagnostic_files={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()},diagnostic_only=True,exit_reasons={1:'SSR-change',2:'zero-acceleration-denominator',3:'zero-grand-acceleration-denominator',4:'interruption',5:'iteration-limit',6:'coefficient-step'}),indent=2)+'\n')
(root/'R').mkdir()

import hashlib,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.linalg import lstsq,solve
repo=Path.cwd(); art=repo/'target/ols-next-20260921'; root=art/'spr1-current'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for index in [704,722,737,773,791,806]:
    native=next((root/'runs').glob(f'current-{index}-*-dtk1'))
    stock=next((root/'runs').glob(f'current-{index}-*-fixest'))
    request=json.loads((stock/'request.json').read_text()); cell=request['cell']; n=cell['n']; k=cell['k']
    datap=Path(request['data']); meta=json.loads(datap.with_suffix('.json').read_text())
    raw=np.fromfile(datap.with_suffix('.bin'),dtype='<f8').reshape(len(meta['columns']),n)
    data=dict(zip(meta['columns'],raw))
    assert all(hashlib.sha256(data[c].tobytes()).hexdigest()==h for c,h in meta['column_sha256'].items())
    X=np.column_stack([data[f'x{i+1}'] for i in range(k)]); y=data['y']; w=data.get('w',np.ones(n)); w=w*n/w.sum()
    _,left=np.unique(data['g1'],return_inverse=True); _,right=np.unique(data['g2'],return_inverse=True)
    l=left.max()+1; r=right.max()+1; components=np.unique(data['component'])
    D=np.zeros((n,l+r)); D[np.arange(n),left]=1; D[np.arange(n),l+right]=1
    keep=np.ones(l+r,dtype=bool)
    for comp in components: keep[l+min(right[data['component']==comp])]=False
    Z=np.column_stack([X,D[:,keep]]); weighted=Z*np.sqrt(w[:,None])
    coeff,_,rank,_=lstsq(weighted,y*np.sqrt(w),lapack_driver='gelsy')
    assert rank==k+l+r-len(components)
    beta=coeff[:k]; effects=np.zeros(l+r); effects[keep]=coeff[k:]
    a=effects[left]; b=effects[l+right]; intercept=np.average(a+b,weights=w)
    for comp in components:
        active=data['component']==comp; center=np.average(b[active],weights=w[active]); a[active]+=center; b[active]-=center
    a-=intercept
    residual=y-Z@coeff; expected=np.array([a,b,residual,X@beta+intercept,y-residual])
    rhs=np.eye(Z.shape[1])[:,:k]; bread=solve(weighted.T@weighted,rhs,assume_a='pos'); score=(Z@bread)*residual[:,None]*w[:,None]
    V=np.zeros((k,k))
    for cols,sign in [(['c1'],1),(['c2'],1),(['c1','c2'],-1)]:
        _,codes=np.unique(np.column_stack([data[c] for c in cols]),axis=0,return_inverse=True)
        sums=np.zeros((codes.max()+1,k)); np.add.at(sums,codes,score); V+=sign*(sums.T@sums)
    G=min(len(np.unique(data[c])) for c in ['c1','c2']); V*=G/(G-1)*(n-1)/(n-rank)
    eig,vec=np.linalg.eigh(V)
    if eig.min()<0: V=(vec*np.maximum(eig,0))@vec.T
    names=[f'x{j+1}' for j in range(k)]
    native_beta=pd.read_csv(native/'coefficients.csv').set_index('name').loc[names,'value'].to_numpy()
    native_v=pd.read_csv(native/'covariance.csv').pivot(index='row',columns='column',values='value').loc[names,names].to_numpy()
    np.testing.assert_allclose(native_beta,beta,rtol=1e-7,atol=1e-10)
    np.testing.assert_allclose(native_v,V,rtol=1e-6,atol=1e-10)
    native_values=np.fromfile(native/'outputs.bin',dtype='<f8').reshape(5,n)
    np.testing.assert_allclose(native_values,expected,rtol=1e-7,atol=1e-9)
    within_coef,_,_,_=lstsq(D[:,keep]*np.sqrt(w[:,None]),np.column_stack([y,X])*np.sqrt(w[:,None]),lapack_driver='gelsd')
    within=np.column_stack([y,X])-D[:,keep]@within_coef
    rec=dict(index=index,weight=cell['weight_kind'],k=k,components=len(components),rank=int(rank),condition=float(np.linalg.cond(weighted)),native_direct_qr_max_error=float(abs(native_values-expected).max()),modes={})
    for mode in sys.argv[1:] or ['stock']:
        folder=art/f'spr1-{mode}-diagnostic'/str(index)
        observed=np.fromfile(folder/'outputs.bin',dtype='<f8').reshape(5,n)
        demeaned=np.fromfile(folder/'demeaned.bin',dtype='<f8').reshape(k+1,n).T
        observed_v=np.fromfile(folder/'covariance.bin',dtype='<f8').reshape(k,k).T
        observed_b=np.fromfile(folder/'beta.bin',dtype='<f8')
        diag=json.loads((folder/'diagnostic.json').read_text())
        original=np.fromfile(stock/'outputs.bin',dtype='<f8').reshape(5,n)
        for values in [observed,demeaned,observed_v,observed_b,expected,V,beta]: assert np.isfinite(values).all()
        failures=lambda x,y,rtol,atol:int(np.sum(abs(x-y)>atol+rtol*abs(y)))
        rec['modes'][mode]=dict(diagnostic=diag,stock_original_exact=bool(np.array_equal(original,observed)),
           output_max_error=np.max(abs(observed-expected),axis=1).tolist(),output_mismatches=[failures(a,b,1e-7,1e-9) for a,b in zip(observed,expected)],
           beta_max_error=float(abs(observed_b-beta).max()),covariance_max_error=float(abs(observed_v-V).max()),covariance_mismatches=failures(observed_v,V,1e-6,1e-10),
           projection_max_error=np.max(abs(demeaned-within),axis=0).tolist(),
           residual_max_group_weighted_mean=max(float(np.max(abs(np.bincount(ids,weights=w*observed[2])/np.bincount(ids,weights=w)))) for ids in [left,right]),
           reconstruction_max_error=float(abs(observed[0]+observed[1]+observed[3]-observed[4]).max()),
           source_hashes={p.name:sha(p) for p in folder.iterdir() if p.is_file()})
    trace=rec['modes']['trace']; stock_mode=rec['modes']['stock']; tight=rec['modes']['tightnossr']
    for name in ['outputs.bin','demeaned.bin','sumFE.bin','beta.bin','covariance.bin']:
        assert trace['source_hashes'][name]==stock_mode['source_hashes'][name],(index,name)
    assert all(exit==1 for exit in trace['diagnostic']['diagnostic_exit'])
    assert all(exit==6 for exit in tight['diagnostic']['diagnostic_exit'])
    assert sum(stock_mode['output_mismatches'])>0
    assert sum(tight['output_mismatches'])==0 and tight['covariance_mismatches']==0
    assert (stock_mode['covariance_mismatches']>0)==(index==773)
    rec.update(native_beta_max_error=float(abs(native_beta-beta).max()), native_covariance_max_error=float(abs(native_v-V).max()),
      status='reference_stopping_error_localized', exact_instrumentation=True, diagnostic_tightened_reference_pass=True,
      bindings=dict(data_binary_sha256=sha(datap.with_suffix('.bin')), data_metadata_sha256=sha(datap.with_suffix('.json')),native_result_sha256=sha(native/'result.json'),stock_result_sha256=sha(stock/'result.json')))
    records.append(rec)
    print(index,[(mode,r['output_max_error'],r['covariance_mismatches'],r['diagnostic']['iterations']) for mode,r in rec['modes'].items()],flush=True)
output=art/'spr1-adjudication.json'; assert not output.exists()
output.write_text(json.dumps(dict(status='completed',source_sha256=sha(Path(__file__)),method='Direct full-model rank-revealing QR with independently formed joint-design cluster sandwich; demeaned SVD for stage localization.',headline_timing_eligible=False,records=records),indent=2)+'\n')

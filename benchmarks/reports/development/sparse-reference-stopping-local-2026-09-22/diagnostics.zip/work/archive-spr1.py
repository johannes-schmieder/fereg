import hashlib,io,json,subprocess,sys,tarfile,zipfile
from pathlib import Path
repo=Path.cwd(); art=repo/'target/ols-next-20260921'; out=repo/'benchmarks/reports/development/sparse-reference-stopping-local-2026-09-22'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense')); import archive_science
archive_science.archive([art/'spr1-current'],out,compact=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def portable(raw):
 return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={}
with zipfile.ZipFile(out/'diagnostics.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 def add(name,raw):
  clean=raw if name.endswith('.bin') else portable(raw); bundle.writestr(name,clean)
  tables[name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
 for mode in ['stock','trace','nossr','tightssr','tightnossr']:
  root=art/f'spr1-{mode}-diagnostic'
  for p in sorted(root.rglob('*')):
   if p.is_file():add(root.name+'/'+str(p.relative_to(root)),p.read_bytes())
 for p in sorted((art/'spr1-current/data').glob('*-n1920-*.bin')):add('input/'+p.name,p.read_bytes())
 for p in sorted(art.glob('spr1-*')):
  if p.is_file():add('work/'+p.name,p.read_bytes())
 add('work/archive-spr1.py',Path(__file__).read_bytes())
 clone=art/'spr1-fixest-diagnostic2'
 add('fixest/source-identity.json',(clone/'source-identity.json').read_bytes())
 for p in sorted(clone.glob('*.patch')):add('fixest/'+p.name,p.read_bytes())
 for relative in ['src/demeaning.cpp','src/fixest_main.h','R/estimation.R','R/methods.R','src/Makevars','config.log']:
  add('fixest/diagnostic/'+relative,(clone/'fixest'/relative).read_bytes())
 with tarfile.open(repo/'target/one-fe-profile-20260919/fixest.tar.gz') as tar:
  for relative in ['src/demeaning.cpp','src/fixest_main.h','R/estimation.R','R/methods.R']:
   add('fixest/original/'+relative,tar.extractfile('fixest/'+relative).read())
(out/'diagnostics-hashes.json').write_text(json.dumps(tables,indent=2)+'\n')
tables={}
with zipfile.ZipFile(out/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 def add(name,raw):
  clean=portable(raw);bundle.writestr(name,clean);tables[name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
 p=art/'identity-dtk1.json'; identity=json.loads(p.read_text());add(p.name,p.read_bytes())
 raw=subprocess.check_output(['git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'])
 with tarfile.open(fileobj=io.BytesIO(raw)) as tree:base={e.name:sha(tree.extractfile(e).read()) for e in tree.getmembers() if e.isfile()}
 for relative,digest in identity['source'].items():
  raw=(art/'dtk1'/relative).read_bytes();assert sha(raw)==digest
  assert sha((repo/relative).read_bytes())==digest
  if base.get(relative)!=digest:add('dtk1/'+relative,raw)
 for relative in ['two_fe_dense/run.py','two_fe_dense/broad.py','two_fe_dense/small_sparse_oracle.py','two_fe_dense/archive_science.py','systematic/generate.py',
 'one_fe_breadth/run.py','one_fe_profile/run.py',*['local_fixest_gap/'+n for n in ['r_worker.R','stata_worker.do','common.py','measure.py']]]:
  add(relative,(repo/'benchmarks'/relative).read_bytes())
(out/'sources-hashes.json').write_text(json.dumps(tables,indent=2)+'\n')
for name in ['spr1-adjudication.json','spr1-failed-preparation1.json']:
 (out/name.removeprefix('spr1-')).write_bytes(portable((art/name).read_bytes()))
print('SPARSE_REFERENCE_STOPPING_ARCHIVE_PREPARED')

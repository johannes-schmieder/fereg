import hashlib, json, os, subprocess
from pathlib import Path
repo=Path.cwd(); art=repo/'target/ols-next-20260921'; root=art/'spr1-current'
out=art/'spr1-stock-diagnostic'; out.mkdir(exist_ok=False)
worker=(root/'controller/r_worker.R').read_text().split('if (c$phase == "warm") {')[0]
worker=worker.replace('feols(formula, data=data,', 'feols(formula, data=data, demeaned=TRUE,')
worker+='''
data <- read_input(c$data)
info <- fromJSON(sub("\\\\.dta$", ".json", c$data))
for (name in names(info$column_sha256)) stopifnot(digest(writeBin(as.double(data[[name]]), raw(), size=8, endian="little"), algo="sha256", serialize=FALSE)==info$column_sha256[[name]])
fit <- fit_model(data)
saved <- recover_outputs(fit,data)
write_values <- function(name, values) {
 con <- file(file.path(output,paste0(name,".bin")),"wb")
 writeBin(as.double(values),con,size=8,endian="little"); close(con)
}
write_values("outputs",unlist(saved))
write_values("demeaned",c(fit$y_demeaned,fit$X_demeaned))
write_values("sumFE",fit$sumFE)
write_values("beta",coef(fit)); write_values("covariance",vcov(fit))
write_json(list(iterations=fit$iterations, convStatus=fit$convStatus, message=fit$message,
 nparams=fit$nparams, df_K=attr(vcov(fit,attr=TRUE),"df.K"),
 fixef_sizes=fit$fixef_sizes, fixef_alg=fit$fixef.algo,
 reference_binary_sha256=digest(file=file.path(find.package("fixest"),"libs/fixest.so"),algo="sha256")),
 file.path(output,"diagnostic.json"), pretty=TRUE,auto_unbox=TRUE,digits=NA)
cat("SPARSE_REFERENCE_DIAGNOSTIC_COMPLETE\\n")
'''
(out/'worker.R').write_text(worker)
env=os.environ.copy(); env.update(R_LIBS_USER=str(repo/'target/one-fe-profile-20260919/R-stock')+':<reference-library>',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
records=[]
for index in [704,722,737,773,791,806]:
    original=next((root/'runs').glob(f'current-{index}-*-fixest/request.json'))
    config=json.loads(original.read_text()); folder=out/str(index); folder.mkdir()
    config['output']=str(folder); request=folder/'request.json'; request.write_text(json.dumps(config,indent=2)+'\n')
    with (folder/'stdout.txt').open('w') as log:
        result=subprocess.run(['/opt/homebrew/bin/Rscript',str(out/'worker.R'),str(request)],env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(index=index,returncode=result.returncode,original_request_sha256=hashlib.sha256(original.read_bytes()).hexdigest()))
    print(index,result.returncode,flush=True)
    if result.returncode: break
(out/'complete.json').write_text(json.dumps(records,indent=2)+'\n')

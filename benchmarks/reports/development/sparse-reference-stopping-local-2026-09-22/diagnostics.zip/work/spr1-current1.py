import json, subprocess, sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad

prior_path = art / 'reference-refinement2-plan.json'
items = sorted((r for r in json.loads(prior_path.read_text())['cells']
    if r['index'] in [704, 722, 737, 773, 791, 806]), key=lambda r: r['index'])
assert len(items) == 6
root = art / 'spr1-current'
root.mkdir(exist_ok=False)
plan = dict(schema='sparse-reference-current-reproduction-v1', cells=items,
    source_sha256=broad.sha(Path(__file__)), runner_sha256=broad.sha(repo / 'benchmarks/two_fe_dense/run.py'),
    prior_plan_sha256=broad.sha(prior_path), native_identity_sha256=broad.sha(art / 'identity-dtk1.json'),
    reference_archive_sha256=broad.sha(repo / 'target/one-fe-profile-20260919/fixest.tar.gz'),
    reference_tolerance=4e-12, variants=['dtk1', 'fixest'], repeats=1,
    headline_timing_eligible=False,
    scope='Reproduce all six unresolved sparse small-graph reference discrepancies on the current accepted computational source and independent grounded dummy oracle. No tolerance, source or historical outcome is reclassified.')
broad.write(root / 'reproduction-plan.json', plan)
progress = []
for item in items:
    label = f"current-{item['index']}"
    command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root),
        '--artifacts', str(art), '--label', label, '--variants', 'dtk1', 'fixest', '--repeats', '1',
        '--oracle', '--reference-precision', '--reference-tolerance', '4e-12',
        '--record-reference-science-disagreement', '--record-reference-output-disagreement',
        *broad.arguments(item['cell'])]
    if item['reference_full_dof']:
        command.append('--reference-full-dof')
    log = root / (label + '.stdout.txt')
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    complete = root / (label + '-complete.json')
    completion = json.loads(complete.read_text()) if complete.exists() else None
    progress.append(dict(index=item['index'], label=label, command=command,
        process_returncode=result.returncode, completion=completion, log_sha256=broad.sha(log)))
    broad.write(root / 'reproduction-progress.json', progress)
    print(label, result.returncode, completion['status'] if completion else 'incomplete', flush=True)
    if result.returncode:
        break
broad.write(root / 'reproduction-complete.json', dict(status='attempts_complete',
    attempted=len(progress), planned=len(items), plan_sha256=broad.sha(root / 'reproduction-plan.json'),
    progress_sha256=broad.sha(root / 'reproduction-progress.json')))

import json, sys, statistics, hashlib, re
from pathlib import Path
REPO=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(REPO/'benchmarks/next_subsystem'))
from audit import compare, exact_exports, read
from surface_audit import outputs, distance
root=Path(__file__).resolve().parent
records=[]
for block,summary in [('paired','paired-summary.json'),('fresh-v2','fresh-summary.json')]:
 s=read(root/summary);p=read(root/block/'progress.json')
 for i,c in enumerate(s['cells']):
  direct=[]
  for rep in range(5):
   paths={r['variant']:root/block/r['result'] for r in p if r['case']==i and r['repetition']==rep}
   checks=compare(paths['qrnorm1'],paths['fixest'],'ols')
   if c['cell']['outputs']=='all':
    n=int(read(paths['qrnorm1']/'result.json')['metadata']['N'])
    checks['outputs']=distance(outputs(paths['qrnorm1'],n),outputs(paths['fixest'],n),1e-7,1e-9)
    checks['passed'] &= checks['outputs']['passed']
   direct.append(checks)
  row=dict(block=block,case=i,cell=c['cell'],medians_ms={v:1000*statistics.median(r['seconds'] for r in p if r['case']==i and r['variant']==v) for v in ['factor_names1','qrnorm1','fixest']},ratios=c['ratios'],direct_stock=direct,exact=[x['exact'] for x in c['pairs']],memory_deltas=[x['tracked_peak_bytes']['qrnorm1']-x['tracked_peak_bytes']['factor_names1'] for x in c['pairs']])
  records.append(row)
  print(block,i,row['medians_ms'],row['ratios'],'memory',min(row['memory_deltas']),max(row['memory_deltas']),'stock',all(x['passed'] for x in direct))
assert all(c['passed'] for r in records for c in r['direct_stock'])
tests=set()
for name in ['rust-low.log','rust-scratch.log']:
 tests.update(re.findall(r'^test (\S+) \.\.\. ok$',(root/name).read_text(),re.M))
result=dict(records=records,rust_distinct_pass=len(tests),rust_tests=sorted(tests))
with (root/'results.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print('RUST_DISTINCT',len(tests))

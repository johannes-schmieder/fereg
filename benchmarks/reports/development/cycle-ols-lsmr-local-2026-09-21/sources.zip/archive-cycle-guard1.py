import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2]; artifacts=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import archive_science
root=repo/'target/g21cy1'
output=repo/'benchmarks/reports/development/cycle-ols-lsmr-local-2026-09-21'
assert json.loads((root/'screen-complete.json').read_text())['attempted']==46
archive_science.archive([root],output,compact=True,omit_output_arrays=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def portable(raw):
 return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={kind:{} for kind in ['sources','checks']}
with zipfile.ZipFile(output/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 def add(name,raw):
  clean=portable(raw);bundle.writestr(name,clean)
  tables['sources'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
 for variant in ['in1','cy1']:
  path=artifacts/f'identity-{variant}.json';identity=json.loads(path.read_text());add(path.name,path.read_bytes())
  raw=subprocess.check_output(['/opt/homebrew/bin/git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'],cwd=repo)
  with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
   base={entry.name:sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
  for relative,digest in identity['source'].items():
   data=(artifacts/variant/relative).read_bytes();assert sha(data)==digest
   if base.get(relative)!=digest: add(variant+'/'+relative,data)
 for name in ['audit_milestone.py','audit_outputs.py','graph_oracle.py','run.py','route_development.py','score.py','broad.py','archive_science.py']:
  add(name,(repo/'benchmarks/two_fe_dense'/name).read_bytes())
 for relative in ['crates/fereg-plugin/src/result.rs','benchmarks/one_fe_optimization/build.py','benchmarks/one_fe_optimization/cycle_ols_lsmr.py','benchmarks/one_fe_optimization/cycle_ols_lsmr.rs']:
  add(relative,(repo/relative).read_bytes())
 for name in ['cycle-guard-screen1.py','audit-cycle-routing1.py','score-kernel-screen2.py','archive-cycle-guard1.py']:
  add(name,(artifacts/name).read_bytes())
with zipfile.ZipFile(output/'checks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 for kind in ['score','inference','outputs','screen','routing','tests']:
  for suffix in ['json','txt']:
   name=f'cycle-guard-{kind}1.{suffix}';path=artifacts/name
   if not path.exists(): continue
   raw=path.read_bytes();clean=portable(raw);bundle.writestr(name,clean)
   tables['checks'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
for kind,table in tables.items(): (output/(kind+'-hashes.json')).write_text(json.dumps(table,indent=2)+'\n')
verifier=(repo/'benchmarks/reports/development/initial-ols-norm-local-2026-09-21/verify.py').read_text()
replacements={"['sf1', 'in1']":"['in1', 'cy1']",'initial-ols-norm-archive-integrity-v1':'cycle-ols-lsmr-archive-integrity-v1','INITIAL_OLS_NORM_ARCHIVE_INTEGRITY_PASS':'CYCLE_OLS_LSMR_ARCHIVE_INTEGRITY_PASS','initial-norm-inference1.json':'cycle-guard-inference1.json','initial-norm-equivalence1.json':'cycle-guard-routing1.json',"audit['planned'] == 48":"audit['planned'] == 138", "for relative in identity['overlays']:\n            reconstructed[relative] = sha(bundle.read(variant + '/' + relative))":"for relative in identity['source']:\n            name = variant + '/' + relative\n            if name in bundle.namelist():\n                reconstructed[relative] = sha(bundle.read(name))"}
for old,new in replacements.items():
 assert old in verifier,old
 verifier=verifier.replace(old,new)
(output/'verify.py').write_text(verifier)
rows=[]
for r in json.loads((artifacts/'cycle-guard-score1.json').read_text())['cells']:
 c=r['cell'];s=r['median_seconds']
 rows.append(f"| {r['index']} | {c['design']} | {c['weight_kind']} | {c['k']} | {c['threads']} | {c['case']} | {c['solver']} | {1000*s['in1']:.0f} | {1000*s['cy1']:.0f} | {r['median_native_ratio']:.4f} |")
(output/'README.md').write_text('''# Exact-cycle automatic LSMR experiment

The captured cy1 source evaluates ADR 0093's exact connected-cycle predicate
before public fast two-intercept automatic OLS. Production routing is unchanged.
It reuses automatic LSMR's existing tolerance, memory admission, fallback and
fresh certificates. It charges successful and rejected probe setup and peak
workspace outside early Schur returns. Explicit/shared/higher-dimensional,
low-memory and excluded graph routes retain their existing policy.

The focused fixture checks row order, group labels, effect swaps, connectivity,
paths, chords, unequal group sizes, weight dispersion and budget rejection.
The captured plugin passes the actual ABI fixture.

The training screen completes 46 cells and 276 successful calls with clean
isolation. All 92 independent native inference checks, 276 exact within-arm
repeat checks and 96 candidate output audits pass. The route audit passes
138 pairs: 84 selected pairs use automatic LSMR without a failed solver or
Schur pilot; 54 excluded pairs retain exact finite exports, samples, status,
FE metadata, certificates, saved vectors and solver fields other than times.

All 28 targeted cycle cells improve: paired runtime ratios range from 0.5067
to 0.7500. All 18 excluded/explicit controls stay within 1.05, with worst
1.0465. These are three-pair training measurements, not fresh validation or
final acceptance. Both unused routing seeds and Linux confirmation remain
required before production adoption. The control margin is narrow.

Tracked peaks increase in every selected pair, by 18,571,188 to 482,354,402
bytes. Among all 138 pairs, 44 peaks match; excluded-pair differences range
from -3,143,088 to +8,863,744 bytes. There is no memory-neutrality claim.
Whole-fit constrained admission remains to be exercised. The tiny borrowed
FE descriptor's joint accounting also needs review before adoption; this
experiment does not establish a complete allocation proof.

| Index | Graph | Weight | K | Threads | Request | Solver | in1 ms | cy1 ms | Paired cy1/in1 |
|---:|---|---|---:|---:|---|---|---:|---:|---:|
'''+ '\n'.join(rows)+'''

`verify.py` checks archived hashes, all captured source members (including the
new experimental module), and independent auditor bindings. Output arrays
remain local with hashes; raw licensed logs and binaries are excluded.
This report authorizes no installation, release or push.
''')
print('CYCLE_OLS_LSMR_ARCHIVE_PREPARED')

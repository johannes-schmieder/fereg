import csv, hashlib, json
from pathlib import Path
repo=Path(__file__).resolve().parents[2]
root=repo/'target/g21cy1'; output=repo/'target/ols-next-20260921/cycle-guard-routing1.json'
assert not output.exists()
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((root/'screen-plan.json').read_text())
progress=json.loads((root/'screen-progress.json').read_text())
def solver(path):
    return {(int(r['row']),int(r['column'])):float(r['value']) for r in csv.DictReader(path.open())}
records=[]
for attempt in progress:
    expected=plan['expected_selected'][attempt['index']]
    paths={v:sorted((root/'runs').glob(attempt['label']+'-*-'+v+'/result.json')) for v in plan['variants']}
    assert all(len(v)==plan['repeats'] for v in paths.values())
    for i in range(plan['repeats']):
        left,right=[paths[v][i] for v in plan['variants']]
        a,b=[json.loads(p.read_text()) for p in [left,right]]
        old,new=[solver(p.with_name('fereg_solver.csv')) for p in [left,right]]
        checks=dict(application=a['status']==b['status']=='pass',sample=a['sample_sha256']==b['sample_sha256'])
        if expected:
            checks.update(requested_auto=new[(1,1)]==1,used_lsmr=new[(1,2)]==3,
                          certified=new[(1,4)]==2,no_discarded_solver=new[(1,11)]==0,
                          cycle_warning=new[(1,12)]==1,no_schur_pilot=new[(1,15)]==0,
                          charged_setup=new[(1,9)]>0)
        else:
            checks['solver_and_certificates']={k:v for k,v in new.items() if k[1] not in [9,10]}=={
                k:v for k,v in old.items() if k[1] not in [9,10]}
            names=['coefficients.csv','covariance.csv','b.csv','V.csv','fereg_fit.csv','fereg_dof.csv',
                   'fereg_certificate.csv','fereg_status.csv','fereg_fe.csv']
            if b['cell']['outputs']!='none': names.append('outputs.bin')
            checks.update({name:sha(left.with_name(name))==sha(right.with_name(name)) for name in names})
        records.append(dict(index=attempt['index'],rep=i+1,expected_selected=expected,checks=checks,
                            status='pass' if all(checks.values()) else 'mismatch',
                            result_sha256={v:sha(paths[v][i]) for v in plan['variants']}))
result=dict(schema='exact-cycle-route-audit-v1',controller_sha256=sha(Path(__file__)),
            solver_layout_source_sha256=sha(repo/'crates/fereg-plugin/src/result.rs'),
            plan_sha256=sha(root/'screen-plan.json'),progress_sha256=sha(root/'screen-progress.json'),
            planned=len(plan['cells'])*plan['repeats'],passing=sum(r['status']=='pass' for r in records),records=records)
output.write_text(json.dumps(result,indent=2)+'\n')
print('CYCLE_ROUTE_AUDIT',result['passing'],'/',result['planned'])
for r in records:
    if r['status']!='pass': print(r['index'],r['rep'],[k for k,v in r['checks'].items() if not v])
assert result['passing']==result['planned']

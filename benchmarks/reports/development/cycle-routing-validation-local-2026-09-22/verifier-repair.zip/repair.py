import hashlib, json, zipfile
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
out = repo / 'benchmarks/reports/development/cycle-routing-validation-local-2026-09-22'
verifier = out / 'verify.py'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>')
records = {}
with zipfile.ZipFile(out / 'verifier-repair.zip', 'x', zipfile.ZIP_DEFLATED) as bundle:
    for name, path in [('original-verify.py', verifier), ('failed-integrity1.txt', art / 'cycle-validation-integrity1.txt'), ('repair.py', Path(__file__))]:
        raw = path.read_bytes(); clean = portable(raw); bundle.writestr(name, clean)
        records[name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
text = verifier.read_text()
before = "outputs['output_auditor_sha256']"
assert text.count(before) == 1
text = text.replace(before, "outputs['auditor_sha256']").replace("folder / 'integrity.json'", "folder / 'integrity2.json'")
verifier.write_text(text)
records['corrected_verify_sha256'] = sha(verifier.read_bytes())
(out / 'verifier-repair.json').write_text(json.dumps(dict(schema='cycle-validation-verifier-repair-v1',
    reason='The verifier used the wrong output-auditor hash field name. Measurement and scientific evidence are unchanged.',
    records=records), indent=2) + '\n')
print('CYCLE_VALIDATION_VERIFIER_FIELD_REPAIRED')

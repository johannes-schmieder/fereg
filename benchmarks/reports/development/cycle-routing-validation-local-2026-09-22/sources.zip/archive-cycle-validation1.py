import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science
out = repo / 'benchmarks/reports/development/cycle-routing-validation-local-2026-09-22'
adjudication = json.loads((art / 'cycle-validation-adjudication1.json').read_text())
assert len(adjudication['blocks']) == 2
roots = [repo / f'target/g21cy{phase}{block}' for block in [1, 2] for phase in ['val', 'route']]
archive_science.archive(roots, out, compact=True, omit_output_arrays=True)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>').replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')
tables = {'sources': {}, 'checks': {}}
with zipfile.ZipFile(out / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['owf1', 'cy2']:
        identity_path = art / f'identity-{variant}.json'
        identity = json.loads(identity_path.read_text()); add(identity_path.name, identity_path.read_bytes())
        raw = subprocess.check_output(['git', 'archive', identity['base_commit'], 'Cargo.toml', 'Cargo.lock', 'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as tree:
            base = {entry.name: sha(tree.extractfile(entry).read()) for entry in tree.getmembers() if entry.isfile()}
        for relative, digest in identity['source'].items():
            raw = (art / variant / relative).read_bytes(); assert sha(raw) == digest
            if base.get(relative) != digest: add(variant + '/' + relative, raw)
    freeze = json.loads((art / 'cycle-candidate-freeze1.json').read_text())
    for relative, digest in freeze['runner_sources'].items():
        raw = (repo / relative).read_bytes(); assert sha(raw) == digest
        add(relative, raw)
    for relative in ['crates/fereg-plugin/src/result.rs', 'benchmarks/two_fe_dense/archive_science.py',
        'benchmarks/two_fe_dense/score.py', 'benchmarks/two_fe_dense/small_sparse_oracle.py',
        'benchmarks/one_fe_breadth/run.py', 'benchmarks/one_fe_profile/run.py',
        *['benchmarks/local_fixest_gap/' + name for name in ['common.py', 'measure.py', 'r_worker.R', 'stata_worker.do']]]:
        if relative not in tables['sources']: add(relative, (repo / relative).read_bytes())
    for name in ['cycle-validation1.py', 'cycle-validation-queue1.py', 'score-cycle-validation1.py', 'audit-cycle-validation-routing1.py', 'audit-cycle-validation1.py', 'join-cycle-validation1.py', 'archive-cycle-validation1.py']:
        add(name, (art / name).read_bytes())
    # The build controller belongs to the already archived cy2 capture, not
    # to later unbuilt experiments in the working checkout.
    previous = repo / 'benchmarks/reports/development/cycle-routing-memory-local-2026-09-21'
    with zipfile.ZipFile(previous / 'sources.zip') as old:
        name = 'benchmarks/one_fe_optimization/build.py'
        add('captured-build-controller.py', old.read(name))
with zipfile.ZipFile(out / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    names = [p.name for p in art.iterdir() if p.is_file() and p.suffix in ['.json', '.txt']
        and (p.name.startswith('cycle-validation-') or p.name == 'cycle-candidate-freeze1.json')
        and not p.name.startswith('cycle-validation-archive')]
    names += list(freeze['evidence'])
    for name in sorted(set(names)):
        raw = (art / name).read_bytes(); clean = portable(raw); bundle.writestr(name, clean)
        tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    raw = (repo / freeze['selection_plan']).read_bytes()
    assert sha(raw) == freeze['selection_plan_sha256']
    name = 'training-selection-plan.json'; clean = portable(raw); bundle.writestr(name, clean)
    tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
for kind, table in tables.items(): (out / (kind + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')
template = (repo / 'benchmarks/reports/development/cycle-routing-memory-local-2026-09-21/verify.py').read_text()
template = template.replace("['owf1', 'cy1', 'cy2']", "['owf1', 'cy2']")
start = template.index("with zipfile.ZipFile(folder / 'checks.zip') as bundle:", template.index('known_sources ='))
end = template.index('\nreceipt =', start)
checks = '''with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    hashes = json.loads((folder / 'checks-hashes.json').read_text())
    freeze = json.loads(bundle.read('cycle-candidate-freeze1.json'))
    assert freeze['controller_sha256'] in known_sources
    assert all(digest in known_sources for digest in freeze['runner_sources'].values())
    assert freeze['selection_plan_sha256'] == hashes['training-selection-plan.json']['original_sha256']
    for name, digest in freeze['evidence'].items(): assert digest == hashes[name]['original_sha256']
    for variant, record in freeze['artifacts'].items():
        assert record['identity_sha256'] == source_hashes[f'identity-{variant}.json']['original_sha256']
        assert record['plugin'] == next(s['plugin'] for s in sources if s['variant'] == variant)
    adjudication = json.loads(bundle.read('cycle-validation-adjudication1.json'))
    assert adjudication['source_sha256'] in known_sources
    for name, digest in adjudication['evidence_sha256'].items():
        assert digest == hashes[name]['original_sha256']
    assert len(adjudication['blocks']) == 2
    for block in adjudication['blocks']:
        assert block['seed'] == freeze['seeds'][block['block'] - 1]
        assert len(block['applications']) == 960
        for kind in ['inference', 'routing', 'fastest']:
            audit = json.loads(bundle.read(f"cycle-validation-block{block['block']}-{kind}1.json"))
            assert audit['controller_sha256'] in known_sources
        inference = json.loads(bundle.read(f"cycle-validation-block{block['block']}-inference1.json"))
        assert inference['oracle_source_sha256'] in known_sources
        routing = json.loads(bundle.read(f"cycle-validation-block{block['block']}-routing1.json"))
        assert routing['solver_layout_source_sha256'] in known_sources
        outputs = json.loads(bundle.read(f"cycle-validation-block{block['block']}-outputs1.json"))
        assert outputs['source_sha256'] in known_sources and outputs['output_auditor_sha256'] in known_sources
'''
template = template[:start] + checks + template[end:]
template = template.replace('cycle-routing-memory-archive-integrity-v1', 'cycle-routing-validation-archive-integrity-v1').replace('CYCLE_ROUTING_MEMORY_ARCHIVE_INTEGRITY_PASS', 'CYCLE_ROUTING_VALIDATION_ARCHIVE_INTEGRITY_PASS').replace("folder / 'integrity2.json'", "folder / 'integrity.json'")
(out / 'verify.py').write_text(template)
rows = []
for block in adjudication['blocks']:
    for cell in block['cells']:
        c = cell['cell']; s = cell['median_seconds']
        rows.append(f"| {block['block']} | {cell['index']} | {c['design']} | {c['weight_kind']} | {c['k']} | {c['threads']} | {c['case']} | {s['owf1']:.3f} | {s['cy2']:.3f} | {cell['median_native_ratio']:.4f} | {cell['median_reference_ratio']} | {all(cell['checks'].values())} |")
(out / 'timings.md').write_text('| Block | Cell | Graph | Weight | K | T | Case | Prior seconds | Candidate seconds | Paired native ratio | Paired reference ratio | Screen limits met |\n|---|---:|---|---|---:|---:|---|---:|---:|---:|---:|---|\n' + '\n'.join(rows) + '\n')
print('CYCLE_VALIDATION_ARCHIVE_PREPARED', adjudication['accepted_mac_validation'])

import json,subprocess,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import audit_outputs
from score import sha
block=int(sys.argv[1]);assert block in [1,2]
root=repo/f'target/g21cyval{block}';route=repo/f'target/g21cyroute{block}'
assert json.loads((root/'screen-complete.json').read_text())['attempted']==46
assert json.loads((route/'route-complete.json').read_text())['attempted']==280
prefix=f'cycle-validation-block{block}'
commands=[
 ('score',[sys.executable,str(art/'score-cycle-validation1.py'),str(root),str(art/f'{prefix}-score1.json')]),
 ('inference',[sys.executable,str(repo/'benchmarks/two_fe_dense/audit_milestone.py'),str(root),'screen',str(art/f'{prefix}-inference1.json')]),
 ('routing',[sys.executable,str(art/'audit-cycle-validation-routing1.py'),str(block)]),
 ('fastest',[sys.executable,str(repo/'benchmarks/two_fe_dense/audit_routes.py'),str(route),str(art/f'{prefix}-fastest1.json')]),
]
steps=[]
for name,command in commands:
 with (art/f'{prefix}-{name}1.txt').open('x') as stream:
  r=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 steps.append(dict(kind=name,process_returncode=r.returncode,command=command))
 print(block,name,r.returncode,flush=True)
records=[]
for attempt in json.loads((root/'screen-progress.json').read_text()):
 if attempt['cell']['case'].endswith('_none'):continue
 for variant in ['owf1','cy2']:
  receipt=root/f"{attempt['label']}-{variant}-independent-outputs.json";assert not receipt.exists()
  try:
   audit_outputs.audit(root,attempt['label'],variant)
   rows=json.loads(receipt.read_text());assert len(rows)==5 and all(r['status']=='pass' for r in rows)
   record=dict(index=attempt['index'],variant=variant,status='pass',receipt_sha256=sha(receipt),records=rows)
  except AssertionError as error:record=dict(index=attempt['index'],variant=variant,status='mismatch_or_incomplete',detail=str(error))
  records.append(record)
out=art/f'{prefix}-outputs1.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='cycle-validation-output-audit-v1',source_sha256=sha(Path(__file__)),auditor_sha256=sha(Path(audit_outputs.__file__)),steps=steps,records=records),indent=2)+'\n')
assert all(s['process_returncode']==0 for s in steps)
assert len(records)==64 and all(r['status']=='pass' for r in records)
print('CYCLE_VALIDATION_AUDITS_COMPLETE',block,flush=True)

import json,subprocess,sys
from pathlib import Path
art=Path(__file__).resolve().parent
records=[]
for block in [1,2]:
 for phase in ['screen','routes']:
  output=art/f'cycle-validation-block{block}-{phase}1.txt'
  print('START',block,phase,flush=True)
  with output.open('x') as stream:
   result=subprocess.run([sys.executable,str(art/'cycle-validation1.py'),str(block),phase],stdout=stream,stderr=subprocess.STDOUT)
  records.append(dict(block=block,phase=phase,process_returncode=result.returncode))
  (art/'cycle-validation-queue-progress1.json').write_text(json.dumps(records,indent=2)+'\n')
  print('FINISH',block,phase,result.returncode,flush=True)
  if result.returncode:raise SystemExit(result.returncode)
print('CYCLE_VALIDATION_BLOCKS_ATTEMPTED',flush=True)

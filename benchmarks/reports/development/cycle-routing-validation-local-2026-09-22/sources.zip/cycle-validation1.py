import json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad,route_development as route
block=int(sys.argv[1]);phase=sys.argv[2]
assert block in [1,2] and phase in ['screen','routes']
freeze_path=art/'cycle-candidate-freeze1.json';freeze=json.loads(freeze_path.read_text())
def validate():
 assert broad.sha(Path(__file__))==freeze['controller_sha256']
 for relative,digest in freeze['runner_sources'].items():assert broad.sha(repo/relative)==digest
 for variant,record in freeze['artifacts'].items():
  assert broad.sha(art/f'identity-{variant}.json')==record['identity_sha256']
  assert broad.sha(art/variant/'dist/fereg_macos.plugin')==record['plugin']
validate()
training_path=repo/freeze['selection_plan'];assert broad.sha(training_path)==freeze['selection_plan_sha256']
training=json.loads(training_path.read_text());seed=freeze['seeds'][block-1]
cells=[dict(c,seed=seed) for c in training['cells']]
root=repo/'target'/f"g21cy{'val' if phase=='screen' else 'route'}{block}"
root.mkdir(exist_ok=False);(root/'execution-source.py').write_bytes(Path(__file__).read_bytes())
if phase=='routes':cells=cells[:28]
plan=dict(schema='cycle-frozen-validation-v1',block=block,seed=seed,cells=cells,repeats=5,
 controller_sha256=broad.sha(Path(__file__)),freeze_sha256=broad.sha(freeze_path),
 acceptance='Frozen fresh-seed five-pair validation. Preserve all applications, reference disagreements and timing exclusions; no source or threshold changes during either block.')
if phase=='screen':plan.update(baseline='owf1',candidate='cy2',variants=['owf1','cy2','fixest'],expected_selected=training['expected_selected'])
else:plan.update(candidate='cy2',families=['auto','lsmr'],selected_indices=list(range(28)))
label='screen' if phase=='screen' else 'route'
broad.write(root/f'{label}-plan.json',plan);progress=[]
for index,cell in enumerate(cells):
 attempts=[(None,None)] if phase=='screen' else [(rep,family) for rep in range(1,6) for family in (['auto','lsmr'] if (index+rep)%2 else ['lsmr','auto'])]
 for rep,family in attempts:
  validate()
  run_label=f'validation-c{index:03d}' if phase=='screen' else f'route-c{index:03d}-r{rep}-{family}'
  request=cell if phase=='screen' else dict(cell,solver=family)
  variants=[v for v in plan['variants'] if v!='fixest' or cell['weight_kind']!='fw'] if phase=='screen' else ['cy2']
  command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),
   '--artifacts',str(art),'--label',run_label,'--variants',*variants,
   '--repeats','5' if phase=='screen' else '1','--timeout','240','--keep-going',
   '--record-reference-science-disagreement','--record-reference-output-disagreement',*broad.arguments(request)]
  stdout=root/(run_label+'.stdout.txt');code,isolation=route.invoke(command,stdout)
  complete=root/(run_label+'-complete.json')
  record=dict(index=index,cell=request,label=run_label,command=command,process_returncode=code,
   timing_isolation=isolation,stdout_sha256=broad.sha(stdout),completion=json.loads(complete.read_text()) if complete.exists() else None)
  if phase=='routes':record.update(rep=rep,family=family,original_index=index)
  progress.append(record);broad.write(root/f'{label}-progress.json',progress)
  print(block,phase,len(progress),'/',len(cells)*(1 if phase=='screen' else 10),run_label,code,isolation['status'],flush=True)
broad.write(root/f'{label}-complete.json',dict(status='attempts_complete',planned=len(cells)*(1 if phase=='screen' else 10),attempted=len(progress),process_failures=sum(r['process_returncode']!=0 for r in progress),plan_sha256=broad.sha(root/f'{label}-plan.json'),progress_sha256=broad.sha(root/f'{label}-progress.json')))

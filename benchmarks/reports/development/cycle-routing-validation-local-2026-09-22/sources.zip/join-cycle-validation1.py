import collections,json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
from score import sha
out=art/'cycle-validation-adjudication1.json';assert not out.exists()
freeze_path=art/'cycle-candidate-freeze1.json';freeze=json.loads(freeze_path.read_text())
records=[];evidence={'cycle-candidate-freeze1.json':sha(freeze_path)}
for block in [1,2]:
 prefix=f'cycle-validation-block{block}'
 audits={}
 for name in ['score','inference','routing','fastest','outputs']:
  p=art/f'{prefix}-{name}1.json';audits[name]=json.loads(p.read_text());evidence[p.name]=sha(p)
 score,inference,routing,fastest,outputs=[audits[k] for k in ['score','inference','routing','fastest','outputs']]
 screen_root=repo/f'target/g21cyval{block}';route_root=repo/f'target/g21cyroute{block}'
 plan=json.loads((screen_root/'screen-plan.json').read_text())
 assert plan['freeze_sha256']==sha(freeze_path) and plan['seed']==freeze['seeds'][block-1]
 assert len(score['cells'])==len(plan['cells'])==46
 apps=[];references=set()
 for root in [screen_root,route_root]:
  for p in sorted((root/'runs').glob('*/result.json')):
   r=json.loads(p.read_text());request=json.loads(p.with_name('request.json').read_text())
   fingerprint=r['measurement_fingerprint'];variant=p.parent.name.rsplit('-',1)[1]
   assert r['cell']['seed']==plan['seed']
   if variant=='fixest':
    references.add(json.dumps({k:fingerprint[k] for k in ['fixest_archive_sha256','fixest_library']},sort_keys=True))
   else:
    assert fingerprint['native']['plugin']==freeze['artifacts'][variant]['plugin']
    assert request['solver'] in ['auto','lsmr']
   apps.append(dict(root=root.name,run=p.parent.name,status=r['status'],result_sha256=sha(p)))
 assert len(references)<=1
 science=inference['complete'] and inference['native_complete']==inference['planned']==46
 science= science and routing['passing']==routing['planned']==230
 science= science and len(outputs['records'])==64 and all(r['status']=='pass' for r in outputs['records'])
 science= science and fastest['complete'] and fastest['planned']==fastest['attempted']==280
 science= science and all(r['status']=='science_pass' for r in fastest['records'])
 rows=[]
 for cell in score['cells']:
  index=cell['index'];selected=plan['expected_selected'][index]
  native=cell['median_native_ratio'];reference=cell['median_reference_ratio']
  checks=dict(clean=cell['isolation']=='no_detected_overlap',
   native_speed=native<freeze['acceptance']['selected_native_ratio_below'] if selected else native<=freeze['acceptance']['excluded_native_ratio_at_most'],
   native_sample=all(p['sample_equal'] for p in cell['pairs']),
   reference_speed=reference is None or reference<freeze['acceptance']['fixest_comparable_ratio_below'])
  rows.append(dict(index=index,cell=cell['cell'],selected=selected,checks=checks,median_native_ratio=native,median_reference_ratio=reference,median_seconds=cell['median_seconds']))
 route_checks=[dict(index=r['index'],ratio=r['median_paired_auto_to_fastest_valid'],
  accepted=r['median_paired_auto_to_fastest_valid'] is not None and r['median_paired_auto_to_fastest_valid']<=freeze['acceptance']['auto_fastest_valid_ratio_at_most']) for r in fastest['cells']]
 route_clean=all(r['isolation']=='no_detected_overlap' for r in fastest['records'])
 complete=len(apps)==960 and all(r['status']=='pass' for r in apps)
 timing=all(all(r['checks'].values()) for r in rows) and route_clean and all(r['accepted'] for r in route_checks)
 record=dict(block=block,seed=plan['seed'],complete_applications=complete,application_counts=dict(collections.Counter(r['status'] for r in apps)),
  native_science=bool(science),timing=timing,cells=rows,route_checks=route_checks,
  reference_science_counts=dict(collections.Counter(a['status'] for r in inference['records'] for a in r['attempts'] if a['variant']=='fixest')),
  applications=apps)
 records.append(record)
 print('BLOCK',block,'applications',complete,'native_science',bool(science),'timing',timing,flush=True)
 for row in rows:
  if not all(row['checks'].values()):print('SCREEN_LIMIT',block,row['index'],row['checks'],row['median_native_ratio'],row['median_reference_ratio'],flush=True)
 for row in route_checks:
  if not row['accepted']:print('ROUTE_LIMIT',block,row,flush=True)
receipt=dict(schema='cycle-frozen-validation-adjudication-v1',source_sha256=sha(Path(__file__)),evidence_sha256=evidence,blocks=records,
 accepted_mac_validation=all(r['complete_applications'] and r['native_science'] and r['timing'] for r in records),
 limitations='Mac development validation only. Reference scientific mismatches remain failures. Linux confirmation and the broader milestone remain open; this does not adopt production routing.')
out.write_text(json.dumps(receipt,indent=2)+'\n')
print('CYCLE_VALIDATION_ADJUDICATED',receipt['accepted_mac_validation'],flush=True)

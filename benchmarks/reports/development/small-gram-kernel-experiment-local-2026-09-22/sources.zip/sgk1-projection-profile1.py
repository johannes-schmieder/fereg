import hashlib, json, re
from pathlib import Path

art = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identities = {v: json.loads((art / f'identity-{v}.json').read_text()) for v in ['scb1', 'dtk1']}
files = ['crates/fereg-core/src/linalg/solve.rs', 'crates/fereg-core/src/fe/single_slope.rs']
assert all(identities['scb1']['source'][f] == identities['dtk1']['source'][f] for f in files)
prior = json.loads((art / 'rps1-audit2.json').read_text())
records = []
for weight in ['aw', 'pw']:
    stack = art / f'rps1-{weight}-sampled1/runs/c000-r0-scb1/native-stacks.txt'
    assert sha(stack) == next(r['stack_sha256'] for r in prior['records'] if r['weight'] == weight)
    nodes = []
    for line in stack.read_text().splitlines():
        match = re.match(r'^([ +!|:]*)(\d+) (.+?)  \(in ([^)]+)\)', line)
        if match:
            nodes.append((len(match[1]), int(match[2]), match[3], match[4]))
    total = solve = 0
    for index, node in enumerate(nodes):
        if 'SingleSlopeAbsorber::project_serial_ordered::' not in node[2]:
            continue
        total += node[1]
        for child in nodes[index + 1:]:
            if child[0] <= node[0]:
                break
            if 'linalg::solve::solve_linear_system::' in child[2]:
                solve += child[1]
    assert 0 < solve < total
    records.append(dict(weight=weight, stack_sha256=sha(stack), projection_samples=total,
        dynamic_solver_samples=solve, solver_share=solve / total))
with (art / 'sgk1-projection-profile1.json').open('x') as stream:
    json.dump(dict(schema='small-gram-kernel-profile-attribution-v1', source_sha256=sha(Path(__file__)),
        prior_audit_sha256=sha(art / 'rps1-audit2.json'),
        identities={v: sha(art / f'identity-{v}.json') for v in identities},
        unchanged_source={f: identities['dtk1']['source'][f] for f in files}, records=records,
        limitation='Statistical attribution from the preserved prior sampling campaign; the projection/solver sources match the current baseline. These are not new baseline phase times.'), stream, indent=2)
print('SMALL_GRAM_PROFILE_ATTRIBUTION_PASS', records)

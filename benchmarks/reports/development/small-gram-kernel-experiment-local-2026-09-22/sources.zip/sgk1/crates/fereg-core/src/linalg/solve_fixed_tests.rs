//! Frozen scalar elimination from the pre-specialization implementation.
use super::*;

fn legacy_dynamic_solve(
    matrix: &mut [f64],
    right_hand_sides: &mut [f64],
    dimension: usize,
    rhs_count: usize,
    relative_tolerance: f64,
) -> Result<usize> {
    if matrix.len() != dimension.saturating_mul(dimension)
        || right_hand_sides.len() != dimension.saturating_mul(rhs_count)
    {
        return Err(FeregError::new(
            ErrorCode::InvalidArgument,
            "linear-system buffers have inconsistent dimensions",
        ));
    }
    if !relative_tolerance.is_finite() || relative_tolerance < 0.0 {
        return Err(FeregError::new(
            ErrorCode::InvalidArgument,
            "linear-system tolerance must be finite and nonnegative",
        ));
    }
    if dimension == 0 {
        return Ok(0);
    }

    let scale = matrix
        .iter()
        .fold(0.0_f64, |maximum, value| maximum.max(value.abs()));
    if scale == 0.0 {
        right_hand_sides.fill(0.0);
        return Ok(0);
    }
    let threshold = scale * relative_tolerance.max(f64::EPSILON);
    let mut rank = 0;

    for column in 0..dimension {
        let mut pivot_row = column;
        let mut pivot_value = matrix[column * dimension + column].abs();
        for row in (column + 1)..dimension {
            let candidate = matrix[row * dimension + column].abs();
            if candidate > pivot_value {
                pivot_row = row;
                pivot_value = candidate;
            }
        }
        if pivot_value <= threshold {
            continue;
        }
        if pivot_row != column {
            for other_column in 0..dimension {
                matrix.swap(
                    column * dimension + other_column,
                    pivot_row * dimension + other_column,
                );
            }
            for rhs in 0..rhs_count {
                right_hand_sides.swap(column * rhs_count + rhs, pivot_row * rhs_count + rhs);
            }
        }

        let pivot = matrix[column * dimension + column];
        for row in (column + 1)..dimension {
            let factor = matrix[row * dimension + column] / pivot;
            matrix[row * dimension + column] = 0.0;
            for other_column in (column + 1)..dimension {
                let pivot_entry = matrix[column * dimension + other_column];
                let index = row * dimension + other_column;
                matrix[index] = (-factor).mul_add(pivot_entry, matrix[index]);
            }
            for rhs in 0..rhs_count {
                let pivot_entry = right_hand_sides[column * rhs_count + rhs];
                let index = row * rhs_count + rhs;
                right_hand_sides[index] = (-factor).mul_add(pivot_entry, right_hand_sides[index]);
            }
        }
        rank += 1;
    }

    for row in (0..dimension).rev() {
        let diagonal = matrix[row * dimension + row];
        if diagonal.abs() <= threshold {
            for rhs in 0..rhs_count {
                right_hand_sides[row * rhs_count + rhs] = 0.0;
            }
            continue;
        }
        for rhs in 0..rhs_count {
            let mut value = right_hand_sides[row * rhs_count + rhs];
            for column in (row + 1)..dimension {
                value = (-matrix[row * dimension + column])
                    .mul_add(right_hand_sides[column * rhs_count + rhs], value);
            }
            right_hand_sides[row * rhs_count + rhs] = value / diagonal;
        }
    }
    Ok(rank)
}

#[test]
fn fixed_dimensions_match_legacy_pivots_rank_and_arithmetic() {
    for dimension in 0..=9 {
        for rhs_count in [0, 1, 2, 7, 12, 52] {
            for case in 0..10 {
                for scale in [1e-150, 1.0, 1e150] {
                    let mut matrix = vec![0.0; dimension * dimension];
                    for row in 0..dimension {
                        for col in 0..dimension {
                            let value = match case {
                                0 => 0.0,
                                1 => {
                                    if row == col {
                                        (row + 1) as f64
                                    } else {
                                        0.0
                                    }
                                }
                                2 => ((row + 1) * (col + 1)) as f64,
                                3 => {
                                    if row == col {
                                        if row % 2 == 0 {
                                            1.0
                                        } else {
                                            0.0
                                        }
                                    } else {
                                        0.0
                                    }
                                }
                                4 => {
                                    if col == 0 {
                                        0.0
                                    } else {
                                        ((row * 11 + col * 17) % 23) as f64 - 11.0
                                    }
                                }
                                5 => {
                                    if col == row {
                                        1e-12
                                    } else {
                                        1.0
                                    }
                                }
                                6 => {
                                    if row + col + 1 == dimension {
                                        -3.0
                                    } else {
                                        1.0
                                    }
                                }
                                7 => {
                                    if row == 0 && col == 0 {
                                        f64::NAN
                                    } else {
                                        1.0
                                    }
                                }
                                8 => {
                                    if row == col {
                                        f64::INFINITY
                                    } else {
                                        -0.0
                                    }
                                }
                                _ => ((row * 31 + col * 19 + row * col * 7) % 41) as f64 - 20.0,
                            };
                            matrix[row * dimension + col] = value * scale;
                        }
                    }
                    let rhs: Vec<f64> = (0..dimension * rhs_count)
                        .map(|i| (((i * 17 + case * 11) % 37) as f64 - 18.0) * scale)
                        .collect();
                    for tolerance in [0.0, 1e-12, 0.25] {
                        let mut expected_matrix = matrix.clone();
                        let mut expected_rhs = rhs.clone();
                        let mut actual_matrix = matrix.clone();
                        let mut actual_rhs = rhs.clone();
                        let expected_rank = legacy_dynamic_solve(
                            &mut expected_matrix,
                            &mut expected_rhs,
                            dimension,
                            rhs_count,
                            tolerance,
                        )
                        .unwrap();
                        let actual_rank = solve_linear_system(
                            &mut actual_matrix,
                            &mut actual_rhs,
                            dimension,
                            rhs_count,
                            tolerance,
                        )
                        .unwrap();
                        assert_eq!(actual_rank, expected_rank);
                        assert_eq!(
                            actual_matrix
                                .iter()
                                .map(|x| x.to_bits())
                                .collect::<Vec<_>>(),
                            expected_matrix
                                .iter()
                                .map(|x| x.to_bits())
                                .collect::<Vec<_>>()
                        );
                        assert_eq!(
                            actual_rhs.iter().map(|x| x.to_bits()).collect::<Vec<_>>(),
                            expected_rhs.iter().map(|x| x.to_bits()).collect::<Vec<_>>()
                        );
                    }
                }
            }
        }
    }
}

#[test]
fn fixed_dimension_validation_precedes_mutation() {
    for dimension in 1..=5 {
        for invalid in 0..5 {
            let mut matrix = vec![2.0; dimension * dimension - usize::from(invalid == 0)];
            let mut rhs = vec![3.0; dimension * 2 - usize::from(invalid == 1)];
            let prior_matrix = matrix.clone();
            let prior_rhs = rhs.clone();
            let tolerance = match invalid {
                2 => -1.0,
                3 => f64::NAN,
                4 => f64::INFINITY,
                _ => 1e-12,
            };
            let error =
                solve_linear_system(&mut matrix, &mut rhs, dimension, 2, tolerance).unwrap_err();
            assert_eq!(error.code, ErrorCode::InvalidArgument);
            assert_eq!(matrix, prior_matrix);
            assert_eq!(rhs, prior_rhs);
        }
    }
}

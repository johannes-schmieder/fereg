import hashlib,json,statistics,sys
from pathlib import Path
sys.path.insert(0,'benchmarks/next_subsystem')
from summarize import summarize
from surface_audit import check
from audit import compare,exact_exports
root=Path('target/ts-multipartition-20260922')
result=dict(blocks={},rows=[],native_pass=0,native_exact=0,native_repeats=0,stock_pass=0,stock_checks=0,saved_exact=[],incomplete_attempts=[],attempt_statuses={},overlaps=0,monitor_errors=0)
for block in ['paired','fresh','fresh-remainder','controls']:
 folder=root/block
 summary=summarize(folder,'covrow1','rawtile1')
 (root/(block+'-summary-final.json')).write_text(json.dumps(summary,indent=2)+'\n')
 if block!='controls':
  audit=check(folder)
  (root/(block+'-surface-final.json')).write_text(json.dumps(audit,indent=2)+'\n')
 rows=json.loads((folder/'progress.json').read_text());plan=json.loads((folder/'plan.json').read_text())
 result['blocks'][block]=dict(completed=(folder/'complete.json').exists(),attempts=len(rows))
 for r in rows:
  result['attempt_statuses'][r['status']]=result['attempt_statuses'].get(r['status'],0)+1
  result['overlaps']+=len(r['overlaps']);result['monitor_errors']+=len(r['monitor_errors'])
 for req in (folder/'runs').glob('*/request.json'):
  if not req.with_name('result.json').exists():result['incomplete_attempts'].append(str(req.parent.relative_to(root)))
 for i,c in enumerate(summary['cells']):
  if not any(r['case']==i for r in rows):continue
  science=[];stock=[];peaks=[];deltas=[]
  for pair in c['pairs']:
   if pair['clean']:
    result['native_pass']+=pair['checks']['passed'];result['native_exact']+=pair['exact']['passed']
    peaks.append(pair['tracked_peak_bytes']['rawtile1']-pair['tracked_peak_bytes']['covrow1'])
    records={r['variant']:r for r in rows if r['case']==i and r['repetition']==pair['repetition']}
    deltas.append(1000*(records['rawtile1']['seconds']-records['covrow1']['seconds']))
    a,b=[folder/records[v]['result'] for v in ('covrow1','rawtile1')]
    if (a/'outputs.bin').exists():result['saved_exact'].append((a/'outputs.bin').read_bytes()==(b/'outputs.bin').read_bytes())
   science.append(pair['checks'])
  result['native_repeats']+=sum(x['checks']['passed'] for x in c['repeats'])
  for rep in range(plan['repeats']):
   attempts={r['variant']:folder/r['result'] for r in rows if r['case']==i and r['repetition']==rep}
   if 'rawtile1' in attempts and 'fixest' in attempts:
    v=compare(attempts['rawtile1'],attempts['fixest'],c['cell']['model']);stock.append(v);result['stock_pass']+=v['passed'];result['stock_checks']+=1
  medians={v:statistics.median(r['seconds'] for r in rows if r['case']==i and r['variant']==v and r['status']=='pass')*1000 for v in plan['variants'] if any(r['case']==i and r['variant']==v and r['status']=='pass' for r in rows)}
  out=dict(block=block,case=i,cell=c['cell'],medians_ms=medians,ratios=c['ratios'],deltas_ms=deltas,peak_deltas_bytes=peaks,science=science,stock=stock)
  result['rows'].append(out)
  print(block,i,medians,c['ratios'],'stock', [x['passed'] for x in stock], 'peaks',peaks)
(root/'results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print({k:v for k,v in result.items() if k not in ('rows','blocks')})

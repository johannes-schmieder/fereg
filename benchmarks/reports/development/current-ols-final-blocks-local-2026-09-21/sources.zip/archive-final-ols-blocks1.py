import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
base = repo / 'benchmarks/two_fe_dense'
sys.path.insert(0, str(base))
import archive_science

output = repo / 'benchmarks/reports/development/current-ols-final-blocks-local-2026-09-21'
assert (art / 'final-block-audit-complete1.json').exists()
labels = [f'final{block}-{inventory}' for block in [1, 2] for inventory in ['primary', 'holdout']]
audits = {label: json.loads((art / (label + '-inference1.json')).read_text()) for label in labels}
scores = {label: json.loads((art / (label + '-score1.json')).read_text()) for label in labels}
for label, audit in audits.items():
    count = 77 if label.endswith('primary') else 16
    assert audit['complete'] and audit['native_complete'] == audit['planned'] == count
    assert scores[label]['identity_audit_complete'] and scores[label]['completely_measured'] == count
archive_science.archive([repo / 'target/g21final1', repo / 'target/g21final2'], output,
                        compact=True, omit_output_arrays=True)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def portable(raw):
    return raw.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>').replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')

tables = {kind: {} for kind in ['sources', 'checks']}
with zipfile.ZipFile(output / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw)
        bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    variant = 'owf1'
    identity_path = art / f'identity-{variant}.json'
    identity = json.loads(identity_path.read_text())
    add(identity_path.name, identity_path.read_bytes())
    raw = subprocess.check_output(['git', 'archive', identity['base_commit'], 'Cargo.toml', 'Cargo.lock',
        'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        original = {entry.name: sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
    for relative, digest in identity['source'].items():
        raw = (art / variant / relative).read_bytes()
        assert sha(raw) == digest
        if original.get(relative) != digest:
            add(variant + '/' + relative, raw)
    for name in ['audit_milestone.py', 'audit_outputs.py', 'graph_oracle.py', 'run.py', 'route_development.py',
                 'score.py', 'broad.py', 'broad_milestone.json', 'broad_holdouts.json', 'archive_science.py']:
        add(name, (base / name).read_bytes())
    for name in ['final-ols-blocks1.py', 'audit-final-blocks1.py', 'archive-final-ols-blocks1.py']:
        add(name, (art / name).read_bytes())
    add('test_graph_inventory_audit.py', (repo / 'tests/python/test_graph_inventory_audit.py').read_bytes())
    with zipfile.ZipFile(repo / 'benchmarks/reports/development/current-ols-primary-screen-local-2026-09-21/sources.zip') as prior:
        add('cached-primary-audit_milestone.py', prior.read('audit_milestone.py'))
with zipfile.ZipFile(output / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    paths = {art / name for name in ['final-candidate-freeze1.json', 'final-block-audit-complete1.json',
        'current-primary-inference1.json', 'graph-oracle-cache-tests2.json', 'graph-oracle-cache-tests2.txt',
        'final-block1.txt', 'final-block2.txt', 'build-owf1-controller1.txt']}
    for label in labels:
        paths.update(art.glob(label + '-*1.json'))
        paths.update(art.glob(label + '-*1.txt'))
    paths.update(art.glob('owf1-*-tests1.txt'))
    for path in sorted(paths):
        raw = path.read_bytes()
        clean = portable(raw)
        bundle.writestr(path.name, clean)
        tables['checks'][path.name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
for kind, table in tables.items():
    (output / (kind + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')

verifier = (repo / 'benchmarks/reports/development/current-ols-primary-screen-local-2026-09-21/verify.py').read_text()
verifier = verifier.replace("['in1']", "['owf1']")
verifier = verifier.replace("['current-primary-inference1.json']", repr(['current-primary-inference1.json'] + [label + '-inference1.json' for label in labels]))
verifier = verifier.replace('current-ols-primary-archive-integrity-v1', 'current-ols-final-blocks-archive-integrity-v1')
verifier = verifier.replace('CURRENT_OLS_PRIMARY_ARCHIVE_INTEGRITY_PASS', 'CURRENT_OLS_FINAL_BLOCKS_ARCHIVE_INTEGRITY_PASS')
extra = '''with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    checks = json.loads((folder / 'checks-hashes.json').read_text())
    for block in [1, 2]:
        for inventory in ['primary', 'holdout']:
            label = f'final{block}-{inventory}'
            audit = json.loads(bundle.read(label + '-inference1.json'))
            cache = 'final1-holdout-inference1.json' if block == 2 and inventory == 'holdout' else 'current-primary-inference1.json'
            assert audit['oracle_cache_sha256'] == checks[cache]['original_sha256']
            score = json.loads(bundle.read(label + '-score1.json'))
            assert score['identity_audit_complete'] and score['candidate_plugin'] == sources[0]['plugin']
    freeze = json.loads(bundle.read('final-candidate-freeze1.json'))
    assert freeze['plugin'] == sources[0]['plugin']
    assert freeze['controller_sha256'] in known_sources

'''
assert verifier.count('receipt = dict(') == 1
(output / 'verify.py').write_text(verifier.replace('receipt = dict(', extra + 'receipt = dict('))

summary_rows = []
for label in labels:
    score, audit = scores[label], audits[label]
    references = [attempt for cell in audit['records'] for attempt in cell['attempts'] if attempt['variant'] == 'fixest']
    ref_pass = sum(attempt['status'] == 'pass' for attempt in references)
    summary_rows.append(f"| {label} | {score['planned']} | {score['wins']} | {score['ties']} | {score['losses']} | {score['timing_eligible']} | {score['worst_ratio']:.5f} | {ref_pass}/{len(references) - ref_pass} |")
detail_rows = []
for inventory in ['primary', 'holdout']:
    first, second = [scores[f'final{block}-{inventory}']['cells'] for block in [1, 2]]
    for a, b in zip(first, second):
        assert a['index'] == b['index'] and a['cell'] == b['cell']
        cell = a['cell']
        detail_rows.append(f"| {inventory} {a['index']} | {cell['design']} | {cell['weight_kind']} | {cell['k']} | {cell['shuffled']} | {cell['case']} | {a['candidate_median_seconds'] * 1000:.0f}/{a['comparator_median_seconds'] * 1000:.0f} | {a['median_paired_ratio']:.5f} | {b['candidate_median_seconds'] * 1000:.0f}/{b['comparator_median_seconds'] * 1000:.0f} | {b['median_paired_ratio']:.5f} |")
repeats = sum(len(cell['repeated_native_exports']) for audit in audits.values() for cell in audit['records'])
outputs = sum(len(json.loads((repo / 'target' / f'g21final{block}' / f'final{block}-{inventory}-owf1-independent-outputs.json').read_text()))
              for block in [1, 2] for inventory in ['primary', 'holdout'])
(output / 'README.md').write_text(f'''# Current OLS final Mac timing blocks

The frozen owf1 candidate completes two independent five-pair blocks on the
unchanged 77 primary and sixteen holdout cells: 1,860 application calls.
The full timing and scientific records, including reference discrepancies,
are preserved. These blocks concern the captured Mac artifact, not completion
of the broader slope, coverage, routing and Linux milestone.

| Block | Cells | Wins | Ties | Losses | Clean cells | Worst paired ratio | Reference inference pass/discrepancy |
|---|---:|---:|---:|---:|---:|---:|---:|
''' + '\n'.join(summary_rows) + f'''

All 186 independent native inference checks, {repeats} exact within-arm repeat
checks and {outputs} independent saved-output audits pass. The optional cache
reuses only source-bound independent weighted dummy equations for byte-identical
input and weight/VCE. New holdout inputs receive fresh solves; every new native
export is checked. The runtime residual certificates are unchanged. Default
fixest discrepancies remain separate from timing results.

The candidate includes the scoped serial OLS memory window and the preceding
residual traversal. The rejected narrow residual experiment and unaccepted cycle
routing experiment are absent. Fresh routing seeds remain untouched. These
blocks do not resolve serial weighted slopes, constrained weighted fits,
cross-platform routing or the remaining current-candidate control/coverage work.

| Cell | Graph | Weight | K | Shuffled | Request | Block 1 fereg/fixest ms | Paired ratio | Block 2 fereg/fixest ms | Paired ratio |
|---|---|---|---:|---|---|---:|---:|---:|---:|
''' + '\n'.join(detail_rows) + '''

`verify.py` checks portable hashes, reconstructs the complete captured source,
binds independent auditor sources and verifies cached-oracle provenance. Large
output arrays stay local with explicit hashes. Raw licensed logs and compiled
binaries are excluded. No release, push or installation is performed.
''')
print('CURRENT_OLS_FINAL_BLOCKS_ARCHIVE_PREPARED')

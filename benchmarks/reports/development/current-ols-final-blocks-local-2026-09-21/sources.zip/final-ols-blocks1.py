import json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];artifacts=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad
import route_development as route
block=int(sys.argv[1]);assert block in [1,2]
freeze=json.loads((artifacts/'final-candidate-freeze1.json').read_text())
assert broad.sha(Path(__file__))==freeze['controller_sha256']
identity_path=artifacts/'identity-owf1.json';assert broad.sha(identity_path)==freeze['identity_sha256']
assert broad.sha(artifacts/'owf1/dist/fereg_macos.plugin')==freeze['plugin']
root=repo/'target'/f'g21final{block}';root.mkdir(exist_ok=True)
source=root/'execution-source.py'
if source.exists():assert source.read_bytes()==Path(__file__).read_bytes()
else:source.write_bytes(Path(__file__).read_bytes())
completions=[]
for inventory,manifest_name,count in [('primary','broad_milestone.json',77),('holdout','broad_holdouts.json',16)]:
 manifest=repo/'benchmarks/two_fe_dense'/manifest_name
 assert broad.sha(manifest)==freeze['manifests'][manifest_name]
 spec=json.loads(manifest.read_text());cells=broad.expand(spec,'primary');assert len(cells)==count
 assert not any(c['seed'] in freeze['untouched_routing_seeds'] for c in cells)
 label=f'final{block}-{inventory}'
 plan=dict(schema='two-fe-broad-execution-v1',label=label,phase='block-a' if block==1 else 'block-b',
  inventory_kind='primary',repetitions=5,variants=['owf1','fixest'],manifest=spec,manifest_sha256=broad.sha(manifest),
  controller_sha256=broad.sha(Path(__file__)),cell_runner_sha256=freeze['cell_runner_sha256'],
  isolation_source_sha256=freeze['isolation_source_sha256'],cells=cells,
  candidate_freeze_sha256=broad.sha(artifacts/'final-candidate-freeze1.json'),
  purpose='Frozen candidate final five-pair block. Preserve all 77 primary and 16 holdout cells, default reference disagreements and every failure; no fresh routing seed.')
 plan_path=root/(label+'-plan.json');progress_path=root/(label+'-progress.json')
 if plan_path.exists():assert json.loads(plan_path.read_text())==plan
 else:
  assert not progress_path.exists();broad.write(plan_path,plan)
 progress=json.loads(progress_path.read_text()) if progress_path.exists() else []
 assert [r['index'] for r in progress]==list(range(len(progress)))
 for index,cell in enumerate(cells[len(progress):],start=len(progress)):
  assert broad.sha(repo/'benchmarks/two_fe_dense/run.py')==freeze['cell_runner_sha256']
  assert broad.sha(Path(route.__file__))==freeze['isolation_source_sha256']
  assert broad.sha(Path(broad.__file__))==freeze['broad_source_sha256']
  cell_label=f'{label}-c{index:03d}';output=root/(cell_label+'.stdout.txt');assert not output.exists()
  command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),'--artifacts',str(artifacts),
   '--label',cell_label,'--variants',*plan['variants'],'--repeats','5','--timeout','240','--keep-going',
   '--record-reference-science-disagreement','--record-reference-output-disagreement',*broad.arguments(cell)]
  code,isolation=route.invoke(command,output);completion=root/(cell_label+'-complete.json')
  status=json.loads(completion.read_text())['status'] if completion.exists() else 'incomplete'
  progress.append(dict(index=index,label=cell_label,cell=cell,command=command,process_returncode=code,
   comparison_status=status,stdout_sha256=broad.sha(output),timing_isolation=isolation))
  broad.write(progress_path,progress)
  print(block,inventory,index+1,'/',count,code,status,isolation['status'],flush=True)
 result=dict(status='attempts_complete',attempted=len(progress),planned=len(cells),
  process_failures=sum(c['process_returncode']!=0 for c in progress),
  plan_sha256=broad.sha(plan_path),progress_sha256=broad.sha(progress_path))
 broad.write(root/(label+'-complete.json'),result);completions.append(result)
broad.write(root/f'final{block}-block-complete.json',dict(status='attempts_complete',planned=93,
 attempted=sum(c['attempted'] for c in completions),process_failures=sum(c['process_failures'] for c in completions),
 freeze_sha256=broad.sha(artifacts/'final-candidate-freeze1.json')))
print('FINAL_OLS_BLOCK_ATTEMPTS_COMPLETE',block,flush=True)
if any(c['process_failures'] for c in completions):raise SystemExit(1)

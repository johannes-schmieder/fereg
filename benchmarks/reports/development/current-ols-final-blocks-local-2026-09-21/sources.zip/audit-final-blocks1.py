import json,os,subprocess,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921';base=repo/'benchmarks/two_fe_dense'
for block in [1,2]:
 complete=json.loads((repo/'target'/f'g21final{block}'/f'final{block}-block-complete.json').read_text())
 assert complete['attempted']==complete['planned']==93
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
results=[]
for block in [1,2]:
 root=repo/'target'/f'g21final{block}'
 for inventory,count in [('primary',77),('holdout',16)]:
  label=f'final{block}-{inventory}';prefix=art/label
  score=art/(label+'-score1.json');audit=art/(label+'-inference1.json')
  commands=[('score',[sys.executable,str(base/'score.py'),str(root),label,str(score)])]
  cache=art/'current-primary-inference1.json'
  prior=art/'final1-holdout-inference1.json'
  if block==2 and inventory=='holdout' and prior.exists():
   old=json.loads(prior.read_text())
   if old['complete'] and old['native_complete']==old['planned']==16:cache=prior
  commands.append(('inference',[sys.executable,str(base/'audit_milestone.py'),str(root),label,str(audit),'--oracle-cache',str(cache)]))
  commands.append(('outputs',[sys.executable,str(base/'audit_outputs.py'),str(root),label,'owf1']))
  for kind,command in commands:
   path=art/(label+'-'+kind+'1.txt')
   with path.open('x') as stream:
    process=subprocess.run(command,cwd=repo,stdout=stream,stderr=subprocess.STDOUT)
   results.append(dict(block=block,inventory=inventory,kind=kind,process_returncode=process.returncode))
   print(block,inventory,kind,process.returncode,flush=True)
   if process.returncode:raise SystemExit(process.returncode)
  numeric=json.loads(audit.read_text());timing=json.loads(score.read_text())
  print('FINAL_BLOCK_RESULT',block,inventory,'science',numeric['native_complete'],'/',count,
        'wins',timing['wins'],'ties',timing['ties'],'losses',timing['losses'],
        'eligible',timing['timing_eligible'],'worst',timing['worst_ratio'],flush=True)
output=art/'final-block-audit-complete1.json';assert not output.exists()
output.write_text(json.dumps(dict(status='attempts_complete',records=results),indent=2)+'\n')

import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo = Path(__file__).resolve().parents[2]; art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science
out = repo / 'benchmarks/reports/development/serial-slope-packed-cache-profile-local-2026-09-22'
roots = [art / f'sp2d-profile-{label}-1' for label in ['aw-k10', 'pw-k6', 'aw-k50']]
archive_science.archive(roots, out, compact=True, omit_output_arrays=True)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>').replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')
tables = {'sources': {}, 'checks': {}}
with zipfile.ZipFile(out / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['rrc1', 'sp2d']:
        p = art / f'identity-{variant}.json'; identity = json.loads(p.read_text()); add(p.name, p.read_bytes())
        raw = subprocess.check_output(['git', 'archive', identity['base_commit'], 'Cargo.toml', 'Cargo.lock', 'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as tree:
            base = {e.name: sha(tree.extractfile(e).read()) for e in tree.getmembers() if e.isfile()}
        for relative, digest in identity['source'].items():
            raw = (art / variant / relative).read_bytes(); assert sha(raw) == digest
            if base.get(relative) != digest: add(variant + '/' + relative, raw)
    for name in ['sp2d-profile1.py', 'audit-sp2d-profiles1.py', 'audit-sp2d-profiles2.py', 'archive-sp2d.py']:
        add(name, (art / name).read_bytes())
    for relative in ['one_fe_optimization/build.py', 'one_fe_breadth/profile.py', 'one_fe_profile/slope_instrument.py',
        'one_fe_profile/slopes.py', 'one_fe_profile/slope_breadth.py', 'one_fe_profile/run.py', 'one_fe_breadth/run.py',
        'systematic/generate.py', 'two_fe_dense/archive_science.py',
        *['local_fixest_gap/' + name for name in ['common.py', 'measure.py', 'r_worker.R', 'stata_worker.do']]]:
        add(relative, (repo / 'benchmarks' / relative).read_bytes())
with zipfile.ZipFile(out / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add_check(name, raw, **extra):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean), **extra)
    for p in sorted(art.glob('sp2d-*')):
        if p.is_file() and p.suffix in ['.json', '.txt'] and 'archive' not in p.name:
            add_check(p.name, p.read_bytes())
    add_check('build-sp2d.log', (art / 'build-sp2d.log').read_bytes())
    for root in roots:
        for p in sorted((root / 'runs').glob('*/stderr.txt')):
            raw = p.read_bytes()
            filtered = ('\n'.join(line for line in raw.decode().splitlines() if line.startswith(('FEREG_PHASE|', 'SLOPE_PROFILE|'))) + '\n').encode()
            add_check(root.name + '/' + p.parent.name + '/native-trace.txt', filtered, original_stream_sha256=sha(raw))
for kind, table in tables.items(): (out / (kind + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')
template = (repo / 'benchmarks/reports/development/serial-slope-recovery-row-cache-local-2026-09-22/verify.py').read_text()
template = template.replace("['rgc1', 'rrc1']", "['rrc1', 'sp2d']")
start = template.index("with zipfile.ZipFile(folder / 'checks.zip') as bundle:", template.index('known_sources ='))
end = template.index('\nreceipt =', start)
checks = """with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    profile = json.loads(bundle.read('sp2d-profile-check2.json'))
    assert profile['status'] == 'pass' and len(profile['records']) == 3
    assert profile['source_sha256'] in known_sources
    for record in profile['records']:
        assert all(record['exact'].values())
        if 'aw-k50' in record['root']:
            assert not record['measured_cache_traces']['sp2d']
        else:
            assert record['measured_cache_traces']['sp2d']
            assert all(int(trace['n']) == 245760 for trace in record['measured_cache_traces']['sp2d'])

"""
template = template[:start] + checks + template[end:]
template = template.replace('recovery-row-cache-archive-integrity-v1', 'packed-score-cache-profile-integrity-v1').replace('RECOVERY_ROW_CACHE_ARCHIVE_INTEGRITY_PASS', 'PACKED_SCORE_CACHE_PROFILE_INTEGRITY_PASS')
(out / 'verify.py').write_text(template)
print('PACKED_SCORE_CACHE_PROFILE_ARCHIVE_PREPARED')

import subprocess, sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
for weight, k, count in [('aw', 10, 1), ('pw', 6, 3), ('aw', 50, 1)]:
    name = f'sp2d-profile-{weight}-k{k}-1'
    assert not (art / name).exists()
    command = [sys.executable, str(repo / 'benchmarks/one_fe_profile/slope_breadth.py'), str(art / name),
        '--artifacts', str(art), '--fixest-archive', str(repo / 'target/one-fe-profile-20260919/fixest.tar.gz'),
        '--variants', 'rrc1', 'sp2d', '--n', '245760', '--widths', str(k), '--threads', '1',
        '--cases', 'robust_outputs', '--repeats', '1',
        '--weight-kind', weight, '--slope-count', str(count), '--trace']
    if weight == 'pw':
        command.append('--slope-only')
    with (art / (name + '.txt')).open('x') as stream:
        result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    print(name, result.returncode, flush=True)
    assert result.returncode == 0

import hashlib, json
from pathlib import Path

art = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
records = []
for label in ['aw-k10', 'pw-k6', 'aw-k50']:
    root = art / f'sp2d-profile-{label}-1'
    plan = json.loads((root / 'plan.json').read_text())
    assert json.loads((root / 'complete.json').read_text())['status'] == 'pass'
    runs = {v: root / 'runs' / f'c000-r0-{v}' for v in plan['variants']}
    results = {v: json.loads((p / 'result.json').read_text()) for v, p in runs.items()}
    assert all(r['status'] == 'pass' and r['sentinel'] and r['process_returncode'] == 0 for r in results.values())
    assert len({r['sample_sha256'] for r in results.values()}) == 1
    assert len({r['input_sha256'] for r in results.values()}) == 1
    phases = {}
    for v in plan['variants']:
        assert results[v]['measurement_fingerprint']['native'] == json.loads((art / f'identity-{v}.json').read_text())
        phases[v] = {}
        for line in (runs[v] / 'stderr.txt').read_text().splitlines():
            if line.startswith(('FEREG_PHASE|', 'SLOPE_PROFILE|')):
                parts = line.split('|')
                phases[v][parts[0] + '/' + parts[1]] = dict(p.split('=', 1) for p in parts[2:])
    exact = {name: len({sha(p / name) for p in runs.values()}) == 1
        for name in ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv', 'outputs.bin']}
    assert all(exact.values()), exact
    assert 'SLOPE_PROFILE/direct_recovery' in phases['sp2d']
    assert 'SLOPE_PROFILE/packed_score_cache' in phases['sp2d']
    records.append(dict(root=root.name, exact=exact, phases=phases,
        result_sha256={v: sha(p / 'result.json') for v, p in runs.items()},
        stderr_sha256={v: sha(p / 'stderr.txt') for v, p in runs.items()}))
out = art / 'sp2d-profile-check1.json'
assert not out.exists()
out.write_text(json.dumps(dict(schema='packed-score-cache-profile-check-v1', status='pass',
    source_sha256=sha(Path(__file__)), records=records,
    limitation='Single diagnostic traces; not headline timing evidence.'), indent=2) + '\n')
print('PACKED_SCORE_CACHE_PROFILE_CHECK_PASS', len(records))

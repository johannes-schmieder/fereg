import hashlib
import json
from pathlib import Path
import sys
import zipfile

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science

output = repo / 'benchmarks/reports/development/ring-cycle-route-calibration-local-2026-09-21'
archive_science.archive([repo / 'target' / f'g21r{threads}' for threads in [16, 8, 1]],
                      output, compact=True, omit_output_arrays=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def portable(data):
    return data.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>')

tables = {'sources': {}, 'checks': {}}
for kind in tables:
    with zipfile.ZipFile(output / (kind + '.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        def add(name, path):
            raw = path.read_bytes()
            clean = portable(raw)
            bundle.writestr(name, clean)
            tables[kind][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
        if kind == 'sources':
            identity = json.loads((artifacts / 'identity-m5.json').read_text())
            add('identity-m5.json', artifacts / 'identity-m5.json')
            for relative in identity['overlays']:
                path = artifacts / 'm5' / relative
                assert sha(path.read_bytes()) == identity['source'][relative]
                add('m5/' + relative, path)
            for name in ['route_development.py', 'run.py']:
                add(name, repo / 'benchmarks/two_fe_dense' / name)
            for name in ['ring-cycle-route-expansion1.py', 'archive-ring-cycle-routes1.py']:
                add(name, artifacts / name)
            for threads in [16, 8, 1]:
                path = artifacts / f'ring-cycle-route-t{threads}-audit-source1.py'
                audit = json.loads((artifacts / f'ring-cycle-route-t{threads}-audit1.json').read_text())
                assert sha(path.read_bytes()) == audit['controller_sha256']
                add(path.name, path)
        else:
            for threads in [16, 8, 1]:
                for suffix in ['audit1.json', 'audit1.txt']:
                    path = artifacts / f'ring-cycle-route-t{threads}-{suffix}'
                    add(path.name, path)
            for name in ['ring-cycle-route-expansion-plan1.json',
                         'ring-cycle-route-expansion-progress1.json']:
                add(name, artifacts / name)
    (output / (kind + '-hashes.json')).write_text(json.dumps(tables[kind], indent=2) + '\n')
print('RING_CYCLE_ROUTE_SUPPLEMENTS_COMPLETE', flush=True)

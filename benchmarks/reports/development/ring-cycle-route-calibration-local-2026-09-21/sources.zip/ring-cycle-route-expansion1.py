import json
from pathlib import Path
import subprocess
import sys

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
records = []
for threads in [16, 8, 1]:
    root = repo / f'target/g21r{threads}'
    command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/route_development.py'),
        str(root), '--artifacts', str(artifacts), '--candidate', 'm5',
        '--indices', *map(str, range(64, 80)), '--families', 'auto', 'lsmr',
        '--threads', str(threads), '--repeats', '3', '--timeout', '60']
    output = artifacts / f'ring-cycle-route-t{threads}-controller1.txt'
    with output.open('x') as stream:
        code = subprocess.call(command, stdout=stream, stderr=subprocess.STDOUT)
    if not root.exists():
        raise RuntimeError(f'Route controller did not create {root}')
    (root / 'expansion-execution-source.py').write_bytes(Path(__file__).read_bytes())
    audit = artifacts / f'ring-cycle-route-t{threads}-audit1.json'
    audit_output = artifacts / f'ring-cycle-route-t{threads}-audit1.txt'
    with audit_output.open('x') as stream:
        audit_code = subprocess.call([sys.executable,
            str(repo / 'benchmarks/two_fe_dense/audit_routes.py'), str(root), str(audit)],
            stdout=stream, stderr=subprocess.STDOUT)
    record = dict(threads=threads, root=str(root), controller_returncode=code,
                  audit_returncode=audit_code)
    records.append(record)
    (artifacts / 'ring-cycle-route-expansion-progress1.json').write_text(
        json.dumps(records, indent=2) + '\n')
    print(record, flush=True)
    if code or audit_code:
        raise RuntimeError('Inspect failed route stage before continuing.')
print('RING_CYCLE_ROUTE_EXPANSION_COMPLETE', flush=True)

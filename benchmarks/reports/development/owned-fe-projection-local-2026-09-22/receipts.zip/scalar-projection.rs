pub fn project_effect_in_place(
    effect: &EffectTerm,
    weights: &[f64],
    values: &mut DenseMatrix,
    workspace: &mut ProjectionWorkspace,
) -> Result<()> {
    if weights.len() != values.nrows() || effect.codes().len() != values.nrows() {
        return Err(FeregError::new(
            ErrorCode::InvalidArgument,
            "projection inputs have inconsistent observation counts",
        ));
    }
    if weights
        .iter()
        .any(|weight| !weight.is_finite() || *weight <= 0.0)
    {
        return Err(FeregError::new(
            ErrorCode::InvalidData,
            "projection weights must be finite and positive",
        ));
    }
    let channels = effect.channels();
    let rhs_count = values.ncols();
    if channels > workspace.max_channels || rhs_count > workspace.rhs_count {
        return Err(FeregError::new(
            ErrorCode::InvalidArgument,
            "projection workspace is smaller than the requested projection",
        ));
    }

    for level in 0..effect.n_levels() {
        let gram_length = channels * channels;
        let rhs_length = channels * rhs_count;
        workspace.gram[..gram_length].fill(0.0);
        workspace.right_hand_sides[..rhs_length].fill(0.0);

        for observation in effect.level_index().members(level) {
            let weight = weights[*observation];
            for left_channel in 0..channels {
                let left_basis = effect.basis_value(left_channel, *observation);
                for right_channel in 0..channels {
                    let right_basis = effect.basis_value(right_channel, *observation);
                    let index = left_channel * channels + right_channel;
                    workspace.gram[index] =
                        (weight * left_basis).mul_add(right_basis, workspace.gram[index]);
                }
                for rhs in 0..rhs_count {
                    let index = left_channel * rhs_count + rhs;
                    workspace.right_hand_sides[index] = (weight * left_basis).mul_add(
                        values[(*observation, rhs)],
                        workspace.right_hand_sides[index],
                    );
                }
            }
        }

        solve_linear_system(
            &mut workspace.gram[..gram_length],
            &mut workspace.right_hand_sides[..rhs_length],
            channels,
            rhs_count,
            1e-12,
        )?;

        for observation in effect.level_index().members(level) {
            for rhs in 0..rhs_count {
                let mut fitted = 0.0;
                for channel in 0..channels {
                    fitted = effect.basis_value(channel, *observation).mul_add(
                        workspace.right_hand_sides[channel * rhs_count + rhs],
                        fitted,
                    );
                }
                values[(*observation, rhs)] -= fitted;
            }
        }
    }
    Ok(())
}

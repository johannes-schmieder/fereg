"""Independent diagnosis; retain the original exact-rank covariance failure."""
import itertools,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
sys.path.insert(0,'benchmarks/next_subsystem')
from surface_audit import absorbed_design
from surface import columns
from oracle import solve
from audit import distance
r=Path('target/owned-geometry-20260922');root=r/'pilot-extra'
cell=json.loads((root/'plan.json').read_text())['cells'][0]
f=pd.read_stata(root/'data/c0-full.dta',convert_categoricals=False)
counts={e:int(f[e].nunique()) for e in cell['effects']}
components={}
for a,b in itertools.combinations(cell['effects'],2):
 ia=pd.factorize(f[a],sort=True)[0];ib=pd.factorize(f[b],sort=True)[0]+counts[a]
 adjacency=coo_matrix((np.ones(2*len(f)),(np.r_[ia,ib],np.r_[ib,ia])),shape=(counts[a]+counts[b],)*2).tocsr()
 components[a+'+'+b]=int(connected_components(adjacency,directed=False,return_labels=False))
assert set(components.values())=={1}
local_rank={}
for e in cell['effects']:
 names=cell['slope_partitions'][e]
 ranks=[int(np.linalg.matrix_rank(np.column_stack([np.ones(len(g))]+[g[z].to_numpy() for z in names]))) for _,g in f.groupby(e)]
 assert set(ranks)=={1+len(names)}
 local_rank[e]=sum(ranks)
# The registered pairwise/continuous rule removes two intercept redundancies;
# all within-group slope channels are nonconstant. It does not count a shared
# global z1 across two different partitions as another redundancy.
policy_count=sum(local_rank.values())-2
F,rank=absorbed_design(f,cell)
assert policy_count==316 and rank==315
null=np.zeros(F.shape[1]);offset=0
for e in cell['effects']:
 for j,name in enumerate(['intercept']+cell['slope_partitions'][e]):
  if name=='z1':null[offset+j*counts[e]:offset+(j+1)*counts[e]] = 1.0 if e=='g1' else -1.0
 offset+=counts[e]*(1+len(cell['slope_partitions'][e]))
assert np.count_nonzero(null)>0 and np.max(np.abs(F@null))==0.0
X=columns(f,cell);y=f.y.to_numpy();n,k=X.shape
Z=np.column_stack([X[:,j]-F@solve(F,X[:,j]) for j in range(k)])
u=y-F@solve(F,y);b=np.linalg.lstsq(Z,u,rcond=None)[0];res=u-Z@b
bread=np.linalg.inv(Z.T@Z);influence=(Z@bread)*res[:,None]
V=influence.T@influence*n/(n-policy_count-k)
checks={}
for variant in ['rawtile1','projrow1','fixest']:
 p=root/f'runs/c0-r0-{variant}';metadata=json.loads((p/'result.json').read_text())['metadata']
 actual=pd.read_csv(p/'covariance.csv').pivot(index='row',columns='column',values='value').loc[cell['coefficient_names'],cell['coefficient_names']]
 dof=(metadata['df_k']==policy_count+k if variant=='fixest' else metadata['df_a']==policy_count and metadata['df_r']==n-policy_count-k)
 checks[variant]=dict(dof_matches_independent_policy=dof,covariance=distance(actual,V,1e-6))
 assert dof and checks[variant]['covariance']['passed']
record=dict(scope='Supplemental policy diagnosis, not a changed oracle or tolerance; original exact-rank V failures remain.',accepted_basis='ADR 0006 conservative absorbed DoF; registered default pairwise/continuous policy',group_counts=counts,pair_components=components,full_local_rank=local_rank,explicit_fe_rank=rank,conservative_policy_count=policy_count,exact_rank_df=n-rank-k,policy_df=n-policy_count-k,shared_global_z1_dependency=True,checks=checks)
(r/'three-slope-dof-audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))

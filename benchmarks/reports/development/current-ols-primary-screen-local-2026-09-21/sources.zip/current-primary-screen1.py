import json
from pathlib import Path
import sys
repo=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad
import route_development as route
artifacts=repo/'target/ols-next-20260921';root=repo/'target/g21pri1';label='primary1'
root.mkdir(exist_ok=False)
manifest=repo/'benchmarks/two_fe_dense/broad_milestone.json'
spec=json.loads(manifest.read_text());milestone=json.loads((repo/'benchmarks/manifests/ols_optimization_20260921_v1.json').read_text())
assert broad.sha(manifest)==milestone['protection']['primary_manifest_sha256']
cells=broad.expand(spec,'primary');assert len(cells)==77
plan=dict(schema='two-fe-broad-execution-v1',label=label,phase='screen',inventory_kind='primary',
 repetitions=3,variants=['in1','fixest'],manifest=spec,manifest_sha256=broad.sha(manifest),
 controller_sha256=broad.sha(Path(__file__)),cell_runner_sha256=broad.sha(repo/'benchmarks/two_fe_dense/run.py'),
 isolation_source_sha256=broad.sha(Path(route.__file__)),cells=cells,
 purpose='Three-pair current-kernel training screen of all unchanged primary cells. Not a final block; no fresh routing seed.')
broad.write(root/(label+'-plan.json'),plan);(root/'execution-source.py').write_bytes(Path(__file__).read_bytes())
progress=[]
for index,cell in enumerate(cells):
 cell_label=f'{label}-c{index:03d}';output=root/(cell_label+'.stdout.txt')
 command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),'--artifacts',str(artifacts),
 '--label',cell_label,'--variants',*plan['variants'],'--repeats','3','--timeout','240','--keep-going',
 '--record-reference-science-disagreement','--record-reference-output-disagreement',*broad.arguments(cell)]
 code,isolation=route.invoke(command,output)
 complete=root/(cell_label+'-complete.json')
 status=json.loads(complete.read_text())['status'] if complete.exists() else 'incomplete'
 progress.append(dict(index=index,label=cell_label,cell=cell,command=command,process_returncode=code,
 comparison_status=status,stdout_sha256=broad.sha(output),timing_isolation=isolation))
 broad.write(root/(label+'-progress.json'),progress)
 print(index+1,'/',len(cells),cell_label,code,status,isolation['status'],flush=True)
broad.write(root/(label+'-complete.json'),dict(status='attempts_complete',attempted=len(progress),planned=len(cells),
 process_failures=sum(c['process_returncode']!=0 for c in progress),
 plan_sha256=broad.sha(root/(label+'-plan.json')),progress_sha256=broad.sha(root/(label+'-progress.json'))))
print('CURRENT_PRIMARY_SCREEN_ATTEMPTS_COMPLETE',flush=True)

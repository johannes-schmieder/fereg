import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2];artifacts=repo/'target/ols-next-20260921';root=repo/'target/g21pri1'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import archive_science
output=repo/'benchmarks/reports/development/current-ols-primary-screen-local-2026-09-21'
audit=json.loads((artifacts/'current-primary-inference1.json').read_text())
assert audit['complete'] and audit['planned']==audit['native_complete']==77
assert json.loads((root/'primary1-complete.json').read_text())['attempted']==77
archive_science.archive([root],output,compact=True,omit_output_arrays=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def portable(raw):return raw.replace(str(repo).encode(),b'<repository>').replace(str(Path.home()).encode(),b'<user-home>').replace(b'<stata-installation>',b'<stata-installation>').replace(b'<reference-library>',b'<reference-library>')
tables={kind:{} for kind in ['sources','checks']}
with zipfile.ZipFile(output/'sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 def add(name,raw):
  clean=portable(raw);z.writestr(name,clean);tables['sources'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
 variant='in1';p=artifacts/f'identity-{variant}.json';identity=json.loads(p.read_text());add(p.name,p.read_bytes())
 raw=subprocess.check_output(['/opt/homebrew/bin/git','archive',identity['base_commit'],'Cargo.toml','Cargo.lock','crates','plugin','stata','tests','scripts','references.lock.toml'],cwd=repo)
 with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
  base={e.name:sha(archive.extractfile(e).read()) for e in archive.getmembers() if e.isfile()}
 for relative,digest in identity['source'].items():
  data=(artifacts/variant/relative).read_bytes();assert sha(data)==digest
  if base.get(relative)!=digest:add(variant+'/'+relative,data)
 for name in ['audit_milestone.py','audit_outputs.py','graph_oracle.py','run.py','route_development.py','score.py','broad.py','broad_milestone.json','archive_science.py']:
  add(name,(repo/'benchmarks/two_fe_dense'/name).read_bytes())
 add('test_graph_inventory_audit.py',(repo/'tests/python/test_graph_inventory_audit.py').read_bytes())
 for name in ['current-primary-screen1.py','archive-current-primary3.py']:
  add(name,(artifacts/name).read_bytes())
with zipfile.ZipFile(output/'checks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for kind in ['score','inference','outputs','screen','auditor-tests']:
  for suffix in ['json','txt']:
   name=f'current-primary-{kind}1.{suffix}';p=artifacts/name
   if not p.exists():continue
   raw=p.read_bytes();clean=portable(raw);z.writestr(name,clean)
   tables['checks'][name]=dict(original_sha256=sha(raw),portable_sha256=sha(clean))
for kind,table in tables.items():(output/(kind+'-hashes.json')).write_text(json.dumps(table,indent=2)+'\n')
v=(repo/'benchmarks/reports/development/cycle-ols-lsmr-local-2026-09-21/verify.py').read_text()
start=v.index("with zipfile.ZipFile(folder / 'checks.zip') as bundle:\n    audit = json.loads(bundle.read('cycle-guard-routing1.json'))")
end=v.index('\nreceipt =',start)
v=v[:start]+v[end:]
for old,new in {"['in1', 'cy1']":"['in1']",'cycle-guard-inference1.json':'current-primary-inference1.json','cycle-ols-lsmr-archive-integrity-v1':'current-ols-primary-archive-integrity-v1','CYCLE_OLS_LSMR_ARCHIVE_INTEGRITY_PASS':'CURRENT_OLS_PRIMARY_ARCHIVE_INTEGRITY_PASS'}.items():
 assert old in v,old
 v=v.replace(old,new)
v=v.replace("'/opt/homebrew/bin/git'", "'git'")
v='\n'.join(line for line in v.splitlines() if "assert b'/Users/" not in line)+'\n'
v=v.replace('machine_home_path_scans=scans', 'supplement_hash_scans=scans')
(output/'verify.py').write_text(v)
score=json.loads((artifacts/'current-primary-score1.json').read_text())
references=[a for c in audit['records'] for a in c['attempts'] if a['variant']=='fixest']
ref_pass=sum(a['status']=='pass' for a in references);ref_fail=len(references)-ref_pass
repeats=sum(len(c['repeated_native_exports']) for c in audit['records'])
rows=[]
for r in score['cells']:
 c=r['cell'];rows.append(f"| {r['index']} | {c['design']} | {c['weight_kind']} | {c['k']} | {c['shuffled']} | {c['case']} | {1000*r['candidate_median_seconds']:.0f} | {1000*r['comparator_median_seconds']:.0f} | {r['median_paired_ratio']:.4f} |")
(output/'README.md').write_text(f'''# Current OLS primary training screen

The in1 kernel wins all 77 unchanged primary cells against pinned default
fixest in this three-pair screen. All 462 applications complete with no
detected timing overlap. Seventy-five cells meet the ten-percent target.
The smallest margins are unbalanced K6/AW (paired ratio 0.92208) and shuffled
K5/unit (0.91892). These are development screens, not the two final five-pair
blocks or a claim about every estimator/domain.

All 77 independent native inference checks, {repeats} exact within-arm repeat
checks and 24 independent saved-output audits pass. The reference inference
audits give {ref_pass} passes and {ref_fail} discrepancies. All reference
science/output disagreements remain recorded; timing does not adjudicate them.
The grounded sparse-direct oracle uses the original input and its own weighted
dummy equations, independently of native FE state.

The auditor supports both one-native primary and two-native paired inventories.
Its two focused fixtures cover separate reference discrepancies and missing,
extra, failed or changed native runs. Each native arm must contain exactly
the planned passing repeats; an extra run cannot offset a missing other arm.
Earlier v1 auditors and their historical receipts remain unchanged.

The captured in1 source predates the scoped serial-window and narrow-residual
experiments. No new routing guard, constrained-memory result or Linux
acceptance follows from this screen. Candidate allocation peaks are preserved
per pair; this comparison provides no native memory-neutrality claim.

| Index | Graph | Weight | K | Shuffled | Request | in1 ms | fixest ms | Paired ratio |
|---:|---|---|---:|---|---|---:|---:|---:|
'''+ '\n'.join(rows)+'''

`verify.py` checks archived hashes, the complete captured native source and
independent auditor bindings. Original output arrays remain local with hashes.
Raw licensed logs and compiled binaries are excluded. No push or installation
is part of this checkpoint.
''')
print('CURRENT_OLS_PRIMARY_ARCHIVE_PREPARED')

import json, sys, statistics, hashlib, re
from pathlib import Path
import pandas as pd
REPO=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(REPO/'benchmarks/next_subsystem'))
from audit import compare, read
from surface_audit import outputs, distance
root=Path(__file__).resolve().parent
records=[]; saved=[]; failures=[]
for block in ['paired','fresh','controls']:
 s=read(root/f'{block}-summary.json');p=read(root/block/'progress.json')
 assert all(r['status']=='pass' and not r['overlaps'] and not r['monitor_errors'] for r in p)
 for i,c in enumerate(s['cells']):
  direct=[]
  assert all(x['checks']['passed'] for x in c['pairs'])
  assert all(all(x['exact']['files'][f] for f in ['fereg_status.csv','fereg_dof.csv','fereg_subset.csv','fereg_fe.csv']) for x in c['pairs'])
  assert all(x['checks']['passed'] for x in c['repeats'])
  for rep in range(3):
   paths={r['variant']:root/block/r['result'] for r in p if r['case']==i and r['repetition']==rep}
   if 'fixest' in paths:
    checks=compare(paths['lowchol2'],paths['fixest'],'ols')
    if c['cell'].get('outputs')=='all':
     n=int(read(paths['lowchol2']/'result.json')['metadata']['N'])
     checks['outputs']=distance(outputs(paths['lowchol2'],n),outputs(paths['fixest'],n),1e-7,1e-9)
     checks['passed'] &= checks['outputs']['passed']
     hashes={v:hashlib.sha256((paths[v]/'outputs.bin').read_bytes()).hexdigest() for v in ['gramrow2','lowchol2']}
     native_outputs=distance(outputs(paths['lowchol2'],n),outputs(paths['gramrow2'],n),1e-7,1e-9)
     assert native_outputs['passed']
     saved.append(dict(block=block,case=i,repetition=rep,hashes=hashes,comparison=native_outputs))
    direct.append(checks)
    if not checks['passed']:failures.append(dict(block=block,case=i,repetition=rep,checks=checks))
  variants=['gramrow2','lowchol2']+(['fixest'] if block!='controls' else [])
  row=dict(block=block,case=i,cell=c['cell'],medians_ms={v:1000*statistics.median(r['seconds'] for r in p if r['case']==i and r['variant']==v) for v in variants},ratios=c['ratios'],direct_stock=direct,exact=[x['exact'] for x in c['pairs']],memory_deltas=[x['tracked_peak_bytes']['lowchol2']-x['tracked_peak_bytes']['gramrow2'] for x in c['pairs']])
  records.append(row)
  print(block,i,row['medians_ms'],row['ratios'],'memory',min(row['memory_deltas']),max(row['memory_deltas']),'stock',all(x['passed'] for x in direct))
# Diagnostic normalization only: original exported covariance remains authoritative.
b=root/'fresh/runs/c4-r0-lowchol2';f=root/'fresh/runs/c4-r0-fixest'
native=read(b/'result.json')['metadata'];stock=read(f/'result.json')['metadata']
names=read(root/'fresh/plan.json')['cells'][4]['coefficient_names']
def covariance(p):return pd.read_csv(p/'covariance.csv').pivot(index='row',columns='column',values='value').loc[names,names].to_numpy()
df_native=native['df_r'];df_stock=stock['N']-stock['df_k']
dof=dict(native_residual_df=df_native,stock_residual_df=df_stock,stock_to_native_covariance_multiplier=df_stock/df_native,diagnostic_rescaled_covariance=distance(covariance(b),covariance(f)*df_stock/df_native,1e-6),scope='Diagnostic only; unmodified stock comparison remains failed and timing unranked. No independent rank adjudication for this full-size topology.')
tests=set()
for path in root.glob('rust-*.log'):
 tests.update(re.findall(r'^test (\S+) \.\.\. ok$',path.read_text(),re.M))
result=dict(records=records,saved_output_identity=saved,stock_failures=failures,disconnected_dof_diagnostic=dof,rust_distinct_pass=len(tests),rust_tests=sorted(tests))
with (root/'results.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print('RUST_DISTINCT',len(tests));print('DOF_DIAGNOSTIC',dof)

import argparse, hashlib, json, os, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/one_fe_profile'))
import slope_breadth as run
p = argparse.ArgumentParser(); p.add_argument('weight', choices=['aw','pw']); p.add_argument('mode', choices=['control','sampled'])
a = p.parse_args(); sampled = a.mode == 'sampled'; repeats = 80 if sampled else 1
root = art / f'rps1-{a.weight}-{a.mode}1'
assert not root.exists()
os.environ['ONE_FE_PROFILE_REPEAT'] = str(repeats)
original_stage = run.stage

def stage(*args, **kwargs):
    folder = original_stage(*args, **kwargs)
    worker = folder / 'stata_worker.do'
    text = worker.read_text()
    needle = "local rc 0\nforvalues profile_j = 1/`profile_repeat' {"
    assert text.count(needle) == 1
    text = text.replace(needle,"local rc 0\nlocal profile_completed 0\nforvalues profile_j = 1/`profile_repeat' {")
    needle = " if `rc' continue, break\n}"
    assert text.count(needle) == 1
    text = text.replace(needle," if `rc' continue, break\n local ++profile_completed\n}")
    needle = 'file write `meta\' "fit_seconds"'
    assert text.count(needle) == 1
    text = text.replace(needle, 'file write `meta\' "profile_completed" _tab "`profile_completed\'" _n\n' + needle)
    worker.write_text(text)
    if sampled:
        path = folder / 'measure.py'; text = path.read_text()
        needle = '    maximum_rss = 0\n'; assert text.count(needle) == 1
        text = text.replace(needle, '    stack_sampler = None\n    stack_sampler_stream = None\n' + needle)
        needle = '            if active and started is None:\n                started = now\n'
        assert text.count(needle) == 1
        text = text.replace(needle, needle + '''                stack_sampler_stream = (output / "stack-sampler.txt").open("x")
                stack_command = ["/usr/bin/sample", str(process.pid), "20", "1", "-mayDie", "-file", str(output / "native-stacks.txt")]
                stack_sampler = subprocess.Popen(stack_command, stdout=stack_sampler_stream, stderr=subprocess.STDOUT)
                write_json(output / "stack-sampler-launch.json", dict(worker_pid=process.pid,
                    sampler_pid=stack_sampler.pid, command=stack_command,
                    scope="Owned Stata worker only, repeated-fit diagnostic; never headline timing evidence."))
''')
        needle = '    meta = metadata(output)\n'; assert text.count(needle) == 1
        text = text.replace(needle, '''    if stack_sampler is not None:
        try:
            stack_code = stack_sampler.wait(timeout=35)
        except subprocess.TimeoutExpired:
            stack_sampler.terminate()
            stack_code = stack_sampler.wait(timeout=5)
        stack_sampler_stream.close()
        write_json(output / "stack-sampler-complete.json", dict(returncode=stack_code,
            stack_sha256=sha256(output / "native-stacks.txt") if (output / "native-stacks.txt").exists() else None))
''' + needle)
        path.write_text(text)
    return folder
run.stage = stage
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
plan = art / f'rps1-{a.weight}-{a.mode}-plan1.json'
assert not plan.exists()
plan.write_text(json.dumps(dict(schema='ols-robust-stack-profile-v1', weight=a.weight, mode=a.mode,
    fits_per_worker=repeats, sampling_interval_ms=1 if sampled else None,
    sampling_duration_seconds=20 if sampled else None, controller_sha256=sha(Path(__file__)),
    identity_sha256=sha(art / 'identity-scb1.json'), headline_timing_eligible=False), indent=2)+'\n')
args=argparse.Namespace(root=root, artifacts=art, fixest_archive=repo / 'target/one-fe-profile-20260919/fixest.tar.gz',
    variants=['scb1'], n=245760, widths=[10 if a.weight == 'aw' else 6], threads=[1],
    seed=104729, repeats=1, trace=False, solver='auto', weight_kind=a.weight,
    slope_count=1 if a.weight == 'aw' else 3, slope_only=a.weight == 'pw', cases=['robust'],
    memory=None, memory_limit_bytes=None)
run.main(args)
result=json.loads((root / 'runs/c000-r0-scb1/result.json').read_text())
assert result['status']=='pass' and result['metadata']['profile_completed']==repeats
print('ROBUST_STACK_PROFILE_RUN_PASS',a.weight,a.mode,repeats,flush=True)

import csv, hashlib, json, statistics
from pathlib import Path

art = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
progress_path = art / 'dtk1-controls-progress1.json'
progress = json.loads(progress_path.read_text())
assert len(progress) == 4
records = []
for attempt in progress:
    root = art / attempt['root']
    complete = root / 'control-complete.json'
    assert json.loads(complete.read_text())['status'] == 'pass'
    assert attempt['process_returncode'] == 0
    assert attempt['timing_isolation']['status'] == 'no_detected_overlap'
    threads = attempt['spec']['threads']
    for k in [1, 5, 15, 16]:
        pairs = []
        for rep in [1, 2, 3]:
            paths = {v: root / 'runs' / f'control-robust-n245760-k{k}-s8675309-shuffle0-t{threads}-r{rep}-{v}'
                for v in ['scb1', 'dtk1']}
            results = {v: json.loads((p / 'result.json').read_text()) for v, p in paths.items()}
            assert all(r['status'] == 'pass' and r['sentinel'] and r['process_returncode'] == 0 for r in results.values())
            assert len({r['input_sha256'] for r in results.values()}) == 1
            assert len({r['sample_sha256'] for r in results.values()}) == 1
            for v, r in results.items():
                assert r['measurement_fingerprint']['native'] == json.loads((art / f'identity-{v}.json').read_text())
                assert r['cell']['k'] == k and r['cell']['n'] == 245760
                assert r['cell']['threads'] == threads
                assert r['cell']['effects'] == attempt['spec']['effects']
                assert r['cell']['weight_kind'] == attempt['spec']['weight']
            exact = {name: sha(paths['scb1'] / name) == sha(paths['dtk1'] / name)
                for name in ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv']}
            assert all(exact.values())
            solver = {v: {(int(row['row']), int(row['column'])): row['value'].strip()
                for row in csv.DictReader((p / 'fereg_solver.csv').open()) if int(row['column']) not in [9, 10]}
                for v, p in paths.items()}
            assert len(solver['scb1']) == 28 and solver['scb1'] == solver['dtk1']
            peaks = {v: r['metadata']['fereg_native_allocation_bytes'] for v, r in results.items()}
            assert len(set(peaks.values())) == 1
            seconds = {v: r['seconds'] for v, r in results.items()}
            pairs.append(dict(rep=rep, seconds=seconds, native_ratio=seconds['dtk1']/seconds['scb1'],
                exact_exports=exact, exact_non_timing_solver_fields=True, peaks=peaks,
                result_sha256={v: sha(p / 'result.json') for v, p in paths.items()},
                solver_sha256={v: sha(p / 'fereg_solver.csv') for v, p in paths.items()}))
        records.append(dict(root=root.name, cell=results['dtk1']['cell'], pairs=pairs,
            isolation=attempt['timing_isolation']['status'], completion_sha256=sha(complete),
            median_seconds={v: statistics.median(p['seconds'][v] for p in pairs) for v in paths},
            median_native_ratio=statistics.median(p['native_ratio'] for p in pairs)))
        print(root.name, k, records[-1]['median_seconds'], records[-1]['median_native_ratio'])
with (art / 'dtk1-controls-audit1.json').open('x') as stream:
    json.dump(dict(schema='fixed-dense-triangle-ordinary-controls-audit-v1', status='pass',
        source_sha256=sha(Path(__file__)), progress_sha256=sha(progress_path), records=records), stream, indent=2)

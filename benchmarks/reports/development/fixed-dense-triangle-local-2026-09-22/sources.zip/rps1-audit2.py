import csv, hashlib, json, re
from pathlib import Path
art=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((art/'identity-scb1.json').read_text())
records=[]
for weight in ['aw','pw']:
 roots={m:art/f'rps1-{weight}-{m}1' for m in ['control','sampled']}
 runs={m:r/'runs/c000-r0-scb1' for m,r in roots.items()}
 results={m:json.loads((r/'result.json').read_text()) for m,r in runs.items()}
 assert all(r['status']=='pass' and r['sentinel'] and r['process_returncode']==0 for r in results.values())
 assert all(r['measurement_fingerprint']['native']==identity for r in results.values())
 assert results['control']['metadata']['profile_completed']==1
 assert results['sampled']['metadata']['profile_completed']==80
 assert len({r['input_sha256'] for r in results.values()})==1
 assert len({r['sample_sha256'] for r in results.values()})==1
 exact={n:len({sha(r/n) for r in runs.values()})==1 for n in ['coefficients.csv','covariance.csv','b.csv','V.csv','fereg_fit.csv','fereg_dof.csv']}
 assert all(exact.values()),exact
 solver={m:{(int(x['row']),int(x['column'])):x['value'].strip() for x in csv.DictReader((r/'fereg_solver.csv').open()) if int(x['column']) not in [9,10]} for m,r in runs.items()}
 assert solver['control']==solver['sampled'] and len(solver['control'])==28
 complete=json.loads((runs['sampled']/'stack-sampler-complete.json').read_text())
 stack=runs['sampled']/'native-stacks.txt'
 assert complete['returncode']==0 and complete['stack_sha256']==sha(stack)
 nodes=[]
 for line in stack.read_text().splitlines():
  match=re.match(r'^([ +!|:]*)(\d+) (.+?)  \(in ([^)]+)\)',line)
  if match:nodes.append((len(match[1]),int(match[2]),match[3],match[4]))
 covariance=[]
 for i,node in enumerate(nodes):
  if 'prepared_robust::build_dense_covariance::' not in node[2]:continue
  branch=[]
  for child in nodes[i+1:]:
   if child[0]<=node[0]:break
   branch.append(child)
  row=sum(x[1] for x in branch if 'PreparedOlsDenseScoreView::fill_reported_row::' in x[2])
  multiplier=sum(x[1] for x in branch if 'OlsRobustScoreMultiplier' in x[2] and 'score_pair::' in x[2])
  # Tail-call optimization can leave a reference-weight frame without its multiplier caller.
  ancestors=[]; tail_weights=0
  for child in branch:
   while ancestors and ancestors[-1][0]>=child[0]:ancestors.pop()
   if 'ReferenceWeightView::value::' in child[2] and not any('OlsRobustScoreMultiplier' in parent[2] for parent in ancestors):
    tail_weights+=child[1]
   ancestors.append(child)
  multiplier+=tail_weights
  assert row+multiplier<=node[1]
  covariance.append(dict(total_samples=node[1],row_construction_samples=row,multiplier_samples=multiplier,tail_called_weight_samples=tail_weights,
    reduction_scaling_and_traversal_samples=node[1]-row-multiplier))
 assert len(covariance)==1 and covariance[0]['total_samples']>500
 records.append(dict(weight=weight,roots={m:r.name for m,r in roots.items()}, successful_target_fits=81,
  exact_exports=exact,exact_non_timing_solver_fields=True,covariance=covariance[0],
  result_sha256={m:sha(r/'result.json') for m,r in runs.items()},stack_sha256=sha(stack),
  sampler_receipt_sha256=sha(runs['sampled']/'stack-sampler-complete.json'),
  allocation_peaks={m:r['metadata']['fereg_native_allocation_bytes'] for m,r in results.items()}))
 print(weight,covariance[0])
out=art/'rps1-audit2.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='ols-robust-stack-profile-audit-v2',status='pass',
 source_sha256=sha(Path(__file__)),identity_sha256=sha(art/'identity-scb1.json'),records=records,
 disassembly=dict(sha256=sha(art/'rps1-dense-reduction-disassembly1.txt'),plugin_sha256=identity['plugin'],
  symbol='__ZN5rayon4iter8plumbing24bridge_producer_consumer6helper17h4dac50b20ef4042cE',start_address='0x125304',stop_address='0x12575c'),
 limitation='Statistical stack samples are diagnostic attribution, not exact phase times. The remainder combines scaling, triangle arithmetic and traversal. Repeated-fit durations are never headline timings.'),indent=2)+'\n')
print('ROBUST_STACK_PROFILE_AUDIT_PASS',sum(r['successful_target_fits'] for r in records))

import subprocess,sys
from pathlib import Path
art=Path(__file__).resolve().parent
for weight in ['aw','pw']:
 for mode in ['control','sampled']:
  name=f'rps1-{weight}-{mode}1'
  with (art/(name+'.txt')).open('x') as stream:
   result=subprocess.run([sys.executable,str(art/'rps1-run1.py'),weight,mode],stdout=stream,stderr=subprocess.STDOUT)
  print(name,result.returncode,flush=True)
  if result.returncode:raise SystemExit(result.returncode)

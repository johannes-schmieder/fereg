import hashlib, json, os, subprocess
from pathlib import Path
art = Path(__file__).resolve().parent
source = art / 'dtk1'
identity_path = art / 'identity-dtk1.json'
identity = json.loads(identity_path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(source / 'dist/fereg_macos.plugin') == identity['plugin']
tests = [
    'sandwich::tests::',
    'strided_score_storage_matches_packed_robust_inference',
    'every_robust_reservation_and_mutation_fails_closed',
    'configured_ppml_sandwich_uses_requested_team_against_global_pool',
    'robust_fweights_equal_literal_row_replication',
    'valid_finite_ppml_sandwich_overflow_is_nonconvergence',
]

env = dict(os.environ, DEVELOPER_DIR='/Library/Developer/CommandLineTools',
    CARGO_NET_OFFLINE='true', CARGO_TARGET_DIR=str(art / 'cargo-dtk1'),
    FEREG_GIT_COMMIT=identity['base_commit'][:8], FEREG_BUILD_DATE='2026-09-22')
receipt = art / 'dtk1-tests1.json'
assert not receipt.exists()
records = []
for index, test in enumerate(tests):
    log = art / f'dtk1-test{index + 1}-1.txt'
    command = ['cargo', 'test', '--locked', '--offline', '--release', '-p', 'fereg-core',
        '--target', 'aarch64-apple-darwin', '--lib', test, '--', '--nocapture']
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=source, env=env, stdout=stream, stderr=subprocess.STDOUT)
    passed = result.returncode == 0 and 'test result: ok.' in log.read_text() and '0 passed; 0 failed;' not in log.read_text()
    records.append(dict(test=test, command=command, returncode=result.returncode, passed=passed,
        log=log.name, log_sha256=sha(log)))
    receipt.write_text(json.dumps(dict(schema='fixed-triangle-sandwich-tests-v1',
        controller_sha256=sha(Path(__file__)), identity_sha256=sha(identity_path), plugin=identity['plugin'],
        status='pass' if len(records) == len(tests) and all(r['passed'] for r in records) else 'incomplete_or_failed',
        tests=records), indent=2) + '\n')
    print(test, result.returncode, passed, flush=True)
    if not passed: raise SystemExit(1)
print('FIXED_TRIANGLE_SANDWICH_TESTS_PASS', flush=True)

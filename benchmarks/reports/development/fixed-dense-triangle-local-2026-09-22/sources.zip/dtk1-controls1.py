import json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad,route_development as route
specs=[dict(effects=effects,weight=weight,threads=threads) for effects,weight in [(['g1'],'none'),(['g1','g2'],'aw')] for threads in [1,16]]
plan=art/'dtk1-controls-plan1.json';assert not plan.exists()
broad.write(plan,dict(schema='fixed-dense-triangle-native-controls-v1',specs=specs,widths=[1,5,15,16],n=245760,repeats=3,
 controller_sha256=broad.sha(Path(__file__)),variants=['scb1','dtk1'],
 identities={v:broad.sha(art/f'identity-{v}.json') for v in ['scb1','dtk1']},
 scope='Focused ordinary one-/two-FE robust controls, including both sides of the fixed-dimension boundary; no release or final-matrix claim.'))
progress=[]
for spec in specs:
 name=f"dtk1-control-e{len(spec['effects'])}-t{spec['threads']}"
 root=art/name;assert not root.exists()
 command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),'--artifacts',str(art),
  '--label','control','--variants','scb1','dtk1','--repeats','3','--design','two_fe_dense','--n','245760',
  '--widths','1','5','15','16','--cases','robust','--threads',str(spec['threads']),
  '--weight-kind',spec['weight'],'--weight-design','none' if spec['weight']=='none' else 'moderate',
  '--effects',*spec['effects']]
 code,isolation=route.invoke(command,art/(name+'.txt'))
 complete=root/'control-complete.json'
 progress.append(dict(spec=spec,root=name,command=command,process_returncode=code,timing_isolation=isolation,
  completion=json.loads(complete.read_text()) if complete.exists() else None))
 broad.write(art/'dtk1-controls-progress1.json',progress)
 print(name,code,isolation['status'],flush=True)
 if code:break
broad.write(art/'dtk1-controls-complete1.json',dict(status='attempts_complete',planned=len(specs),attempted=len(progress),
 plan_sha256=broad.sha(plan),progress_sha256=broad.sha(art/'dtk1-controls-progress1.json')))

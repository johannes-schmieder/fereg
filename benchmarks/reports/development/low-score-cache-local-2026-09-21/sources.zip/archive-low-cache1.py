import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science

output = repo / 'benchmarks/reports/development/low-score-cache-local-2026-09-21'
archive_science.archive([repo / 'target' / name for name in ['g21mc4', 'g21low6', 'g21mc7', 'g21sc1']],
                      output, compact=True, omit_output_arrays=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def portable(data):
    return data.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>') \
        .replace(b'<stata-installation>', b'<stata-installation>') \
        .replace(b'<reference-library>', b'<reference-library>')

sources, checks = {}, {}
with zipfile.ZipFile(output / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add_source(name, data):
        clean = portable(data)
        bundle.writestr(name, clean)
        sources[name] = dict(original_sha256=sha(data), portable_sha256=sha(clean))
    for variant in ['m5', 'm6', 'm7', 'sc1']:
        identity_path = artifacts / f'identity-{variant}.json'
        identity = json.loads(identity_path.read_text())
        add_source(identity_path.name, identity_path.read_bytes())
        for path in identity['overlays']:
            data = (artifacts / variant / path).read_bytes()
            assert sha(data) == identity['source'][path]
            add_source(variant + '/' + path, data)
    for name in ['m7-low-sample1.py', 'low-final-product-screen1.py', 'sc1-screen1.py',
                 'low-final-products-rejected1.patch', 'low-final-products-rejected1.json']:
        add_source(name, (artifacts / name).read_bytes())
    add_source('archive-low-cache1.py', Path(__file__).read_bytes())

names = ['m6-low-product-tests1.txt', 'm6-low-output-audit1.txt',
         'm6-low-screen-inference1.json', 'm6-low-screen-inference1.txt', 'm6-low-screen-outputs1.txt',
         'm7-low-product-tests1.txt', 'm7-low-output-audit1.txt', 'm7-low-inference-audit1.json',
         'm7-low-sample1/receipt.json', 'sc1-scratch-cache-tests1.txt', 'sc1-low-cluster-tests1.txt',
         'sc1-screen-inference1.json', 'sc1-screen-inference1.txt', 'sc1-screen-outputs1.txt',
         'sc1-screen-score1.json']
with zipfile.ZipFile(output / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name in names:
        data = (artifacts / name).read_bytes()
        if name.endswith('sc1-screen-inference1.json'):
            assert json.loads(data)['complete']
        clean = portable(data)
        bundle.writestr(name, clean)
        checks[name] = dict(original_sha256=sha(data), portable_sha256=sha(clean))
    sample = artifacts / 'm7-low-sample1/sample.txt'
    stack = '\n'.join(line for line in sample.read_text().splitlines()
                      if 'fereg_core::' in line) + '\n'
    data = stack.encode()
    name = 'm7-low-sample-fereg-stacks.txt'
    clean = portable(data)
    bundle.writestr(name, clean)
    checks[name] = dict(original_sample_sha256=sha(sample.read_bytes()),
                       extraction='Lines containing fereg_core::, with original order and counts.',
                       original_sha256=sha(data), portable_sha256=sha(clean))
    trace = next((repo / 'target/g21mc7/runs').glob('low-final-*/stderr.txt'))
    data = trace.read_bytes()
    clean = portable(data)
    bundle.writestr('m7-public-phase-trace.txt', clean)
    checks['m7-public-phase-trace.txt'] = dict(original_sha256=sha(data), portable_sha256=sha(clean))
for name, table in [('source-hashes.json', sources), ('check-hashes.json', checks)]:
    (output / name).write_text(json.dumps(table, indent=2) + '\n')
print('LOW_CACHE_SUPPLEMENTS_COMPLETE', len(sources), len(checks), flush=True)

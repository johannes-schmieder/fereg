import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
request = json.loads(next((repo / 'target/g21mc7/runs').glob('low-final-*/request.json')).read_text())
root = artifacts / 'm7-low-sample1'
root.mkdir(exist_ok=False)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
source = artifacts / 'm7'
program = f'''version 19.0
clear all
set more off
set varabbrev off
set processors 8
sysdir set PLUS "{root}"
sysdir set PERSONAL "{root}"
capture adopath - SITE
capture adopath - "."
adopath ++ "{source}/stata"
adopath ++ "{source}/dist"
quietly use "{request['data']}", clear
capture noisily fereg y x1-x6 [aw=w], absorb(out_fe1=g1 out_fe2=g2) threads(16) solver(auto) poolsize(10) vce(cluster c1 c2) residuals(out_resid) memory(low)
local result = _rc
display "LOW_SAMPLE_RC|`result'"
display "LOW_SAMPLE_COMPLETE"
exit, clear
'''
(root / 'run.do').write_text(program)
env = dict(os.environ, FEREG_PHASE_TIMING='1')
env.pop('FEREG_MEMORY_LIMIT_BYTES', None)
with (root / 'stdout.txt').open('x') as stream:
    process = subprocess.Popen(['<stata-installation>/StataMP.app/Contents/MacOS/stata-mp',
                                '-b', 'do', 'run.do'], cwd=root, env=env,
                               stdout=stream, stderr=subprocess.STDOUT)
    time.sleep(3)
    sample = subprocess.run(['/usr/bin/sample', str(process.pid), '5', '1', '-file', str(root / 'sample.txt')],
                            capture_output=True, text=True)
    (root / 'sample-controller.txt').write_text(sample.stdout + sample.stderr)
    try:
        code = process.wait(timeout=60)
        timed_out = False
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()
        code, timed_out = None, True
log = (root / 'run.log').read_text(errors='replace')
codes = re.findall(r'^LOW_SAMPLE_RC\|(\d+)\s*$', log, re.MULTILINE)
record = dict(variant='m7', process_returncode=code, timed_out=timed_out,
    application_returncode=int(codes[0]) if len(codes) == 1 else None,
    sentinel=any(line.strip() == 'LOW_SAMPLE_COMPLETE' for line in log.splitlines()),
    plugin=json.loads((artifacts / 'identity-m7.json').read_text())['plugin'],
    program_sha256=hashlib.sha256(program.encode()).hexdigest(),
    controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    sample_process_returncode=sample.returncode,
    scope='Diagnostic sampling; elapsed time is not a benchmark result.')
(root / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(record, flush=True)

import json, os, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route
art = repo / 'target/ols-next-20260921'
root = repo / 'target/g21fctrlhi1'
original_path = repo / 'target/g21finalcontrols1/final-controls1-plan.json'
original = json.loads(original_path.read_text())
score_path = art / 'final-controls1-score1.json'
score = json.loads(score_path.read_text())
indices = [c['index'] for c in score['cells'] if c['median_paired_ratio'] > score['threshold']]
assert indices == [46, 49] and score['timing_eligible'] == score['completely_measured'] == 111
freeze = json.loads((art / 'final-candidate-freeze1.json').read_text())
assert broad.sha(art / 'identity-owf1.json') == freeze['identity_sha256']
plan = dict(schema='native-protection-single-command-clock-v1', phase='confirmation', inventory_kind='controls',
    cells=[original['cells'][i] for i in indices], repetitions=5, variants=['baseline', 'owf1'],
    manifest=original['manifest'], original_indices=indices, original_plan_sha256=broad.sha(original_path),
    original_score_sha256=broad.sha(score_path), controller_sha256=broad.sha(Path(__file__)),
    isolation_source_sha256=broad.sha(Path(route.__file__)),
    clock_identity_sha256=broad.sha(root / 'controller/clock-identity.json'),
    candidate_freeze_sha256=broad.sha(art / 'final-candidate-freeze1.json'),
    purpose='Five fresh pairs for each failed rounded timing cell. Bracket the same single public command with the calibrated monotonic clock; retain ordinary timing and subtract no overhead.')
assert not (root / 'fine-plan.json').exists()
broad.write(root / 'fine-plan.json', plan)
(root / 'execution-source.py').write_bytes(Path(__file__).read_bytes())
os.environ['TWO_FE_HIGHRES_CLOCK'] = str(root / 'clock/clock.plugin')
progress = []
for index, cell in enumerate(plan['cells']):
    label = f'fine-c{index:03d}'
    command = [sys.executable, str(repo / 'benchmarks/two_fe_dense/run.py'), str(root), '--artifacts', str(art),
        '--label', label, '--variants', *plan['variants'], '--repeats', '5', '--keep-going', *broad.arguments(cell)]
    code, isolation = route.invoke(command, root / (label + '.stdout.txt'))
    complete = root / (label + '-complete.json')
    progress.append(dict(index=index, original_index=indices[index], cell=cell, label=label, process_returncode=code,
        comparison_status=json.loads(complete.read_text())['status'] if complete.exists() else 'incomplete',
        timing_isolation=isolation))
    broad.write(root / 'fine-progress.json', progress)
    print(indices[index], code, progress[-1]['comparison_status'], isolation['status'], flush=True)
broad.write(root / 'fine-complete.json', dict(status='attempts_complete', planned=2, attempted=len(progress),
    process_failures=sum(row['process_returncode'] != 0 for row in progress),
    plan_sha256=broad.sha(root / 'fine-plan.json')))
print('FINAL_CONTROL_FINE_CLOCK_COMPLETE', flush=True)

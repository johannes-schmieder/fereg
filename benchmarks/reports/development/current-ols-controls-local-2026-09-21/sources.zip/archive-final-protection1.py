import hashlib, io, json, math, statistics, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science
output = repo / 'benchmarks/reports/development/current-ols-controls-local-2026-09-21'
roots = [repo / 'target/g21finalcontrols1', repo / 'target/g21fctrlhi1']
score = json.loads((art / 'final-controls1-score1.json').read_text())
science = json.loads((art / 'final-controls1-science1.json').read_text())
confirmation = json.loads((art / 'final-control-fine-score1.json').read_text())
assert science['passing'] == science['planned'] == 111
assert confirmation['all_control_limits_with_confirmation_met']
assert score['completely_measured'] == score['timing_eligible'] == 111
archive_science.archive(roots, output, compact=True, omit_output_arrays=True)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>').replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')
tables = {kind: {} for kind in ['sources', 'checks']}
with zipfile.ZipFile(output / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['baseline', 'owf1']:
        path = art / f'identity-{variant}.json'
        identity = json.loads(path.read_text()); add(path.name, path.read_bytes())
        raw = subprocess.check_output(['git', 'archive', identity['base_commit'], 'Cargo.toml', 'Cargo.lock',
            'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            original = {entry.name: sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
        for relative, digest in identity['source'].items():
            raw = (art / variant / relative).read_bytes(); assert sha(raw) == digest
            if original.get(relative) != digest: add(variant + '/' + relative, raw)
    for name in ['broad.py', 'broad_milestone.json', 'score.py', 'audit_protection.py', 'audit_outputs.py',
                 'run.py', 'route_development.py', 'highres.py', 'highres_clock.c', 'archive_science.py']:
        add(name, (repo / 'benchmarks/two_fe_dense' / name).read_bytes())
    for relative in ['benchmarks/one_fe_profile/run.py', 'plugin/stplugin.c', 'plugin/stplugin.h',
                     'plugin/exports_macos.txt', 'tests/python/test_native_protection_audit.py']:
        add(relative, (repo / relative).read_bytes())
    for name in ['final-native-controls1.py', 'audit-final-native-controls1.py', 'final-control-clock1.py',
                 'score-final-control-clock1.py', 'archive-final-protection1.py']:
        add(name, (art / name).read_bytes())
    for path in (roots[1] / 'clock').iterdir():
        if path.suffix in ['.txt', '.json', '.do', '.patch']: add('clock/' + path.name, path.read_bytes())
with zipfile.ZipFile(output / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    names = ['final-candidate-freeze1.json', 'final-native-controls1.txt', 'final-native-control-audits1.txt',
        'final-control-audit-complete1.json', 'final-control-clock-prepare1.txt', 'final-control-fine-clock1.txt']
    names += [f'final-controls1-{kind}1.{suffix}' for kind in ['score', 'science'] for suffix in ['json', 'txt']]
    names += ['final-controls1-outputs1.txt']
    names += [f'final-control-fine-{kind}1.{suffix}' for kind in ['science', 'score'] for suffix in ['json', 'txt']]
    for name in names:
        raw = (art / name).read_bytes(); clean = portable(raw); bundle.writestr(name, clean)
        tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
for kind, table in tables.items():
    (output / (kind + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')
verifier = (repo / 'benchmarks/reports/development/current-ols-primary-screen-local-2026-09-21/verify.py').read_text()
verifier = verifier.replace("['in1']", "['baseline', 'owf1']")
start = verifier.index("with zipfile.ZipFile(folder / 'checks.zip') as bundle:", verifier.index('known_sources ='))
end = verifier.index('\nreceipt =', start)
verifier = verifier[:start] + '''with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    for name in ['final-controls1-science1.json', 'final-control-fine-science1.json']:
        audit = json.loads(bundle.read(name))
        assert audit['passing'] == audit['planned']
        assert audit['controller_sha256'] in known_sources
        assert audit['numerical_comparator_sha256'] in known_sources
    confirmation = json.loads(bundle.read('final-control-fine-score1.json'))
    assert confirmation['controller_sha256'] in known_sources
    assert confirmation['all_control_limits_with_confirmation_met']
    hashes = json.loads((folder / 'checks-hashes.json').read_text())
    assert confirmation['original_score_sha256'] == hashes['final-controls1-score1.json']['original_sha256']
    assert confirmation['science_sha256'] == hashes['final-control-fine-science1.json']['original_sha256']
    freeze = json.loads(bundle.read('final-candidate-freeze1.json'))
    assert freeze['plugin'] == next(item['plugin'] for item in sources if item['variant'] == 'owf1')

''' + verifier[end:]
verifier = verifier.replace('current-ols-primary-archive-integrity-v1', 'current-ols-controls-archive-integrity-v1')
verifier = verifier.replace('CURRENT_OLS_PRIMARY_ARCHIVE_INTEGRITY_PASS', 'CURRENT_OLS_CONTROLS_ARCHIVE_INTEGRITY_PASS')
(output / 'verify.py').write_text(verifier)
groups = {}
for cell in score['cells']: groups.setdefault(cell['cell']['group'], []).append(cell)
rows = []
for name, cells in groups.items():
    ratios = [c['median_paired_ratio'] for c in cells]
    rows.append(f"| {name} | {len(cells)} | {math.exp(statistics.mean(math.log(v) for v in ratios)):.4f} | {max(ratios):.4f} |")
fine_rows = []
for record in confirmation['records']:
    fine_rows.append(f"| {record['original_index']} | {record['cell']['weight_kind']} | {record['cell']['k']} | {record['original_median_paired_ratio']:.5f} | {record['median_paired_ratio']:.5f} | {record['unchanged_ordinary_median_ratio']:.5f} |")
pairs = [pair for record in science['records'] for pair in record['pairs']]
exact = sum(all(pair['exact_exports'][name] for name in ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv']) for pair in pairs)
exact_outputs = sum(pair['exact_exports'].get('outputs.bin', False) for pair in pairs)
outputs = json.loads((roots[0] / 'final-controls1-owf1-independent-outputs.json').read_text())
increased = [cell for cell in score['cells'] if any(pair['candidate_peak_bytes'] > pair['baseline_peak_bytes'] for pair in cell['pairs'])]
largest = max(pair['candidate_peak_bytes'] - pair['baseline_peak_bytes'] for cell in score['cells'] for pair in cell['pairs'])
(output / 'README.md').write_text(f'''# Current OLS protected native controls

The frozen owf1 candidate completes all 111 unchanged protected controls
against baseline `0efa78bd`: 666 successful application calls, each cell with
three pairs and no detected timing overlap. All 333 native scientific pairs
pass, including exact samples, status and degrees of freedom. There are {exact}
bit-identical six-bundle pairs. All {len(outputs)} independent saved-output
audits pass; {exact_outputs} native output pairs are bit-identical.

Two original timing cells exceed the 1.05 ratio limit. Both remain recorded.
Each receives five fresh pairs around the same single public command with
the calibrated monotonic bracket and unchanged ordinary timer. All twenty
calls, ten scientific comparisons and both isolation checks pass. Both
confirmations satisfy the limit, so all 111 control limits are met with these
explicit confirmations. No estimator change or clock-overhead subtraction is
made. The confirmation does not assert a precise speed gain for these short fits.

| Original index | Weight | K | Original paired ratio | Monotonic confirmation | Ordinary confirmation |
|---:|---|---:|---:|---:|---:|
''' + '\n'.join(fine_rows) + '''

| Control family | Cells | Geometric mean paired ratio | Original worst ratio |
|---|---:|---:|---:|
''' + '\n'.join(rows) + f'''

Tracked peaks increase in {len(increased)} cells, with maximum paired increase
{largest:,} bytes. Every paired peak remains in the score. This is not a
memory-neutrality or complete allocation-proof claim. The independent output
checks complement the earlier explicit-dummy and literal-FW inference oracles;
this control campaign is not a new full qualification matrix.

The archive preserves all 686 calls, both failed original timing cells, both
confirmations, complete baseline/owf1 source identities and both clock
provenances. `verify.py` checks source reconstruction, portable hashes and
auditor/confirmation bindings. Large output arrays remain local with hashes;
raw licensed logs and binaries are excluded. Expanded current-candidate graph
coverage, remaining slope losses, routing and Linux work remain open. No push,
installation or release is performed.
''')
print('CURRENT_OLS_CONTROLS_ARCHIVE_PREPARED')

import json, os, subprocess, sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
root = repo / 'target/g21finalcontrols1'
base = repo / 'benchmarks/two_fe_dense'
label = 'final-controls1'
complete = json.loads((root / (label + '-complete.json')).read_text())
assert complete['attempted'] == complete['planned'] == 111
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
commands = [
    ('score', [sys.executable, str(base / 'score.py'), str(root), label,
               str(art / (label + '-score1.json'))]),
    ('science', [sys.executable, str(base / 'audit_protection.py'), str(root), label,
                 str(art / (label + '-science1.json'))]),
    ('outputs', [sys.executable, str(base / 'audit_outputs.py'), str(root), label, 'owf1']),
]
records = []
for kind, command in commands:
    with (art / (label + '-' + kind + '1.txt')).open('x') as stream:
        process = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    records.append(dict(kind=kind, process_returncode=process.returncode))
    print(kind, process.returncode, flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
score = json.loads((art / (label + '-score1.json')).read_text())
science = json.loads((art / (label + '-science1.json')).read_text())
print('FINAL_CONTROL_RESULT', 'science', science['passing'], '/', science['planned'],
      'eligible', score['timing_eligible'], 'threshold_met', score['timing_threshold_met'],
      'worst', score['worst_ratio'], flush=True)
for cell in score['cells']:
    if cell['issues'] or not cell['timing_eligible'] or cell.get('median_paired_ratio', float('inf')) > score['threshold']:
        print('CONTROL_REQUIRES_REVIEW', cell['index'], cell.get('median_paired_ratio'),
              cell['issues'], cell['timing_isolation'], flush=True)
with (art / 'final-control-audit-complete1.json').open('x') as stream:
    json.dump(dict(status='attempts_complete', records=records), stream, indent=2)
    stream.write('\n')

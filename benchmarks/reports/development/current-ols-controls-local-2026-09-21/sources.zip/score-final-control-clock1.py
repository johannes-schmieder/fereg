import hashlib, json, math, statistics
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
root = repo / 'target/g21fctrlhi1'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
plan = json.loads((root / 'fine-plan.json').read_text())
progress = json.loads((root / 'fine-progress.json').read_text())
science_path = art / 'final-control-fine-science1.json'
science = json.loads(science_path.read_text())
assert science['passing'] == science['planned'] == len(plan['cells']) == len(progress) == 2
original_path = art / 'final-controls1-score1.json'
assert sha(original_path) == plan['original_score_sha256']
original = json.loads(original_path.read_text())
assert original['completely_measured'] == original['timing_eligible'] == 111
assert plan['original_indices'] == [c['index'] for c in original['cells'] if c['median_paired_ratio'] > 1.05]
records = []
for index, (cell, attempt) in enumerate(zip(plan['cells'], progress)):
    assert attempt['cell'] == cell and attempt['index'] == index
    assert attempt['process_returncode'] == 0 and attempt['timing_isolation']['status'] == 'no_detected_overlap'
    pairs = []
    for rep in range(1, 6):
        matches = {variant: list((root / 'runs').glob(f"{attempt['label']}-*-r{rep}-{variant}/result.json")) for variant in plan['variants']}
        assert all(len(paths) == 1 for paths in matches.values())
        paths = {variant: paths[0] for variant, paths in matches.items()}
        results = {variant: json.loads(path.read_text()) for variant, path in paths.items()}
        for result in results.values():
            assert result['status'] == 'pass' and result['sentinel'] and result['process_returncode'] == 0
            metadata = result['metadata']
            assert math.isfinite(metadata['highres_seconds']) and metadata['highres_seconds'] > 0
            assert 0 <= metadata['clock_empty_min'] <= metadata['clock_empty_mean'] <= metadata['clock_empty_max'] < .01
        seconds = {v: r['metadata']['highres_seconds'] for v, r in results.items()}
        pairs.append(dict(rep=rep, seconds=seconds, ratio=seconds['owf1'] / seconds['baseline'],
            ordinary_seconds={v: r['seconds'] for v, r in results.items()},
            clocks={v: {k: r['metadata'][k] for k in ['clock_empty_min', 'clock_empty_mean', 'clock_empty_max']} for v, r in results.items()},
            result_sha256={v: sha(path) for v, path in paths.items()}))
    ratio = statistics.median(pair['ratio'] for pair in pairs)
    original_index = plan['original_indices'][index]
    records.append(dict(original_index=original_index, cell=cell,
        original_median_paired_ratio=original['cells'][original_index]['median_paired_ratio'],
        pairs=pairs, median_paired_ratio=ratio, threshold=1.05, threshold_met=ratio <= 1.05,
        unchanged_ordinary_median_ratio=statistics.median(pair['ordinary_seconds']['owf1'] / pair['ordinary_seconds']['baseline'] for pair in pairs),
        median_seconds={v: statistics.median(pair['seconds'][v] for pair in pairs) for v in plan['variants']}))
confirmed = all(r['threshold_met'] for r in records) and all(c['median_paired_ratio'] <= 1.05 for c in original['cells'] if c['index'] not in plan['original_indices'])
receipt = dict(schema='native-protection-fine-clock-confirmation-v2', controller_sha256=sha(Path(__file__)),
    plan_sha256=sha(root / 'fine-plan.json'), progress_sha256=sha(root / 'fine-progress.json'),
    original_score_sha256=sha(original_path), science_sha256=sha(science_path), records=records,
    all_control_limits_with_confirmation_met=confirmed,
    scope='Two fresh five-pair confirmations of failed rounded controls. Original failures are preserved; no kernel changes or overhead subtraction.')
with (art / 'final-control-fine-score1.json').open('x') as stream:
    json.dump(receipt, stream, indent=2); stream.write('\n')
for record in records:
    print('FINAL_CONTROL_FINE_SCORE', record['original_index'], record['median_paired_ratio'], record['unchanged_ordinary_median_ratio'], record['threshold_met'])
print('ALL_CONTROL_LIMITS_WITH_CONFIRMATION', confirmed)

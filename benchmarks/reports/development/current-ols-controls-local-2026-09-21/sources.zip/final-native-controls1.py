import json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2];art=repo/'target/ols-next-20260921'
sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'))
import broad
import route_development as route
freeze=json.loads((art/'final-candidate-freeze1.json').read_text())
assert broad.sha(art/'identity-owf1.json')==freeze['identity_sha256']
manifest=repo/'benchmarks/two_fe_dense/broad_milestone.json'
assert broad.sha(manifest)==freeze['manifests'][manifest.name]
spec=json.loads(manifest.read_text());cells=broad.expand(spec,'controls');assert len(cells)==111
baseline=json.loads((art/'identity-baseline.json').read_text());milestone=json.loads((repo/'benchmarks/manifests/ols_optimization_20260921_v1.json').read_text())
assert baseline['base_commit']==milestone['baseline_commit'] and baseline['abi']=='pass'
root=repo/'target/g21finalcontrols1';label='final-controls1';root.mkdir(exist_ok=False)
plan=dict(schema='two-fe-broad-execution-v1',label=label,phase='controls',inventory_kind='controls',
 repetitions=3,variants=['baseline','owf1'],manifest=spec,manifest_sha256=broad.sha(manifest),cells=cells,
 controller_sha256=broad.sha(Path(__file__)),cell_runner_sha256=broad.sha(repo/'benchmarks/two_fe_dense/run.py'),
 isolation_source_sha256=broad.sha(Path(route.__file__)),baseline_identity_sha256=broad.sha(art/'identity-baseline.json'),
 candidate_freeze_sha256=broad.sha(art/'final-candidate-freeze1.json'))
broad.write(root/(label+'-plan.json'),plan);(root/'execution-source.py').write_bytes(Path(__file__).read_bytes());progress=[]
for index,cell in enumerate(cells):
 cell_label=f'{label}-c{index:03d}';output=root/(cell_label+'.stdout.txt')
 command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),'--artifacts',str(art),
  '--label',cell_label,'--variants',*plan['variants'],'--repeats','3','--timeout','240','--keep-going',*broad.arguments(cell)]
 code,isolation=route.invoke(command,output);complete=root/(cell_label+'-complete.json')
 status=json.loads(complete.read_text())['status'] if complete.exists() else 'incomplete'
 progress.append(dict(index=index,label=cell_label,cell=cell,command=command,process_returncode=code,
  comparison_status=status,stdout_sha256=broad.sha(output),timing_isolation=isolation))
 broad.write(root/(label+'-progress.json'),progress)
 print(index+1,'/',111,code,status,isolation['status'],flush=True)
broad.write(root/(label+'-complete.json'),dict(status='attempts_complete',planned=111,attempted=len(progress),
 process_failures=sum(r['process_returncode']!=0 for r in progress),plan_sha256=broad.sha(root/(label+'-plan.json')),
 progress_sha256=broad.sha(root/(label+'-progress.json'))))
print('FINAL_NATIVE_CONTROLS_ATTEMPTS_COMPLETE',flush=True)

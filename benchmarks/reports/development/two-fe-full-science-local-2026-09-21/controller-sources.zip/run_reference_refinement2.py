from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,sys,hashlib
repo=Path.cwd();sys.path.insert(0,str(repo/'benchmarks/two_fe_dense'));import broad
items=[]
for root in sorted((repo/'target').glob('g21d?')):
 plan=json.loads((root/'diagnostic-plan.json').read_text());lookup={r['index']:r for r in plan['cells']}
 for record in json.loads((root/'diagnostic-progress.json').read_text()):
  if record['status']!='pass':items.append(lookup[record['index']])
assert len(items)==18
base=repo/'target/ols-next-20260921';(base/'reference-refinement2-plan.json').write_text(json.dumps(dict(cells=items,reference_tolerance=4e-12,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
def run(shard):
 root=repo/f'target/g21f{shard}';root.mkdir(exist_ok=False);progress=[]
 for item in items[shard::4]:
  label='refine-'+str(item['index']);command=[sys.executable,str(repo/'benchmarks/two_fe_dense/run.py'),str(root),'--artifacts',str(base),'--label',label,'--variants','slope-recovery2','fixest','--repeats','1','--oracle','--reference-precision','--reference-tolerance','4e-12','--record-reference-science-disagreement','--record-reference-output-disagreement',*broad.arguments(item['cell'])]
  if item['reference_full_dof']:command.append('--reference-full-dof')
  with (root/(label+'.stdout.txt')).open('x') as stream:code=subprocess.call(command,stdout=stream,stderr=subprocess.STDOUT)
  complete=root/(label+'-complete.json');status=json.loads(complete.read_text())['status'] if complete.exists() else 'incomplete';progress.append(dict(index=item['index'],label=label,process_returncode=code,status=status));broad.write(root/'refinement-progress.json',progress)
 return dict(shard=shard,progress=progress)
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,range(4)))
broad.write(base/'reference-refinement2-terminal.json',results);print('REFINEMENT_ATTEMPTS_COMPLETE',sum(len(r['progress']) for r in results),flush=True)

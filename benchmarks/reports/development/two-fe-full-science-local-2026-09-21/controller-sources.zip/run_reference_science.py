from pathlib import Path
import subprocess,sys,json
root=Path.cwd();processes=[];streams=[]
for shard in range(4):
 stream=(root/f'target/ols-next-20260921/reference-science-{shard}.txt').open('x');streams.append(stream)
 command=[sys.executable,str(root/'benchmarks/two_fe_dense/reference_science.py'),str(root/f'target/g21d{shard}'),'--summary',str(root/'target/ols-next-20260921/full-graph-science.json'),'--inputs',str(root/'target'),'--artifacts',str(root/'target/ols-next-20260921'),'--shard',str(shard)]
 processes.append(subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT))
results=[]
for i,p in enumerate(processes):
 code=p.wait();streams[i].close();results.append(dict(shard=i,returncode=code));print(results[-1],flush=True)
(root/'target/ols-next-20260921/reference-science-terminal.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['returncode']==0 for r in results)

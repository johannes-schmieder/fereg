from pathlib import Path
import json,subprocess,sys,hashlib,os
root=Path.cwd();sys.path.insert(0,str(root/'benchmarks/two_fe_dense'));import milestone
spec=json.loads(milestone.MANIFEST.read_text());cells=milestone.expand(spec,'small');assert len(cells)==1518
processes=[];streams=[];jobs=[]
for shard in range(4):
 folder=root/f'target/g21s{shard}';assert not folder.exists()
 selected=list(range(shard,len(cells),4))
 command=[sys.executable,str(root/'benchmarks/two_fe_dense/milestone.py'),str(folder),'--artifacts',str(root/'target/ols-next-20260921'),'--candidate','slope-recovery2','--label','science','--phase','small','--indices',*map(str,selected)]
 output=root/f'target/ols-next-20260921/graph-science-{shard}.txt';assert not output.exists()
 stream=output.open('w');streams.append(stream)
 jobs.append(dict(shard=shard,rows=len(selected),root=str(folder),indices=selected))
 processes.append(subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT))
(root/'target/ols-next-20260921/graph-science-dispatch.json').write_text(json.dumps(dict(schema='local-graph-science-shards-v1',candidate='slope-recovery2',jobs=jobs,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),threads_per_fit=16,concurrent_streams=4,timings='diagnostic_only'),indent=2)+'\n')
results=[]
for job,process,stream in zip(jobs,processes,streams):
 code=process.wait();stream.close();results.append(dict(shard=job['shard'],returncode=code));print(results[-1],flush=True)
(root/'target/ols-next-20260921/graph-science-terminal.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['returncode']==0 for r in results)

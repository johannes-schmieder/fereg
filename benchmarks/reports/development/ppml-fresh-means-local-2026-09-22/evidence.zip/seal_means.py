from pathlib import Path
import difflib,hashlib,json,re,statistics,subprocess,sys
sys.dont_write_bytecode=True
root=Path('target/ppml-next-20260922'); repo=Path.cwd()
sys.path.insert(0,str(repo/'benchmarks/next_subsystem'))
from audit import runtime
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 with (root/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
identity=json.loads((root/'artifacts/identity-means1.json').read_text())
match={p:sha(repo/p)==h for p,h in identity['source'].items()}
assert all(match.values())
(root/'means-source.patch').write_bytes(subprocess.check_output(['git','diff','346d80e4','--','crates/fereg-core/src/ols/prepared_fit.rs']))
(root/'means-harness.patch').write_bytes(subprocess.check_output(['git','diff','346d80e4','--','benchmarks/next_subsystem/profile.py','benchmarks/next_subsystem/oracles.py']))
diag=[]
for p in ['crates/fereg-core/src/ols/prepared_fit.rs','crates/fereg-core/src/ols/linear_session.rs']:
 old=subprocess.check_output(['git','show','346d80e4:'+p],text=True).splitlines(True)
 new=(root/'artifacts/assembly-traced'/p).read_text().splitlines(True)
 diag.extend(difflib.unified_diff(old,new,fromfile='a/'+p,tofile='b/'+p))
(root/'means-diagnostic.patch').write_text(''.join(diag))
for p in ['benchmarks/next_subsystem/oracles.py','benchmarks/next_subsystem/profile.py','benchmarks/next_subsystem/summarize.py','benchmarks/stata_input_probe/fixtures.py']:
 (root/('means-controller-'+Path(p).name)).write_bytes((repo/p).read_bytes())
names=set(); tests={}
for f in ['tests-bound-means.txt','tests-means-ppml.txt','tests-means-reported.txt']:
 s=(root/f).read_text(); n=re.findall(r'^test (.*?) \.\.\. ok$',s,re.M);names.update(n)
 assert not re.search(r'^test .*? \.\.\. FAILED$',s,re.M)
 tests[f]=dict(passed=len(n),sha256=sha(root/f))
fixtures=[]
for rec in json.loads((root/'artifacts/fixtures-means1.json').read_text()):
 d=root/'artifacts/fixtures/means1'/Path(rec['fixture']).stem
 log=(d/'run.log').read_text()
 assert '\n'+rec['fixture_sentinel']+'\n' in log and '\nACCESSOR_FIXTURE_COMPLETE\n' in log
 fixtures.append(dict(rec,log_sha256=sha(d/'run.log'),script_sha256=sha(d/'run.do')))
phases={};peaks=[];attempts=[]
for screen in ['means-screen','means-confirm','means-controls']:
 s=json.loads((root/(screen+'-summary.json')).read_text())
 progress=json.loads((root/screen/'progress.json').read_text()); attempts.extend(progress)
 phases[screen]=[]
 for i,c in enumerate(s['cells']):
  for pair in c['pairs']:
   assert pair['clean'] and pair['checks']['passed'] and pair['exact']['passed']
   peaks.append(pair['tracked_peak_bytes']['means1']-pair['tracked_peak_bytes']['separation1'])
  if c['cell']['model']!='ppml':continue
  vals={}
  for v in ['separation1','means1']:
   samples=[runtime(root/screen/p['result'],'ppml') for p in progress if p['case']==i and p['variant']==v]
   vals[v]={k:statistics.median(x[k] for x in samples) for k in samples[0] if k.startswith('time_') and all(x[k] is not None for x in samples)}
  phases[screen].append(dict(cell=c['cell'],medians=vals))
assert all(p['status']=='pass' and not p['overlaps'] and not p['monitor_errors'] for p in attempts)
save('means-validation.json',dict(base=identity['base_commit'],artifact=identity['plugin'],source_inputs=len(match),source_matches=match,
 tests=tests,distinct_tests=len(names),fixture_records=fixtures,headline_attempts=len(attempts),native_pairs=len(peaks),tracked_peak_change_bytes=dict(minimum=min(peaks),maximum=max(peaks)),
 allocation_audit=dict(status='fails on preserved source drift',sha256=sha(root/'means-allocation-audit.txt'))))
save('means-phase-medians.json',phases)
print('VALIDATION',len(match),len(names),len(attempts),len(peaks),min(peaks),max(peaks))

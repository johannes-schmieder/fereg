version 19.0
clear all
set more off
set processors 4
adopath ++ "$REPO/target/next-subsystem-20260922/artifacts/reference1/stata"
adopath ++ "$REPO/target/next-subsystem-20260922/artifacts/reference1/dist"
use "$REPO/target/next-subsystem-20260922/reference-confirm/data/c3-warm.dta",clear
capture noisily feppml y x1-x12, absorb(g1) threads(4) vce(robust)
local rc = _rc
file open report using "$REPO/target/next-subsystem-20260922/zero-replay/reference1.status",write text replace
file write report "rc=`rc'" _n
file close report
display "ZERO_REPLAY_COMPLETE rc=`rc'"

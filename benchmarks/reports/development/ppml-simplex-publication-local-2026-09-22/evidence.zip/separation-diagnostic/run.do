version 19.0
clear all
set more off
set processors 4
sysdir set PLUS "$REPO/target/ppml-next-20260922/separation-diagnostic"
sysdir set PERSONAL "$REPO/target/ppml-next-20260922/separation-diagnostic"
capture adopath - SITE
capture adopath - "."
adopath ++ "$REPO/target/next-subsystem-20260922/artifacts/reference1/stata"
adopath ++ "$REPO/target/next-subsystem-20260922/artifacts/reference1/dist"
adopath ++ "$REPO/target/ppml-next-20260922/separation-diagnostic/ado"
use "$REPO/target/next-subsystem-20260922/reference-confirm/data/c3-warm.dta",clear
capture noisily feppml y x1-x12, absorb(g1) threads(4) vce(robust)
local rc = _rc
display "SEPARATION_DIAGNOSTIC_COMPLETE rc=`rc'"

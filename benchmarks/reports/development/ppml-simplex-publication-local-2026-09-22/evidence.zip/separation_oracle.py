"""Bounded one-FE zero-outcome oracle; separation is proved before fitting."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
import pandas as pd
repo=Path.cwd()
sys.path.insert(0,str(repo/'benchmarks/systematic'))
from oracle import oracle
sys.path.insert(0,str(repo/'benchmarks/next_subsystem'))
from audit import distance, compare, read
root=Path(sys.argv[1]); output=Path(sys.argv[2])
plan=read(root/'plan.json');cell=plan['cells'][0]
assert cell['model']=='ppml' and cell['effects']==['g1'] and cell['section']=='zeros'
frame=pd.read_stata(root/'data/c0-full.dta',convert_categoricals=False)
assert len(frame)<=7680 and (frame.groupby('g1').size()>=2).all()
positive_by_level=frame.groupby('g1').y.transform('max')>0
retained=frame.loc[positive_by_level].copy()
names=[f'x{j}' for j in range(1,cell['k']+1)]
interior=retained.loc[retained.y>0]
# Every retained level has a positive row. If X*beta+FE is zero on all
# positive rows, demeaning within those rows gives within(X)*beta=0.
# Full finite rank forces beta=0 and then all FE coordinates=0. No nonzero
# recession direction can remain. Deleted zero-only levels have exact -1
# indicator witnesses, independently of any native detector output.
within=interior[names]-interior.groupby('g1')[names].transform('mean')
sv=np.linalg.svd(within.to_numpy(),compute_uv=False)
assert len(sv)==cell['k'] and sv[-1]>1e-8*sv[0]
path=output.with_suffix('.retained.dta');retained.to_stata(path,write_index=False,version=118)
expected=oracle(path,cell)
digest=hashlib.sha256()
for obs in retained.obs_id:digest.update(int(obs).to_bytes(8,'little'))
checks={}
for variant in plan['variants']:
 p=root/f'runs/c0-r0-{variant}';r=read(p/'result.json');assert r['status']=='pass'
 b=pd.read_csv(p/'coefficients.csv').set_index('name').loc[names].value
 V=pd.read_csv(p/'covariance.csv').pivot(index='row',columns='column',values='value').loc[names,names]
 c=dict(sample=r['sample_sha256']==digest.hexdigest(),N=r['metadata']['N']==len(retained),
        coefficients=distance(b,expected['coefficients'],1e-7),covariance=distance(V,expected['covariance'],1e-6))
 for key in ['ll','deviance']:c[key]=distance([r['metadata'].get(key,r['metadata'].get('loglik'))],[expected[key]],1e-8)
 c['passed']=all(x if isinstance(x,bool) else x['passed'] for x in c.values());checks[variant]=c
result=dict(source_sha256=hashlib.sha256((root/'data/c0-full.dta').read_bytes()).hexdigest(),
    independent_sample=dict(candidate=len(frame),retained=len(retained),zero_level_drops=len(frame)-len(retained),
        sha256=digest.hexdigest(),positive_within_singular_values=sv.tolist(),passed=True),oracle=expected,checks=checks,
    stock_pairwise=compare(root/'runs/c0-r0-separation1',root/'runs/c0-r0-fixest','ppml'))
with output.open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print({v:c['passed'] for v,c in checks.items()},'independent_drops',len(frame)-len(retained))
assert all(c['passed'] for c in checks.values())

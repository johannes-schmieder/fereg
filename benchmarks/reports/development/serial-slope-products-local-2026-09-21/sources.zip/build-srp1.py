import hashlib, json, os, subprocess, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/one_fe_optimization'))
import build
for name in ['srp1', 'cargo-srp1', 'identity-srp1.json', 'build-srp1.log', 'srp1-tests.json']:
    assert not (art / name).exists(), name
overlays = subprocess.check_output(['/opt/homebrew/bin/git', 'diff', '--name-only'], cwd=repo, text=True).splitlines()
assert len(overlays) == 7 and all(path.startswith('crates/fereg-core/src/') for path in overlays)
identity = build.build(art, 'srp1', 'HEAD', overlays)
tests = ['retained_serial_products_reconstruct_and_preserve_fresh_projection',
         'single_slope_cache_is_ols_only_and_preserves_full_fit',
         'ordered_serial_fusion_preserves_projection_norms_and_fresh_certificates']
env = dict(os.environ, CARGO_TARGET_DIR=str(art / 'cargo-srp1'), CARGO_NET_OFFLINE='true')
checks = []
for index, name in enumerate(tests):
    path = art / f'srp1-captured-test{index + 1}.txt'
    command = ['cargo', 'test', '--locked', '--offline', '--release', '--target', 'aarch64-apple-darwin',
        '-p', 'fereg-core', '--lib', name, '--', '--nocapture']
    with path.open('x') as stream:
        process = subprocess.run(command, cwd=art / 'srp1', env=env, stdout=stream, stderr=subprocess.STDOUT)
    checks.append(dict(test=name, returncode=process.returncode, log=path.name,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    print('SRP1_TEST', name, process.returncode, flush=True)
    if process.returncode: break
with (art / 'srp1-tests.json').open('x') as stream:
    json.dump(dict(identity_sha256=build.sha(art / 'identity-srp1.json'),
        controller_sha256=build.sha(Path(__file__)), checks=checks), stream, indent=2)
assert len(checks) == len(tests) and all(check['returncode'] == 0 for check in checks)

import hashlib, io, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science
out = repo / 'benchmarks/reports/development/serial-slope-products-local-2026-09-21'
progress = json.loads((art / 'srp1-screen-progress1.json').read_text())
roots = [art / r['root'] for r in progress] + [art / f'srp1-profile-{w}1' for w in ['aw', 'pw']]
archive_science.archive(roots, out, compact=True, omit_output_arrays=True)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def portable(raw):
    return raw.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>').replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')
tables = {'sources': {}, 'checks': {}}
with zipfile.ZipFile(out / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['owf1', 'srp1', 'srp1-profile']:
        path = art / f'identity-{variant}.json'; identity = json.loads(path.read_text()); add(path.name, path.read_bytes())
        raw = subprocess.check_output(['git', 'archive', identity['base_commit'], 'Cargo.toml', 'Cargo.lock',
            'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(raw)) as tree:
            base = {e.name: sha(tree.extractfile(e).read()) for e in tree.getmembers() if e.isfile()}
        for relative, digest in identity['source'].items():
            raw = (art / variant / relative).read_bytes(); assert sha(raw) == digest
            if base.get(relative) != digest: add(variant + '/' + relative, raw)
    for path in (art / 'failed-srp1-test-source1').iterdir(): add('failed-tests/' + path.name, path.read_bytes())
    for name in ['build-srp1.py', 'srp1-screen1.py', 'audit-srp1-screen1.py', 'srp1-profile1.py', 'archive-srp1.py']:
        add(name, (art / name).read_bytes())
    for relative in ['one_fe_profile/slopes.py', 'one_fe_profile/slope_breadth.py', 'one_fe_profile/run.py',
        'one_fe_profile/slope_instrument.py', 'one_fe_profile/recovery_instrument.py', 'one_fe_breadth/run.py',
        'one_fe_optimization/prepare_profile.py', 'one_fe_optimization/build.py', 'systematic/generate.py',
        'two_fe_dense/route_development.py', 'two_fe_dense/archive_science.py']:
        add(relative, (repo / 'benchmarks' / relative).read_bytes())
with zipfile.ZipFile(out / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add_check(name, raw, **extra):
        clean = portable(raw); bundle.writestr(name, clean)
        tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean), **extra)
    for path in sorted(art.glob('srp1*')):
        if path.is_file() and path.suffix in ['.txt', '.json']: add_check(path.name, path.read_bytes())
    for name in ['build-srp1.log', 'build-srp1-profile.log']: add_check(name, (art / name).read_bytes())
    for root in roots[-2:]:
        for path in sorted((root / 'runs').glob('*/stderr.txt')):
            raw = path.read_bytes()
            trace = ('\n'.join(line for line in raw.decode().splitlines() if line.startswith(('FEREG_PHASE|', 'SLOPE_PROFILE|'))) + '\n').encode()
            add_check(root.name + '/' + path.parent.name + '/native-trace.txt', trace, original_stream_sha256=sha(raw))
for name, table in tables.items(): (out / (name + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')
verifier = (repo / 'benchmarks/reports/development/current-ols-controls-local-2026-09-21/verify.py').read_text()
verifier = verifier.replace("['baseline', 'owf1']", "['owf1', 'srp1', 'srp1-profile']")
start = verifier.index("with zipfile.ZipFile(folder / 'checks.zip') as bundle:", verifier.index('known_sources ='))
end = verifier.index('\nreceipt =', start)
verifier = verifier[:start] + '''with zipfile.ZipFile(folder / 'checks.zip') as bundle:
    tests = json.loads(bundle.read('srp1-tests.json'))
    assert tests['controller_sha256'] in known_sources
    assert tests['identity_sha256'] == source_hashes['identity-srp1.json']['original_sha256']
    assert len(tests['checks']) == 3 and all(r['returncode'] == 0 for r in tests['checks'])
    hashes = json.loads((folder / 'checks-hashes.json').read_text())
    for r in tests['checks']: assert r['sha256'] == hashes[r['log']]['original_sha256']
    audit = json.loads(bundle.read('srp1-screen-audit1.json'))
    assert audit['source_sha256'] in known_sources
    assert len(audit['records']) == 9 and all(r['isolation'] == 'no_detected_overlap' for r in audit['records'])
    assert audit['progress_sha256'] == hashes['srp1-screen-progress1.json']['original_sha256']
    profile = json.loads(bundle.read('srp1-profiler-check1.json'))
    assert profile['status'] == 'pass' and len(profile['records']) == 2

''' + verifier[end:]
verifier = verifier.replace('current-ols-controls-archive-integrity-v1', 'serial-slope-products-archive-integrity-v1').replace('CURRENT_OLS_CONTROLS_ARCHIVE_INTEGRITY_PASS', 'SERIAL_SLOPE_PRODUCTS_ARCHIVE_INTEGRITY_PASS')
(out / 'verify.py').write_text(verifier)
audit = json.loads((art / 'srp1-screen-audit1.json').read_text())
rows = []
for r in audit['records']:
    s = r['median_seconds']
    rows.append(f"| {r['cell']['weight_kind']} | {r['cell']['k']} | {r['cell']['threads']} | {r['cell']['case']} | {s['owf1']:.3f} | {s['srp1']:.3f} | {s.get('fixest', 'FW control')} | {r['median_native_ratio']:.4f} |")
(out / 'timings.md').write_text('| Weight | K | T | Case | Prior seconds | Draft seconds | fixest seconds | Paired draft/prior |\n|---|---:|---:|---|---:|---:|---|---:|\n' + '\n'.join(rows) + '\n')
print('SERIAL_SLOPE_PRODUCTS_ARCHIVE_PREPARED')

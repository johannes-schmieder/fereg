//! Allocation-bounded certified MAP for categorical intercept and slope effects.
//!
//! The finalized categorical topology remains the sole owner of compact codes
//! and membership.  Continuous slope columns are borrowed from the prepared
//! numeric sample.  All numerical workspace is reserved before the first
//! projection; iterations and final certificates allocate nothing.

use std::time::Instant;

use crate::data::DenseMatrix;
use crate::error::{ErrorCode, FeregError, Result};
use crate::memory::{FeSolverMemoryBudget, SolverWorkspacePeak};
use rayon::prelude::*;

use super::{
    absorb_borrowed_intercept_cg_recovery_certified, borrow_categorical_topology_design,
    connected_components_all_fallible, recover_borrowed_intercept_sd_lsmr_coefficients,
    BorrowedInterceptRecoveryMethod, BorrowedMapWeights, CertifiedBorrowedMap, FeCertificate,
    FeCoefficientBatch, FeSolverKind, FinalizedCategoricalTopology, LsmrConfig, LsmrPreconditioner,
    MapConfig, SolveReport, SolveStopReason,
};
use within::{Effect, LsmrOptions, PreconditionerConfig};

#[derive(Debug, Clone, Copy)]
struct ValidatedWeights<'a> {
    values: Option<&'a [f64]>,
    raw_scale: f64,
}

impl ValidatedWeights<'_> {
    fn value(self, row: usize) -> f64 {
        self.values
            .map_or(1.0, |values| values[row] / self.raw_scale)
    }
}

/// One borrowed absorbed-effect basis in requested term order.
///
/// Categorical codes and membership remain owned by the finalized topology;
/// continuous channels remain owned by the prepared numeric sample.
#[derive(Debug, Clone, PartialEq)]
pub struct CategoricalAbsorbedEffectView<'a> {
    intercept: bool,
    slopes: Vec<&'a [f64]>,
}

/// Certified recovery of the absorbed contribution and any requested
/// term/channel contributions on the final compact observation axis.
///
/// Channels use absorbed-term order, with an intercept first when present and
/// slopes following in their declared order. Unrequested channels retain a
/// `None` slot so callers cannot accidentally lose wire identity.
#[derive(Debug, PartialEq)]
pub struct RecoveredCategoricalEffects {
    absorbed_sum: Option<Vec<f64>>,
    channels: Vec<Option<Vec<f64>>>,
    iterations: usize,
    reconstruction_relative_infinity: f64,
    recovery_method: CategoricalRecoveryMethod,
    solver_workspace_peak: SolverWorkspacePeak,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum CategoricalRecoveryMethod {
    RetainedCoefficients,
    Direct,
    SteepestDescent,
    HybridLsmr,
    Cg,
    Lsmr,
    Map,
}

impl RecoveredCategoricalEffects {
    /// Incremental recovery envelope, including every earlier failed attempt.
    /// Unsupported recovery models stay explicitly unknown.
    #[must_use]
    pub const fn solver_workspace_peak(&self) -> SolverWorkspacePeak {
        self.solver_workspace_peak
    }

    pub(crate) fn with_solver_workspace_peak(mut self, peak: SolverWorkspacePeak) -> Self {
        self.solver_workspace_peak = peak;
        self
    }

    #[must_use]
    pub fn absorbed_sum(&self) -> &[f64] {
        self.absorbed_sum
            .as_deref()
            .expect("categorical recovery caller requested the absorbed sum")
    }

    #[must_use]
    pub fn channels(&self) -> &[Option<Vec<f64>>] {
        &self.channels
    }

    #[must_use]
    pub const fn iterations(&self) -> usize {
        self.iterations
    }

    #[must_use]
    pub const fn reconstruction_relative_infinity(&self) -> f64 {
        self.reconstruction_relative_infinity
    }

    #[cfg(test)]
    pub(crate) const fn recovery_method(&self) -> CategoricalRecoveryMethod {
        self.recovery_method
    }

    #[must_use]
    pub fn into_parts(self) -> (Vec<f64>, Vec<Option<Vec<f64>>>) {
        (
            self.absorbed_sum
                .expect("categorical recovery caller requested the absorbed sum"),
            self.channels,
        )
    }

    #[must_use]
    pub fn into_optional_parts(self) -> (Option<Vec<f64>>, Vec<Option<Vec<f64>>>) {
        (self.absorbed_sum, self.channels)
    }
}

impl<'a> CategoricalAbsorbedEffectView<'a> {
    pub fn new(intercept: bool, slopes: Vec<&'a [f64]>) -> Result<Self> {
        if !intercept && slopes.is_empty() {
            return Err(invalid_argument(
                "categorical absorbed effect must contain an intercept or slope",
            ));
        }
        Ok(Self { intercept, slopes })
    }

    #[must_use]
    pub const fn has_intercept(&self) -> bool {
        self.intercept
    }

    #[must_use]
    pub fn slopes(&self) -> &[&'a [f64]] {
        &self.slopes
    }

    #[must_use]
    pub fn channels(&self) -> usize {
        usize::from(self.intercept) + self.slopes.len()
    }

    pub(crate) fn slope_storage_bytes(&self) -> u128 {
        self.slopes.capacity() as u128 * std::mem::size_of::<&[f64]>() as u128
    }

    fn basis_value(&self, channel: usize, row: usize, scales: &[f64]) -> f64 {
        if self.intercept {
            if channel == 0 {
                1.0
            } else {
                self.slopes[channel - 1][row] / scales[channel]
            }
        } else {
            self.slopes[channel][row] / scales[channel]
        }
    }
}

trait SlopeWorkspaceReservation {
    fn reserve_f64(
        &mut self,
        target: &mut Vec<f64>,
        elements: usize,
        label: &'static str,
    ) -> Result<()>;

    fn reserve_usize(
        &mut self,
        target: &mut Vec<usize>,
        elements: usize,
        label: &'static str,
    ) -> Result<()>;
}

struct SystemSlopeWorkspaceReservation;

impl SlopeWorkspaceReservation for SystemSlopeWorkspaceReservation {
    fn reserve_f64(
        &mut self,
        target: &mut Vec<f64>,
        elements: usize,
        label: &'static str,
    ) -> Result<()> {
        target
            .try_reserve_exact(elements)
            .map_err(|_| allocation(label))
    }

    fn reserve_usize(
        &mut self,
        target: &mut Vec<usize>,
        elements: usize,
        label: &'static str,
    ) -> Result<()> {
        target
            .try_reserve_exact(elements)
            .map_err(|_| allocation(label))
    }
}

pub(crate) fn slope_map_workspace_bytes(channels: usize, rhs: usize) -> Result<u128> {
    SlopeWorkspace::modeled_bytes(channels, rhs)
}

struct SlopeWorkspace {
    max_channels: usize,
    reference_norms: Vec<f64>,
    residual_norms: Vec<f64>,
    rhs_scales: Vec<f64>,
    value_scales: Vec<f64>,
    channel_scales: Vec<f64>,
    gram: Vec<f64>,
    gram_corrections: Vec<f64>,
    factor: Vec<f64>,
    cross: Vec<f64>,
    cross_corrections: Vec<f64>,
    factor_cross: Vec<f64>,
    coefficients: Vec<f64>,
    permutation: Vec<usize>,
}

impl SlopeWorkspace {
    fn modeled_bytes(channels: usize, rhs: usize) -> Result<u128> {
        let channels = channels as u128;
        let rhs = rhs as u128;
        let cells = channels
            .checked_mul(channels)
            .and_then(|square| square.checked_mul(3))
            .and_then(|square| {
                channels
                    .checked_mul(rhs)
                    .and_then(|cross| cross.checked_mul(4))
                    .and_then(|cross| square.checked_add(cross))
            })
            .and_then(|cells| rhs.checked_mul(4).and_then(|rhs| cells.checked_add(rhs)))
            .and_then(|cells| cells.checked_add(channels))
            .ok_or_else(|| allocation("categorical slope MAP workspace overflows"))?;
        cells
            .checked_mul(std::mem::size_of::<f64>() as u128)
            .and_then(|bytes| {
                channels
                    .checked_mul(std::mem::size_of::<usize>() as u128)
                    .and_then(|indices| bytes.checked_add(indices))
            })
            .ok_or_else(|| allocation("categorical slope MAP workspace bytes overflow"))
    }

    fn payload_bytes(&self) -> Result<u128> {
        let vectors = [
            &self.reference_norms,
            &self.residual_norms,
            &self.rhs_scales,
            &self.value_scales,
            &self.channel_scales,
            &self.gram,
            &self.gram_corrections,
            &self.factor,
            &self.cross,
            &self.cross_corrections,
            &self.factor_cross,
            &self.coefficients,
        ];
        let bytes = vectors.iter().try_fold(0_u128, |sum, values| {
            sum.checked_add((values.capacity() as u128) * std::mem::size_of::<f64>() as u128)
                .ok_or_else(|| allocation("categorical slope MAP capacities overflow"))
        })?;
        bytes
            .checked_add(
                (self.permutation.capacity() as u128) * std::mem::size_of::<usize>() as u128,
            )
            .ok_or_else(|| allocation("categorical slope MAP permutation capacity overflows"))
    }

    fn new<R: SlopeWorkspaceReservation>(
        max_channels: usize,
        rhs: usize,
        reservation: &mut R,
    ) -> Result<Self> {
        if max_channels == 0 {
            return Err(invalid_argument(
                "categorical slope MAP requires at least one basis channel",
            ));
        }
        let gram_elements = max_channels
            .checked_mul(max_channels)
            .ok_or_else(|| allocation("categorical slope MAP Gram workspace overflows"))?;
        let rhs_elements = max_channels
            .checked_mul(rhs)
            .ok_or_else(|| allocation("categorical slope MAP RHS workspace overflows"))?;
        Ok(Self {
            max_channels,
            reference_norms: reserved_zeros(
                rhs,
                reservation,
                "unable to reserve intercept-slope MAP reference norms",
            )?,
            residual_norms: reserved_zeros(
                rhs,
                reservation,
                "unable to reserve intercept-slope MAP residual norms",
            )?,
            rhs_scales: reserved_zeros(
                rhs,
                reservation,
                "unable to reserve intercept-slope MAP RHS scales",
            )?,
            value_scales: reserved_zeros(
                rhs,
                reservation,
                "unable to reserve intercept-slope MAP value scales",
            )?,
            channel_scales: reserved_zeros(
                max_channels,
                reservation,
                "unable to reserve categorical slope MAP channel scales",
            )?,
            gram: reserved_zeros(
                gram_elements,
                reservation,
                "unable to reserve categorical slope MAP Gram matrix",
            )?,
            gram_corrections: reserved_zeros(
                gram_elements,
                reservation,
                "unable to reserve categorical slope MAP Gram corrections",
            )?,
            factor: reserved_zeros(
                gram_elements,
                reservation,
                "unable to reserve categorical slope MAP factor matrix",
            )?,
            cross: reserved_zeros(
                rhs_elements,
                reservation,
                "unable to reserve categorical slope MAP cross-products",
            )?,
            cross_corrections: reserved_zeros(
                rhs_elements,
                reservation,
                "unable to reserve categorical slope MAP cross-product corrections",
            )?,
            factor_cross: reserved_zeros(
                rhs_elements,
                reservation,
                "unable to reserve categorical slope MAP factored cross-products",
            )?,
            coefficients: reserved_zeros(
                rhs_elements,
                reservation,
                "unable to reserve categorical slope MAP coefficients",
            )?,
            permutation: reserved_indices(
                max_channels,
                reservation,
                "unable to reserve categorical slope MAP permutation",
            )?,
        })
    }
}

/// Compatibility wrapper for the previously qualified intercept-plus-one-slope
/// surface. New code should use `absorb_finalized_categorical_slope_map_certified`.
pub fn absorb_finalized_categorical_intercept_slope_map_certified(
    topology: &FinalizedCategoricalTopology,
    slopes: &[Option<&[f64]>],
    weights: BorrowedMapWeights<'_>,
    values: DenseMatrix,
    config: MapConfig,
) -> Result<CertifiedBorrowedMap> {
    let mut effects = Vec::new();
    effects
        .try_reserve_exact(slopes.len())
        .map_err(|_| allocation("unable to reserve compatibility absorbed effects"))?;
    for slope in slopes {
        let mut channels = Vec::new();
        channels
            .try_reserve_exact(usize::from(slope.is_some()))
            .map_err(|_| allocation("unable to reserve compatibility slope channels"))?;
        if let Some(values) = slope {
            channels.push(*values);
        }
        effects.push(CategoricalAbsorbedEffectView::new(true, channels)?);
    }
    absorb_finalized_categorical_slope_map_certified(topology, &effects, weights, values, config)
}

/// Residualize arbitrary categorical intercept, slope-only, and
/// intercept-plus-slope effects without copying observation-scale topology or
/// continuous source columns.
pub fn absorb_finalized_categorical_slope_map_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    values: DenseMatrix,
    config: MapConfig,
) -> Result<CertifiedBorrowedMap> {
    absorb_finalized_categorical_slope_map_with_budget_certified(
        topology, effects, weights, values, config, None,
    )
}

pub(crate) fn absorb_finalized_categorical_slope_map_with_budget_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    values: DenseMatrix,
    config: MapConfig,
    budget: Option<FeSolverMemoryBudget>,
) -> Result<CertifiedBorrowedMap> {
    let mut reservation = SystemSlopeWorkspaceReservation;
    absorb_with_reservation(
        topology,
        effects,
        weights,
        values,
        config,
        budget,
        &mut reservation,
    )
}

/// Recover one normalized MAP decomposition of an absorbed contribution.
///
/// Starting from zero and accumulating every ordered projection reproduces the
/// same weighted-zero-mean normalization used by the pinned reference for
/// intercept-only effects. The total absorbed contribution is always returned;
/// observation-scale channel vectors are allocated only when requested.
pub fn recover_finalized_categorical_effects_map_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    config: MapConfig,
) -> Result<RecoveredCategoricalEffects> {
    let mut reservation = SystemSlopeWorkspaceReservation;
    recover_with_reservation(
        topology,
        effects,
        weights,
        target,
        requested_channels,
        config,
        &mut reservation,
    )
}

/// Additional storage over the existing recovery finishing envelope. Construction
/// owns a target copy, group/column coefficient banks and one workspace per
/// bounded worker; these owners are released before publication certification.
pub(crate) fn single_slope_recovery_extra_bytes(
    observations: usize,
    levels: usize,
    channels: usize,
    threads: usize,
) -> Result<u128> {
    if levels == 0 || levels > observations || !(1..=4).contains(&channels) || threads == 0 {
        return Err(invalid_argument(
            "single slope recovery memory dimensions are inconsistent",
        ));
    }
    let workers = threads.min(levels);
    let workspace =
        SlopeWorkspace::modeled_bytes(channels, 1)? + std::mem::size_of::<SlopeWorkspace>() as u128;
    (observations as u128 * 8)
        .checked_add(levels as u128 * (channels as u128 * 16 + 16))
        .and_then(|bytes| bytes.checked_add(workers as u128 * workspace))
        .ok_or_else(|| allocation("single slope recovery storage overflows"))
}

/// One partition has independent level systems. Keep the established scaled,
/// compensated MAP rank policy, then independently certify the reconstructed
/// target through the ordinary channel-major finishing boundary.
#[allow(clippy::too_many_arguments)]
pub(crate) fn recover_finalized_single_slope_direct_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    tolerance: f64,
    materialize_absorbed_sum: bool,
) -> Result<RecoveredCategoricalEffects> {
    let recovery_started = Instant::now();
    validate_recovery_inputs(topology, effects, target, requested_channels)?;
    if effects.len() != 1
        || effects[0].slopes().is_empty()
        || effects[0].channels() > 4
        || !tolerance.is_finite()
        || tolerance <= 0.0
    {
        return Err(invalid_argument(
            "direct slope recovery requires one bounded slope partition",
        ));
    }
    let weights = validate_weights(weights, target.len())?;
    let effect = &effects[0];
    let source = topology
        .registry()
        .source(topology.effect_to_topology()[0])?;
    let levels = source.n_levels();
    let channels = effect.channels();
    let width = levels
        .checked_mul(channels)
        .ok_or_else(|| allocation("single slope recovery coefficient count overflows"))?;
    let workers = rayon::current_num_threads().min(levels).max(1);
    let block = levels.div_ceil(workers);
    let blocks = levels.div_ceil(block);
    let planned = single_slope_recovery_extra_bytes(target.len(), levels, channels, workers)?;
    let values = DenseMatrix::from_row_major(
        target.len(),
        1,
        fallible_copy(target, "unable to reserve direct recovery target")?,
    )?;
    let mut group_coefficients =
        fallible_filled(width, 0.0, "unable to reserve direct group coefficients")?;
    let mut coefficients =
        fallible_filled(width, 0.0, "unable to reserve direct channel coefficients")?;
    let mut workspaces = Vec::new();
    workspaces
        .try_reserve_exact(blocks)
        .map_err(|_| allocation("unable to reserve direct recovery workers"))?;
    for _ in 0..blocks {
        workspaces.push(SlopeWorkspace::new(
            channels,
            1,
            &mut SystemSlopeWorkspaceReservation,
        )?);
    }
    let actual = 8
        * (values.storage_capacity() as u128
            + group_coefficients.capacity() as u128
            + coefficients.capacity() as u128)
        + workspaces.capacity() as u128 * std::mem::size_of::<SlopeWorkspace>() as u128;
    let actual = workspaces.iter().try_fold(actual, |bytes, workspace| {
        workspace.payload_bytes().map(|payload| bytes + payload)
    })?;
    if actual > planned {
        return Err(allocation(
            "direct recovery capacities exceed their admission",
        ));
    }
    let recovery_groups = Instant::now();
    group_coefficients
        .par_chunks_mut(block * channels)
        .zip(workspaces.par_iter_mut())
        .enumerate()
        .try_for_each(|(batch, (bank, workspace))| -> Result<()> {
            for (local, destination) in bank.chunks_mut(channels).enumerate() {
                group_moments(
                    source.members(batch * block + local)?,
                    effect,
                    weights,
                    &values,
                    workspace,
                )?;
                solve_group(channels, 1, workspace)?;
                for (channel, value) in destination.iter_mut().enumerate() {
                    *value = workspace.coefficients[channel] / workspace.channel_scales[channel];
                    if !value.is_finite() {
                        return Err(invalid_data("direct recovery coefficient is not finite"));
                    }
                }
            }
            Ok(())
        })?;
    let recovery_scatter = Instant::now();
    for channel in 0..channels {
        for level in 0..levels {
            coefficients[channel * levels + level] = group_coefficients[level * channels + channel];
        }
    }
    drop(workspaces);
    drop(group_coefficients);
    drop(values);
    // A single intercept-bearing effect has no cross-effect normalization.
    let recovery_finish = Instant::now();
    let recovered = finish_channel_major_recovery(
        topology,
        effects,
        weights,
        target,
        requested_channels,
        &coefficients,
        1,
        tolerance,
        CategoricalRecoveryMethod::Direct,
        materialize_absorbed_sum,
    );
    eprintln!("SLOPE_PROFILE|direct_recovery|setup={:.9}|groups={:.9}|transpose={:.9}|finish={:.9}", recovery_groups.duration_since(recovery_started).as_secs_f64(), recovery_scatter.duration_since(recovery_groups).as_secs_f64(), recovery_finish.duration_since(recovery_scatter).as_secs_f64(), recovery_finish.elapsed().as_secs_f64());
    recovered
}

/// Recover normalized categorical effects from a coefficient product retained
/// by the estimator. This path performs no iterative solve: it normalizes the
/// solver's null-space representative, scatters requested channels, and
/// independently certifies reconstruction and FE orthogonality.
#[allow(clippy::too_many_arguments)]
#[cfg(test)]
pub(crate) fn recover_finalized_categorical_effects_from_coefficients_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    coefficients: &FeCoefficientBatch,
    tolerance: f64,
    known_connected: bool,
) -> Result<RecoveredCategoricalEffects> {
    recover_finalized_categorical_effects_from_coefficients_selected_certified(
        topology,
        effects,
        weights,
        target,
        requested_channels,
        coefficients,
        tolerance,
        known_connected,
        true,
    )
}

/// Retained-coefficient publication with an exact output materialization plan.
/// Saved-only calls certify the same coefficient product without retaining an
/// additional observation-length combined absorbed vector.
#[allow(clippy::too_many_arguments)]
pub(crate) fn recover_finalized_categorical_effects_from_coefficients_selected_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    coefficients: &FeCoefficientBatch,
    tolerance: f64,
    known_connected: bool,
    materialize_absorbed_sum: bool,
) -> Result<RecoveredCategoricalEffects> {
    validate_recovery_inputs(topology, effects, target, requested_channels)?;
    validate_coefficient_layout(topology, effects, coefficients)?;
    if coefficients.rhs_count() != 1 {
        return Err(invalid_argument(
            "categorical recovery requires exactly one combined coefficient RHS",
        ));
    }
    let weights = validate_weights(weights, target.len())?;
    let mut normalized = fallible_copy(
        coefficients.rhs(0)?,
        "unable to reserve categorical recovery normalized coefficients",
    )?;
    normalize_intercept_components(topology, effects, weights, &mut normalized, known_connected)?;
    finish_channel_major_recovery(
        topology,
        effects,
        weights,
        target,
        requested_channels,
        &normalized,
        0,
        tolerance,
        CategoricalRecoveryMethod::RetainedCoefficients,
        materialize_absorbed_sum,
    )
}

/// Propagate an already projected two-effect target over a spanning forest.
/// Every edge is checked by the ordinary reconstruction certificate afterward;
/// inconsistent targets and accumulated roundoff fall back to iterative recovery.
#[allow(clippy::too_many_arguments)]
pub(crate) fn recover_finalized_two_effects_graph_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    tolerance: f64,
    known_connected: bool,
    materialize_absorbed_sum: bool,
) -> Result<RecoveredCategoricalEffects> {
    validate_recovery_inputs(topology, effects, target, requested_channels)?;
    if effects.len() != 2 || effects.iter().any(|e| !e.has_intercept() || !e.slopes().is_empty()) {
        return Err(invalid_argument("graph recovery requires two intercept-only effects"));
    }
    let sources = topology_source_table(topology)?;
    let design = borrow_categorical_topology_design(target.len(), topology.registry(),
        &sources, topology.effect_to_topology())?;
    let left = &design.effects()[0];
    let right = &design.effects()[1];
    let offset = left.n_levels();
    let count = offset.checked_add(right.n_levels())
        .ok_or_else(|| allocation("graph recovery level count overflows"))?;
    // NaN is only an unvisited marker. All assigned coefficients must be finite.
    let mut coefficients = fallible_filled(count, f64::NAN, "graph recovery coefficients")?;
    {
        let mut queue = fallible_with_capacity(count, "graph recovery traversal")?;
        for root in 0..offset {
            if !coefficients[root].is_nan() { continue; }
            coefficients[root] = 0.0;
            queue.clear();
            queue.push(root);
            let mut head = 0;
            while head < queue.len() {
                let node = queue[head];
                head += 1;
                let (effect, level) = if node < offset { (left, node) } else { (right, node - offset) };
                for &row in effect.level_index().checked_members(level)? {
                    let other = if node < offset { offset + right.codes()[row] as usize }
                        else { left.codes()[row] as usize };
                    if coefficients[other].is_nan() {
                        let value = target[row] - coefficients[node];
                        if !value.is_finite() {
                            return Err(invalid_data("graph recovery coefficient is nonfinite"));
                        }
                        coefficients[other] = value;
                        queue.push(other);
                    }
                }
            }
        }
    }
    let weights = validate_weights(weights, target.len())?;
    normalize_intercept_components(topology, effects, weights, &mut coefficients, known_connected)?;
    finish_channel_major_recovery(topology, effects, weights, target, requested_channels,
        &coefficients, 0, tolerance, CategoricalRecoveryMethod::Direct, materialize_absorbed_sum)
}

/// Recover effects with one coefficient-producing modified-LSMR solve.
///
/// This is the bounded fallback for observation-space MAP/CG/extrapolation
/// routes and for low-memory fits that deliberately do not retain all initial
/// RHS coefficient vectors.
pub(crate) fn recover_finalized_categorical_effects_lsmr_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    config: LsmrConfig,
    publication_tolerance: f64,
) -> Result<RecoveredCategoricalEffects> {
    validate_recovery_inputs(topology, effects, target, requested_channels)?;
    if !config.tolerance.is_finite()
        || config.tolerance <= 0.0
        || config.max_iterations == 0
        || config.local_size == Some(0)
        || !publication_tolerance.is_finite()
        || publication_tolerance <= 0.0
    {
        return Err(invalid_argument(
            "categorical recovery LSMR policy is invalid",
        ));
    }
    let source_table = topology_source_table(topology)?;
    let mut within_effects = Vec::new();
    within_effects
        .try_reserve_exact(effects.len())
        .map_err(|_| allocation("unable to reserve categorical recovery LSMR effects"))?;
    let mut effect_channels = Vec::new();
    let mut level_counts = Vec::new();
    effect_channels
        .try_reserve_exact(effects.len())
        .map_err(|_| allocation("unable to reserve categorical recovery channel layout"))?;
    level_counts
        .try_reserve_exact(effects.len())
        .map_err(|_| allocation("unable to reserve categorical recovery level layout"))?;
    for (effect_index, effect) in effects.iter().enumerate() {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        let codes = source.codes(&source_table)?;
        within_effects.push(
            Effect::new(
                codes,
                effect.has_intercept(),
                effect.slopes().iter().copied(),
            )
            .map_err(|error| {
                invalid_data(format!(
                    "unable to construct categorical recovery LSMR effect: {error}"
                ))
            })?,
        );
        effect_channels.push(effect.channels());
        level_counts.push(source.n_levels());
    }
    let options = LsmrOptions {
        tol: config.tolerance,
        maxiter: config.max_iterations,
        local_size: config.local_size,
    };
    let coefficient_count = effect_channels.iter().zip(&level_counts).try_fold(
        0_usize,
        |total, (&channels, &levels)| {
            total
                .checked_add(channels.checked_mul(levels).ok_or_else(|| {
                    allocation("categorical recovery LSMR coefficient width overflows")
                })?)
                .ok_or_else(|| allocation("categorical recovery LSMR coefficient count overflows"))
        },
    )?;
    let preconditioner =
        recovery_preconditioner(config.preconditioner, effects.len(), coefficient_count);
    let weight_values = match weights {
        BorrowedMapWeights::Unit => None,
        BorrowedMapWeights::Provided(values) => Some(values),
    };
    let initial = within::solve(
        within_effects.clone(),
        target,
        weight_values,
        Some(&options),
        preconditioner,
    );
    let solved = match initial {
        Ok(solved) => solved,
        Err(error)
            if config.preconditioner == LsmrPreconditioner::Auto
                && recovery_preconditioner_breakdown(&error) =>
        {
            within::solve(
                within_effects,
                target,
                weight_values,
                Some(&options),
                PreconditionerConfig::Off,
            )
            .map_err(|fallback_error| {
                invalid_data(format!(
                    "categorical recovery LSMR failed after unpreconditioned fallback: {fallback_error}"
                ))
            })?
        }
        Err(error) => {
            return Err(invalid_data(format!(
                "categorical recovery LSMR failed: {error}"
            )))
        }
    };
    if !solved.converged {
        return Err(invalid_data(format!(
            "categorical recovery LSMR exhausted its iteration budget after {} iterations",
            solved.iterations
        )));
    }
    let residual = DenseMatrix::from_row_major(target.len(), 1, solved.demeaned)?;
    let validated_weights = validate_weights(weights, target.len())?;
    let mut reservation = SystemSlopeWorkspaceReservation;
    let mut workspace = SlopeWorkspace::new(
        effects
            .iter()
            .map(CategoricalAbsorbedEffectView::channels)
            .max()
            .unwrap_or(1),
        1,
        &mut reservation,
    )?;
    weighted_norms(
        &DenseMatrix::from_row_major(
            target.len(),
            1,
            fallible_copy(
                target,
                "unable to reserve categorical recovery reference target",
            )?,
        )?,
        validated_weights,
        &mut workspace.reference_norms,
        &mut workspace.value_scales,
        &mut workspace.coefficients[..1],
    )?;
    let certificate = certify(
        topology,
        effects,
        validated_weights,
        &residual,
        publication_tolerance,
        &mut workspace,
    )?;
    if !certificate.passed {
        return Err(invalid_data(
            "categorical recovery LSMR returned an uncertified residual",
        ));
    }
    let coefficients = FeCoefficientBatch::from_values(effect_channels, level_counts, 1, solved.x)?;
    let mut normalized = fallible_copy(
        coefficients.rhs(0)?,
        "unable to reserve categorical recovery LSMR normalized coefficients",
    )?;
    normalize_intercept_components(topology, effects, validated_weights, &mut normalized, false)?;
    finish_channel_major_recovery(
        topology,
        effects,
        validated_weights,
        target,
        requested_channels,
        &normalized,
        solved.iterations,
        publication_tolerance,
        CategoricalRecoveryMethod::Lsmr,
        true,
    )
}

/// Recover intercept-only effects through the production SD-Kaczmarz pilot
/// and remainder-LSMR hybrid. Component normalization and publication checks
/// remain topology-owned and are recomputed from the combined coefficients.
pub(crate) fn recover_finalized_categorical_effects_sd_lsmr_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    lsmr: LsmrConfig,
    map: MapConfig,
    validated_single: Option<super::ValidatedSingleTopology<'_>>,
) -> Result<RecoveredCategoricalEffects> {
    let validated_single = match validated_single {
        Some(validated) => {
            if !validated.matches_owner(topology) {
                return Err(invalid_argument("recovery validation receipt belongs to another topology"));
            }
            Some(validated)
        }
        None => topology.validate_single_source()?,
    };
    if validated_single.is_none() {
        topology.validate()?;
    }
    validate_recovery_arguments(topology, effects, target, requested_channels)?;
    if effects
        .iter()
        .any(|effect| !effect.has_intercept() || !effect.slopes().is_empty())
    {
        return Err(invalid_argument(
            "SD-Kaczmarz fast recovery requires intercept-only effects",
        ));
    }
    let design = if let Some(validated) = validated_single {
        validated.into_design(target.len())?
    } else {
        let source_table = topology_source_table(topology)?;
        borrow_categorical_topology_design(
            target.len(), topology.registry(), &source_table, topology.effect_to_topology(),
        )?
    };
    let recovered = recover_borrowed_intercept_sd_lsmr_coefficients(
        &design,
        weights,
        target,
        map,
        lsmr,
        recovery_reconstruction_threshold(map.tolerance),
    )?;
    let validated_weights = validate_weights(weights, target.len())?;
    let mut normalized = fallible_copy(
        recovered.coefficients.rhs(0)?,
        "unable to reserve categorical recovery SD-LSMR normalized coefficients",
    )?;
    normalize_intercept_components(topology, effects, validated_weights, &mut normalized, false)?;
    let method = match recovered.method {
        BorrowedInterceptRecoveryMethod::Direct => CategoricalRecoveryMethod::Direct,
        BorrowedInterceptRecoveryMethod::SteepestDescent => {
            CategoricalRecoveryMethod::SteepestDescent
        }
        BorrowedInterceptRecoveryMethod::HybridLsmr => CategoricalRecoveryMethod::HybridLsmr,
    };
    finish_channel_major_recovery(
        topology,
        effects,
        validated_weights,
        target,
        requested_channels,
        &normalized,
        recovered.iterations,
        map.tolerance,
        method,
        true,
    )
}

/// Recover intercept-only effects with the optimized borrowed one-RHS CG
/// recurrence and retain the coefficient product it already computes.
pub(crate) fn recover_finalized_categorical_effects_cg_certified(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    map: MapConfig,
) -> Result<RecoveredCategoricalEffects> {
    validate_recovery_inputs(topology, effects, target, requested_channels)?;
    if effects
        .iter()
        .any(|effect| !effect.has_intercept() || !effect.slopes().is_empty())
    {
        return Err(invalid_argument(
            "CG fast recovery requires intercept-only effects",
        ));
    }
    let source_table = topology_source_table(topology)?;
    let design = borrow_categorical_topology_design(
        target.len(),
        topology.registry(),
        &source_table,
        topology.effect_to_topology(),
    )?;
    let mut target_values = Vec::new();
    target_values
        .try_reserve_exact(target.len())
        .map_err(|_| allocation("unable to reserve CG recovery target"))?;
    target_values.extend_from_slice(target);
    let recovered = absorb_borrowed_intercept_cg_recovery_certified(
        &design,
        weights,
        DenseMatrix::from_row_major(target.len(), 1, target_values)?,
        map,
        recovery_reconstruction_threshold(map.tolerance),
    )?;
    let (_, report, coefficients) = recovered.into_full_parts();
    let coefficients = coefficients.ok_or_else(|| {
        invalid_data("CG recovery did not retain its certified coefficient product")
    })?;
    let validated_weights = validate_weights(weights, target.len())?;
    let mut normalized = fallible_copy(
        coefficients.rhs(0)?,
        "unable to reserve categorical recovery CG normalized coefficients",
    )?;
    normalize_intercept_components(topology, effects, validated_weights, &mut normalized, false)?;
    finish_channel_major_recovery(
        topology,
        effects,
        validated_weights,
        target,
        requested_channels,
        &normalized,
        report.iterations,
        map.tolerance,
        CategoricalRecoveryMethod::Cg,
        true,
    )
}

fn validate_recovery_inputs(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    target: &[f64],
    requested_channels: &[bool],
) -> Result<()> {
    topology.validate()?;
    validate_recovery_arguments(topology, effects, target, requested_channels)
}

fn validate_recovery_arguments(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    target: &[f64],
    requested_channels: &[bool],
) -> Result<()> {
    if target.len() != topology.retained_rows().len()
        || effects.len() != topology.effect_to_topology().len()
        || target.is_empty()
        || target.iter().any(|value| !value.is_finite())
    {
        return Err(invalid_argument(
            "categorical recovery inputs are not finite and aligned",
        ));
    }
    let channels = effects.iter().try_fold(0_usize, |total, effect| {
        total
            .checked_add(effect.channels())
            .ok_or_else(|| allocation("categorical recovery channel count overflows"))
    })?;
    if channels == 0 || requested_channels.len() != channels {
        return Err(invalid_argument(
            "categorical recovery requested-channel layout differs",
        ));
    }
    Ok(())
}

fn validate_coefficient_layout(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    coefficients: &FeCoefficientBatch,
) -> Result<()> {
    if coefficients.effect_channels().len() != effects.len()
        || coefficients.level_counts().len() != topology.effect_to_topology().len()
    {
        return Err(invalid_argument(
            "categorical recovery coefficient layout differs from the finalized effects",
        ));
    }
    for (effect_index, effect) in effects.iter().enumerate() {
        let levels = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?
            .n_levels();
        if coefficients.effect_channels()[effect_index] != effect.channels()
            || coefficients.level_counts()[effect_index] != levels
        {
            return Err(invalid_argument(
                "categorical recovery coefficient layout differs from the finalized effects",
            ));
        }
    }
    Ok(())
}

fn topology_source_table(
    topology: &FinalizedCategoricalTopology,
) -> Result<Vec<super::CategoricalCodeView<'_>>> {
    let mut source_table = Vec::new();
    source_table
        .try_reserve_exact(topology.compacted_sources().len())
        .map_err(|_| allocation("unable to reserve categorical recovery source views"))?;
    for source in topology.compacted_sources() {
        source_table.push(source.view());
    }
    Ok(source_table)
}

fn normalize_intercept_components(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: ValidatedWeights<'_>,
    coefficients: &mut [f64],
    known_connected: bool,
) -> Result<()> {
    let mut intercept_effects = fallible_with_capacity(
        effects.len(),
        "unable to reserve categorical recovery intercept-effect indices",
    )?;
    for (index, effect) in effects.iter().enumerate() {
        if effect.has_intercept() {
            intercept_effects.push(index);
        }
    }
    if intercept_effects.len() <= 1 {
        return Ok(());
    }
    if known_connected {
        return normalize_connected_intercepts(
            topology,
            effects,
            weights,
            coefficients,
            &intercept_effects,
        );
    }
    let source_table = topology_source_table(topology)?;
    let mut codes = fallible_with_capacity(
        intercept_effects.len(),
        "unable to reserve categorical recovery component code views",
    )?;
    let mut levels = fallible_with_capacity(
        intercept_effects.len(),
        "unable to reserve categorical recovery component level counts",
    )?;
    for &effect_index in &intercept_effects {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        codes.push(source.codes(&source_table)?);
        levels.push(source.n_levels());
    }
    let components = connected_components_all_fallible(&codes, &levels)?;
    let mut component_weights = fallible_filled(
        components.n_components,
        0.0_f64,
        "unable to reserve categorical recovery component weights",
    )?;
    let anchor_components = &components.component_by_effect_level[0];
    for (level, &component) in anchor_components.iter().enumerate() {
        if component == usize::MAX {
            continue;
        }
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[intercept_effects[0]])?;
        let members = source.members(level)?;
        if weights.values.is_none() {
            component_weights[component] += members.len() as f64;
        } else {
            for &row in members {
                component_weights[component] += weights.value(row);
            }
        }
    }
    let effect_offsets = channel_major_effect_offsets(topology, effects)?;
    let mut anchor_adjustments = fallible_filled(
        components.n_components,
        0.0_f64,
        "unable to reserve categorical recovery component adjustments",
    )?;
    for (local_effect, &effect_index) in intercept_effects.iter().enumerate().skip(1) {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        let mut means = fallible_filled(
            components.n_components,
            0.0_f64,
            "unable to reserve categorical recovery component means",
        )?;
        for level in 0..source.n_levels() {
            let component = components.component_by_effect_level[local_effect][level];
            if component == usize::MAX {
                continue;
            }
            let coefficient = coefficients[effect_offsets[effect_index] + level];
            let members = source.members(level)?;
            if weights.values.is_none() {
                means[component] += members.len() as f64 * coefficient;
            } else {
                for &row in members {
                    means[component] += weights.value(row) * coefficient;
                }
            }
        }
        for (mean, &weight) in means.iter_mut().zip(&component_weights) {
            *mean = if weight > 0.0 { *mean / weight } else { 0.0 };
        }
        for level in 0..source.n_levels() {
            let component = components.component_by_effect_level[local_effect][level];
            if component != usize::MAX {
                coefficients[effect_offsets[effect_index] + level] -= means[component];
            }
        }
        for (adjustment, mean) in anchor_adjustments.iter_mut().zip(means) {
            *adjustment += mean;
        }
    }
    let anchor_effect = intercept_effects[0];
    let anchor_source = topology
        .registry()
        .source(topology.effect_to_topology()[anchor_effect])?;
    for level in 0..anchor_source.n_levels() {
        let component = components.component_by_effect_level[0][level];
        if component != usize::MAX {
            coefficients[effect_offsets[anchor_effect] + level] += anchor_adjustments[component];
        }
    }
    if coefficients.iter().any(|value| !value.is_finite()) {
        return Err(invalid_data(
            "categorical recovery normalization produced a nonfinite coefficient",
        ));
    }
    Ok(())
}

fn normalize_connected_intercepts(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: ValidatedWeights<'_>,
    coefficients: &mut [f64],
    intercept_effects: &[usize],
) -> Result<()> {
    let effect_offsets = channel_major_effect_offsets(topology, effects)?;
    let total_weight = if weights.values.is_none() {
        topology.retained_rows().len() as f64
    } else {
        (0..topology.retained_rows().len())
            .map(|row| weights.value(row))
            .sum::<f64>()
    };
    if !total_weight.is_finite() || total_weight <= 0.0 {
        return Err(invalid_data(
            "categorical recovery connected-component weight is invalid",
        ));
    }
    let mut anchor_adjustment = 0.0_f64;
    for &effect_index in intercept_effects.iter().skip(1) {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        let mut numerator = 0.0_f64;
        for level in 0..source.n_levels() {
            let coefficient = coefficients[effect_offsets[effect_index] + level];
            let members = source.members(level)?;
            if weights.values.is_none() {
                numerator += members.len() as f64 * coefficient;
            } else {
                for &row in members {
                    numerator += weights.value(row) * coefficient;
                }
            }
        }
        let mean = numerator / total_weight;
        if !mean.is_finite() {
            return Err(invalid_data(
                "categorical recovery connected-component mean is invalid",
            ));
        }
        for level in 0..source.n_levels() {
            coefficients[effect_offsets[effect_index] + level] -= mean;
        }
        anchor_adjustment += mean;
    }
    let anchor_effect = intercept_effects[0];
    let anchor_source = topology
        .registry()
        .source(topology.effect_to_topology()[anchor_effect])?;
    for level in 0..anchor_source.n_levels() {
        coefficients[effect_offsets[anchor_effect] + level] += anchor_adjustment;
    }
    if coefficients.iter().any(|value| !value.is_finite()) {
        return Err(invalid_data(
            "categorical recovery connected normalization produced a nonfinite coefficient",
        ));
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn finish_channel_major_recovery(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: ValidatedWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    coefficients: &[f64],
    iterations: usize,
    tolerance: f64,
    recovery_method: CategoricalRecoveryMethod,
    materialize_absorbed_sum: bool,
) -> Result<RecoveredCategoricalEffects> {
    let effect_offsets = channel_major_effect_offsets(topology, effects)?;
    if coefficients.len() != effect_offsets.last().copied().unwrap_or(0) {
        return Err(invalid_argument(
            "categorical recovery coefficient count is inconsistent",
        ));
    }
    if effects
        .iter()
        .all(|effect| effect.has_intercept() && effect.slopes().is_empty())
    {
        return finish_intercept_only_recovery(
            topology,
            effects,
            weights,
            target,
            requested_channels,
            coefficients,
            &effect_offsets,
            iterations,
            tolerance,
            recovery_method,
            materialize_absorbed_sum,
        );
    }
    let mut absorbed_sum = fallible_filled(
        target.len(),
        0.0_f64,
        "unable to reserve categorical recovery absorbed sum",
    )?;
    let mut channels = Vec::new();
    channels
        .try_reserve_exact(requested_channels.len())
        .map_err(|_| allocation("unable to reserve recovered channel registry"))?;
    let mut flat_channel = 0_usize;
    for (effect_index, effect) in effects.iter().enumerate() {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        for channel in 0..effect.channels() {
            let mut contribution = if requested_channels[flat_channel] {
                Some(fallible_filled(
                    target.len(),
                    0.0_f64,
                    "unable to reserve categorical recovery channel contribution",
                )?)
            } else {
                None
            };
            for level in 0..source.n_levels() {
                let alpha = coefficients
                    [effect_offsets[effect_index] + channel * source.n_levels() + level];
                for &row in source.members(level)? {
                    let basis = if effect.has_intercept() && channel == 0 {
                        1.0
                    } else {
                        let slope_index = channel - usize::from(effect.has_intercept());
                        effect.slopes()[slope_index][row]
                    };
                    let value = alpha * basis;
                    absorbed_sum[row] += value;
                    if let Some(output) = contribution.as_mut() {
                        output[row] = value;
                    }
                }
            }
            channels.push(contribution);
            flat_channel += 1;
        }
    }
    let mut reservation = SystemSlopeWorkspaceReservation;
    let mut workspace = SlopeWorkspace::new(
        effects
            .iter()
            .map(CategoricalAbsorbedEffectView::channels)
            .max()
            .unwrap_or(1),
        1,
        &mut reservation,
    )?;
    workspace.value_scales[0] = 0.0;
    workspace.coefficients[0] = 1.0;
    let mut target_infinity = 0.0_f64;
    let mut residual_infinity = 0.0_f64;
    let mut residual_values = Vec::new();
    residual_values
        .try_reserve_exact(target.len())
        .map_err(|_| allocation("unable to reserve categorical recovery residual"))?;
    for (row, (&expected, &actual)) in target.iter().zip(&absorbed_sum).enumerate() {
        let remainder = expected - actual;
        if !remainder.is_finite() {
            return Err(invalid_data(
                "categorical recovery coefficient product produced a nonfinite residual",
            ));
        }
        residual_values.push(remainder);
        target_infinity = target_infinity.max(expected.abs());
        residual_infinity = residual_infinity.max(remainder.abs());
        let weighted_target = weights.value(row).sqrt() * expected;
        if !weighted_target.is_finite() {
            return Err(invalid_data(
                "categorical recovery weighted target is nonfinite",
            ));
        }
        update_scaled_sum(
            weighted_target,
            &mut workspace.value_scales[0],
            &mut workspace.coefficients[0],
        );
    }
    workspace.reference_norms[0] = if workspace.value_scales[0] == 0.0 {
        0.0
    } else {
        workspace.value_scales[0] * workspace.coefficients[0].sqrt()
    };
    if !workspace.reference_norms[0].is_finite() {
        return Err(invalid_data(
            "categorical recovery weighted target norm is nonfinite",
        ));
    }
    let residual = DenseMatrix::from_row_major(target.len(), 1, residual_values)?;
    let reconstruction_relative_infinity = if target_infinity == 0.0 {
        residual_infinity
    } else {
        residual_infinity / target_infinity
    };
    if !reconstruction_relative_infinity.is_finite() {
        return Err(invalid_data(
            "categorical recovery reconstruction ratio is not finite",
        ));
    }
    if reconstruction_relative_infinity > recovery_reconstruction_threshold(tolerance) {
        return Err(invalid_data(format!(
            "categorical recovery coefficient product failed reconstruction: relative infinity residual {reconstruction_relative_infinity:.6e}"
        )));
    }
    let certificate = if recovery_method == CategoricalRecoveryMethod::Direct
        && effects.len() == 1 && rayon::current_num_threads() > 1
    {
        certify_single_slope_parallel(topology, &effects[0], weights, &residual, tolerance, &mut workspace)?
    } else {
        certify(topology, effects, weights, &residual, tolerance, &mut workspace)?
    };
    if !certificate.passed {
        return Err(invalid_data(
            "categorical recovery coefficient product failed its FE certificate",
        ));
    }
    Ok(RecoveredCategoricalEffects {
        solver_workspace_peak: SolverWorkspacePeak::UNMODELED,
        absorbed_sum: Some(absorbed_sum),
        channels,
        iterations,
        reconstruction_relative_infinity,
        recovery_method,
    })
}

#[allow(clippy::too_many_arguments)]
fn finish_intercept_only_recovery(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: ValidatedWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    coefficients: &[f64],
    effect_offsets: &[usize],
    iterations: usize,
    tolerance: f64,
    recovery_method: CategoricalRecoveryMethod,
    materialize_absorbed_sum: bool,
) -> Result<RecoveredCategoricalEffects> {
    const RECOVERY_CHUNK_ROWS: usize = 32_768;

    if effects.len() == 1 {
        return finish_one_intercept_recovery(
            topology,
            weights,
            target,
            requested_channels,
            coefficients,
            effect_offsets,
            iterations,
            tolerance,
            recovery_method,
            materialize_absorbed_sum,
        );
    }

    let source_table = topology_source_table(topology)?;
    let mut codes = Vec::new();
    codes
        .try_reserve_exact(effects.len())
        .map_err(|_| allocation("unable to reserve intercept recovery code views"))?;
    let mut levels = Vec::new();
    levels
        .try_reserve_exact(effects.len())
        .map_err(|_| allocation("unable to reserve intercept recovery level counts"))?;
    for effect_index in 0..effects.len() {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        codes.push(source.codes(&source_table)?);
        levels.push(source.n_levels());
    }

    let mut channels = Vec::new();
    channels
        .try_reserve_exact(requested_channels.len())
        .map_err(|_| allocation("unable to reserve recovered channel registry"))?;
    for effect_index in 0..effects.len() {
        if requested_channels[effect_index] {
            let mut values = fallible_filled(
                target.len(),
                0.0_f64,
                "unable to reserve categorical recovery intercept channel",
            )?;
            let effect_codes = codes[effect_index];
            let coefficient_offset = effect_offsets[effect_index];
            let effect_levels = levels[effect_index];
            values
                .par_iter_mut()
                .enumerate()
                .try_for_each(|(row, value)| -> Result<()> {
                    let level = effect_codes[row] as usize;
                    if level >= effect_levels {
                        return Err(invalid_argument(
                            "categorical recovery code exceeds the final level count",
                        ));
                    }
                    *value = coefficients[coefficient_offset + level];
                    if !value.is_finite() {
                        return Err(invalid_data(
                            "categorical recovery coefficient product is nonfinite",
                        ));
                    }
                    Ok(())
                })?;
            channels.push(Some(values));
        } else {
            channels.push(None);
        }
    }

    let mut residual_values = fallible_filled(
        target.len(),
        0.0_f64,
        "unable to reserve categorical recovery intercept residual",
    )?;
    let mut absorbed_sum = if materialize_absorbed_sum {
        Some(fallible_filled(
            target.len(),
            0.0_f64,
            "unable to reserve categorical recovery intercept absorbed sum",
        )?)
    } else {
        None
    };
    if let Some(absorbed) = absorbed_sum.as_mut() {
        absorbed
            .par_iter_mut()
            .zip(residual_values.par_iter_mut())
            .enumerate()
            .try_for_each(|(row, (actual, remainder))| -> Result<()> {
                let mut value = 0.0_f64;
                for effect_index in 0..effects.len() {
                    let level = codes[effect_index][row] as usize;
                    if level >= levels[effect_index] {
                        return Err(invalid_argument(
                            "categorical recovery code exceeds the final level count",
                        ));
                    }
                    value += coefficients[effect_offsets[effect_index] + level];
                }
                *actual = value;
                *remainder = target[row] - value;
                if !actual.is_finite() || !remainder.is_finite() {
                    return Err(invalid_data(
                        "categorical recovery coefficient product produced a nonfinite residual",
                    ));
                }
                Ok(())
            })?;
    } else {
        residual_values.par_iter_mut().enumerate().try_for_each(
            |(row, remainder)| -> Result<()> {
                let mut value = 0.0_f64;
                for effect_index in 0..effects.len() {
                    let level = codes[effect_index][row] as usize;
                    if level >= levels[effect_index] {
                        return Err(invalid_argument(
                            "categorical recovery code exceeds the final level count",
                        ));
                    }
                    value += coefficients[effect_offsets[effect_index] + level];
                }
                *remainder = target[row] - value;
                if !remainder.is_finite() {
                    return Err(invalid_data(
                        "categorical recovery coefficient product produced a nonfinite residual",
                    ));
                }
                Ok(())
            },
        )?;
    }

    let partial_count = target.len().div_ceil(RECOVERY_CHUNK_ROWS);
    let mut partials = fallible_filled(
        partial_count,
        (0.0_f64, 0.0_f64, 0.0_f64, 0.0_f64),
        "unable to reserve categorical recovery row partials",
    )?;
    partials
        .par_iter_mut()
        .enumerate()
        .try_for_each(|(chunk, partial)| -> Result<()> {
            let row_start = chunk * RECOVERY_CHUNK_ROWS;
            let row_end = (row_start + RECOVERY_CHUNK_ROWS).min(target.len());
            let expected_values = &target[row_start..row_end];
            let remainder_values = &residual_values[row_start..row_end];
            let mut target_infinity = 0.0_f64;
            let mut residual_infinity = 0.0_f64;
            let mut target_norm_scale = 0.0_f64;
            let mut target_norm_sum = 1.0_f64;
            let mut residual_norm_scale = 0.0_f64;
            let mut residual_norm_sum = 1.0_f64;
            for (local_row, (&expected, &remainder)) in
                expected_values.iter().zip(remainder_values).enumerate()
            {
                target_infinity = target_infinity.max(expected.abs());
                residual_infinity = residual_infinity.max(remainder.abs());
                let weighted_target = weights.value(row_start + local_row).sqrt() * expected;
                if !weighted_target.is_finite() {
                    return Err(invalid_data(
                        "categorical recovery weighted target is nonfinite",
                    ));
                }
                let weighted_residual = weights.value(row_start + local_row).sqrt() * remainder;
                if !weighted_residual.is_finite() {
                    return Err(invalid_data(
                        "categorical recovery weighted residual is nonfinite",
                    ));
                }
                update_scaled_sum(
                    weighted_target,
                    &mut target_norm_scale,
                    &mut target_norm_sum,
                );
                update_scaled_sum(
                    weighted_residual,
                    &mut residual_norm_scale,
                    &mut residual_norm_sum,
                );
            }
            let target_norm = if target_norm_scale == 0.0 {
                0.0
            } else {
                target_norm_scale * target_norm_sum.sqrt()
            };
            let residual_norm = if residual_norm_scale == 0.0 {
                0.0
            } else {
                residual_norm_scale * residual_norm_sum.sqrt()
            };
            *partial = (
                target_infinity,
                residual_infinity,
                target_norm,
                residual_norm,
            );
            Ok(())
        })?;
    let mut target_infinity = 0.0_f64;
    let mut residual_infinity = 0.0_f64;
    let mut target_norm_scale = 0.0_f64;
    let mut target_norm_sum = 1.0_f64;
    let mut residual_norm_scale = 0.0_f64;
    let mut residual_norm_sum = 1.0_f64;
    for (partial_target, partial_residual, partial_target_norm, partial_residual_norm) in partials {
        target_infinity = target_infinity.max(partial_target);
        residual_infinity = residual_infinity.max(partial_residual);
        update_scaled_sum(
            partial_target_norm,
            &mut target_norm_scale,
            &mut target_norm_sum,
        );
        update_scaled_sum(
            partial_residual_norm,
            &mut residual_norm_scale,
            &mut residual_norm_sum,
        );
    }
    let target_norm = if target_norm_scale == 0.0 {
        0.0
    } else {
        target_norm_scale * target_norm_sum.sqrt()
    };
    if !target_norm.is_finite() {
        return Err(invalid_data(
            "categorical recovery weighted target norm is nonfinite",
        ));
    }
    let residual_norm = if residual_norm_scale == 0.0 {
        0.0
    } else {
        residual_norm_scale * residual_norm_sum.sqrt()
    };
    if !residual_norm.is_finite() {
        return Err(invalid_data(
            "categorical recovery weighted residual norm is nonfinite",
        ));
    }
    let reconstruction_relative_infinity = if target_infinity == 0.0 {
        residual_infinity
    } else {
        residual_infinity / target_infinity
    };
    if !reconstruction_relative_infinity.is_finite()
        || reconstruction_relative_infinity > recovery_reconstruction_threshold(tolerance)
    {
        return Err(invalid_data(format!(
            "categorical recovery coefficient product failed reconstruction: relative infinity residual {reconstruction_relative_infinity:.6e}"
        )));
    }

    let certificate = certify_intercept_only_recovery(
        topology,
        weights,
        &residual_values,
        target_norm,
        residual_norm,
        tolerance,
    )?;
    if !certificate.passed {
        return Err(invalid_data(
            "categorical recovery coefficient product failed its FE certificate",
        ));
    }
    Ok(RecoveredCategoricalEffects {
        solver_workspace_peak: SolverWorkspacePeak::UNMODELED,
        absorbed_sum,
        channels,
        iterations,
        reconstruction_relative_infinity,
        recovery_method,
    })
}

#[allow(clippy::too_many_arguments)]
fn finish_one_intercept_recovery(
    topology: &FinalizedCategoricalTopology,
    weights: ValidatedWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    coefficients: &[f64],
    effect_offsets: &[usize],
    iterations: usize,
    tolerance: f64,
    recovery_method: CategoricalRecoveryMethod,
    materialize_absorbed_sum: bool,
) -> Result<RecoveredCategoricalEffects> {
    const ROW_CHUNK: usize = 32_768;
    const LEVEL_CHUNK: usize = 4_096;

    if requested_channels.len() != 1 || effect_offsets.len() != 2 {
        return Err(invalid_argument(
            "one-intercept recovery layout is inconsistent",
        ));
    }
    let source_table = topology_source_table(topology)?;
    let source = topology
        .registry()
        .source(topology.effect_to_topology()[0])?;
    let codes = source.codes(&source_table)?;
    let levels = source.n_levels();
    let coefficient_offset = effect_offsets[0];
    let needs_publication = requested_channels[0] || materialize_absorbed_sum;
    let mut publication = if needs_publication {
        Some(fallible_filled(
            target.len(),
            0.0_f64,
            "unable to reserve one-intercept recovery publication",
        )?)
    } else {
        None
    };

    let compute_rows = |chunk: usize,
                        expected_values: &[f64],
                        mut output: Option<&mut [f64]>|
     -> Result<(f64, f64, f64, f64)> {
        let row_start = chunk * ROW_CHUNK;
        let mut target_infinity = 0.0_f64;
        let mut residual_infinity = 0.0_f64;
        let mut target_norm_scale = 0.0_f64;
        let mut target_norm_sum = 1.0_f64;
        let mut residual_norm_scale = 0.0_f64;
        let mut residual_norm_sum = 1.0_f64;
        for (local_row, &expected) in expected_values.iter().enumerate() {
            let row = row_start + local_row;
            let level = codes[row] as usize;
            if level >= levels {
                return Err(invalid_argument(
                    "categorical recovery code exceeds the final level count",
                ));
            }
            let actual = coefficients[coefficient_offset + level];
            let remainder = expected - actual;
            if !actual.is_finite() || !remainder.is_finite() {
                return Err(invalid_data(
                    "categorical recovery coefficient product produced a nonfinite residual",
                ));
            }
            if let Some(values) = output.as_deref_mut() {
                values[local_row] = actual;
            }
            target_infinity = target_infinity.max(expected.abs());
            residual_infinity = residual_infinity.max(remainder.abs());
            let root_weight = weights.value(row).sqrt();
            let weighted_target = root_weight * expected;
            let weighted_residual = root_weight * remainder;
            if !weighted_target.is_finite() || !weighted_residual.is_finite() {
                return Err(invalid_data(
                    "categorical recovery weighted product is nonfinite",
                ));
            }
            update_scaled_sum(
                weighted_target,
                &mut target_norm_scale,
                &mut target_norm_sum,
            );
            update_scaled_sum(
                weighted_residual,
                &mut residual_norm_scale,
                &mut residual_norm_sum,
            );
        }
        let target_norm = if target_norm_scale == 0.0 {
            0.0
        } else {
            target_norm_scale * target_norm_sum.sqrt()
        };
        let residual_norm = if residual_norm_scale == 0.0 {
            0.0
        } else {
            residual_norm_scale * residual_norm_sum.sqrt()
        };
        Ok((
            target_infinity,
            residual_infinity,
            target_norm,
            residual_norm,
        ))
    };
    let row_partial_count = target.len().div_ceil(ROW_CHUNK);
    let mut row_partials = fallible_filled(
        row_partial_count,
        (0.0_f64, 0.0_f64, 0.0_f64, 0.0_f64),
        "unable to reserve one-intercept recovery row partials",
    )?;
    if let Some(values) = publication.as_mut() {
        target
            .par_chunks(ROW_CHUNK)
            .zip(values.par_chunks_mut(ROW_CHUNK))
            .zip(row_partials.par_iter_mut())
            .enumerate()
            .try_for_each(|(chunk, ((expected, output), partial))| -> Result<()> {
                *partial = compute_rows(chunk, expected, Some(output))?;
                Ok(())
            })?;
    } else {
        target
            .par_chunks(ROW_CHUNK)
            .zip(row_partials.par_iter_mut())
            .enumerate()
            .try_for_each(|(chunk, (expected, partial))| -> Result<()> {
                *partial = compute_rows(chunk, expected, None)?;
                Ok(())
            })?;
    }
    let mut target_infinity = 0.0_f64;
    let mut residual_infinity = 0.0_f64;
    let mut target_norm_scale = 0.0_f64;
    let mut target_norm_sum = 1.0_f64;
    let mut residual_norm_scale = 0.0_f64;
    let mut residual_norm_sum = 1.0_f64;
    for (partial_target, partial_residual, partial_target_norm, partial_residual_norm) in
        row_partials
    {
        target_infinity = target_infinity.max(partial_target);
        residual_infinity = residual_infinity.max(partial_residual);
        update_scaled_sum(
            partial_target_norm,
            &mut target_norm_scale,
            &mut target_norm_sum,
        );
        update_scaled_sum(
            partial_residual_norm,
            &mut residual_norm_scale,
            &mut residual_norm_sum,
        );
    }
    let target_norm = if target_norm_scale == 0.0 {
        0.0
    } else {
        target_norm_scale * target_norm_sum.sqrt()
    };
    let residual_norm = if residual_norm_scale == 0.0 {
        0.0
    } else {
        residual_norm_scale * residual_norm_sum.sqrt()
    };
    if !target_norm.is_finite() || !residual_norm.is_finite() {
        return Err(invalid_data(
            "categorical recovery certificate norm is nonfinite",
        ));
    }
    let reconstruction_relative_infinity = if target_infinity == 0.0 {
        residual_infinity
    } else {
        residual_infinity / target_infinity
    };
    if !reconstruction_relative_infinity.is_finite()
        || reconstruction_relative_infinity > recovery_reconstruction_threshold(tolerance)
    {
        return Err(invalid_data(format!(
            "categorical recovery coefficient product failed reconstruction: relative infinity residual {reconstruction_relative_infinity:.6e}"
        )));
    }

    let denominator = target_norm.max(residual_norm);
    let level_partial_count = levels.div_ceil(LEVEL_CHUNK);
    let mut level_partials = fallible_filled(
        level_partial_count,
        InterceptRecoveryCertificatePartial::default(),
        "unable to reserve one-intercept recovery certificate partials",
    )?;
    level_partials.par_iter_mut().enumerate().try_for_each(
        |(chunk, destination)| -> Result<()> {
            let start = chunk * LEVEL_CHUNK;
            let end = (start + LEVEL_CHUNK).min(levels);
            let mut partial = InterceptRecoveryCertificatePartial {
                absolute_infinity: 0.0,
                relative_infinity: 0.0,
                relative_squares: 0.0,
                count: 0,
            };
            for level in start..end {
                let members = source.members(level)?;
                if members.is_empty() {
                    return Err(invalid_argument(
                        "categorical recovery certificate contains an empty final level",
                    ));
                }
                let alpha = coefficients[coefficient_offset + level];
                let mut value_scale = 0.0_f64;
                for &row in members {
                    let remainder = target[row] - alpha;
                    if !remainder.is_finite() {
                        return Err(invalid_data(
                            "categorical recovery certificate residual is nonfinite",
                        ));
                    }
                    value_scale = value_scale.max(remainder.abs());
                }
                let mut gram = 0.0_f64;
                let mut gram_correction = 0.0_f64;
                let mut cross = 0.0_f64;
                let mut cross_correction = 0.0_f64;
                for &row in members {
                    let weight = weights.value(row);
                    compensated_add(weight, &mut gram, &mut gram_correction)?;
                    if value_scale != 0.0 {
                        compensated_add(
                            weight * ((target[row] - alpha) / value_scale),
                            &mut cross,
                            &mut cross_correction,
                        )?;
                    }
                }
                gram += gram_correction;
                cross += cross_correction;
                if !gram.is_finite() || gram <= 0.0 || !cross.is_finite() {
                    return Err(invalid_data(
                        "categorical recovery certificate group moment is invalid",
                    ));
                }
                let coefficient = value_scale * (cross / gram);
                let projected_square = coefficient.mul_add(gram * coefficient, 0.0);
                let projected = projected_square.max(0.0).sqrt();
                let relative = if denominator == 0.0 {
                    if projected == 0.0 {
                        0.0
                    } else {
                        f64::INFINITY
                    }
                } else {
                    projected / denominator
                };
                if !relative.is_finite() {
                    return Err(invalid_data(
                        "categorical recovery certificate ratio is nonfinite",
                    ));
                }
                partial.relative_infinity = partial.relative_infinity.max(relative);
                partial.relative_squares = relative.mul_add(relative, partial.relative_squares);
                partial.count = partial.count.checked_add(1).ok_or_else(|| {
                    allocation("categorical recovery certificate count overflows")
                })?;
                let raw = cross.abs() * value_scale * weights.raw_scale;
                partial.absolute_infinity = partial.absolute_infinity.max(if raw.is_finite() {
                    raw
                } else {
                    f64::INFINITY
                });
            }
            *destination = partial;
            Ok(())
        },
    )?;
    let mut certificate_total = InterceptRecoveryCertificatePartial {
        absolute_infinity: 0.0,
        relative_infinity: 0.0,
        relative_squares: 0.0,
        count: 0,
    };
    for partial in level_partials {
        certificate_total.absolute_infinity = certificate_total
            .absolute_infinity
            .max(partial.absolute_infinity);
        certificate_total.relative_infinity = certificate_total
            .relative_infinity
            .max(partial.relative_infinity);
        certificate_total.relative_squares += partial.relative_squares;
        certificate_total.count = certificate_total
            .count
            .checked_add(partial.count)
            .ok_or_else(|| allocation("categorical recovery certificate count overflows"))?;
    }
    let relative_two = if certificate_total.count == 0 {
        0.0
    } else {
        (certificate_total.relative_squares / certificate_total.count as f64).sqrt()
    };
    if !relative_two.is_finite() {
        return Err(invalid_data(
            "categorical recovery certificate two norm is nonfinite",
        ));
    }
    let certificate = FeCertificate {
        absolute_infinity_norm: certificate_total.absolute_infinity,
        relative_infinity_norm: certificate_total.relative_infinity,
        relative_two_norm: relative_two,
        passed: certificate_total.relative_infinity <= tolerance,
    };
    if !certificate.passed {
        return Err(invalid_data(
            "categorical recovery coefficient product failed its FE certificate",
        ));
    }

    let mut channels = fallible_filled(
        1,
        None,
        "unable to reserve one-intercept recovery channel registry",
    )?;
    let absorbed_sum = match (requested_channels[0], materialize_absorbed_sum) {
        (true, true) => {
            let values = publication
                .take()
                .expect("one-intercept publication buffer was requested");
            let absorbed = fallible_copy(
                &values,
                "unable to reserve one-intercept recovery absorbed sum",
            )?;
            channels[0] = Some(values);
            Some(absorbed)
        }
        (true, false) => {
            channels[0] = publication.take();
            None
        }
        (false, true) => publication.take(),
        (false, false) => None,
    };
    Ok(RecoveredCategoricalEffects {
        solver_workspace_peak: SolverWorkspacePeak::UNMODELED,
        absorbed_sum,
        channels,
        iterations,
        reconstruction_relative_infinity,
        recovery_method,
    })
}

#[derive(Debug, Clone, Copy, Default)]
struct InterceptRecoveryCertificatePartial {
    absolute_infinity: f64,
    relative_infinity: f64,
    relative_squares: f64,
    count: usize,
}

fn certify_intercept_only_recovery(
    topology: &FinalizedCategoricalTopology,
    weights: ValidatedWeights<'_>,
    residuals: &[f64],
    reference_norm: f64,
    residual_norm: f64,
    tolerance: f64,
) -> Result<FeCertificate> {
    const LEVEL_CHUNK: usize = 4_096;

    if !reference_norm.is_finite()
        || reference_norm < 0.0
        || !residual_norm.is_finite()
        || residual_norm < 0.0
    {
        return Err(invalid_data(
            "categorical recovery certificate norms are invalid",
        ));
    }
    let denominator = reference_norm.max(residual_norm);
    let mut total = InterceptRecoveryCertificatePartial {
        absolute_infinity: 0.0,
        relative_infinity: 0.0,
        relative_squares: 0.0,
        count: 0,
    };
    for &source_index in topology.effect_to_topology() {
        let source = topology.registry().source(source_index)?;
        let chunk_count = source.n_levels().div_ceil(LEVEL_CHUNK);
        let mut partials = fallible_filled(
            chunk_count,
            InterceptRecoveryCertificatePartial::default(),
            "unable to reserve intercept recovery certificate partials",
        )?;
        partials
            .par_iter_mut()
            .enumerate()
            .try_for_each(|(chunk, destination)| -> Result<()> {
                let start = chunk * LEVEL_CHUNK;
                let end = (start + LEVEL_CHUNK).min(source.n_levels());
                let mut partial = InterceptRecoveryCertificatePartial {
                    absolute_infinity: 0.0,
                    relative_infinity: 0.0,
                    relative_squares: 0.0,
                    count: 0,
                };
                for level in start..end {
                    let members = source.members(level)?;
                    if members.is_empty() {
                        return Err(invalid_argument(
                            "categorical recovery certificate contains an empty final level",
                        ));
                    }
                    let mut value_scale = 0.0_f64;
                    for &row in members {
                        let value = *residuals.get(row).ok_or_else(|| {
                            invalid_argument(
                                "categorical recovery membership exceeds the residual axis",
                            )
                        })?;
                        value_scale = value_scale.max(value.abs());
                    }
                    let mut gram = 0.0_f64;
                    let mut gram_correction = 0.0_f64;
                    let mut cross = 0.0_f64;
                    let mut cross_correction = 0.0_f64;
                    for &row in members {
                        let weight = weights.value(row);
                        compensated_add(weight, &mut gram, &mut gram_correction)?;
                        if value_scale != 0.0 {
                            compensated_add(
                                weight * (residuals[row] / value_scale),
                                &mut cross,
                                &mut cross_correction,
                            )?;
                        }
                    }
                    gram += gram_correction;
                    cross += cross_correction;
                    if !gram.is_finite() || gram <= 0.0 || !cross.is_finite() {
                        return Err(invalid_data(
                            "categorical recovery certificate group moment is invalid",
                        ));
                    }
                    let coefficient = value_scale * (cross / gram);
                    let projected_square = coefficient.mul_add(gram * coefficient, 0.0);
                    let projected = projected_square.max(0.0).sqrt();
                    let relative = if denominator == 0.0 {
                        if projected == 0.0 {
                            0.0
                        } else {
                            f64::INFINITY
                        }
                    } else {
                        projected / denominator
                    };
                    if !relative.is_finite() {
                        return Err(invalid_data(
                            "categorical recovery certificate ratio is nonfinite",
                        ));
                    }
                    partial.relative_infinity = partial.relative_infinity.max(relative);
                    partial.relative_squares = relative.mul_add(relative, partial.relative_squares);
                    if !partial.relative_squares.is_finite() {
                        return Err(invalid_data(
                            "categorical recovery certificate two-norm accumulation is nonfinite",
                        ));
                    }
                    partial.count = partial.count.checked_add(1).ok_or_else(|| {
                        allocation("categorical recovery certificate count overflows")
                    })?;
                    let raw = cross.abs() * value_scale * weights.raw_scale;
                    partial.absolute_infinity = partial.absolute_infinity.max(if raw.is_finite() {
                        raw
                    } else {
                        f64::INFINITY
                    });
                }
                *destination = partial;
                Ok(())
            })?;
        for partial in partials {
            total.absolute_infinity = total.absolute_infinity.max(partial.absolute_infinity);
            total.relative_infinity = total.relative_infinity.max(partial.relative_infinity);
            total.relative_squares += partial.relative_squares;
            if !total.relative_squares.is_finite() {
                return Err(invalid_data(
                    "categorical recovery certificate two-norm accumulation is nonfinite",
                ));
            }
            total.count = total
                .count
                .checked_add(partial.count)
                .ok_or_else(|| allocation("categorical recovery certificate count overflows"))?;
        }
    }
    let relative_two = if total.count == 0 {
        0.0
    } else {
        (total.relative_squares / total.count as f64).sqrt()
    };
    if !relative_two.is_finite() {
        return Err(invalid_data(
            "categorical recovery certificate two norm is nonfinite",
        ));
    }
    Ok(FeCertificate {
        absolute_infinity_norm: total.absolute_infinity,
        relative_infinity_norm: total.relative_infinity,
        relative_two_norm: relative_two,
        passed: total.relative_infinity <= tolerance,
    })
}

fn channel_major_effect_offsets(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
) -> Result<Vec<usize>> {
    let offset_count = effects
        .len()
        .checked_add(1)
        .ok_or_else(|| allocation("categorical recovery offset count overflows"))?;
    let mut offsets = fallible_with_capacity(
        offset_count,
        "unable to reserve categorical recovery coefficient offsets",
    )?;
    offsets.push(0);
    for (effect_index, effect) in effects.iter().enumerate() {
        let levels = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?
            .n_levels();
        let width = levels
            .checked_mul(effect.channels())
            .ok_or_else(|| allocation("categorical recovery coefficient width overflows"))?;
        offsets.push(
            offsets
                .last()
                .copied()
                .unwrap_or(0_usize)
                .checked_add(width)
                .ok_or_else(|| allocation("categorical recovery coefficient offset overflows"))?,
        );
    }
    Ok(offsets)
}

fn recovery_preconditioner(
    requested: LsmrPreconditioner,
    effects: usize,
    coefficients: usize,
) -> PreconditionerConfig {
    match requested {
        LsmrPreconditioner::Off => PreconditionerConfig::Off,
        LsmrPreconditioner::Diagonal => PreconditionerConfig::Diagonal,
        LsmrPreconditioner::Schwarz => PreconditionerConfig::default(),
        LsmrPreconditioner::Auto if effects >= 2 && coefficients >= 256 => {
            PreconditionerConfig::default()
        }
        LsmrPreconditioner::Auto => PreconditionerConfig::Diagonal,
    }
}

fn recovery_preconditioner_breakdown(error: &within::WithinError) -> bool {
    matches!(
        error,
        within::WithinError::Solve(within::SolveError::InvalidInput { context, message })
            if *context == "mlsmr" && message.contains("preconditioner not positive definite")
    )
}

fn recover_with_reservation<R: SlopeWorkspaceReservation>(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    target: &[f64],
    requested_channels: &[bool],
    config: MapConfig,
    reservation: &mut R,
) -> Result<RecoveredCategoricalEffects> {
    validate_config(config)?;
    topology.validate()?;
    let nobs = topology.retained_rows().len();
    if target.len() != nobs || effects.len() != topology.effect_to_topology().len() {
        return Err(invalid_argument(
            "categorical effect recovery topology, basis, and target dimensions differ",
        ));
    }
    if target.is_empty() || target.iter().any(|value| !value.is_finite()) {
        return Err(invalid_data(
            "categorical effect recovery requires a nonempty finite target",
        ));
    }
    let channel_count = effects.iter().try_fold(0_usize, |total, effect| {
        total
            .checked_add(effect.channels())
            .ok_or_else(|| allocation("categorical recovery channel count overflows"))
    })?;
    if requested_channels.len() != channel_count || channel_count == 0 {
        return Err(invalid_argument(
            "categorical effect recovery requested-channel layout differs",
        ));
    }
    let mut effect_offsets = Vec::new();
    reservation.reserve_usize(
        &mut effect_offsets,
        effects.len() + 1,
        "unable to reserve categorical recovery effect offsets",
    )?;
    if effect_offsets.capacity() < effects.len() + 1 {
        return Err(allocation(
            "categorical recovery effect-offset reservation was undersized",
        ));
    }
    effect_offsets.push(0);
    let mut coefficient_count = 0_usize;
    let mut max_channels = 0_usize;
    for (effect_index, effect) in effects.iter().enumerate() {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        max_channels = max_channels.max(effect.channels());
        coefficient_count = coefficient_count
            .checked_add(
                source
                    .n_levels()
                    .checked_mul(effect.channels())
                    .ok_or_else(|| {
                        allocation("categorical recovery coefficient block overflows")
                    })?,
            )
            .ok_or_else(|| allocation("categorical recovery coefficient count overflows"))?;
        effect_offsets.push(coefficient_count);
    }
    let mut alphas = reserved_zeros(
        coefficient_count,
        reservation,
        "unable to reserve categorical recovery coefficients",
    )?;
    let mut residual_values = Vec::new();
    reservation.reserve_f64(
        &mut residual_values,
        nobs,
        "unable to reserve categorical recovery residual",
    )?;
    if residual_values.capacity() < nobs {
        return Err(allocation(
            "categorical recovery residual reservation was undersized",
        ));
    }
    residual_values.extend_from_slice(target);
    let mut residual = DenseMatrix::from_row_major(nobs, 1, residual_values)?;
    let weights = validate_weights(weights, nobs)?;
    let mut workspace = SlopeWorkspace::new(max_channels, 1, reservation)?;
    weighted_norms(
        &residual,
        weights,
        &mut workspace.reference_norms,
        &mut workspace.value_scales,
        &mut workspace.coefficients[..1],
    )?;

    let initial = certify(
        topology,
        effects,
        weights,
        &residual,
        config.tolerance,
        &mut workspace,
    )?;
    // A small FE moment only shows that the remainder is nearly orthogonal to
    // each effect. Weak graphs can reach that condition before the remainder
    // is small enough to certify that the target lies in the absorbed span.
    if initial.passed && recovery_reconstruction_passed(target, &residual, config.tolerance)? {
        return finish_recovery(
            topology,
            effects,
            target,
            requested_channels,
            &effect_offsets,
            &alphas,
            &residual,
            0,
            config.tolerance,
            reservation,
        );
    }

    for iteration in 1..=config.max_iterations {
        for (effect_index, effect) in effects.iter().enumerate() {
            project_effect_and_accumulate(
                topology,
                effect_index,
                effect,
                weights,
                &mut residual,
                &mut workspace,
                &mut alphas,
                effect_offsets[effect_index],
            )?;
        }
        if config.symmetric && effects.len() > 1 {
            for effect_index in (0..effects.len() - 1).rev() {
                project_effect_and_accumulate(
                    topology,
                    effect_index,
                    &effects[effect_index],
                    weights,
                    &mut residual,
                    &mut workspace,
                    &mut alphas,
                    effect_offsets[effect_index],
                )?;
            }
        }
        if iteration % config.check_every == 0 || iteration == config.max_iterations {
            let certificate = certify(
                topology,
                effects,
                weights,
                &residual,
                config.tolerance,
                &mut workspace,
            )?;
            if certificate.passed
                && recovery_reconstruction_passed(target, &residual, config.tolerance)?
            {
                return finish_recovery(
                    topology,
                    effects,
                    target,
                    requested_channels,
                    &effect_offsets,
                    &alphas,
                    &residual,
                    iteration,
                    config.tolerance,
                    reservation,
                );
            }
            if certificate.passed && iteration == config.max_iterations {
                return finish_recovery(
                    topology,
                    effects,
                    target,
                    requested_channels,
                    &effect_offsets,
                    &alphas,
                    &residual,
                    iteration,
                    config.tolerance,
                    reservation,
                );
            }
        }
    }
    Err(invalid_data(
        "categorical effect recovery exhausted its iteration budget without certification",
    ))
}

#[allow(clippy::too_many_arguments)]
fn project_effect_and_accumulate(
    topology: &FinalizedCategoricalTopology,
    effect_index: usize,
    effect: &CategoricalAbsorbedEffectView<'_>,
    weights: ValidatedWeights<'_>,
    residual: &mut DenseMatrix,
    workspace: &mut SlopeWorkspace,
    alphas: &mut [f64],
    effect_offset: usize,
) -> Result<()> {
    let source = topology.registry().source(
        *topology
            .effect_to_topology()
            .get(effect_index)
            .ok_or_else(|| invalid_argument("categorical recovery effect index is out of range"))?,
    )?;
    let channels = effect.channels();
    for level in 0..source.n_levels() {
        let members = source.members(level)?;
        group_moments(members, effect, weights, residual, workspace)?;
        solve_group(channels, 1, workspace)?;
        let level_offset = effect_offset
            .checked_add(
                level
                    .checked_mul(channels)
                    .ok_or_else(|| allocation("categorical recovery level offset overflows"))?,
            )
            .ok_or_else(|| allocation("categorical recovery coefficient offset overflows"))?;
        for channel in 0..channels {
            let raw = workspace.coefficients[channel] / workspace.channel_scales[channel];
            let destination = alphas.get_mut(level_offset + channel).ok_or_else(|| {
                invalid_argument("categorical recovery coefficient is out of range")
            })?;
            *destination += raw;
            if !destination.is_finite() {
                return Err(invalid_data(
                    "categorical recovery coefficient accumulation is not finite",
                ));
            }
        }
        for &row in members {
            let mut fitted = 0.0_f64;
            for channel in 0..channels {
                fitted = effect
                    .basis_value(channel, row, &workspace.channel_scales)
                    .mul_add(workspace.coefficients[channel], fitted);
            }
            residual[(row, 0)] -= fitted;
            if !residual[(row, 0)].is_finite() {
                return Err(invalid_data(
                    "categorical recovery projection produced a nonfinite residual",
                ));
            }
        }
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn finish_recovery<R: SlopeWorkspaceReservation>(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    target: &[f64],
    requested_channels: &[bool],
    effect_offsets: &[usize],
    alphas: &[f64],
    residual: &DenseMatrix,
    iterations: usize,
    tolerance: f64,
    reservation: &mut R,
) -> Result<RecoveredCategoricalEffects> {
    let reconstruction_relative_infinity =
        recovery_reconstruction_relative_infinity(target, residual)?;
    if reconstruction_relative_infinity > recovery_reconstruction_threshold(tolerance) {
        return Err(invalid_data(format!(
            "categorical recovery target is not certified to lie in the absorbed span: relative infinity residual {reconstruction_relative_infinity:.6e}",
        )));
    }

    let mut absorbed_sum = reserved_zeros(
        target.len(),
        reservation,
        "unable to reserve recovered absorbed sum",
    )?;
    let mut channels = Vec::new();
    channels
        .try_reserve_exact(requested_channels.len())
        .map_err(|_| allocation("unable to reserve recovered channel registry"))?;
    let mut flat_channel = 0_usize;
    for (effect_index, effect) in effects.iter().enumerate() {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        let channel_count = effect.channels();
        for channel in 0..channel_count {
            let requested = requested_channels[flat_channel];
            let mut contribution = if requested {
                Some(reserved_zeros(
                    target.len(),
                    reservation,
                    "unable to reserve recovered channel contribution",
                )?)
            } else {
                None
            };
            for level in 0..source.n_levels() {
                let alpha_index = effect_offsets[effect_index] + level * channel_count + channel;
                let alpha = *alphas.get(alpha_index).ok_or_else(|| {
                    invalid_argument("categorical recovery alpha index is out of range")
                })?;
                for &row in source.members(level)? {
                    let basis = if effect.intercept && channel == 0 {
                        1.0
                    } else {
                        let slope_index = channel - usize::from(effect.intercept);
                        effect.slopes[slope_index][row]
                    };
                    let value = alpha * basis;
                    absorbed_sum[row] += value;
                    if let Some(values) = contribution.as_mut() {
                        values[row] = value;
                    }
                }
            }
            channels.push(contribution);
            flat_channel += 1;
        }
    }
    for ((recovered, expected), remainder) in
        absorbed_sum.iter().zip(target).zip(residual.as_slice())
    {
        let error = (*recovered + *remainder - *expected).abs();
        if !error.is_finite() || error > (tolerance * expected.abs().max(1.0) * 256.0).max(1e-10) {
            return Err(invalid_data(
                "categorical recovery decomposition failed its reconstruction identity",
            ));
        }
    }
    Ok(RecoveredCategoricalEffects {
        solver_workspace_peak: SolverWorkspacePeak::UNMODELED,
        absorbed_sum: Some(absorbed_sum),
        channels,
        iterations,
        reconstruction_relative_infinity,
        recovery_method: CategoricalRecoveryMethod::Map,
    })
}

fn recovery_reconstruction_passed(
    target: &[f64],
    residual: &DenseMatrix,
    tolerance: f64,
) -> Result<bool> {
    Ok(recovery_reconstruction_relative_infinity(target, residual)?
        <= recovery_reconstruction_threshold(tolerance))
}

fn recovery_reconstruction_relative_infinity(
    target: &[f64],
    residual: &DenseMatrix,
) -> Result<f64> {
    if residual.ncols() != 1 || residual.nrows() != target.len() {
        return Err(invalid_argument(
            "categorical recovery reconstruction dimensions differ",
        ));
    }
    let scale = target
        .iter()
        .map(|value| value.abs())
        .fold(0.0_f64, f64::max);
    let residual_max = residual
        .as_slice()
        .iter()
        .map(|value| value.abs())
        .fold(0.0_f64, f64::max);
    let relative = if scale == 0.0 {
        residual_max
    } else {
        residual_max / scale
    };
    if !relative.is_finite() {
        return Err(invalid_data(
            "categorical recovery reconstruction ratio is not finite",
        ));
    }
    Ok(relative)
}

fn recovery_reconstruction_threshold(tolerance: f64) -> f64 {
    (tolerance * 100.0).max(1e-10)
}

fn absorb_with_reservation<R: SlopeWorkspaceReservation>(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: BorrowedMapWeights<'_>,
    mut values: DenseMatrix,
    config: MapConfig,
    budget: Option<FeSolverMemoryBudget>,
    reservation: &mut R,
) -> Result<CertifiedBorrowedMap> {
    validate_config(config)?;
    let max_channels = effects
        .iter()
        .map(CategoricalAbsorbedEffectView::channels)
        .max()
        .unwrap_or(0);
    let validation_bytes = topology.validation_workspace_bytes()?;
    let workspace_bytes = SlopeWorkspace::modeled_bytes(max_channels, values.ncols())?;
    let planned_peak = validation_bytes.max(workspace_bytes);
    if budget.is_some_and(|budget| !budget.fits(planned_peak)) {
        return Err(allocation(
            "categorical slope MAP exceeds the joint execution/solver budget",
        ));
    }
    topology.validate()?;
    let nobs = topology.retained_rows().len();
    if values.nrows() != nobs || effects.len() != topology.effect_to_topology().len() {
        return Err(invalid_argument(
            "categorical slope MAP topology, basis, and value dimensions differ",
        ));
    }
    if nobs == 0 || values.ncols() == 0 {
        return Err(invalid_data(
            "categorical slope MAP requires nonempty observation and RHS axes",
        ));
    }
    if values.as_slice().iter().any(|value| !value.is_finite()) {
        return Err(invalid_data("categorical slope MAP values must be finite"));
    }
    let mut max_channels = 0_usize;
    for effect in effects {
        if !effect.intercept && effect.slopes.is_empty() {
            return Err(invalid_argument(
                "categorical slope MAP effect has no basis channels",
            ));
        }
        max_channels = max_channels.max(effect.channels());
        for slope in &effect.slopes {
            if slope.len() != nobs || slope.iter().any(|value| !value.is_finite()) {
                return Err(invalid_data(
                    "categorical slope MAP values are not finite and aligned",
                ));
            }
        }
    }
    if max_channels == 0 {
        return Err(invalid_argument(
            "categorical slope MAP request has no basis channels",
        ));
    }
    for effect in effects {
        if effect.channels() > nobs {
            return Err(invalid_data(
                "categorical slope MAP effect has more channels than observations",
            ));
        }
    }
    let weights = validate_weights(weights, nobs)?;

    let setup_started = Instant::now();
    let mut workspace = SlopeWorkspace::new(max_channels, values.ncols(), reservation)?;
    let payload_peak = validation_bytes.max(workspace.payload_bytes()?);
    if budget.is_some_and(|budget| !budget.fits(payload_peak)) {
        return Err(allocation(
            "categorical slope MAP reserved capacities exceed the joint budget",
        ));
    }
    let workspace_peak = SolverWorkspacePeak::from_bytes(payload_peak)?;
    weighted_norms(
        &values,
        weights,
        &mut workspace.reference_norms,
        &mut workspace.value_scales,
        &mut workspace.coefficients[..values.ncols()],
    )?;
    let setup_seconds = setup_started.elapsed().as_secs_f64();
    let solve_started = Instant::now();

    let initial = certify(
        topology,
        effects,
        weights,
        &values,
        config.tolerance,
        &mut workspace,
    )?;
    if initial.passed {
        return finish(
            values,
            0,
            initial,
            setup_seconds,
            solve_started.elapsed().as_secs_f64(),
            workspace_peak,
        );
    }

    for iteration in 1..=config.max_iterations {
        for (effect_index, effect) in effects.iter().enumerate() {
            project_effect(
                topology,
                effect_index,
                effect,
                weights,
                &mut values,
                &mut workspace,
            )?;
        }
        if config.symmetric && effects.len() > 1 {
            for effect_index in (0..effects.len() - 1).rev() {
                project_effect(
                    topology,
                    effect_index,
                    &effects[effect_index],
                    weights,
                    &mut values,
                    &mut workspace,
                )?;
            }
        }
        if iteration % config.check_every == 0 || iteration == config.max_iterations {
            let certificate = certify(
                topology,
                effects,
                weights,
                &values,
                config.tolerance,
                &mut workspace,
            )?;
            if certificate.passed {
                return finish(
                    values,
                    iteration,
                    certificate,
                    setup_seconds,
                    solve_started.elapsed().as_secs_f64(),
                    workspace_peak,
                );
            }
        }
    }
    Err(invalid_data(
        "intercept-slope MAP exhausted its iteration budget without certification",
    ))
}

fn project_effect(
    topology: &FinalizedCategoricalTopology,
    effect_index: usize,
    effect: &CategoricalAbsorbedEffectView<'_>,
    weights: ValidatedWeights<'_>,
    values: &mut DenseMatrix,
    workspace: &mut SlopeWorkspace,
) -> Result<()> {
    let source = topology.registry().source(
        *topology
            .effect_to_topology()
            .get(effect_index)
            .ok_or_else(|| {
                invalid_argument("categorical slope MAP effect index is out of range")
            })?,
    )?;
    for level in 0..source.n_levels() {
        let members = source.members(level)?;
        group_moments(members, effect, weights, values, workspace)?;
        solve_group(effect.channels(), values.ncols(), workspace)?;
        for &row in members {
            for rhs in 0..values.ncols() {
                let mut fitted = 0.0_f64;
                for channel in 0..effect.channels() {
                    fitted = effect
                        .basis_value(channel, row, &workspace.channel_scales)
                        .mul_add(
                            workspace.coefficients[channel * values.ncols() + rhs],
                            fitted,
                        );
                }
                let residual = values[(row, rhs)] - fitted;
                if !residual.is_finite() {
                    return Err(invalid_data(
                        "categorical slope MAP projection produced a nonfinite residual",
                    ));
                }
                values[(row, rhs)] = residual;
            }
        }
    }
    Ok(())
}

fn group_moments(
    members: &[usize],
    effect: &CategoricalAbsorbedEffectView<'_>,
    weights: ValidatedWeights<'_>,
    values: &DenseMatrix,
    workspace: &mut SlopeWorkspace,
) -> Result<()> {
    if members.is_empty() {
        return Err(invalid_argument(
            "categorical slope MAP contains an empty final level",
        ));
    }
    let channels = effect.channels();
    let rhs_count = values.ncols();
    let gram_elements = channels * channels;
    let cross_elements = channels * rhs_count;
    workspace.gram[..gram_elements].fill(0.0);
    workspace.gram_corrections[..gram_elements].fill(0.0);
    workspace.cross[..cross_elements].fill(0.0);
    workspace.cross_corrections[..cross_elements].fill(0.0);
    workspace.value_scales.fill(0.0);
    workspace.channel_scales[..channels].fill(0.0);
    let slope_offset = usize::from(effect.intercept);
    if effect.intercept {
        workspace.channel_scales[0] = 1.0;
    }
    for (slope_index, slope) in effect.slopes.iter().enumerate() {
        let channel = slope_offset + slope_index;
        let scale = members
            .iter()
            .map(|row| slope[*row].abs())
            .fold(0.0_f64, f64::max);
        // A zero group-specific slope contributes no local span. Keeping unit
        // scale lets the rank-revealing solve drop it without division by zero.
        workspace.channel_scales[channel] = if scale == 0.0 { 1.0 } else { scale };
    }
    for &row in members {
        if row >= values.nrows() {
            return Err(invalid_argument(
                "categorical slope MAP membership exceeds the observation axis",
            ));
        }
        for rhs in 0..values.ncols() {
            workspace.value_scales[rhs] = workspace.value_scales[rhs].max(values[(row, rhs)].abs());
        }
    }
    for &row in members {
        let weight = weights.value(row);
        for left in 0..channels {
            let left_basis = effect.basis_value(left, row, &workspace.channel_scales);
            for right in 0..channels {
                compensated_add(
                    weight * left_basis * effect.basis_value(right, row, &workspace.channel_scales),
                    &mut workspace.gram[left * channels + right],
                    &mut workspace.gram_corrections[left * channels + right],
                )?;
            }
            for rhs in 0..rhs_count {
                let scale = workspace.value_scales[rhs];
                if scale != 0.0 {
                    compensated_add(
                        weight * left_basis * (values[(row, rhs)] / scale),
                        &mut workspace.cross[left * rhs_count + rhs],
                        &mut workspace.cross_corrections[left * rhs_count + rhs],
                    )?;
                }
            }
        }
    }
    for index in 0..gram_elements {
        workspace.gram[index] += workspace.gram_corrections[index];
    }
    for index in 0..cross_elements {
        workspace.cross[index] += workspace.cross_corrections[index];
    }
    Ok(())
}

fn solve_group(channels: usize, rhs_count: usize, workspace: &mut SlopeWorkspace) -> Result<usize> {
    if channels == 0 || channels > workspace.max_channels {
        return Err(invalid_argument(
            "categorical slope MAP channel count exceeds its workspace",
        ));
    }
    let gram_elements = channels * channels;
    let cross_elements = channels * rhs_count;
    workspace.factor[..gram_elements].copy_from_slice(&workspace.gram[..gram_elements]);
    workspace.factor_cross[..cross_elements].copy_from_slice(&workspace.cross[..cross_elements]);
    workspace.coefficients[..cross_elements].fill(0.0);
    for (index, destination) in workspace.permutation[..channels].iter_mut().enumerate() {
        *destination = index;
    }
    let diagonal_scale = (0..channels)
        .map(|index| workspace.factor[index * channels + index].abs())
        .fold(0.0_f64, f64::max);
    if !diagonal_scale.is_finite() {
        return Err(invalid_data(
            "categorical slope MAP Gram scale is not finite",
        ));
    }
    let tolerance = f64::EPSILON * diagonal_scale.max(1.0) * (channels.max(1) as f64) * 128.0;
    let mut rank = 0_usize;
    for pivot_position in 0..channels {
        let mut pivot_index = pivot_position;
        let mut pivot_value = workspace.factor[pivot_position * channels + pivot_position].abs();
        for candidate in pivot_position + 1..channels {
            let value = workspace.factor[candidate * channels + candidate].abs();
            if value > pivot_value {
                pivot_index = candidate;
                pivot_value = value;
            }
        }
        if pivot_value <= tolerance {
            break;
        }
        if pivot_index != pivot_position {
            swap_symmetric(&mut workspace.factor, channels, pivot_position, pivot_index);
            swap_rhs_rows(
                &mut workspace.factor_cross,
                rhs_count,
                pivot_position,
                pivot_index,
            );
            workspace.permutation.swap(pivot_position, pivot_index);
        }
        let pivot = workspace.factor[pivot_position * channels + pivot_position];
        if !pivot.is_finite() || pivot.abs() <= tolerance {
            break;
        }
        for row in pivot_position + 1..channels {
            let multiplier = workspace.factor[row * channels + pivot_position] / pivot;
            if !multiplier.is_finite() {
                return Err(invalid_data(
                    "categorical slope MAP elimination multiplier is not finite",
                ));
            }
            workspace.factor[row * channels + pivot_position] = multiplier;
            for column in pivot_position + 1..channels {
                let updated = workspace.factor[row * channels + column]
                    - multiplier * workspace.factor[pivot_position * channels + column];
                if !updated.is_finite() {
                    return Err(invalid_data(
                        "categorical slope MAP factorization is not finite",
                    ));
                }
                workspace.factor[row * channels + column] = updated;
            }
            for rhs in 0..rhs_count {
                let updated = workspace.factor_cross[row * rhs_count + rhs]
                    - multiplier * workspace.factor_cross[pivot_position * rhs_count + rhs];
                if !updated.is_finite() {
                    return Err(invalid_data(
                        "categorical slope MAP transformed cross-product is not finite",
                    ));
                }
                workspace.factor_cross[row * rhs_count + rhs] = updated;
            }
        }
        rank += 1;
    }
    for rhs in 0..rhs_count {
        for row in (0..rank).rev() {
            let mut value = workspace.factor_cross[row * rhs_count + rhs];
            for column in row + 1..rank {
                value -= workspace.factor[row * channels + column]
                    * workspace.factor_cross[column * rhs_count + rhs];
            }
            let pivot = workspace.factor[row * channels + row];
            let solution = value / pivot;
            if !solution.is_finite() {
                return Err(invalid_data(
                    "categorical slope MAP group solution is not finite",
                ));
            }
            workspace.factor_cross[row * rhs_count + rhs] = solution;
        }
        for position in 0..rank {
            let channel = workspace.permutation[position];
            workspace.coefficients[channel * rhs_count + rhs] =
                workspace.value_scales[rhs] * workspace.factor_cross[position * rhs_count + rhs];
        }
    }
    Ok(rank)
}

fn swap_symmetric(matrix: &mut [f64], dimension: usize, left: usize, right: usize) {
    for column in 0..dimension {
        matrix.swap(left * dimension + column, right * dimension + column);
    }
    for row in 0..dimension {
        matrix.swap(row * dimension + left, row * dimension + right);
    }
}

fn swap_rhs_rows(values: &mut [f64], rhs_count: usize, left: usize, right: usize) {
    for rhs in 0..rhs_count {
        values.swap(left * rhs_count + rhs, right * rhs_count + rhs);
    }
}


/// Group computations match the serial certificate. Ordered scalar reduction
/// preserves even its diagnostic RMS arithmetic across worker counts.
fn certify_single_slope_parallel(
    topology: &FinalizedCategoricalTopology,
    effect: &CategoricalAbsorbedEffectView<'_>,
    weights: ValidatedWeights<'_>,
    residual: &DenseMatrix,
    tolerance: f64,
    workspace: &mut SlopeWorkspace,
) -> Result<FeCertificate> {
    weighted_norms(
        residual,
        weights,
        &mut workspace.residual_norms,
        &mut workspace.value_scales,
        &mut workspace.coefficients[..1],
    )?;
    let scale = workspace.reference_norms[0].max(workspace.residual_norms[0]);
    let source = topology
        .registry()
        .source(topology.effect_to_topology()[0])?;
    let levels = source.n_levels();
    let block = levels.div_ceil(rayon::current_num_threads().min(levels));
    let blocks = levels.div_ceil(block);
    let channels = effect.channels();
    let mut partials = fallible_filled(
        levels,
        (0.0_f64, 0.0_f64),
        "unable to reserve direct recovery certificates",
    )?;
    let mut workspaces = Vec::new();
    workspaces
        .try_reserve_exact(blocks)
        .map_err(|_| allocation("unable to reserve direct certificate workers"))?;
    for _ in 0..blocks {
        let mut worker = SlopeWorkspace::new(channels, 1, &mut SystemSlopeWorkspaceReservation)?;
        worker.rhs_scales[0] = scale;
        workspaces.push(worker);
    }
    let actual = partials.capacity() as u128 * 16
        + workspaces.capacity() as u128 * std::mem::size_of::<SlopeWorkspace>() as u128;
    let actual = workspaces.iter().try_fold(actual, |bytes, worker| {
        worker.payload_bytes().map(|payload| bytes + payload)
    })?;
    if actual
        > single_slope_recovery_extra_bytes(
            residual.nrows(),
            levels,
            channels,
            rayon::current_num_threads(),
        )?
    {
        return Err(allocation(
            "direct certificate capacities exceed their admission",
        ));
    }
    partials
        .par_chunks_mut(block)
        .zip(workspaces.par_iter_mut())
        .enumerate()
        .try_for_each(|(batch, (bank, worker))| -> Result<()> {
            for (local, partial) in bank.iter_mut().enumerate() {
                group_moments(
                    source.members(batch * block + local)?,
                    effect,
                    weights,
                    residual,
                    worker,
                )?;
                solve_group(channels, 1, worker)?;
                *partial = group_rhs_certificate(worker, channels, 1, 0, weights.raw_scale)?;
            }
            Ok(())
        })?;
    let mut absolute = 0.0_f64;
    let mut relative_infinity = 0.0_f64;
    let mut squares = 0.0_f64;
    for (raw, relative) in partials {
        absolute = absolute.max(raw);
        relative_infinity = relative_infinity.max(relative);
        squares = relative.mul_add(relative, squares);
    }
    Ok(FeCertificate {
        absolute_infinity_norm: absolute,
        relative_infinity_norm: relative_infinity,
        relative_two_norm: (squares / levels as f64).sqrt(),
        passed: relative_infinity <= tolerance,
    })
}


fn certify(
    topology: &FinalizedCategoricalTopology,
    effects: &[CategoricalAbsorbedEffectView<'_>],
    weights: ValidatedWeights<'_>,
    residuals: &DenseMatrix,
    tolerance: f64,
    workspace: &mut SlopeWorkspace,
) -> Result<FeCertificate> {
    weighted_norms(
        residuals,
        weights,
        &mut workspace.residual_norms,
        &mut workspace.value_scales,
        &mut workspace.coefficients[..residuals.ncols()],
    )?;
    for rhs in 0..residuals.ncols() {
        workspace.rhs_scales[rhs] =
            workspace.reference_norms[rhs].max(workspace.residual_norms[rhs]);
    }
    let mut absolute = 0.0_f64;
    let mut relative_infinity = 0.0_f64;
    let mut relative_squares = 0.0_f64;
    let mut count = 0_usize;
    for (effect_index, effect) in effects.iter().enumerate() {
        let source = topology
            .registry()
            .source(topology.effect_to_topology()[effect_index])?;
        for level in 0..source.n_levels() {
            group_moments(
                source.members(level)?,
                effect,
                weights,
                residuals,
                workspace,
            )?;
            solve_group(effect.channels(), residuals.ncols(), workspace)?;
            let channels = effect.channels();
            for rhs in 0..residuals.ncols() {
                let (raw, relative) = group_rhs_certificate(workspace, channels, residuals.ncols(), rhs, weights.raw_scale)?;
                absolute = absolute.max(raw);
                relative_infinity = relative_infinity.max(relative);
                relative_squares = relative.mul_add(relative, relative_squares);
                count = count
                    .checked_add(1)
                    .ok_or_else(|| allocation("intercept-slope MAP certificate count overflows"))?;
            }
        }
    }
    let relative_two = if count == 0 {
        0.0
    } else {
        (relative_squares / count as f64).sqrt()
    };
    Ok(FeCertificate {
        absolute_infinity_norm: absolute,
        relative_infinity_norm: relative_infinity,
        relative_two_norm: relative_two,
        passed: relative_infinity <= tolerance,
    })
}

fn group_rhs_certificate(
    workspace: &SlopeWorkspace,
    channels: usize,
    rhs_count: usize,
    rhs: usize,
    raw_scale: f64,
) -> Result<(f64, f64)> {
    let mut absolute = 0.0_f64;
    let mut projected_square = 0.0_f64;
    for left in 0..channels {
        for right in 0..channels {
            projected_square = workspace.coefficients[left * rhs_count + rhs].mul_add(
                workspace.gram[left * channels + right]
                    * workspace.coefficients[right * rhs_count + rhs],
                projected_square,
            );
        }
    }
    let projected = projected_square.max(0.0).sqrt();
    let denominator = workspace.rhs_scales[rhs];
    let relative = if denominator == 0.0 {
        if projected == 0.0 {
            0.0
        } else {
            f64::INFINITY
        }
    } else {
        projected / denominator
    };
    if !relative.is_finite() {
        return Err(invalid_data(
            "intercept-slope MAP certificate ratio is not finite",
        ));
    }
    for channel in 0..channels {
        let raw = workspace.cross[channel * rhs_count + rhs].abs()
            * workspace.value_scales[rhs]
            * workspace.channel_scales[channel]
            * raw_scale;
        absolute = absolute.max(if raw.is_finite() { raw } else { f64::INFINITY });
    }
    Ok((absolute, relative))
}


fn weighted_norms(
    values: &DenseMatrix,
    weights: ValidatedWeights<'_>,
    output: &mut [f64],
    scales: &mut [f64],
    sums: &mut [f64],
) -> Result<()> {
    if output.len() != values.ncols()
        || scales.len() != values.ncols()
        || sums.len() != values.ncols()
    {
        return Err(invalid_argument(
            "intercept-slope MAP norm workspace dimensions differ",
        ));
    }
    scales.fill(0.0);
    sums.fill(1.0);
    for row in 0..values.nrows() {
        let root_weight = weights.value(row).sqrt();
        for rhs in 0..values.ncols() {
            let value = root_weight * values[(row, rhs)];
            if !value.is_finite() {
                return Err(invalid_data(
                    "intercept-slope MAP weighted value is not finite",
                ));
            }
            update_scaled_sum(value, &mut scales[rhs], &mut sums[rhs]);
        }
    }
    for rhs in 0..values.ncols() {
        output[rhs] = if scales[rhs] == 0.0 {
            0.0
        } else {
            scales[rhs] * sums[rhs].sqrt()
        };
        if !output[rhs].is_finite() {
            return Err(invalid_data(
                "intercept-slope MAP weighted norm is not finite",
            ));
        }
    }
    Ok(())
}

fn validate_weights(weights: BorrowedMapWeights<'_>, nobs: usize) -> Result<ValidatedWeights<'_>> {
    match weights {
        BorrowedMapWeights::Unit => Ok(ValidatedWeights {
            values: None,
            raw_scale: 1.0,
        }),
        BorrowedMapWeights::Provided(values) => {
            if values.len() != nobs
                || values
                    .iter()
                    .any(|value| !value.is_finite() || *value <= 0.0)
            {
                return Err(invalid_data(
                    "intercept-slope MAP weights must be positive, finite, and aligned",
                ));
            }
            let raw_scale = values.iter().copied().fold(0.0_f64, f64::max);
            if values.iter().any(|value| *value / raw_scale == 0.0) {
                return Err(invalid_data(
                    "intercept-slope MAP normalized weight underflowed to zero",
                ));
            }
            Ok(ValidatedWeights {
                values: Some(values),
                raw_scale,
            })
        }
    }
}

fn validate_config(config: MapConfig) -> Result<()> {
    if !config.tolerance.is_finite() || config.tolerance <= 0.0 {
        return Err(invalid_argument(
            "intercept-slope MAP tolerance must be finite and positive",
        ));
    }
    if config.max_iterations == 0 || config.check_every == 0 {
        return Err(invalid_argument(
            "intercept-slope MAP iteration budgets must be positive",
        ));
    }
    Ok(())
}

fn finish(
    values: DenseMatrix,
    iterations: usize,
    certificate: FeCertificate,
    setup_seconds: f64,
    solve_seconds: f64,
    workspace_peak: SolverWorkspacePeak,
) -> Result<CertifiedBorrowedMap> {
    CertifiedBorrowedMap::from_certified_parts(
        values,
        SolveReport {
            checkpoint_retries: 0,
            solver_workspace_peak: workspace_peak,
            requested_solver: FeSolverKind::Map,
            used_solver: FeSolverKind::Map,
            iterations,
            stop_reason: SolveStopReason::Certified,
            normal_equation_residual: certificate.relative_two_norm,
            certificate,
            setup_seconds,
            solve_seconds,
            certification_seconds: 0.0,
            fallback_used: false,
            requested_preconditioner: None,
            used_preconditioner: None,
            pilot_iterations: 0,
            pilot_contraction: 0.0,
            warnings: Vec::new(),
        },
    )
}

fn compensated_add(value: f64, sum: &mut f64, correction: &mut f64) -> Result<()> {
    let updated = *sum + value;
    let adjustment = if sum.abs() >= value.abs() {
        (*sum - updated) + value
    } else {
        (value - updated) + *sum
    };
    *sum = updated;
    *correction += adjustment;
    if !sum.is_finite() || !correction.is_finite() {
        return Err(invalid_data(
            "intercept-slope MAP compensated accumulation is not finite",
        ));
    }
    Ok(())
}

fn update_scaled_sum(value: f64, scale: &mut f64, sum: &mut f64) {
    let absolute = value.abs();
    if absolute == 0.0 {
        return;
    }
    if *scale < absolute {
        let ratio = *scale / absolute;
        *sum = 1.0 + *sum * ratio * ratio;
        *scale = absolute;
    } else {
        let ratio = absolute / *scale;
        *sum += ratio * ratio;
    }
}

fn fallible_with_capacity<T>(elements: usize, label: &'static str) -> Result<Vec<T>> {
    let mut output = Vec::new();
    output
        .try_reserve_exact(elements)
        .map_err(|_| allocation(label))?;
    Ok(output)
}

fn fallible_filled<T: Clone>(elements: usize, value: T, label: &'static str) -> Result<Vec<T>> {
    let mut output = fallible_with_capacity(elements, label)?;
    output.resize(elements, value);
    Ok(output)
}

fn fallible_copy<T: Clone>(source: &[T], label: &'static str) -> Result<Vec<T>> {
    let mut output = fallible_with_capacity(source.len(), label)?;
    output.extend_from_slice(source);
    Ok(output)
}

fn reserved_zeros<R: SlopeWorkspaceReservation>(
    elements: usize,
    reservation: &mut R,
    label: &'static str,
) -> Result<Vec<f64>> {
    let mut output = Vec::new();
    reservation.reserve_f64(&mut output, elements, label)?;
    if output.capacity() < elements {
        return Err(allocation(
            "intercept-slope MAP workspace reservation returned insufficient capacity",
        ));
    }
    output.resize(elements, 0.0);
    Ok(output)
}

fn reserved_indices<R: SlopeWorkspaceReservation>(
    elements: usize,
    reservation: &mut R,
    label: &'static str,
) -> Result<Vec<usize>> {
    let mut output = Vec::new();
    reservation.reserve_usize(&mut output, elements, label)?;
    if output.capacity() < elements {
        return Err(allocation(
            "categorical slope MAP permutation reservation returned insufficient capacity",
        ));
    }
    output.extend(0..elements);
    Ok(output)
}

fn allocation(message: impl Into<String>) -> FeregError {
    FeregError::new(ErrorCode::Allocation, message)
}

fn invalid_argument(message: impl Into<String>) -> FeregError {
    FeregError::new(ErrorCode::InvalidArgument, message)
}

fn invalid_data(message: impl Into<String>) -> FeregError {
    FeregError::new(ErrorCode::InvalidData, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::fe::{finalize_categorical_topology, CategoricalCodeView};

    fn config() -> MapConfig {
        MapConfig {
            tolerance: 1e-11,
            max_iterations: 20_000,
            check_every: 1,
            symmetric: true,
        }
    }

    #[derive(Default)]
    struct InjectedReservation {
        calls: usize,
        fail_at: Option<usize>,
        undersize_at: Option<usize>,
        excess: usize,
    }

    impl SlopeWorkspaceReservation for InjectedReservation {
        fn reserve_f64(
            &mut self,
            target: &mut Vec<f64>,
            elements: usize,
            _label: &'static str,
        ) -> Result<()> {
            let call = self.calls;
            self.calls += 1;
            if self.fail_at == Some(call) {
                return Err(allocation(
                    "injected intercept-slope MAP allocation failure",
                ));
            }
            if self.undersize_at != Some(call) {
                target
                    .try_reserve_exact(elements + self.excess)
                    .map_err(|_| allocation("test intercept-slope MAP reservation failed"))?;
            }
            Ok(())
        }

        fn reserve_usize(
            &mut self,
            target: &mut Vec<usize>,
            elements: usize,
            _label: &'static str,
        ) -> Result<()> {
            let call = self.calls;
            self.calls += 1;
            if self.fail_at == Some(call) {
                return Err(allocation(
                    "injected categorical slope MAP allocation failure",
                ));
            }
            if self.undersize_at != Some(call) {
                target
                    .try_reserve_exact(elements + self.excess)
                    .map_err(|_| allocation("test categorical slope MAP reservation failed"))?;
            }
            Ok(())
        }
    }

    #[test]
    fn slope_memory_model_covers_every_numeric_capacity_and_overflow() {
        for channels in [1, 2, 7] {
            for rhs in [1, 3, 19] {
                let workspace =
                    SlopeWorkspace::new(channels, rhs, &mut SystemSlopeWorkspaceReservation)
                        .unwrap();
                assert_eq!(
                    workspace.payload_bytes().unwrap(),
                    SlopeWorkspace::modeled_bytes(channels, rhs).unwrap()
                );
            }
        }
        assert_eq!(
            SlopeWorkspace::modeled_bytes(usize::MAX, usize::MAX)
                .unwrap_err()
                .code,
            ErrorCode::Allocation
        );
    }

    #[test]
    fn slope_memory_exact_budget_shortfall_and_capacity_growth_fail_closed() {
        let group = [0, 0, 0, 1, 1, 1];
        let topology = finalize_categorical_topology(
            &[CategoricalCodeView::new(&group, 2)],
            &[&[0]],
            &[true; 6],
        )
        .unwrap();
        let slope = [0.0, 1.0, 2.0, 0.0, 1.5, 3.0];
        let effects = [CategoricalAbsorbedEffectView::new(true, vec![&slope]).unwrap()];
        let values = DenseMatrix::from_columns(&[vec![1.0, 2.0, 4.0, 3.0, 5.0, 8.0]]).unwrap();
        let required = SlopeWorkspace::modeled_bytes(2, 1)
            .unwrap()
            .max(topology.validation_workspace_bytes().unwrap());
        let base = 1234;
        for weights in [
            BorrowedMapWeights::Unit,
            BorrowedMapWeights::Provided(&[1.0, 3.0, 2.0, 5.0, 1.0, 2.0]),
        ] {
            let expected = absorb_finalized_categorical_slope_map_certified(
                &topology,
                &effects,
                weights,
                values.clone(),
                config(),
            )
            .unwrap();
            let exact = FeSolverMemoryBudget {
                execution_bytes: base,
                usable_bytes: base + required,
            };
            let actual = absorb_finalized_categorical_slope_map_with_budget_certified(
                &topology,
                &effects,
                weights,
                values.clone(),
                config(),
                Some(exact),
            )
            .unwrap();
            assert_eq!(actual.residualized(), expected.residualized());
            assert_eq!(
                actual.report().solver_workspace_peak.bytes(),
                Some(required as u64)
            );
            let mut denied = InjectedReservation::default();
            let error = absorb_with_reservation(
                &topology,
                &effects,
                weights,
                values.clone(),
                config(),
                Some(FeSolverMemoryBudget {
                    usable_bytes: exact.usable_bytes - 1,
                    ..exact
                }),
                &mut denied,
            )
            .unwrap_err();
            assert_eq!(error.code, ErrorCode::Allocation);
            assert_eq!(denied.calls, 0);
            let mut oversized = InjectedReservation {
                excess: 1,
                ..InjectedReservation::default()
            };
            assert_eq!(
                absorb_with_reservation(
                    &topology,
                    &effects,
                    weights,
                    values.clone(),
                    config(),
                    Some(exact),
                    &mut oversized,
                )
                .unwrap_err()
                .code,
                ErrorCode::Allocation
            );
        }
    }

    #[test]
    fn slope_memory_charges_interaction_validation_as_a_sequential_peak() {
        let left: Vec<u32> = (0..100).map(|row| row % 5).collect();
        let right: Vec<u32> = (0..100).map(|row| row % 7).collect();
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&left, 5),
                CategoricalCodeView::new(&right, 7),
            ],
            &[&[0, 1]],
            &[true; 100],
        )
        .unwrap();
        let validation = topology.validation_workspace_bytes().unwrap();
        assert_eq!(
            validation,
            (4 * std::mem::size_of::<super::super::CategoricalCodeView<'_>>()
                + 100 * (std::mem::size_of::<usize>() + std::mem::size_of::<u32>()))
                as u128
        );
        assert!(validation > SlopeWorkspace::modeled_bytes(2, 1).unwrap());
        let slope: Vec<f64> = (0..100).map(|row| row as f64).collect();
        let effects = [CategoricalAbsorbedEffectView::new(true, vec![&slope]).unwrap()];
        let values = DenseMatrix::from_columns(&[slope.clone()]).unwrap();
        let result = absorb_finalized_categorical_slope_map_with_budget_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            values,
            config(),
            Some(FeSolverMemoryBudget {
                execution_bytes: 0,
                usable_bytes: validation,
            }),
        )
        .unwrap();
        assert_eq!(
            result.report().solver_workspace_peak.bytes(),
            Some(validation as u64)
        );
    }

    #[test]
    fn intercept_plus_slope_and_second_intercept_effect_match_explicit_span() {
        let group = [0, 0, 0, 1, 1, 1, 2, 2, 2];
        let second = [0, 1, 2, 0, 1, 2, 0, 1, 2];
        let sources = [
            CategoricalCodeView::new(&group, 3),
            CategoricalCodeView::new(&second, 3),
        ];
        let topology =
            finalize_categorical_topology(&sources, &[&[0_usize][..], &[1_usize][..]], &[true; 9])
                .expect("topology");
        let slope = [0.0, 1.0, 2.0, 0.0, 2.0, 3.0, 1.0, 2.0, 4.0];
        let values = DenseMatrix::from_columns(&[
            (0..9)
                .map(|row| {
                    3.0 + 0.5 * group[row] as f64
                        + (group[row] as f64 + 1.0) * slope[row]
                        + 0.25 * second[row] as f64
                })
                .collect::<Vec<_>>(),
            (0..9).map(|row| slope[row] + second[row] as f64).collect(),
        ])
        .expect("values");
        let result = absorb_finalized_categorical_intercept_slope_map_certified(
            &topology,
            &[Some(&slope), None],
            BorrowedMapWeights::Unit,
            values,
            config(),
        )
        .expect("certified MAP");
        assert!(result.report().certified());
        assert!(result
            .residualized()
            .as_slice()
            .iter()
            .all(|value| value.abs() < 1e-9));
    }

    #[test]
    fn slope_only_multiple_channels_match_their_explicit_local_span() {
        let firm = [0, 0, 0, 1, 1, 1];
        let worker = [0, 0, 0, 1, 1, 1];
        let sources = [
            CategoricalCodeView::new(&firm, 2),
            CategoricalCodeView::new(&worker, 2),
        ];
        let topology =
            finalize_categorical_topology(&sources, &[&[0_usize][..], &[1_usize][..]], &[true; 6])
                .expect("topology");
        let time = [1.0, 2.0, 3.0, 1.0, 2.0, 3.0];
        let x2 = [1.0, 4.0, 2.0, 2.0, 1.0, 5.0];
        let effects = vec![
            CategoricalAbsorbedEffectView::new(false, vec![&time]).expect("firm slope"),
            CategoricalAbsorbedEffectView::new(false, vec![&time, &x2]).expect("worker slopes"),
        ];
        let values =
            DenseMatrix::from_columns(&[vec![3.0, 8.0, 8.0, 4.0, 5.0, 11.0]]).expect("values");
        let result = absorb_finalized_categorical_slope_map_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            values,
            config(),
        )
        .expect("multiple slope-only MAP");
        assert!(result.report().certified());
        assert!(result
            .residualized()
            .as_slice()
            .iter()
            .all(|value| value.abs() < 1e-9));
    }

    #[test]
    fn three_nonorthogonal_slope_channels_preserve_the_known_complement() {
        let group = [0_u32, 0, 0, 0];
        let sources = [CategoricalCodeView::new(&group, 1)];
        let topology = finalize_categorical_topology(&sources, &[&[0_usize][..]], &[true; 4])
            .expect("topology");
        let first = [1.0, 1.0, 0.0, 0.0];
        let second = [0.0, 1.0, 1.0, 0.0];
        let third = [0.0, 0.0, 1.0, 1.0];
        let complement = [-1.0, 1.0, -1.0, 1.0];
        let values = (0..4)
            .map(|row| 2.0 * first[row] - 3.0 * second[row] + 0.5 * third[row] + complement[row])
            .collect::<Vec<_>>();
        let effects = [
            CategoricalAbsorbedEffectView::new(false, vec![&first, &second, &third])
                .expect("three slopes"),
        ];
        let result = absorb_finalized_categorical_slope_map_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            DenseMatrix::from_columns(&[values]).expect("values"),
            config(),
        )
        .expect("three-slope MAP");
        assert!(result.report().certified());
        for (actual, expected) in result.residualized().as_slice().iter().zip(complement) {
            assert!((actual - expected).abs() < 1e-10);
        }
    }

    #[test]
    fn recovery_returns_centered_crossed_effects_and_requested_channels() {
        let worker = [0_u32, 0, 1, 1, 2, 2];
        let firm = [0_u32, 1, 0, 1, 0, 1];
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker, 3),
                CategoricalCodeView::new(&firm, 2),
            ],
            &[&[0], &[1]],
            &[true; 6],
        )
        .expect("topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let worker_effect = [-1.0, -1.0, 0.25, 0.25, 0.75, 0.75];
        let firm_effect = [-0.5, 0.5, -0.5, 0.5, -0.5, 0.5];
        let target = worker_effect
            .iter()
            .zip(firm_effect)
            .map(|(left, right)| left + right)
            .collect::<Vec<_>>();
        let recovered = recover_finalized_categorical_effects_map_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, false],
            config(),
        )
        .expect("recovery");
        assert!(recovered.iterations() > 0);
        assert!(recovered.reconstruction_relative_infinity() < 1e-10);
        for (actual, expected) in recovered.absorbed_sum().iter().zip(&target) {
            assert!((actual - expected).abs() < 1e-10);
        }
        let saved_worker = recovered.channels()[0].as_ref().expect("worker output");
        for (actual, expected) in saved_worker.iter().zip(worker_effect) {
            assert!((actual - expected).abs() < 1e-10);
        }
        assert!(recovered.channels()[1].is_none());
    }

    #[test]
    fn direct_single_slope_recovery_preserves_rank_weights_and_rejection() {
        let n = 4099;
        let codes: Vec<_> = (0..n).map(|r| (r % 257) as u32).collect();
        let topology = finalize_categorical_topology(&[CategoricalCodeView::new(&codes, 257)],
            &[&[0]], &vec![true; n]).unwrap();
        for intercept in [false, true] { for rank_case in 0..4 { for scale in [1e-8, 1.0, 1e8] {
            let z: Vec<_> = (0..n).map(|r| ((r * 7) as f64).sin() * scale).collect();
            let z2: Vec<_> = (0..n).map(|r| match rank_case {
                1 => 0.0, 2 => z[r], 3 => z[r] + scale * 1e-15 * (r as f64).cos(),
                _ => ((r * 11) as f64).cos() * scale,
            }).collect();
            let effects = [CategoricalAbsorbedEffectView::new(intercept, vec![&z, &z2]).unwrap()];
            let target: Vec<_> = (0..n).map(|r| {
                let g = codes[r] as f64;
                (if intercept { g.cos() } else { 0.0 })
                    + g.sin() * z[r] / scale + (g * 0.7).cos() * z2[r] / scale
            }).collect();
            for weight_scale in [0.0, 1e-100, 1.0, 1e100] {
                let raw: Vec<_> = (0..n).map(|r| weight_scale * (1 + r % 7) as f64).collect();
                let weights = if weight_scale == 0.0 { BorrowedMapWeights::Unit }
                    else { BorrowedMapWeights::Provided(&raw) };
                for threads in [1, 4] { crate::ThreadTeam::new(crate::ThreadConfig::from_requested(threads, false).unwrap()).install(|| {
                    let requested = vec![true; effects[0].channels()];
                    let actual = recover_finalized_single_slope_direct_certified(&topology, &effects,
                        weights, &target, &requested, 1e-12, true).unwrap();
                    let expected = recover_finalized_categorical_effects_map_certified(&topology, &effects,
                        weights, &target, &requested, config()).unwrap();
                    assert_eq!(actual.recovery_method(), CategoricalRecoveryMethod::Direct);
                    let residual = DenseMatrix::from_row_major(n, 1, (0..n)
                        .map(|r| target[r] * 0.123 + 0.1 * (r as f64).sin()).collect()).unwrap();
                    let validated = validate_weights(weights, n).unwrap();
                    let mut workspace = SlopeWorkspace::new(effects[0].channels(), 1, &mut SystemSlopeWorkspaceReservation).unwrap();
                    workspace.reference_norms[0] = 100.0;
                    let serial = certify(&topology, &effects, validated, &residual, 1e-12, &mut workspace).unwrap();
                    let parallel = certify_single_slope_parallel(&topology, &effects[0], validated, &residual, 1e-12, &mut workspace).unwrap();
                    assert_eq!(serial, parallel);
                    for (a,b) in actual.absorbed_sum().iter().zip(&target) { assert!((a-b).abs() < 1e-10); }
                    for (a,b) in actual.channels().iter().zip(expected.channels()) {
                        for (a,b) in a.as_ref().unwrap().iter().zip(b.as_ref().unwrap()) {
                            assert!((a-b).abs() < 1e-9, "{intercept} {rank_case} {scale}: {a} {b}");
                        }
                    }
                    let partial: Vec<_> = (0..effects[0].channels()).map(|c| c == 1).collect();
                    let selected = recover_finalized_single_slope_direct_certified(&topology, &effects,
                        weights, &target, &partial, 1e-12, false).unwrap();
                    for (c, values) in selected.channels().iter().enumerate() {
                        assert_eq!(values.is_some(), c == 1);
                    }
                    let mut inconsistent = target.clone(); inconsistent[0] += 0.001;
                    assert_eq!(recover_finalized_single_slope_direct_certified(&topology, &effects,
                        weights, &inconsistent, &requested, 1e-12, true).unwrap_err().code, ErrorCode::InvalidData);
                }).unwrap(); }
            }
        }}}
    }

    #[test]
    fn two_effect_graph_recovery_certifies_disconnected_and_inconsistent_targets() {
        for disconnected in [false, true] {
            for reversed in [false, true] {
                let mut left = vec![0_u32, 0, 1, 1, 2, 2, 3, 3];
                let mut right = if disconnected { vec![0_u32, 1, 0, 1, 2, 3, 2, 3] }
                    else { vec![0_u32, 1, 1, 2, 2, 3, 3, 0] };
                if reversed { left.reverse(); right.reverse(); }
                let topology = finalize_categorical_topology(&[
                    CategoricalCodeView::new(&left, 4), CategoricalCodeView::new(&right, 4),
                ], &[&[0], &[1]], &[true; 8]).unwrap();
                let effects = [CategoricalAbsorbedEffectView::new(true, Vec::new()).unwrap(),
                    CategoricalAbsorbedEffectView::new(true, Vec::new()).unwrap()];
                let target = left.iter().zip(&right).map(|(&a,&b)|
                    (a as f64 * 0.7).sin() + (b as f64 * 0.9).cos()).collect::<Vec<_>>();
                for requested in [[true,true], [true,false], [false,true]] {
                    for materialize in [false,true] {
                        let actual = recover_finalized_two_effects_graph_certified(&topology,
                            &effects, BorrowedMapWeights::Unit, &target, &requested, 1e-12,
                            !disconnected, materialize).unwrap();
                        let expected = recover_finalized_categorical_effects_map_certified(&topology,
                            &effects, BorrowedMapWeights::Unit, &target, &requested, config()).unwrap();
                        assert_eq!(actual.recovery_method(), CategoricalRecoveryMethod::Direct);
                        assert!(actual.reconstruction_relative_infinity() < 1e-12);
                        for (a,b) in actual.channels().iter().zip(expected.channels()) {
                            assert_eq!(a.is_some(),b.is_some());
                            if let (Some(a),Some(b)) = (a,b) {
                                for (&a,&b) in a.iter().zip(b) { assert!((a-b).abs()<1e-10); }
                            }
                        }
                        assert_eq!(actual.absorbed_sum.is_some(), materialize);
                    }
                }
                let mut inconsistent = target.clone();
                inconsistent[0] += 0.001;
                assert_eq!(recover_finalized_two_effects_graph_certified(&topology, &effects,
                    BorrowedMapWeights::Unit, &inconsistent, &[true,true], 1e-12,
                    !disconnected, true).unwrap_err().code, ErrorCode::InvalidData);
            }
        }
    }

    #[test]
    fn weighted_graph_recovery_preserves_components_scale_and_pointwise_rejection() {
        for disconnected in [false, true] {
            for reverse in [false, true] {
                let mut left = vec![0_u32, 0, 1, 1, 2, 2, 3, 3];
                let mut right = if disconnected { vec![0_u32, 1, 0, 1, 2, 3, 2, 3] }
                    else { vec![0_u32, 1, 1, 2, 2, 3, 3, 0] };
                if reverse { left.reverse(); right.reverse(); }
                let topology = finalize_categorical_topology(&[
                    CategoricalCodeView::new(&left, 4), CategoricalCodeView::new(&right, 4),
                ], &[&[0], &[1]], &[true; 8]).unwrap();
                let effects = [CategoricalAbsorbedEffectView::new(true, Vec::new()).unwrap(),
                    CategoricalAbsorbedEffectView::new(true, Vec::new()).unwrap()];
                let a = [-0.3, 1.7, 0.4, -1.1];
                let b = [0.2, -0.7, 0.9, 1.3];
                let target = left.iter().zip(&right).map(|(&l, &r)| a[l as usize] + b[r as usize])
                    .collect::<Vec<_>>();
                for raw in [vec![4.0; 8], vec![1.0, 3.0, 5.0, 2.0, 7.0, 4.0, 2.0, 6.0],
                    vec![1e-18, 1.0, 1e-12, 1.0, 1e-8, 1.0, 1e-4, 1.0]] {
                    let component = |row: usize| if disconnected { (left[row] / 2) as usize } else { 0 };
                    let mut mass = [0.0; 2];
                    let mut centers = [0.0; 2];
                    for row in 0..8 {
                        mass[component(row)] += raw[row];
                        centers[component(row)] += raw[row] * b[right[row] as usize];
                    }
                    for c in 0..=usize::from(disconnected) { centers[c] /= mass[c]; }
                    for scale in [1e-100, 1.0, 1e100] {
                        let weights = raw.iter().map(|w| w * scale).collect::<Vec<_>>();
                        for requested in [[true, true], [true, false], [false, true]] {
                            for materialize in [false, true] {
                                let recovered = recover_finalized_two_effects_graph_certified(&topology,
                                    &effects, BorrowedMapWeights::Provided(&weights), &target, &requested,
                                    1e-12, !disconnected, materialize).unwrap();
                                assert!(recovered.reconstruction_relative_infinity() < 1e-12);
                                for row in 0..8 {
                                    let expected = [a[left[row] as usize] + centers[component(row)],
                                        b[right[row] as usize] - centers[component(row)]];
                                    for channel in 0..2 {
                                        assert_eq!(recovered.channels()[channel].is_some(), requested[channel]);
                                        if let Some(values) = &recovered.channels()[channel] {
                                            assert!((values[row] - expected[channel]).abs() < 1e-12);
                                        }
                                    }
                                }
                                assert_eq!(recovered.absorbed_sum.is_some(), materialize);
                            }
                        }
                        // The first edge can have negligible weight. Its cycle inconsistency
                        // must still fail the unweighted pointwise reconstruction certificate.
                        let mut inconsistent = target.clone();
                        inconsistent[0] += 0.001;
                        assert_eq!(recover_finalized_two_effects_graph_certified(&topology, &effects,
                            BorrowedMapWeights::Provided(&weights), &inconsistent, &[true, true],
                            1e-12, !disconnected, true).unwrap_err().code, ErrorCode::InvalidData);
                    }
                }
            }
        }
    }

    #[test]
    fn coefficient_lsmr_recovery_matches_map_normalization() {
        let worker = [0_u32, 0, 1, 1, 2, 2];
        let firm = [0_u32, 1, 0, 1, 0, 1];
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker, 3),
                CategoricalCodeView::new(&firm, 2),
            ],
            &[&[0], &[1]],
            &[true; 6],
        )
        .expect("topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let target = [-1.5, -0.5, -0.25, 0.75, 0.25, 1.25];
        let map = recover_finalized_categorical_effects_map_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            config(),
        )
        .expect("MAP recovery");
        let lsmr = recover_finalized_categorical_effects_lsmr_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            LsmrConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                ..LsmrConfig::default()
            },
            1e-12,
        )
        .expect("LSMR recovery");
        for (left, right) in lsmr.absorbed_sum().iter().zip(map.absorbed_sum()) {
            assert!((left - right).abs() < 1e-10);
        }
        for channel in 0..2 {
            for (left, right) in lsmr.channels()[channel]
                .as_ref()
                .expect("LSMR channel")
                .iter()
                .zip(map.channels()[channel].as_ref().expect("MAP channel"))
            {
                assert!((left - right).abs() < 1e-10, "{left} != {right}");
            }
        }
    }

    #[test]
    fn four_sweep_sd_pilot_then_lsmr_matches_strict_lsmr() {
        let worker = [0_u32, 0, 1, 1, 2, 2, 3, 3];
        let firm = [0_u32, 1, 1, 2, 2, 3, 3, 0];
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker, 4),
                CategoricalCodeView::new(&firm, 4),
            ],
            &[&[0], &[1]],
            &[true; 8],
        )
        .expect("topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let target = [-1.5, -0.5, -0.25, 0.75, 0.25, 1.25, 1.5, -1.5];
        let lsmr_config = LsmrConfig {
            tolerance: 1e-12,
            max_iterations: 20_000,
            ..LsmrConfig::default()
        };
        let hybrid = recover_finalized_categorical_effects_sd_lsmr_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            lsmr_config,
            MapConfig {
                tolerance: 1e-12,
                ..config()
            },
            None,
        )
        .expect("SD recovery");
        let lsmr = recover_finalized_categorical_effects_lsmr_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            lsmr_config,
            1e-12,
        )
        .expect("LSMR recovery");
        assert_eq!(
            hybrid.recovery_method(),
            CategoricalRecoveryMethod::HybridLsmr
        );
        assert!(hybrid.reconstruction_relative_infinity() <= 1e-10);
        for (actual, expected) in hybrid.absorbed_sum().iter().zip(lsmr.absorbed_sum()) {
            assert!((actual - expected).abs() <= 1e-10);
        }
        for channel in 0..2 {
            for (actual, expected) in hybrid.channels()[channel]
                .as_ref()
                .expect("hybrid channel")
                .iter()
                .zip(lsmr.channels()[channel].as_ref().expect("LSMR channel"))
            {
                assert!((actual - expected).abs() <= 1e-9);
            }
        }
    }

    #[test]
    fn borrowed_cg_recovery_matches_strict_lsmr_coefficients() {
        let worker = [0_u32, 0, 1, 1, 2, 2, 3, 3];
        let firm = [0_u32, 1, 1, 2, 2, 3, 3, 0];
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker, 4),
                CategoricalCodeView::new(&firm, 4),
            ],
            &[&[0], &[1]],
            &[true; 8],
        )
        .expect("topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let target = [-1.5, -0.5, -0.25, 0.75, 0.25, 1.25, 1.5, -1.5];
        let cg = recover_finalized_categorical_effects_cg_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            MapConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                check_every: 1,
                symmetric: true,
            },
        )
        .expect("CG recovery");
        let lsmr = recover_finalized_categorical_effects_lsmr_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            LsmrConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                ..LsmrConfig::default()
            },
            1e-12,
        )
        .expect("LSMR recovery");
        assert_eq!(cg.recovery_method(), CategoricalRecoveryMethod::Cg);
        for (actual, expected) in cg.absorbed_sum().iter().zip(lsmr.absorbed_sum()) {
            assert!((actual - expected).abs() <= 1e-10);
        }
        for channel in 0..2 {
            for (actual, expected) in cg.channels()[channel]
                .as_ref()
                .expect("CG channel")
                .iter()
                .zip(lsmr.channels()[channel].as_ref().expect("LSMR channel"))
            {
                assert!((actual - expected).abs() <= 1e-9);
            }
        }
    }

    #[test]
    fn sd_lsmr_recovery_reuses_only_the_same_topology_validation() {
        let group = [0_u32, 0, 1, 1, 2, 2];
        let topology = finalize_categorical_topology(
            &[CategoricalCodeView::new(&group, 3)], &[&[0]], &[true; 6],
        ).unwrap();
        let effects = [CategoricalAbsorbedEffectView::new(true, Vec::new()).unwrap()];
        let supplied_weights = [1.0, 3.0, 2.0, 5.0, 4.0, 7.0];
        for weights in [BorrowedMapWeights::Unit, BorrowedMapWeights::Provided(&supplied_weights)] {
            for perturbation in 0..4 {
                let mut target = [-2.0, -2.0, 0.5, 0.5, 1.5, 1.5];
                match perturbation {
                    1 => target[0] += 1e-13,
                    2 => target[0] += 1.0,
                    3 => target[0] = f64::NAN,
                    _ => {},
                }
                let run = |receipt| recover_finalized_categorical_effects_sd_lsmr_certified(
                    &topology, &effects, weights, &target, &[true], LsmrConfig::default(),
                    config(), receipt,
                );
                assert_eq!(run(None), run(topology.validate_single_source().unwrap()));
            }
        }
        let other = topology.clone();
        let error = recover_finalized_categorical_effects_sd_lsmr_certified(
            &topology, &effects, BorrowedMapWeights::Unit, &[0.0; 6], &[true],
            LsmrConfig::default(), config(), other.validate_single_source().unwrap(),
        ).unwrap_err();
        assert_eq!(error.code, ErrorCode::InvalidArgument);
        assert!(error.message.contains("another topology"));
    }

    #[test]
    fn sd_lsmr_recovery_uses_the_direct_one_effect_path_with_weights() {
        let group = [0_u32, 0, 1, 1, 2, 2];
        let topology = finalize_categorical_topology(
            &[CategoricalCodeView::new(&group, 3)],
            &[&[0]],
            &[true; 6],
        )
        .expect("topology");
        let effects = [CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("group")];
        let target = [-2.0, -2.0, 0.5, 0.5, 1.5, 1.5];
        let weights = [1.0, 3.0, 2.0, 5.0, 4.0, 7.0];
        let recovered = recover_finalized_categorical_effects_sd_lsmr_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Provided(&weights),
            &target,
            &[true],
            LsmrConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                ..LsmrConfig::default()
            },
            MapConfig {
                tolerance: 1e-12,
                ..config()
            },
            None,
        )
        .expect("direct recovery");
        assert_eq!(
            recovered.recovery_method(),
            CategoricalRecoveryMethod::Direct
        );
        assert_eq!(recovered.iterations(), 1);
        for (actual, expected) in recovered.absorbed_sum().iter().zip(target) {
            assert!((actual - expected).abs() <= 1e-12);
        }
    }

    #[test]
    fn coefficient_lsmr_recovery_normalizes_disconnected_components() {
        let worker = [0_u32, 1, 2, 3];
        let firm = [0_u32, 0, 1, 1];
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker, 4),
                CategoricalCodeView::new(&firm, 2),
            ],
            &[&[0], &[1]],
            &[true; 4],
        )
        .expect("disconnected topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let target = [1.0, 3.0, 10.0, 14.0];
        let map = recover_finalized_categorical_effects_map_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            config(),
        )
        .expect("disconnected MAP recovery");
        let lsmr = recover_finalized_categorical_effects_lsmr_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            LsmrConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                ..LsmrConfig::default()
            },
            1e-12,
        )
        .expect("disconnected LSMR recovery");
        for channel in 0..2 {
            for (left, right) in lsmr.channels()[channel]
                .as_ref()
                .expect("LSMR channel")
                .iter()
                .zip(map.channels()[channel].as_ref().expect("MAP channel"))
            {
                assert!((left - right).abs() < 1e-10, "{left} != {right}");
            }
        }
    }

    #[test]
    fn retained_coefficient_connected_hint_matches_component_normalization() {
        let worker = [0_u32, 0, 1, 1, 2, 2, 3, 3];
        let firm = [0_u32, 1, 1, 2, 2, 3, 3, 0];
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker, 4),
                CategoricalCodeView::new(&firm, 4),
            ],
            &[&[0], &[1]],
            &[true; 8],
        )
        .expect("connected topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let coefficient_values = vec![1.0, -2.0, 0.5, 3.0, 4.0, -1.0, 2.0, -3.0];
        let coefficients =
            FeCoefficientBatch::from_values(vec![1, 1], vec![4, 4], 1, coefficient_values.clone())
                .expect("coefficient batch");
        let target = worker
            .iter()
            .zip(&firm)
            .map(|(&worker, &firm)| {
                coefficient_values[worker as usize] + coefficient_values[4 + firm as usize]
            })
            .collect::<Vec<_>>();
        let general = recover_finalized_categorical_effects_from_coefficients_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            &coefficients,
            1e-12,
            false,
        )
        .expect("general normalization");
        let connected = recover_finalized_categorical_effects_from_coefficients_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            &coefficients,
            1e-12,
            true,
        )
        .expect("known-connected normalization");
        assert_eq!(general.absorbed_sum(), connected.absorbed_sum());
        assert_eq!(general.channels(), connected.channels());
    }

    #[test]
    fn retained_coefficient_saved_only_plan_omits_combined_observation_vector() {
        let worker = [0_u32, 0, 1, 1, 2, 2, 3, 3];
        let firm = [0_u32, 1, 1, 2, 2, 3, 3, 0];
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker, 4),
                CategoricalCodeView::new(&firm, 4),
            ],
            &[&[0], &[1]],
            &[true; 8],
        )
        .expect("connected topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let coefficient_values = vec![1.0, -2.0, 0.5, 3.0, 4.0, -1.0, 2.0, -3.0];
        let coefficients =
            FeCoefficientBatch::from_values(vec![1, 1], vec![4, 4], 1, coefficient_values.clone())
                .expect("coefficient batch");
        let target = worker
            .iter()
            .zip(&firm)
            .map(|(&worker, &firm)| {
                coefficient_values[worker as usize] + coefficient_values[4 + firm as usize]
            })
            .collect::<Vec<_>>();

        let materialized =
            recover_finalized_categorical_effects_from_coefficients_selected_certified(
                &topology,
                &effects,
                BorrowedMapWeights::Unit,
                &target,
                &[true, true],
                &coefficients,
                1e-12,
                true,
                true,
            )
            .expect("materialized retained-coefficient recovery");
        let saved_only =
            recover_finalized_categorical_effects_from_coefficients_selected_certified(
                &topology,
                &effects,
                BorrowedMapWeights::Unit,
                &target,
                &[true, true],
                &coefficients,
                1e-12,
                true,
                false,
            )
            .expect("saved-only retained-coefficient recovery");
        assert_eq!(materialized.channels(), saved_only.channels());
        let (materialized_sum, materialized_channels) = materialized.into_optional_parts();
        let (saved_only_sum, saved_only_channels) = saved_only.into_optional_parts();
        assert!(materialized_sum.is_some());
        assert!(saved_only_sum.is_none());
        assert_eq!(materialized_channels, saved_only_channels);
    }

    #[test]
    fn recovery_waits_for_reconstruction_after_an_early_moment_certificate() {
        const GROUPS: usize = 72;
        let observations = GROUPS * 2;
        let mut worker_codes = Vec::with_capacity(observations);
        let mut firm_codes = Vec::with_capacity(observations);
        let mut target = Vec::with_capacity(observations);
        for firm in 0..GROUPS {
            for worker in [firm, (firm + 1) % GROUPS] {
                worker_codes.push(worker as u32);
                firm_codes.push(firm as u32);
                let worker_effect =
                    0.35 * (std::f64::consts::TAU * worker as f64 / GROUPS as f64).cos();
                let firm_effect = (std::f64::consts::TAU * firm as f64 / GROUPS as f64).sin();
                target.push(2.0 + worker_effect + firm_effect);
            }
        }
        let sources = [
            CategoricalCodeView::new(&worker_codes, GROUPS),
            CategoricalCodeView::new(&firm_codes, GROUPS),
        ];
        let retained = vec![true; observations];
        let topology =
            finalize_categorical_topology(&sources, &[&[0_usize][..], &[1_usize][..]], &retained)
                .expect("weak AKM-cycle topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker effect"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm effect"),
        ];
        let recovered = recover_finalized_categorical_effects_map_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            MapConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                check_every: 1,
                symmetric: true,
            },
        )
        .expect("weak AKM-cycle recovery");
        assert!(recovered.reconstruction_relative_infinity() <= 1e-10);
        for (actual, expected) in recovered.absorbed_sum().iter().zip(target) {
            assert!((actual - expected).abs() <= 1e-9);
        }
    }

    #[test]
    fn weak_cycle_uses_the_hybrid_remainder_solve_and_certifies() {
        const GROUPS: usize = 72;
        let observations = GROUPS * 2;
        let mut worker_codes = Vec::with_capacity(observations);
        let mut firm_codes = Vec::with_capacity(observations);
        let mut target = Vec::with_capacity(observations);
        for firm in 0..GROUPS {
            for worker in [firm, (firm + 1) % GROUPS] {
                worker_codes.push(worker as u32);
                firm_codes.push(firm as u32);
                target.push(
                    0.35 * (std::f64::consts::TAU * worker as f64 / GROUPS as f64).cos()
                        + (std::f64::consts::TAU * firm as f64 / GROUPS as f64).sin(),
                );
            }
        }
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker_codes, GROUPS),
                CategoricalCodeView::new(&firm_codes, GROUPS),
            ],
            &[&[0], &[1]],
            &vec![true; observations],
        )
        .expect("weak topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let recovered = recover_finalized_categorical_effects_sd_lsmr_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            LsmrConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                ..LsmrConfig::default()
            },
            MapConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                check_every: 1,
                symmetric: true,
            },
            None,
        )
        .expect("hybrid weak-cycle recovery");
        assert_eq!(
            recovered.recovery_method(),
            CategoricalRecoveryMethod::HybridLsmr
        );
        assert!(recovered.reconstruction_relative_infinity() <= 1e-10);
    }

    #[test]
    fn weak_cycle_cg_continues_to_the_reconstruction_certificate() {
        const GROUPS: usize = 72;
        let observations = GROUPS * 2;
        let mut worker_codes = Vec::with_capacity(observations);
        let mut firm_codes = Vec::with_capacity(observations);
        let mut target = Vec::with_capacity(observations);
        for firm in 0..GROUPS {
            for worker in [firm, (firm + 1) % GROUPS] {
                worker_codes.push(worker as u32);
                firm_codes.push(firm as u32);
                target.push(
                    0.35 * (std::f64::consts::TAU * worker as f64 / GROUPS as f64).cos()
                        + (std::f64::consts::TAU * firm as f64 / GROUPS as f64).sin(),
                );
            }
        }
        let topology = finalize_categorical_topology(
            &[
                CategoricalCodeView::new(&worker_codes, GROUPS),
                CategoricalCodeView::new(&firm_codes, GROUPS),
            ],
            &[&[0], &[1]],
            &vec![true; observations],
        )
        .expect("weak topology");
        let effects = [
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("worker"),
            CategoricalAbsorbedEffectView::new(true, Vec::new()).expect("firm"),
        ];
        let recovered = recover_finalized_categorical_effects_cg_certified(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            &target,
            &[true, true],
            MapConfig {
                tolerance: 1e-12,
                max_iterations: 20_000,
                check_every: 1,
                symmetric: true,
            },
        )
        .expect("strict CG recovery");
        assert_eq!(recovered.recovery_method(), CategoricalRecoveryMethod::Cg);
        assert!(recovered.reconstruction_relative_infinity() <= 1e-10);
        for (actual, expected) in recovered.absorbed_sum().iter().zip(target) {
            assert!((actual - expected).abs() <= 1e-9);
        }
    }

    #[test]
    fn every_workspace_reservation_and_capacity_guard_fails_closed() {
        let group = [0, 0, 0, 1, 1, 1];
        let topology = finalize_categorical_topology(
            &[CategoricalCodeView::new(&group, 2)],
            &[&[0]],
            &[true; 6],
        )
        .expect("topology");
        let slope = [0.0, 1.0, 2.0, 0.0, 1.5, 3.0];
        let effects =
            [CategoricalAbsorbedEffectView::new(true, vec![&slope]).expect("slope effect")];
        let values =
            DenseMatrix::from_columns(&[vec![1.0, 2.0, 4.0, 3.0, 5.0, 8.0]]).expect("values");
        let mut successful = InjectedReservation::default();
        absorb_with_reservation(
            &topology,
            &effects,
            BorrowedMapWeights::Unit,
            values.clone(),
            config(),
            None,
            &mut successful,
        )
        .expect("allocation audit baseline");
        assert!(successful.calls > 0);
        for call in 0..successful.calls {
            let mut injected = InjectedReservation {
                fail_at: Some(call),
                ..InjectedReservation::default()
            };
            let error = absorb_with_reservation(
                &topology,
                &effects,
                BorrowedMapWeights::Unit,
                values.clone(),
                config(),
                None,
                &mut injected,
            )
            .expect_err("injected allocation failure");
            assert_eq!(error.code, ErrorCode::Allocation, "call {call}");

            let mut undersized = InjectedReservation {
                undersize_at: Some(call),
                ..InjectedReservation::default()
            };
            let error = absorb_with_reservation(
                &topology,
                &effects,
                BorrowedMapWeights::Unit,
                values.clone(),
                config(),
                None,
                &mut undersized,
            )
            .expect_err("undersized allocation");
            assert_eq!(error.code, ErrorCode::Allocation, "call {call}");
        }
    }

    #[test]
    fn recovery_output_capacity_overflow_is_an_allocation_error() {
        let error = fallible_filled(
            usize::MAX,
            0.0_f64,
            "injected categorical recovery output overflow",
        )
        .expect_err("oversized recovery output");
        assert_eq!(error.code, ErrorCode::Allocation);
    }
}

import json
from pathlib import Path
import sys

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route

specs = [dict(weight='aw', k=10, threads=1, count=1, intercept=True, cases=['robust_outputs']),
         dict(weight='fw', k=10, threads=1, count=1, intercept=True, cases=['cluster2_outputs']),
         dict(weight='pw', k=6, threads=1, count=3, intercept=False, cases=['robust_outputs', 'cluster2_outputs']),
         dict(weight='pw', k=6, threads=16, count=3, intercept=False, cases=['robust_outputs', 'cluster2_outputs'])]
plan = dict(schema='ordered-serial-slope-weight-screen-v1', specs=specs, baseline='wr2', candidate='sf1',
    repeats=3, controller_sha256=broad.sha(Path(__file__)), isolation_source_sha256=broad.sha(Path(route.__file__)),
    scope='Serial AW/PW/FW and saved-output checks; unchanged threaded slope-only control. FW uses native control, not ordinary fixest weights.')
output = artifacts / 'sf1-weight-screen-plan1.json'
assert not output.exists()
broad.write(output, plan)
progress = []
for spec in specs:
    name = f"sf1-{spec['weight']}-k{spec['k']}-t{spec['threads']}"
    variants = ['wr2', 'sf1'] + ([] if spec['weight'] == 'fw' else ['fixest'])
    command = [sys.executable, str(repo / 'benchmarks/one_fe_profile/slope_breadth.py'),
        str(artifacts / name), '--artifacts', str(artifacts), '--fixest-archive',
        str(repo / 'target/one-fe-profile-20260919/fixest.tar.gz'), '--variants', *variants,
        '--n', '245760', '--widths', str(spec['k']), '--threads', str(spec['threads']),
        '--cases', *spec['cases'], '--repeats', '3', '--weight-kind', spec['weight'], '--slope-count', str(spec['count'])]
    if not spec['intercept']:
        command.append('--slope-only')
    code, isolation = route.invoke(command, artifacts / (name + '.stdout.txt'))
    complete = artifacts / name / 'complete.json'
    progress.append(dict(spec=spec, root=name, command=command, variants=variants, process_returncode=code,
        timing_isolation=isolation, completion=json.loads(complete.read_text()) if complete.exists() else None))
    broad.write(artifacts / 'sf1-weight-screen-progress1.json', progress)
    print(name, code, isolation['status'], flush=True)
broad.write(artifacts / 'sf1-weight-screen-complete1.json', dict(status='attempts_complete',
    planned=len(specs), attempted=len(progress), plan_sha256=broad.sha(output),
    progress_sha256=broad.sha(artifacts / 'sf1-weight-screen-progress1.json')))

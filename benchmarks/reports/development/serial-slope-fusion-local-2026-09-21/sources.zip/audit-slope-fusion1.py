import hashlib
import json
from pathlib import Path
import statistics

artifacts = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
records = []
identities = {}
for progress_name in ['sf1-screen-progress1.json', 'sf1-weight-screen-progress1.json']:
    for attempt in json.loads((artifacts / progress_name).read_text()):
        root = artifacts / attempt['root']
        plan = json.loads((root / 'plan.json').read_text())
        complete = json.loads((root / 'complete.json').read_text())
        assert complete['status'] == 'pass'
        for index, cell in enumerate(plan['cells']):
            pairs = []
            for rep in range(plan['repeats']):
                paths = {variant: root / 'runs' / f'c{index:03d}-r{rep}-{variant}' / 'result.json'
                    for variant in plan['variants']}
                data = {variant: json.loads(path.read_text()) for variant, path in paths.items()}
                assert all(value['status'] == 'pass' and value['process_returncode'] == 0 and value['sentinel'] for value in data.values())
                assert len({value['input_sha256'] for value in data.values()}) == 1
                assert len({value['sample_sha256'] for value in data.values()}) == 1
                for variant in ['wr2', 'sf1']:
                    identity = data[variant]['measurement_fingerprint']['native']
                    assert identity['abi'] == 'pass'
                    assert identities.setdefault(variant, identity) == identity
                names = ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv']
                if cell['outputs'] != 'none':
                    names.append('outputs.bin')
                equal = {name: sha(paths['wr2'].parent/name) == sha(paths['sf1'].parent/name) for name in names}
                assert all(equal.values()), (root, equal)
                seconds = {variant: value['seconds'] for variant, value in data.items()}
                pairs.append(dict(rep=rep, seconds=seconds, native_ratio=seconds['sf1']/seconds['wr2'],
                    reference_ratio=seconds['sf1']/seconds['fixest'] if 'fixest' in seconds else None,
                    exact_exports=equal, result_sha256={variant: sha(path) for variant, path in paths.items()},
                    peaks={variant: data[variant]['metadata']['fereg_native_allocation_bytes'] for variant in ['wr2', 'sf1']}))
            records.append(dict(root=root.name, index=index, cell=cell,
                timing_isolation=attempt['timing_isolation']['status'], pairs=pairs,
                plan_sha256=sha(root/'plan.json'), completion_sha256=sha(root/'complete.json'),
                median_seconds={variant: statistics.median(pair['seconds'][variant] for pair in pairs) for variant in plan['variants']},
                median_native_ratio=statistics.median(pair['native_ratio'] for pair in pairs)))
assert len(records) == 10
assert all(r['timing_isolation'] == 'no_detected_overlap' for r in records)
output = artifacts / 'sf1-combined-audit1.json'
assert not output.exists()
output.write_text(json.dumps(dict(schema='serial-ordered-slope-fusion-audit-v1', records=records,
    controller_sha256=sha(Path(__file__)), plugins={variant: identity['plugin'] for variant, identity in identities.items()}), indent=2) + '\n')
print('SLOPE_FUSION_AUDIT_PASS', len(records), sum(len(r['pairs']) for r in records)),

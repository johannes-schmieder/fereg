import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import zipfile

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import archive_science
output = repo / 'benchmarks/reports/development/serial-slope-fusion-local-2026-09-21'
roots = [artifacts / name for name in ['sf1-unit-k10-t1', 'sf1-unit-k10-t16', 'sf1-unit-k50-t1', 'sf1-unit-k50-t16',
    'sf1-aw-k10-t1', 'sf1-fw-k10-t1', 'sf1-pw-k6-t1', 'sf1-pw-k6-t16', 'wr2-serial-profile', 'wr2-serial-pw-profile']]
assert all((root / 'complete.json').is_file() for root in roots)
archive_science.archive(roots, output, compact=True, omit_output_arrays=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def portable(data):
    return data.replace(str(repo).encode(), b'<repository>').replace(str(Path.home()).encode(), b'<user-home>') \
        .replace(b'<stata-installation>', b'<stata-installation>').replace(b'<reference-library>', b'<reference-library>')
tables = {'sources': {}, 'checks': {}}
with zipfile.ZipFile(output / 'sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add(name, raw):
        clean = portable(raw)
        bundle.writestr(name, clean)
        tables['sources'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean))
    for variant in ['wr2', 'sf1', 'wr2-profile']:
        path = artifacts / f'identity-{variant}.json'
        identity = json.loads(path.read_text())
        add(path.name, path.read_bytes())
        data = subprocess.check_output(['/opt/homebrew/bin/git', 'archive', identity['base_commit'],
            'Cargo.toml', 'Cargo.lock', 'crates', 'plugin', 'stata', 'tests', 'scripts', 'references.lock.toml'], cwd=repo)
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            base = {entry.name: sha(archive.extractfile(entry).read()) for entry in archive.getmembers() if entry.isfile()}
        changed = []
        for relative, digest in identity['source'].items():
            raw = (artifacts / variant / relative).read_bytes()
            assert sha(raw) == digest
            if base.get(relative) != digest:
                changed.append(relative)
                add(variant + '/' + relative, raw)
        add(variant + '/captured-differences.json', (json.dumps(changed, indent=2) + '\n').encode())
    for name in ['audit_milestone.py', 'audit_outputs.py', 'graph_oracle.py', 'run.py', 'route_development.py']:
        add(name, (repo / 'benchmarks/two_fe_dense' / name).read_bytes())
    add('score-before-broad-isolation.py', subprocess.check_output(['/opt/homebrew/bin/git', 'show', '18447afe:benchmarks/two_fe_dense/score.py'], cwd=repo))
    add('score-with-broad-isolation.py', (repo / 'benchmarks/two_fe_dense/score.py').read_bytes())
    for name in ['sf1-screen1.py', 'sf1-weight-screen1.py', 'audit-slope-fusion1.py', 'archive-slope-fusion1.py']:
        add(name, (artifacts / name).read_bytes())
    for relative in ['one_fe_profile/slopes.py', 'one_fe_profile/slope_breadth.py', 'one_fe_profile/run.py',
                     'one_fe_profile/slope_instrument.py', 'one_fe_optimization/completion_profile.py',
                     'one_fe_optimization/statistics_profile.py', 'one_fe_optimization/build.py', 'systematic/generate.py']:
        add(relative, (repo / 'benchmarks' / relative).read_bytes())
with zipfile.ZipFile(output / 'checks.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    def add_check(name, raw, **extra):
        clean = portable(raw)
        bundle.writestr(name, clean)
        tables['checks'][name] = dict(original_sha256=sha(raw), portable_sha256=sha(clean), **extra)
    for name in ['sf1-slope-tests1.txt', 'sf1-screen-plan1.json', 'sf1-screen-progress1.json', 'sf1-screen-complete1.json',
                 'sf1-weight-screen-plan1.json', 'sf1-weight-screen-progress1.json', 'sf1-weight-screen-complete1.json',
                 'sf1-combined-audit1.json', 'sf1-combined-audit1.txt', 'sf1-screen-score1.json', 'sf1-weight-screen-score1.json']:
        add_check(name, (artifacts / name).read_bytes())
    for root in roots[-2:]:
        for path in sorted((root / 'runs').glob('*/stderr.txt')):
            raw = path.read_bytes()
            trace = ('\n'.join(line for line in raw.decode().splitlines() if line.startswith(('FEREG_PHASE|', 'SLOPE_PROFILE|'))) + '\n').encode()
            add_check(root.name + '/' + path.parent.name + '/native-trace.txt', trace, original_stream_sha256=sha(raw),
                      extraction='Only native phase/slope profile lines, in original order.')
for name, table in tables.items():
    (output / (name + '-hashes.json')).write_text(json.dumps(table, indent=2) + '\n')
print('SERIAL_SLOPE_FUSION_SUPPLEMENTS_COMPLETE', flush=True)

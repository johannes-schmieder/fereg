import json
from pathlib import Path
import sys

repo = Path(__file__).resolve().parents[2]
artifacts = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route

specs = [(k, threads) for k in [10, 50] for threads in [1, 16]]
plan = dict(schema='ordered-serial-slope-screen-v1', specs=specs, baseline='wr2', candidate='sf1',
    variants=['wr2', 'sf1', 'fixest'], repeats=3, controller_sha256=broad.sha(Path(__file__)),
    isolation_source_sha256=broad.sha(Path(route.__file__)),
    scope='Isolated serial ordered-group pass fusion; paired screen before wider weights/output checks.')
output = artifacts / 'sf1-screen-plan1.json'
assert not output.exists()
broad.write(output, plan)
progress = []
for k, threads in specs:
    name = f'sf1-unit-k{k}-t{threads}'
    command = [sys.executable, str(repo / 'benchmarks/one_fe_profile/slope_breadth.py'),
        str(artifacts / name), '--artifacts', str(artifacts), '--fixest-archive',
        str(repo / 'target/one-fe-profile-20260919/fixest.tar.gz'), '--variants', *plan['variants'],
        '--n', '245760', '--widths', str(k), '--threads', str(threads), '--cases', 'iid', '--repeats', '3']
    code, isolation = route.invoke(command, artifacts / (name + '.stdout.txt'))
    complete = artifacts / name / 'complete.json'
    progress.append(dict(k=k, threads=threads, root=name, command=command, process_returncode=code,
        timing_isolation=isolation, completion=json.loads(complete.read_text()) if complete.exists() else None))
    broad.write(artifacts / 'sf1-screen-progress1.json', progress)
    print(name, code, isolation['status'], flush=True)
broad.write(artifacts / 'sf1-screen-complete1.json', dict(status='attempts_complete',
    planned=len(specs), attempted=len(progress), plan_sha256=broad.sha(output),
    progress_sha256=broad.sha(artifacts / 'sf1-screen-progress1.json')))

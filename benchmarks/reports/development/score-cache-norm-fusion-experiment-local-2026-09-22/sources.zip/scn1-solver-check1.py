import csv, hashlib, json
from pathlib import Path
art = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
records = []
for variant in ['scn1']:
    for block in ['screen', 'confirm1', 'confirm2']:
        audit_path = art / f'{variant}-{block}-audit1.json'
        audit = json.loads(audit_path.read_text())
        for record in audit['records']:
            for pair in record['pairs']:
                paths = {v: art / record['root'] / 'runs' / f"c{record['index']:03d}-r{pair['rep']}-{v}" / 'fereg_solver.csv'
                    for v in ['dtk1', variant]}
                fields = {v: {(int(r['row']), int(r['column'])): r['value'].strip()
                    for r in csv.DictReader(path.open()) if int(r['column']) not in [9, 10]} for v, path in paths.items()}
                assert fields['dtk1'] == fields[variant], (variant, block, record['root'], pair['rep'])
                assert len(fields[variant]) == 28
                records.append(dict(variant=variant, root=record['root'], cell=record['index'], repeat=pair['rep'],
                    exact_non_timing_fields=True, audit_sha256=sha(audit_path),
                    solver_sha256={v: sha(p) for v, p in paths.items()}))
out = art / 'scn1-solver-check1.json'; assert not out.exists()
out.write_text(json.dumps(dict(schema='score-cache-norm-fusion-solver-stability-v1', status='pass',
    source_sha256=sha(Path(__file__)), excluded_timing_columns=[9, 10], records=records), indent=2)+'\n')
print('SCORE_CACHE_NORM_FUSION_SOLVER_STABILITY_PASS',len(records))

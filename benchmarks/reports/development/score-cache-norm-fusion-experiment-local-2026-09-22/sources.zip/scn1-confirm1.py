import json, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route
block = int(sys.argv[1]); assert block in [1, 2]
specs = [
    dict(weight='aw', k=10, threads=1, count=1, intercept=True, cases=['robust_outputs', 'cluster2_outputs']),
    dict(weight='pw', k=6, threads=1, count=3, intercept=False, cases=['robust_outputs', 'cluster2_outputs', 'robust_saved']),
    dict(weight='none', k=10, threads=1, count=1, intercept=True, cases=['robust_outputs']),
    dict(weight='fw', k=10, threads=1, count=1, intercept=True, cases=['robust_outputs']),
]

names = [f"scn1-confirm{block}-{s['weight']}-k{s['k']}-t{s['threads']}" for s in specs]
assert all(not (art / name).exists() for name in names)
plan_path = art / f'scn1-confirm{block}-plan1.json'
assert not plan_path.exists()
plan = dict(schema='score-cache-norm-fusion-confirmation-v1', specs=specs, baseline='dtk1', candidate='scn1', repeats=5,
    controller_sha256=broad.sha(Path(__file__)), isolation_source_sha256=broad.sha(Path(route.__file__)),
    identities={v: broad.sha(art / f'identity-{v}.json') for v in ['dtk1', 'scn1']},
    scope='Fixed dimensions one through sixteen remove repeated dense triangle address/bound bookkeeping. Production/certificate operands, accumulation order, fixed blocks, independent reverse certificate merge and workspaces remain unchanged. Larger dimensions retain the generic loop. This shared kernel is also covered by focused PPML science fixtures. Ordinary fixest is excluded for FW inference.')
broad.write(plan_path, plan)
progress = []
for spec, name in zip(specs, names):
    variants = ['dtk1', 'scn1']
    command = [sys.executable, str(repo / 'benchmarks/one_fe_profile/slope_breadth.py'), str(art / name),
        '--artifacts', str(art), '--fixest-archive', str(repo / 'target/one-fe-profile-20260919/fixest.tar.gz'),
        '--variants', *variants, '--n', '245760', '--widths', str(spec['k']), '--threads', str(spec['threads']),
        '--cases', *spec['cases'], '--repeats', '5', '--weight-kind', spec['weight'], '--slope-count', str(spec['count'])]
    if not spec['intercept']: command.append('--slope-only')
    code, isolation = route.invoke(command, art / (name + '.stdout.txt'))
    complete = art / name / 'complete.json'
    progress.append(dict(spec=spec, root=name, command=command, variants=variants, process_returncode=code,
        timing_isolation=isolation, completion=json.loads(complete.read_text()) if complete.exists() else None))
    broad.write(art / f'scn1-confirm{block}-progress1.json', progress)
    print(name, code, isolation['status'], flush=True)
    if code: break
broad.write(art / f'scn1-confirm{block}-complete1.json', dict(status='attempts_complete', planned=len(specs),
    attempted=len(progress), plan_sha256=broad.sha(plan_path), progress_sha256=broad.sha(art / f'scn1-confirm{block}-progress1.json')))

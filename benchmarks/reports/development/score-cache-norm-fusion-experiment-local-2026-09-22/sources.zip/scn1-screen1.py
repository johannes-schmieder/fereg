import json, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
sys.path.insert(0, str(repo / 'benchmarks/two_fe_dense'))
import broad
import route_development as route
specs = [
    dict(weight='aw', k=10, threads=1, count=1, intercept=True, cases=['robust_outputs', 'cluster2_outputs', 'robust']),
    dict(weight='pw', k=6, threads=1, count=3, intercept=False, cases=['robust_outputs', 'cluster2_outputs', 'robust_saved']),
    dict(weight='fw', k=10, threads=1, count=1, intercept=True, cases=['robust_outputs']),
    dict(weight='none', k=10, threads=1, count=1, intercept=True, cases=['robust_outputs', 'iid']),
    dict(weight='pw', k=6, threads=16, count=3, intercept=False, cases=['robust_outputs', 'cluster2_outputs']),
    dict(weight='aw', k=50, threads=1, count=1, intercept=True, cases=['robust_outputs']),
    dict(weight='pw', k=6, threads=8, count=3, intercept=False, cases=['robust_outputs', 'cluster2_outputs']),
    dict(weight='aw', k=10, threads=16, count=1, intercept=True, cases=['robust_outputs']),
    dict(weight='aw', k=50, threads=16, count=1, intercept=True, cases=['robust_outputs']),
]
names = [f"scn1-{s['weight']}-k{s['k']}-t{s['threads']}" for s in specs]
assert all(not (art / name).exists() for name in names)
plan_path = art / 'scn1-screen-plan1.json'
assert not plan_path.exists()
plan = dict(schema='score-cache-norm-fusion-screen-v1', specs=specs, baseline='dtk1', candidate='scn1', repeats=3,
    controller_sha256=broad.sha(Path(__file__)), isolation_source_sha256=broad.sha(Path(route.__file__)),
    identities={v: broad.sha(art / f'identity-{v}.json') for v in ['dtk1', 'scn1']},
    scope='Successful serial cached-slope inference may compute fresh max-normalized within norms while copying packed score rows and accumulating means. Preserve each norm recurrence and row order, outcome and omitted-intercept coordinates, fixed mean blocks, independent certification and cache budget. Raw absorption norms are never rescaled or substituted. Wider, threaded, unit cached-norm, rejected cache, explicit/shared and strided paths retain their eligibility. Ordinary fixest is excluded for FW inference.')
broad.write(plan_path, plan)
progress = []
for spec, name in zip(specs, names):
    variants = ['dtk1', 'scn1'] + ([] if spec['weight'] == 'fw' else ['fixest'])
    command = [sys.executable, str(repo / 'benchmarks/one_fe_profile/slope_breadth.py'), str(art / name),
        '--artifacts', str(art), '--fixest-archive', str(repo / 'target/one-fe-profile-20260919/fixest.tar.gz'),
        '--variants', *variants, '--n', '245760', '--widths', str(spec['k']), '--threads', str(spec['threads']),
        '--cases', *spec['cases'], '--repeats', '3', '--weight-kind', spec['weight'], '--slope-count', str(spec['count'])]
    if not spec['intercept']: command.append('--slope-only')
    code, isolation = route.invoke(command, art / (name + '.stdout.txt'))
    complete = art / name / 'complete.json'
    progress.append(dict(spec=spec, root=name, command=command, variants=variants, process_returncode=code,
        timing_isolation=isolation, completion=json.loads(complete.read_text()) if complete.exists() else None))
    broad.write(art / 'scn1-screen-progress1.json', progress)
    print(name, code, isolation['status'], flush=True)
    if code: break
broad.write(art / 'scn1-screen-complete1.json', dict(status='attempts_complete', planned=len(specs),
    attempted=len(progress), plan_sha256=broad.sha(plan_path), progress_sha256=broad.sha(art / 'scn1-screen-progress1.json')))

import hashlib, json
from pathlib import Path
import numpy as np
art = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
records = []
for label in ['aw-k10', 'pw-k6', 'aw-k50']:
    root = art / f'sn1-profile-{label}-1'
    phases = {}; results = {}; exact = {}
    for variant in ['owf1', 'sn1']:
        run = root / 'runs' / f'c000-r0-{variant}'
        result = json.loads((run / 'result.json').read_text())
        assert result['status'] == 'pass' and result['sentinel'] and result['process_returncode'] == 0
        identity = json.loads((art / f'identity-{variant}.json').read_text())
        assert result['measurement_fingerprint']['native'] == identity
        lines = [line for line in (run / 'stderr.txt').read_text().splitlines() if line.startswith('FEREG_PHASE|fit|')]
        assert len(lines) == 2
        phases[variant] = {k: float(v) for k, v in (part.split('=') for part in lines[-1].split('|')[2:])}
        results[variant] = dict(result_sha256=sha(run / 'result.json'), stderr_sha256=sha(run / 'stderr.txt'))
    a = root / 'runs/c000-r0-owf1'; b = root / 'runs/c000-r0-sn1'
    for name in ['coefficients.csv', 'covariance.csv', 'b.csv', 'V.csv', 'fereg_fit.csv', 'fereg_dof.csv', 'outputs.bin']:
        exact[name] = sha(a / name) == sha(b / name)
    assert all(exact.values())
    records.append(dict(root=root.name, status='pass', exact=exact, phases=phases, results=results))
out = art / 'sn1-profile-check1.json'
assert not out.exists()
out.write_text(json.dumps(dict(schema='slope-normalized-norm-phase-check-v1', source_sha256=sha(Path(__file__)),
    status='pass', records=records, limitation='Single diagnostic traces; not headline timing evidence.'), indent=2) + '\n')
print('SLOPE_NORM_PROFILE_CHECK_PASS', len(records))

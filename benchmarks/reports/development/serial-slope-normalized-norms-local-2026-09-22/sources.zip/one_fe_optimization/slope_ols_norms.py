"""Captured-source experiment: hand off freshly computed OLS weight-scale norms."""
from pathlib import Path


def instrument(source):
    path = source / 'crates/fereg-core/src/fe/single_slope.rs'
    text = path.read_text()

    def replace(before, after):
        nonlocal text
        assert text.count(before) == 1, before
        text = text.replace(before, after)

    replace('    absorption_bytes: u128,', '    absorption_bytes: u128,\n    ols_norm_scale: Option<f64>,')
    replace('            absorption_bytes,\n', '            absorption_bytes,\n            ols_norm_scale: None,\n')
    replace('''        // This projector retains the generic slope solver's raw-weight
        // arithmetic. OLS's norm cache uses weights divided by their maximum;
        // the two scales coincide only for the unit-weight handoff.''', '''        // Raw-weight references remain authoritative for projection checks.
        // Supplied-weight OLS norms are computed independently in its own
        // normalized frame during eligible serial reconstruction.''')
    replace('    pub(crate) fn absorb(', '''    // The caller owns an immutable, already validated OLS weight view. Compute
    // its normalized norms from each residual value; never rescale a raw norm.
    pub(crate) fn enable_ols_norms(&mut self, scale: f64, budget: Option<FeSolverMemoryBudget>) -> Result<bool> {
        if !self.serial_ordered || rayon::current_num_threads() != 1
            || !matches!(self.weights, BorrowedMapWeights::Provided(_)) {
            return Ok(false);
        }
        if !scale.is_finite() || scale <= 0.0 || self.ols_norm_scale.is_some() {
            return Err(invalid());
        }
        let extra = if scale == 1.0 { 0 } else { self.max_rhs as u128 * 8 };
        let admitted = self.absorption_bytes.checked_add(extra).ok_or_else(allocation)?;
        if budget.is_some_and(|b| !b.fits(admitted)) { return Ok(false); }
        self.absorption_bytes = admitted;
        self.ols_norm_scale = Some(scale);
        Ok(true)
    }

    pub(crate) fn absorb(''')
    replace('                        references,\n                        certificate,', '                        references,\n                        None,\n                        certificate,')
    replace('        let mut coefficients = filled(self.groups.len() * channels * rhs, 0.0)?;', '''        let serial_ols_norms = self.serial_ordered && rayon::current_num_threads() == 1
            && self.ols_norm_scale.is_some_and(|scale| scale != 1.0);
        let mut ols_norms = serial_ols_norms.then(|| filled(rhs, 0.0)).transpose()?;
        let mut coefficients = filled(self.groups.len() * channels * rhs, 0.0)?;''')
    replace('            + bytes(&references)\n            + 5 * rhs as u128 * 8;', '''            + bytes(&references)
            + ols_norms.as_ref().map_or(0, bytes)
            + 5 * rhs as u128 * 8;''')
    replace('self.project_serial_ordered::<16, 64>(&original, &mut result, &mut coefficients)?',
            'self.project_serial_ordered::<16, 64>(&original, &mut result, &mut coefficients, ols_norms.as_deref_mut())?')
    replace('                    &original, &mut result, &mut coefficients)?',
            '                    &original, &mut result, &mut coefficients, ols_norms.as_deref_mut())?')
    replace('            residual_norms,\n            certificate,', '            residual_norms,\n            ols_norms,\n            certificate,')
    replace('        residual_norms: Vec<f64>,\n        certificate: FeCertificate,',
            '        residual_norms: Vec<f64>,\n        ols_norms: Option<Vec<f64>>,\n        certificate: FeCertificate,')
    replace('        let certified = if matches!(self.weights, BorrowedMapWeights::Unit) {', '''        let certified = if let Some(norms) = ols_norms {
            certified.with_residual_norms(norms)?
        } else if matches!(self.weights, BorrowedMapWeights::Unit)
            || (self.ols_norm_scale == Some(1.0) && self.serial_ordered && rayon::current_num_threads() == 1) {''')
    replace('        right_scales: &mut [f64],\n    ) -> Result<Vec<f64>> {',
            '        right_scales: &mut [f64],\n        mut ols_norms: Option<&mut [f64]>,\n    ) -> Result<Vec<f64>> {')
    replace('        let mut norm_sums = [1.0; WIDTH];', '''        let mut norm_sums = [1.0; WIDTH];
        let mut ols_scales = [0.0; WIDTH];
        let mut ols_sums = [1.0; WIDTH];
        let ols_scale = ols_norms.as_ref().map(|_| self.ols_norm_scale.ok_or_else(invalid)).transpose()?;
        if ols_norms.as_ref().is_some_and(|norms| norms.len() != rhs) { return Err(invalid()); }''')
    replace('                for (column, (fitted, &value)) in target.iter_mut()', '''                let ols_root = ols_scale.map(|scale| (weight(self.weights, row) / scale).sqrt());
                if ols_root.is_some_and(|root| !root.is_finite() || root <= 0.0) { return Err(invalid()); }
                for (column, (fitted, &value)) in target.iter_mut()''')
    replace('                    group_scales[column] = group_scales[column].max(weighted.abs());', '''                    group_scales[column] = group_scales[column].max(weighted.abs());
                    if let Some(root) = ols_root {
                        let normalized = root * *fitted;
                        if !normalized.is_finite() { return Err(invalid()); }
                        update_scaled_sum_of_squares(normalized, &mut ols_scales[column], &mut ols_sums[column]);
                    }''')
    replace('            if !norms[column].is_finite() { return Err(invalid()); }\n        }\n        Ok(norms)', '''            if !norms[column].is_finite() { return Err(invalid()); }
            if let Some(ols) = ols_norms.as_deref_mut() {
                ols[column] = if ols_scales[column] == 0.0 { 0.0 }
                    else { ols_scales[column] * ols_sums[column].sqrt() };
                if !ols[column].is_finite() { return Err(invalid()); }
            }
        }
        Ok(norms)''')
    assert text.count('mod tests {') == 1
    text = text.replace('mod tests {', '''mod tests {
    #[test]
    fn normalized_slope_norm_extra_bank_obeys_exact_budget() {
        let pool = rayon::ThreadPoolBuilder::new().num_threads(1).build().unwrap();
        pool.install(|| {
            let n = 73; let levels = 7; let rhs = 8;
            let effect = EffectTerm::new((0..n).map(|r| (r * levels / n) as u32).collect(),
                levels, true, vec![(0..n).map(|r| (r as f64 * 0.17).sin()).collect()]).unwrap();
            let partition = BorrowedInterceptEffect::new(effect.codes(), levels, effect.level_index()).unwrap();
            let weights = vec![2.0; n];
            let view = || CategoricalAbsorbedEffectView::new(true, effect.slopes().iter().map(Vec::as_slice).collect()).unwrap();
            for short in [false, true] {
                let mut peak = SolverWorkspacePeak::ZERO;
                let mut absorber = SingleSlopeAbsorber::build(partition, view(),
                    BorrowedMapWeights::Provided(&weights), rhs, None, &mut peak).unwrap().unwrap();
                let original = absorber.absorption_bytes;
                let parent = 137;
                let budget = FeSolverMemoryBudget { execution_bytes: parent,
                    usable_bytes: parent + original + rhs as u128 * 8 - u128::from(short) };
                assert_eq!(absorber.enable_ols_norms(2.0, Some(budget)).unwrap(), !short);
                assert_eq!(absorber.ols_norm_scale, if short { None } else { Some(2.0) });
                assert_eq!(absorber.absorption_bytes, original + if short { 0 } else { rhs as u128 * 8 });
                let input = DenseMatrix::from_columns(&(0..rhs).map(|c| (0..n)
                    .map(|r| ((r * (c + 3)) as f64 * 0.019).cos()).collect()).collect::<Vec<_>>()).unwrap();
                let result = absorber.absorb(input, 1e-8, Some(budget), None, false).unwrap();
                let SingleSlopeAttempt::Certified(mut result) = result else { panic!("budget changed existing certification"); };
                assert_eq!(result.take_residual_norms().len(), if short { 0 } else { rhs });
                assert!(result.report().solver_workspace_peak.bytes().unwrap() as u128 <= budget.usable_bytes - parent);
            }
        });
    }
''')
    path.write_text(text)
    path = source / 'crates/fereg-core/src/ols/prepared_fit.rs'
    text = path.read_text()
    anchor = '''    let mut cmg = build_fit_fe_absorber_with_one_fe_reuse(prepared, weights.borrowed(), config,
        !perturbations.one_fe_borrow_reuse_disabled, true)?;'''
    assert text.count(anchor) == 1
    text = text.replace(anchor, anchor + '''
    if config.allow_final_fe_recovery {
        if let Some(session) = cmg.single_slope.as_mut() {
            session.enable_ols_norms(weights.raw_scale, config.absorb.solver_memory_budget)?;
        }
    }
''')
    assert text.count('mod tests {') == 1
    text = text.replace('mod tests {', 'mod tests {\n' + Path(__file__).with_name('slope_ols_norms_tests.rs').read_text())
    path.write_text(text)

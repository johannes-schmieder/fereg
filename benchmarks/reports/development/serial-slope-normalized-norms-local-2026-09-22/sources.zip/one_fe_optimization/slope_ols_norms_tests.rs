    #[test]
    fn serial_slope_norm_handoff_requires_the_actual_serial_pool() {
        use crate::fe::{BorrowedInterceptEffect, CategoricalAbsorbedEffectView, EffectTerm, SingleSlopeAbsorber, SingleSlopeAttempt};
        let serial = rayon::ThreadPoolBuilder::new().num_threads(1).build().unwrap();
        let parallel = rayon::ThreadPoolBuilder::new().num_threads(4).build().unwrap();
        let n = 1031;
        let levels = 73;
        let rhs = 8;
        let effect = EffectTerm::new((0..n).map(|r| (r * levels / n) as u32).collect(), levels, true,
            vec![(0..n).map(|r| (r as f64 * 0.13).sin()).collect()]).unwrap();
        let partition = BorrowedInterceptEffect::new(effect.codes(), levels, effect.level_index()).unwrap();
        let input = DenseMatrix::from_columns(&(0..rhs).map(|c| (0..n)
            .map(|r| ((r * (c + 3)) as f64 * 0.019).cos()).collect()).collect::<Vec<_>>()).unwrap();
        for scale in [1.0, 5.0] {
            let weights = vec![scale; n];
            let view = || CategoricalAbsorbedEffectView::new(true,
                effect.slopes().iter().map(Vec::as_slice).collect()).unwrap();
            let (mut original, mut changed) = serial.install(|| {
                let mut peak = crate::memory::SolverWorkspacePeak::ZERO;
                let original = SingleSlopeAbsorber::build(partition, view(), BorrowedMapWeights::Provided(&weights), rhs, None, &mut peak).unwrap().unwrap();
                let mut changed = SingleSlopeAbsorber::build(partition, view(), BorrowedMapWeights::Provided(&weights), rhs, None, &mut peak).unwrap().unwrap();
                assert!(changed.enable_ols_norms(scale, None).unwrap());
                (original, changed)
            });
            parallel.install(|| {
                for check_input in [false, true] {
                    let a = original.absorb(input.clone(), 1e-8, None, None, check_input).unwrap();
                    let b = changed.absorb(input.clone(), 1e-8, None, None, check_input).unwrap();
                    match (a, b) {
                        (SingleSlopeAttempt::Certified(mut a), SingleSlopeAttempt::Certified(mut b)) => {
                            assert_eq!(a.residualized(), b.residualized());
                            assert_eq!(a.report().certificate, b.report().certificate);
                            assert!(a.take_residual_norms().is_empty());
                            assert!(b.take_residual_norms().is_empty());
                        },
                        _ => panic!("pool change altered a certified slope fit"),
                    }
                }
            });
        }
    }

    #[test]
    fn serial_slope_ols_norm_handoff_matches_fresh_normalized_scans() {
        use crate::fe::{BorrowedInterceptEffect, CategoricalAbsorbedEffectView, EffectTerm, SingleSlopeAbsorber, SingleSlopeAttempt};
        for threads in [1, 4] {
            let pool = rayon::ThreadPoolBuilder::new().num_threads(threads).build().unwrap();
            pool.install(|| {
                for shuffled in [false, true] {
                    for intercept in [false, true] {
                        for slope_count in [1, 3] {
                            for rhs in [1, 8, 52] {
                                for scale_case in 0..5 {
                                    let n = 1031;
                                    let levels = 73;
                                    let row_at = |r: usize| if shuffled { r * 37 % n } else { r };
                                    let codes: Vec<_> = (0..n).map(|r| (row_at(r) * levels / n) as u32).collect();
                                    let slopes: Vec<Vec<_>> = (0..slope_count).map(|c| (0..n).map(|r| {
                                        let r = row_at(r);
                                        if c == 2 && r * levels / n % 3 == 0 { 0.0 }
                                        else { ((r * (13 + c * 4)) as f64 * 0.13).sin() }
                                    }).collect()).collect();
                                    let effect = EffectTerm::new(codes, levels, intercept, slopes).unwrap();
                                    let partition = BorrowedInterceptEffect::new(effect.codes(), levels, effect.level_index()).unwrap();
                                    let weights: Vec<_> = (0..n).map(|r| match scale_case {
                                        0 => 128.0,
                                        1 => (1 + row_at(r) % 5) as f64 / 5.0,
                                        2 => 10.0_f64.powi((row_at(r) % 13) as i32 - 6),
                                        3 => 1e-100 * (1 + row_at(r) % 5) as f64,
                                        _ => 1e100 * (1 + row_at(r) % 5) as f64,
                                    }).collect();
                                    let raw_scale = weights.iter().copied().fold(0.0_f64, f64::max);
                                    let borrowed = BorrowedMapWeights::Provided(&weights);
                                    let normalized = NormalizedWeights { values: Some(&weights), raw_scale, kind: Some(WeightKind::Analytic) };
                                    let view = || CategoricalAbsorbedEffectView::new(intercept,
                                        effect.slopes().iter().map(Vec::as_slice).collect()).unwrap();
                                    let mut peak = crate::memory::SolverWorkspacePeak::ZERO;
                                    let mut original = SingleSlopeAbsorber::build(partition, view(), borrowed, rhs, None, &mut peak).unwrap().unwrap();
                                    let mut changed = SingleSlopeAbsorber::build(partition, view(), borrowed, rhs, None, &mut peak).unwrap().unwrap();
                                    let enabled = changed.enable_ols_norms(raw_scale, None).unwrap();
                                    assert_eq!(enabled, threads == 1 && !shuffled);
                                    let input = DenseMatrix::from_columns(&(0..rhs).map(|c| (0..n)
                                        .map(|r| ((row_at(r) * (c + 3)) as f64 * 0.019).cos())
                                        .collect()).collect::<Vec<_>>()).unwrap();
                                    let a = original.absorb(input.clone(), 1e-8, None, None, false).unwrap();
                                    let b = changed.absorb(input.clone(), 1e-8, None, None, false).unwrap();
                                    match (a, b) {
                                        (SingleSlopeAttempt::Certified(mut a), SingleSlopeAttempt::Certified(mut b)) => {
                                            assert_eq!(a.residualized(), b.residualized());
                                            assert_eq!(a.report().certificate, b.report().certificate);
                                            assert!(a.take_residual_norms().is_empty());
                                            let norms = b.take_residual_norms();
                                            if enabled {
                                                assert_eq!(norms.len(), rhs);
                                                for (column, actual) in norms.into_iter().enumerate() {
                                                    let expected = weighted_matrix_column_norm(b.residualized(), column, normalized).unwrap();
                                                    assert_eq!(actual.to_bits(), expected.to_bits());
                                                }
                                            } else { assert!(norms.is_empty()); }
                                            let old_final = original.absorb(a.residualized().clone(), 1e-8, None, None, true).unwrap();
                                            let new_final = changed.absorb(b.residualized().clone(), 1e-8, None, None, true).unwrap();
                                            match (old_final, new_final) {
                                                (SingleSlopeAttempt::Certified(a), SingleSlopeAttempt::Certified(mut b)) => {
                                                    assert_eq!(a.residualized(), b.residualized());
                                                    assert_eq!(a.report().certificate, b.report().certificate);
                                                    for (column, actual) in b.take_residual_norms().into_iter().enumerate() {
                                                        let expected = weighted_matrix_column_norm(b.residualized(), column, normalized).unwrap();
                                                        assert_eq!(actual.to_bits(), expected.to_bits());
                                                    }
                                                },
                                                _ => panic!("fresh final check changed acceptance"),
                                            }
                                        },
                                        (SingleSlopeAttempt::Rejected { original: a, iterations: ai, .. },
                                         SingleSlopeAttempt::Rejected { original: b, iterations: bi, .. }) => {
                                            assert_eq!(a, input);assert_eq!(a, b);assert_eq!(ai, bi);
                                        },
                                        _ => panic!("normalized norm handoff changed certification or fallback"),
                                    }
                                }
                            }
                        }
                    }
                }
            });
        }
    }

import hashlib, json, subprocess, zipfile
from pathlib import Path
repo = Path(__file__).resolve().parents[2]
art = repo / 'target/ols-next-20260921'
report = repo / 'benchmarks/reports/development/serial-slope-normalized-norms-local-2026-09-22'
def sha(raw): return hashlib.sha256(raw).hexdigest()
assert json.loads((report / 'integrity.json').read_text())['status'] == 'pass'
table = json.loads((report / 'sources-hashes.json').read_text())
names = ['one_fe_optimization/build.py', 'one_fe_optimization/slope_ols_norms.py', 'one_fe_optimization/slope_ols_norms_tests.rs']
before = {}
for name in names:
    before[name] = sha((repo / 'benchmarks' / name).read_bytes())
    assert before[name] == table[name]['original_sha256']
baseline = json.loads((art / 'identity-owf1.json').read_text())
native_names = ['crates/fereg-core/src/fe/' + name for name in ['borrowed_map.rs', 'cmg.rs', 'lsmr_batch.rs', 'single_slope.rs']]
native_names += ['crates/fereg-core/src/memory.rs', 'crates/fereg-core/src/ols/prepared_fit.rs', 'crates/fereg-core/src/ols/prepared_rhs.rs']
native = {name: sha((repo / name).read_bytes()) for name in native_names}
assert all(digest == baseline['source'][name] for name, digest in native.items())
original_build = subprocess.check_output(['git', 'show', 'HEAD:benchmarks/one_fe_optimization/build.py'], cwd=repo)
(repo / 'benchmarks/one_fe_optimization/build.py').write_bytes(original_build)
for name in names[1:]: (repo / 'benchmarks' / name).unlink()
assert all(sha((repo / name).read_bytes()) == digest for name, digest in native.items())
record = dict(schema='slope-norm-experiment-source-disposition-v1', status='restored',
    decision='Do not adopt the broad handoff: small AW gains and repeated PW regressions do not close the serial gap.',
    archived_active_source_sha256=before, restored_builder_sha256=sha(original_build),
    unchanged_native_files_sha256=native, controller_sha256=sha(Path(__file__).read_bytes()))
(report / 'source-disposition.json').write_text(json.dumps(record, indent=2) + '\n')
with zipfile.ZipFile(report / 'source-disposition.zip', 'x', zipfile.ZIP_DEFLATED) as bundle:
    bundle.writestr('restore.py', Path(__file__).read_bytes())
print('SLOPE_NORM_ACTIVE_SOURCE_RESTORED')
